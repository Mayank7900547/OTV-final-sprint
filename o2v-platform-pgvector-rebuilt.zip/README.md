# O2V AI Platform — Sprint 1 + Sprint 2

## What this is (and isn't) yet

This is the foundation and first real capability of a document
intelligence platform that will eventually discover corporate documents,
extract structured organizational intelligence (starting with McKinsey's
Organize-to-Value framework), and build a versioned Ground Truth Dataset.

- **Sprint 1** delivered no AI capability at all, by design: project
  structure, configuration/logging, a working database, and two
  registries (Company, Framework).
- **Sprint 2** adds the **Document Discovery Service** — given a company,
  automatically find and register its official documents (Annual
  Reports, 10-Ks, ESG/Sustainability Reports, Code of Conduct, Investor
  Relations pages, Proxy Statements, etc.). **Still no AI, no LLM, no
  LangChain, no downloading, and no parsing of document content** —
  Sprint 2 only discovers and validates *where* documents live, via
  deterministic rule-based methods: SEC EDGAR's public API and
  keyword/sitemap-based matching against a company's own website.

Explicitly NOT yet in this codebase: downloading document content,
PDF/HTML content parsing, chunking, embeddings, vector retrieval, LLM
extraction, or validation of extracted claims. Those are Sprint 3+ (see
`docs/` for the full platform architecture and milestone roadmap).

## Project Philosophy

Four decisions shape everything in this codebase:

1. **Frameworks are data, not code.** The Framework Registry schema (see
   `data/frameworks/o2v.yaml` and `src/registry/framework_loader.py`) is
   built so that adding a new framework — O2V's remaining components, COSO,
   Balanced Scorecard, ESG, ISO 27001, whatever comes next — is *writing a
   YAML file and running one CLI command*. If adding a framework ever
   requires a Python change, that's a bug in this design, not an
   acceptable cost of extensibility.

2. **Thin CLI, fat services.** Every CLI command in `src/cli/main.py` is a
   few lines: open a session, call a service function, print the result.
   All real logic lives in `src/services/`, `src/registry/`, and (from
   Sprint 2) `src/discovery/`. This is what lets a future REST API reuse
   this exact logic without duplicating it.

3. **Fail loud, fail early.** CSV imports validate every row before
   writing any row. Framework YAML files are strictly validated with
   specific error messages. A single company's discovery failure never
   silently corrupts or blocks the rest of a batch run — it's caught,
   logged, and reported per-company (see `discover all`).

4. **Allowlist, not blocklist (Sprint 2).** Document URL validation
   (`src/discovery/url_validator.py`) accepts only a company's own
   domain/subdomains plus a short list of trusted external sources (SEC
   EDGAR). Everything else — Wikipedia, blogs, news sites, forums, GitHub
   mirrors — is rejected by DEFAULT, not because any of them are named in
   a blocklist. This is a structurally stronger guarantee than trying to
   enumerate every bad source on the internet.

## Folder Structure

```
o2v-platform/
├── src/
│   ├── core/          # domain constants + exception hierarchy, no external deps
│   ├── config/        # settings (env vars) + logging configuration
│   ├── database/      # SQLAlchemy engine, session management, schema init
│   ├── models/        # ORM models: Company, Framework, DocumentRegistry
│   ├── services/       # business logic: Company/Framework/Document services + DocumentDiscoveryService
│   ├── registry/       # framework YAML loader/validator (the "no code changes" mechanism)
│   ├── discovery/       # Sprint 2: SEC EDGAR client, sitemap crawler, URL validator, category classifier, HTTP client
│   ├── utils/          # path resolution helpers
│   └── cli/            # Typer CLI entry point
├── data/
│   ├── companies/      # company CSV files (sample provided)
│   ├── frameworks/      # framework YAML definitions (o2v.yaml provided)
│   ├── raw/             # placeholder for Sprint 3 (raw downloaded document content)
│   └── processed/       # placeholder for Sprint 3+ (parsed/chunked output)
├── docs/                # architecture docs
├── tests/               # pytest suite — pure-logic tests + real-DB integration tests (see Testing below)
├── logs/                # rotating log files (created at runtime)
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

## Installation (local, without Docker)

Requires Python 3.11+ and a running PostgreSQL instance.

```bash
# 1. Clone and enter the project
cd o2v-platform

# 2. Create a virtual environment
python3.11 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your local Postgres credentials

# 5. Initialize the platform (creates data/log dirs + DB tables, including
#    the new document_registry table from Sprint 2)
python -m src.cli.main init
```

## Running with Docker

```bash
# 1. Configure environment
cp .env.example .env

# 2. Start Postgres and build the app image
docker compose up -d db
docker compose build app

# 3. Initialize the platform
docker compose run --rm app init

# 4. Run any other command the same way
docker compose run --rm app db status
```

## Usage

```bash
# Initialize (first run only, safe to re-run — idempotent)
o2v init

# Check database connectivity and registry counts (Companies, Frameworks, Documents)
o2v db status

# Import the O2V framework definition (proves the "no code" extensibility claim)
o2v framework import data/frameworks/o2v.yaml

# See what frameworks are registered
o2v framework show
o2v framework show O2V

# Import a batch of companies
o2v company import data/companies/sample_companies.csv
o2v company list

# --- Sprint 2: Document Discovery ---

# Discover documents for one company (SEC EDGAR filings + sitemap/heuristic
# crawl of the company's own website)
o2v discover documents "Apple Inc."

# Discover documents for every company in the registry (continues past any
# single company's failure — see `discover_for_all_companies` in
# src/services/document_discovery_service.py)
o2v discover all

# Platform-wide discovery statistics: by category, status, and method
o2v discover stats

# List discovered documents across all companies
o2v document list

# Show discovered documents for one company
o2v document show "Apple Inc."
```

(Prefix every command with `docker compose run --rm app` instead of `o2v`
if running via Docker.)

## How Document Discovery Works (Sprint 2)

Two independent, both rule-based (no LLM), discovery strategies feed into
one shared validate → dedup → persist pipeline:

1. **SEC EDGAR** (`src/discovery/sec_edgar_client.py`) — for a company
   with a ticker, looks up its CIK via SEC's public ticker-mapping file,
   then queries SEC's submissions API for `10-K`, `20-F`, and `DEF 14A`
   (proxy statement) filings. This is authoritative: filing date, form
   type, and document URL all come directly from SEC's own system of
   record — no guessing.

2. **Sitemap crawl + heuristic path/subdomain probing, always merged**
   (`src/discovery/sitemap_crawler.py`) — for a company's own registered
   website, fetches and parses its `sitemap.xml`, classifying each listed
   URL by keyword match against its path (e.g. a URL containing
   `sustainability` → Sustainability Report), AND separately probes:
   - a curated list of conventional paths per category
     (`/investor-relations`, `/code-of-conduct`, `/sustainability`, etc.
     — see `_HEURISTIC_PATHS`), and
   - conventional subdomain roots (`investor.<domain>`, `ir.<domain>`,
     `sustainability.<domain>`, `esg.<domain>`, `governance.<domain>` —
     see `_HEURISTIC_SUBDOMAINS`), since several large companies host an
     entire section on its own subdomain rather than a path, which a
     sitemap crawl or path probe alone would never find.

   Heuristic hits are tagged with the category they were probed *for*
   (the dict key), not re-derived by keyword-matching the resulting URL —
   a bare subdomain root (`https://investor.apple.com/`) has no path for
   keyword matching to work against, so re-classifying it would always
   fail. Results from sitemap crawling and heuristic probing are merged
   and deduplicated by URL. **This was originally sitemap-first-with-
   heuristic-as-fallback-only, changed after live testing against
   apple.com showed a real sitemap can return a thin, partial result
   (Apple's listed only an About Us page) without being empty — so "the
   sitemap found something" turned out not to be reliable evidence it
   found everything.** Running both unconditionally costs a small,
   bounded number of extra requests per company in exchange for not
   silently missing pages a sitemap omits.

   **Known limitation, by design:** the path and subdomain lists are
   curated to real, common corporate-site conventions, not exhaustive —
   an unbounded guess-list would turn "polite discovery" into something
   closer to a scan against a company's own infrastructure. A company
   whose IR/ESG/governance content lives at a genuinely unconventional
   path or subdomain, and isn't listed in its sitemap either, can still
   be missed. SEC EDGAR discovery is unaffected by this since it doesn't
   depend on the company's own site at all.

Every candidate from either source passes through:
- **URL validation** (`src/discovery/url_validator.py`) — allowlist-first:
  only the company's own domain/subdomains or a trusted external domain
  (SEC's) survive.
- **Deduplication** (`src/services/document_service.py`) — checked
  against `(company_id, official_url)` before insert; re-running
  discovery for a company that's already been processed correctly skips
  everything already registered rather than creating duplicates.

Nothing is downloaded — only the URL, a classified category, an inferred
or authoritative publication year, and metadata about how it was found
are stored in the `document_registry` table.

## Adding a New Framework (no code required)

1. Create a new YAML file under `data/frameworks/`, e.g. `coso.yaml`,
   following the structure in `data/frameworks/o2v.yaml`.
2. Run: `o2v framework import data/frameworks/coso.yaml`
3. Confirm: `o2v framework show COSO`

That's the entire process — no Python file is touched.

## Configuration Reference (.env)

Beyond the Sprint 1 database/logging settings, Sprint 2 adds:

| Variable | Default | Purpose |
|---|---|---|
| `DISCOVERY_TIMEOUT_SECONDS` | `10.0` | Per-request timeout for all discovery HTTP calls |
| `DISCOVERY_RETRY_LIMIT` | `3` | Max attempts per URL before giving up |
| `DISCOVERY_RETRY_BACKOFF_SECONDS` | `1.0` | Base delay between retries (doubles each attempt) |
| `DISCOVERY_RATE_LIMIT_DELAY_SECONDS` | `0.5` | Fixed pause between consecutive outbound requests |
| `DISCOVERY_USER_AGENT` | placeholder, see `.env.example` | Sent on every request — **SEC EDGAR requires a descriptive User-Agent with real contact info**; replace the placeholder in production |

`discovery_trusted_external_domains` (SEC's domains) is a code-level
default in `src/config/settings.py` rather than a typical env var, since
it's a short, rarely-changing allowlist central to the security model —
override it there if a future sprint needs to trust an additional
official source (e.g. a national securities regulator outside the US).

## Running Tests

```bash
pytest
# or, with coverage:
pytest --cov=src
```

The suite now has two tiers:

- **Pure-logic tests** (no database, no network) — CSV/YAML validation,
  settings assembly, the URL validator, the category classifier. These
  always run, with zero external setup required.
- **Mocked-network tests** — the SEC EDGAR client and sitemap/heuristic
  crawler tests. All HTTP calls are mocked via `monkeypatch` on
  `src.discovery.http_client.get` (see that module's docstring for why
  it's the one function tests patch) — no real network access, no
  `respx`/`responses` dependency needed.
- **Integration tests** (real database) — `DocumentDiscoveryService`
  tested end-to-end against a REAL Postgres database, exactly as Sprint
  1's `tests/conftest.py` planned. These use a `db_session` fixture that
  connects to a **separate** test database (`{DB_NAME}_test`, e.g.
  `o2v_platform_test` by default) with per-test transaction rollback for
  isolation. Create it once before running tests:
  ```sql
  CREATE DATABASE o2v_platform_test OWNER o2v_user;
  ```
  If this database isn't reachable, those specific tests are **skipped**
  with a clear message — the rest of the suite still runs.

## What's Next (Sprint 3+)

See `docs/` for the full platform architecture and milestone roadmap.
Sprint 3 is where document CONTENT finally gets touched: downloading the
URLs this sprint discovered, parsing PDF/HTML into page-tagged text, and
chunking for retrieval — still no LLM extraction yet; that's the sprint
after.
