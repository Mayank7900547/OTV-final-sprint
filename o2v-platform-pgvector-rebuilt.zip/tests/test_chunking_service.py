"""
Integration tests for `src/chunking/service.py` (DocumentChunkingService).

Requires a real Postgres test database, exactly like
`test_parser_service.py` — skipped automatically if unreachable (see
`tests/conftest.py`'s module docstring). `DocumentChunkingService.
chunk_parsed_document` calls `session.commit()` internally, so this
module uses the same SAVEPOINT-based session fixture
`test_parser_service.py` already established.
"""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import event
from sqlalchemy.orm import sessionmaker

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.base_chunker import ChunkerConfig
from src.chunking.models import Chunk, ChunkingHistory, ChunkingStatusEnum
from src.chunking.service import DocumentChunkingService
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum

# Import so the table registers on Base.metadata, same requirement as conftest.py.
from src.chunking import models as _chunking_models_module  # noqa: F401


@pytest.fixture
def chunking_session(_test_engine):
    """SAVEPOINT-based session fixture — see module docstring."""
    connection = _test_engine.connect()
    outer_transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()
    session.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def _restart_savepoint(sess, trans):
        if trans.nested and not trans._parent.nested:
            sess.begin_nested()

    yield session

    session.close()
    outer_transaction.rollback()
    connection.close()


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _make_company(session, name="Acme Corp"):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company, doc_type=DocumentType.PDF.value):
    doc = DocumentRegistry(
        company_id=company.id,
        document_name="Annual Report",
        document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=doc_type,
        document_year=2024,
        official_url=f"https://acme.com/{uuid.uuid4()}.pdf",
        source_domain="acme.com",
        discovery_method="sitemap_crawl",
        status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _make_version(session, document, tmp_path, *, version_number=1):
    path = tmp_path / f"report_{version_number}.pdf"
    path.write_bytes(b"%PDF-1.4 fake content")
    version = DocumentVersion(
        document_id=document.id,
        version_number=version_number,
        file_hash="a" * 64,
        storage_path=str(path),
        file_size=path.stat().st_size,
        status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()
    return version


def _make_parsed_document(
    session,
    document,
    version,
    *,
    raw_text="Default paragraph text for testing.",
    page_text=None,
    status=ParsingStatusEnum.SUCCESS,
    metadata_json=None,
):
    if page_text is None:
        page_text = [{"page_number": 1, "text": raw_text}]
    row = ParsedDocument(
        document_id=document.id,
        document_version_id=version.id,
        parser_used="pdf_parser",
        parser_version="1.0.0",
        document_type=DocumentType.PDF.value,
        page_count=max((p["page_number"] for p in page_text), default=0) if page_text else 0,
        raw_text=raw_text,
        page_text=page_text,
        character_count=len(raw_text),
        status=status,
        metadata_json=metadata_json,
    )
    session.add(row)
    session.flush()
    return row


def _make_scenario(session, tmp_path, *, company_name="Acme Corp", **parsed_kwargs):
    company = _make_company(session, name=company_name)
    document = _make_document(session, company)
    version = _make_version(session, document, tmp_path)
    parsed = _make_parsed_document(session, document, version, **parsed_kwargs)
    return company, document, version, parsed


def _test_service(**config_overrides) -> DocumentChunkingService:
    """A service with small, deterministic chunk sizes for fast, predictable tests."""
    config = ChunkerConfig(
        chunk_size=config_overrides.pop("chunk_size", 80),
        chunk_overlap=config_overrides.pop("chunk_overlap", 10),
        min_chunk_size=config_overrides.pop("min_chunk_size", 10),
        max_chunk_size=config_overrides.pop("max_chunk_size", 160),
        **config_overrides,
    )
    return DocumentChunkingService(config=config)


# ---------------------------------------------------------------------------
# chunk_parsed_document — happy path
# ---------------------------------------------------------------------------


def test_chunk_parsed_document_success_persists_chunks(chunking_session, tmp_path):
    _, _, version, parsed = _make_scenario(
        chunking_session, tmp_path, raw_text="A short paragraph of report text."
    )

    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["chunks_created"] == 1

    rows = chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).all()
    assert len(rows) == 1
    assert rows[0].text == "A short paragraph of report text."
    assert rows[0].chunker_used == "recursive_chunker"
    assert rows[0].document_version_id == version.id
    assert rows[0].chunk_id == f"{version.id}:0"


def test_chunk_parsed_document_succeeds_despite_substantial_duplicate_content(chunking_session, tmp_path):
    """
    Regression test for a genuine bug found running the full pipeline
    against real Apple SEC EDGAR filings: a proxy statement whose
    'Audit Committee' summary section repeats a full sentence that also
    appears in the detailed 'Audit and Finance Committee Report' section
    (legitimate document structure, not a chunker defect) used to fail
    chunking entirely — 0 chunks created for the whole document — because
    duplicate-text detection was a fatal check. It's now a logged warning
    only; this asserts the document chunks successfully end-to-end.
    """
    repeated_sentence = (
        "Apple's financial statements and other financial information "
        "provided by Apple to its shareholders and others; " * 3
    )  # well over the test service's min_chunk_size=10
    raw_text = (
        f"Audit Committee\n{repeated_sentence}\n\n"
        f"Audit and Finance Committee Report\n{repeated_sentence}"
    )
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text=raw_text)

    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["chunks_created"] > 0

    rows = chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).all()
    assert len(rows) == outcome["chunks_created"]


def test_chunk_parsed_document_records_chunking_history(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path)

    service = _test_service()
    service.chunk_parsed_document(chunking_session, parsed.id)

    history = (
        chunking_session.query(ChunkingHistory)
        .filter(ChunkingHistory.parsed_document_id == parsed.id)
        .all()
    )
    assert len(history) == 1
    assert history[0].chunking_status == ChunkingStatusEnum.SUCCESS
    assert history[0].attempt_number == 1
    assert history[0].chunks_produced == 1


def test_chunk_parsed_document_splits_long_text_into_multiple_chunks(chunking_session, tmp_path):
    long_text = "\n\n".join(f"This is paragraph number {i} with some filler content in it." for i in range(20))
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text=long_text)

    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["chunks_created"] > 1

    rows = (
        chunking_session.query(Chunk)
        .filter(Chunk.parsed_document_id == parsed.id)
        .order_by(Chunk.chunk_index.asc())
        .all()
    )
    assert [r.chunk_index for r in rows] == list(range(len(rows)))
    assert all(r.character_count <= 160 for r in rows)


def test_chunk_parsed_document_preserves_section_hierarchy(chunking_session, tmp_path):
    text = "Overview\n\nWe are a company that builds things.\n\nRisk Factors\n\nMarkets can be volatile."
    _, _, _, parsed = _make_scenario(
        chunking_session,
        tmp_path,
        raw_text=text,
        page_text=[{"page_number": 1, "text": text}],
        metadata_json={"headings": [{"level": "h1", "text": "Overview"}, {"level": "h1", "text": "Risk Factors"}]},
    )

    service = _test_service()
    service.chunk_parsed_document(chunking_session, parsed.id)

    rows = (
        chunking_session.query(Chunk)
        .filter(Chunk.parsed_document_id == parsed.id)
        .order_by(Chunk.chunk_index.asc())
        .all()
    )
    sections = {r.section_title for r in rows}
    assert "Overview" in sections
    assert "Risk Factors" in sections


# ---------------------------------------------------------------------------
# chunk_parsed_document — not found / not eligible / empty
# ---------------------------------------------------------------------------


def test_chunk_parsed_document_returns_failed_for_unknown_id(chunking_session):
    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, 999_999_999)

    assert outcome["status"] == "FAILED"
    assert "not found" in outcome["error"].lower()


def test_chunk_parsed_document_skips_failed_parse_status(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, status=ParsingStatusEnum.FAILED)

    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)

    assert outcome["status"] == "SKIPPED"
    assert chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).count() == 0


def test_chunk_parsed_document_fails_for_empty_text(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text="", page_text=[])

    service = _test_service()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)

    assert outcome["status"] == "FAILED"
    assert "no extractable text" in outcome["error"].lower()

    history = (
        chunking_session.query(ChunkingHistory)
        .filter(ChunkingHistory.parsed_document_id == parsed.id)
        .all()
    )
    assert len(history) == 1
    assert history[0].chunking_status == ChunkingStatusEnum.FAILED


# ---------------------------------------------------------------------------
# chunk_parsed_document — duplicate prevention
# ---------------------------------------------------------------------------


def test_chunk_parsed_document_is_skipped_on_second_call_without_force(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path)

    service = _test_service()
    first = service.chunk_parsed_document(chunking_session, parsed.id)
    second = service.chunk_parsed_document(chunking_session, parsed.id)

    assert first["status"] == "SUCCESS"
    assert second["status"] == "SKIPPED"

    count = chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).count()
    assert count == first["chunks_created"]


def test_chunk_parsed_document_rechunks_when_forced(chunking_session, tmp_path):
    long_text = "\n\n".join(f"Paragraph {i} has some unique filler text in it here." for i in range(20))
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text=long_text)

    service = _test_service()
    first = service.chunk_parsed_document(chunking_session, parsed.id)
    second = service.chunk_parsed_document(chunking_session, parsed.id, force=True)

    assert first["status"] == "SUCCESS"
    assert second["status"] == "SUCCESS"

    count = chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).count()
    # force=True deletes and reinserts rather than doubling them up.
    assert count == second["chunks_created"]


def test_chunk_parsed_document_no_duplicate_chunk_rows_without_force(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path)
    service = _test_service()
    service.chunk_parsed_document(chunking_session, parsed.id)
    service.chunk_parsed_document(chunking_session, parsed.id)  # skipped, no-op

    rows = chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).all()
    assert len(rows) == 1


# ---------------------------------------------------------------------------
# load_eligible_parsed_document_ids / load_failed_parsed_document_ids
# ---------------------------------------------------------------------------


def test_load_eligible_parsed_document_ids_includes_success_and_partial(chunking_session, tmp_path):
    _, _, _, success_doc = _make_scenario(
        chunking_session, tmp_path, company_name="Success Corp", status=ParsingStatusEnum.SUCCESS
    )
    _, _, _, partial_doc = _make_scenario(
        chunking_session, tmp_path, company_name="Partial Corp", status=ParsingStatusEnum.PARTIAL
    )
    _, _, _, failed_doc = _make_scenario(
        chunking_session, tmp_path, company_name="Failed Corp", status=ParsingStatusEnum.FAILED
    )

    service = _test_service()
    ids = service.load_eligible_parsed_document_ids(chunking_session)

    assert success_doc.id in ids
    assert partial_doc.id in ids
    assert failed_doc.id not in ids


def test_load_eligible_parsed_document_ids_filters_by_company(chunking_session, tmp_path):
    company_a = _make_company(chunking_session, name="Alpha Corp")
    doc_a = _make_document(chunking_session, company_a)
    version_a = _make_version(chunking_session, doc_a, tmp_path, version_number=1)
    parsed_a = _make_parsed_document(chunking_session, doc_a, version_a)

    company_b = _make_company(chunking_session, name="Beta Corp")
    doc_b = _make_document(chunking_session, company_b)
    version_b = _make_version(chunking_session, doc_b, tmp_path, version_number=2)
    parsed_b = _make_parsed_document(chunking_session, doc_b, version_b)

    service = _test_service()
    ids = service.load_eligible_parsed_document_ids(chunking_session, company_filter="Alpha")

    assert parsed_a.id in ids
    assert parsed_b.id not in ids


def test_load_failed_parsed_document_ids_excludes_successfully_chunked(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path)
    service = _test_service()
    service.chunk_parsed_document(chunking_session, parsed.id)  # succeeds

    ids = service.load_failed_parsed_document_ids(chunking_session)
    assert parsed.id not in ids


def test_load_failed_parsed_document_ids_includes_empty_text_failure(chunking_session, tmp_path):
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text="", page_text=[])
    service = _test_service()
    service.chunk_parsed_document(chunking_session, parsed.id)  # fails (empty text)

    ids = service.load_failed_parsed_document_ids(chunking_session)
    assert parsed.id in ids


# ---------------------------------------------------------------------------
# Large-document / performance-shaped test
# ---------------------------------------------------------------------------


def test_chunk_parsed_document_handles_large_document(chunking_session, tmp_path):
    paragraphs = [f"Paragraph {i}: " + ("word " * 40).strip() + "." for i in range(500)]
    large_text = "\n\n".join(paragraphs)
    _, _, _, parsed = _make_scenario(chunking_session, tmp_path, raw_text=large_text)

    service = _test_service(chunk_size=500, chunk_overlap=50, min_chunk_size=50, max_chunk_size=1000)

    import time

    start = time.monotonic()
    outcome = service.chunk_parsed_document(chunking_session, parsed.id)
    elapsed = time.monotonic() - start

    assert outcome["status"] == "SUCCESS"
    assert outcome["chunks_created"] > 1
    assert elapsed < 10.0  # generous ceiling — this is a correctness guard, not a strict benchmark

    total_chars = sum(
        r.character_count
        for r in chunking_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).all()
    )
    # Every paragraph's text should be accounted for somewhere in the
    # persisted chunks (overlap only ever ADDS characters, never drops them).
    assert total_chars >= len(large_text.replace("\n\n", ""))
