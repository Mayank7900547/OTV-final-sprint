"""Unit tests for `src/retrieval/hybrid_scoring.py`."""

from src.retrieval.hybrid_scoring import compute_final_scores, compute_metadata_score, normalize_scores
from src.retrieval.types import EvidenceCandidate, RetrievalConfig, RetrievalQuery


def _candidate(**overrides) -> EvidenceCandidate:
    base = dict(
        chunk_id=1, document_id="doc-1", company_id="co-1", page_number=1,
        section_title="Overview", document_type="Annual Report", chunk_text="Some text.",
    )
    base.update(overrides)
    return EvidenceCandidate(**base)


# ---------------------------------------------------------------------------
# normalize_scores
# ---------------------------------------------------------------------------


def test_normalize_scores_min_max_scales_to_zero_one():
    candidates = [_candidate(semantic_score=0.2), _candidate(semantic_score=0.6), _candidate(semantic_score=1.0)]
    normalize_scores(candidates, attr="semantic_score")
    assert candidates[0].semantic_score == 0.0
    assert candidates[2].semantic_score == 1.0
    assert 0.0 < candidates[1].semantic_score < 1.0


def test_normalize_scores_empty_list_is_a_no_op():
    normalize_scores([], attr="semantic_score")  # should not raise


def test_normalize_scores_zero_variance_leaves_values_unchanged():
    candidates = [_candidate(semantic_score=0.5), _candidate(semantic_score=0.5)]
    normalize_scores(candidates, attr="semantic_score")
    assert candidates[0].semantic_score == 0.5
    assert candidates[1].semantic_score == 0.5


def test_normalize_scores_all_zero_is_left_as_zero_not_manufactured():
    candidates = [_candidate(lexical_score=0.0), _candidate(lexical_score=0.0)]
    normalize_scores(candidates, attr="lexical_score")
    assert all(c.lexical_score == 0.0 for c in candidates)


# ---------------------------------------------------------------------------
# compute_metadata_score
# ---------------------------------------------------------------------------


def test_compute_metadata_score_match_returns_match_score():
    candidate = _candidate(document_type="Annual Report")
    query = RetrievalQuery(text="q", field_name="f", component="Purpose", document_sources=["Annual Report"])
    assert compute_metadata_score(candidate, [query], match_score=1.0, no_match_score=0.4) == 1.0


def test_compute_metadata_score_no_match_returns_no_match_score():
    candidate = _candidate(document_type="Press Release")
    query = RetrievalQuery(text="q", field_name="f", component="Purpose", document_sources=["Annual Report"])
    assert compute_metadata_score(candidate, [query], match_score=1.0, no_match_score=0.4) == 0.4


def test_compute_metadata_score_no_document_sources_returns_no_match_score():
    candidate = _candidate(document_type="Annual Report")
    query = RetrievalQuery(text="q", field_name="f", component="Purpose", document_sources=None)
    assert compute_metadata_score(candidate, [query], match_score=1.0, no_match_score=0.4) == 0.4


def test_compute_metadata_score_missing_document_type_returns_no_match_score():
    candidate = _candidate(document_type=None)
    query = RetrievalQuery(text="q", field_name="f", component="Purpose", document_sources=["Annual Report"])
    assert compute_metadata_score(candidate, [query], match_score=1.0, no_match_score=0.4) == 0.4


def test_compute_metadata_score_checks_any_matching_query():
    candidate = _candidate(document_type="10-K")
    queries = [
        RetrievalQuery(text="q1", field_name="f1", component="Purpose", document_sources=["Annual Report"]),
        RetrievalQuery(text="q2", field_name="f2", component="Purpose", document_sources=["10-K"]),
    ]
    assert compute_metadata_score(candidate, queries, match_score=1.0, no_match_score=0.4) == 1.0


# ---------------------------------------------------------------------------
# compute_final_scores
# ---------------------------------------------------------------------------


def test_compute_final_scores_combines_weighted_signals():
    config = RetrievalConfig(semantic_weight=0.6, lexical_weight=0.25, metadata_weight=0.15)
    candidates = [
        _candidate(semantic_score=1.0, lexical_score=0.0, metadata_score=1.0),
        _candidate(semantic_score=0.0, lexical_score=1.0, metadata_score=0.4),
    ]
    compute_final_scores(candidates, config=config)

    # First candidate: normalized semantic=1.0 (max), lexical=0.0 (min) -> 0.6*1 + 0.25*0 + 0.15*1 = 0.75
    assert candidates[0].final_score == 0.75 or abs(candidates[0].final_score - 0.75) < 1e-9


def test_compute_final_scores_higher_semantic_yields_higher_final_score():
    config = RetrievalConfig()
    strong = _candidate(chunk_id=1, semantic_score=0.9, lexical_score=0.1, metadata_score=0.5)
    weak = _candidate(chunk_id=2, semantic_score=0.1, lexical_score=0.1, metadata_score=0.5)
    candidates = [strong, weak]
    compute_final_scores(candidates, config=config)
    assert strong.final_score > weak.final_score
