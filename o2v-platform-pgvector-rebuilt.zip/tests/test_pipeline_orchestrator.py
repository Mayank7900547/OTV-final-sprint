"""
Unit tests for `src/pipeline/orchestrator.py`.

These test the ORCHESTRATOR's control flow — does it continue to the next
stage when one stage errors, does skip_discovery/skip_acquisition actually
skip, does the embeddings retry-pass loop stop at the right time — not the
individual stages' internal logic, which is already covered by
test_acquisition_service.py / test_parser_service.py / test_chunking_
service.py / test_embeddings_service.py / test_retrieval_service.py /
test_extraction_service.py. Every stage method is monkeypatched directly
on the orchestrator instance, so no real DB, network, or LLM provider is
needed for any test here.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from src.core.exceptions import O2VError
from src.pipeline.orchestrator import PipelineOrchestrator, StageResult


@pytest.fixture
def orchestrator():
    return PipelineOrchestrator(embedding_retry_passes=1)


def _patch_all_stages(monkeypatch, orchestrator, *, statuses: dict[str, str] | None = None):
    """
    Replace every _stage_* method with a stub returning a StageResult with
    the given status (default SUCCESS for all) — the standard setup for
    tests that care about orchestration, not individual stage behavior.
    """
    statuses = statuses or {}

    def _make(stage_name):
        def _stub(*args, **kwargs):
            return StageResult(stage=stage_name, status=statuses.get(stage_name, "SUCCESS"), detail=f"{stage_name} ran")
        return _stub

    monkeypatch.setattr(orchestrator, "_stage_discovery", _make("discovery"))
    monkeypatch.setattr(orchestrator, "_stage_acquisition", _make("acquisition"))
    monkeypatch.setattr(orchestrator, "_stage_parsing", lambda company_name, force: _make("parsing")())
    monkeypatch.setattr(orchestrator, "_stage_chunking", lambda company_name, force: _make("chunking")())
    monkeypatch.setattr(orchestrator, "_stage_embeddings", lambda company_name, force: _make("embeddings")())
    monkeypatch.setattr(orchestrator, "_resolve_company", lambda session, company_name: MagicMock(id="fake-company-id"))
    monkeypatch.setattr(orchestrator, "_stage_retrieval", lambda session, company, components, framework_name: _make("retrieval")())
    monkeypatch.setattr(orchestrator, "_stage_extraction", lambda session, company, components, framework_name, force=False: _make("extraction")())
    # Never let a test attempt to actually reach or spawn a real Ollama
    # process — on a machine where 'ollama' genuinely IS installed, an
    # un-mocked call here would spawn a real background server every
    # time this test file runs, which is exactly the kind of real-world
    # side effect a unit test must never have. See
    # test_ensure_providers_ready_upfront_* below for tests of this
    # method's own logic, in isolation.
    monkeypatch.setattr(orchestrator, "_ensure_providers_ready_upfront", lambda: None)
    # session_scope() is called directly inside orchestrator.run()'s retrieval/extraction
    # closures — patch it at the module level so those `with session_scope() as session:`
    # blocks don't need a real database.
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)


# ---------------------------------------------------------------------------
# Happy path — every stage succeeds
# ---------------------------------------------------------------------------


def test_run_executes_every_stage_in_order(monkeypatch, orchestrator):
    _patch_all_stages(monkeypatch, orchestrator)

    results = orchestrator.run("Acme Corp")

    stages_in_order = [r.stage for r in results]
    assert stages_in_order == ["discovery", "acquisition", "parsing", "chunking", "embeddings", "retrieval", "extraction"]
    assert all(r.status == "SUCCESS" for r in results)


# ---------------------------------------------------------------------------
# Continue-on-error — the core value proposition of this whole feature
# ---------------------------------------------------------------------------


def test_run_continues_past_a_stage_that_raises_o2v_error(monkeypatch, orchestrator):
    """A stage raising its own domain exception (e.g. AcquisitionError) must not stop the pipeline — this is THE thing this feature exists to fix."""

    def _raising_acquisition(company_name):
        raise O2VError("simulated acquisition failure")

    _patch_all_stages(monkeypatch, orchestrator)
    monkeypatch.setattr(orchestrator, "_stage_acquisition", _raising_acquisition)

    results = orchestrator.run("Acme Corp")

    assert len(results) == 7  # every stage still produced a result, including the ones after the failure
    acquisition_result = next(r for r in results if r.stage == "acquisition")
    assert acquisition_result.status == "ERROR"
    assert "simulated acquisition failure" in acquisition_result.detail
    # Stages after acquisition still ran and succeeded.
    later_stages = [r for r in results if r.stage in ("parsing", "chunking", "embeddings", "retrieval", "extraction")]
    assert all(r.status == "SUCCESS" for r in later_stages)


def test_run_continues_past_a_stage_that_raises_unexpected_exception(monkeypatch, orchestrator):
    """Even a completely unanticipated exception (not an O2VError subclass) must not stop the pipeline."""

    def _raising_chunking(company_name, force):
        raise RuntimeError("something nobody anticipated")

    _patch_all_stages(monkeypatch, orchestrator)
    monkeypatch.setattr(orchestrator, "_stage_chunking", _raising_chunking)

    results = orchestrator.run("Acme Corp")

    assert len(results) == 7
    chunking_result = next(r for r in results if r.stage == "chunking")
    assert chunking_result.status == "ERROR"
    assert "something nobody anticipated" in chunking_result.detail
    embeddings_result = next(r for r in results if r.stage == "embeddings")
    assert embeddings_result.status == "SUCCESS"  # ran despite chunking's failure


def test_run_multiple_stage_failures_all_reported_independently(monkeypatch, orchestrator):
    _patch_all_stages(monkeypatch, orchestrator)
    monkeypatch.setattr(orchestrator, "_stage_discovery", lambda company_name: (_ for _ in ()).throw(O2VError("discovery down")))
    monkeypatch.setattr(orchestrator, "_stage_embeddings", lambda company_name, force: (_ for _ in ()).throw(O2VError("embeddings provider down")))

    results = orchestrator.run("Acme Corp")

    by_stage = {r.stage: r for r in results}
    assert by_stage["discovery"].status == "ERROR"
    assert by_stage["embeddings"].status == "ERROR"
    # Stages between and after the two failures still ran.
    assert by_stage["acquisition"].status == "SUCCESS"
    assert by_stage["parsing"].status == "SUCCESS"
    assert by_stage["chunking"].status == "SUCCESS"
    assert by_stage["retrieval"].status == "SUCCESS"
    assert by_stage["extraction"].status == "SUCCESS"


# ---------------------------------------------------------------------------
# skip_discovery / skip_acquisition
# ---------------------------------------------------------------------------


def test_run_skip_discovery_does_not_call_the_stage(monkeypatch, orchestrator):
    _patch_all_stages(monkeypatch, orchestrator)
    called = {"discovery": False}
    monkeypatch.setattr(orchestrator, "_stage_discovery", lambda company_name: called.__setitem__("discovery", True))

    results = orchestrator.run("Acme Corp", skip_discovery=True)

    assert called["discovery"] is False
    discovery_result = next(r for r in results if r.stage == "discovery")
    assert discovery_result.status == "SKIPPED"


def test_run_skip_acquisition_does_not_call_the_stage(monkeypatch, orchestrator):
    _patch_all_stages(monkeypatch, orchestrator)
    called = {"acquisition": False}
    monkeypatch.setattr(orchestrator, "_stage_acquisition", lambda company_name: called.__setitem__("acquisition", True))

    results = orchestrator.run("Acme Corp", skip_acquisition=True)

    assert called["acquisition"] is False
    acquisition_result = next(r for r in results if r.stage == "acquisition")
    assert acquisition_result.status == "SKIPPED"


def test_run_without_skip_flags_calls_discovery_and_acquisition(monkeypatch, orchestrator):
    _patch_all_stages(monkeypatch, orchestrator)
    calls = {"discovery": 0, "acquisition": 0}
    monkeypatch.setattr(orchestrator, "_stage_discovery", lambda company_name: (calls.__setitem__("discovery", calls["discovery"] + 1), StageResult(stage="discovery", status="SUCCESS", detail=""))[1])
    monkeypatch.setattr(orchestrator, "_stage_acquisition", lambda company_name: (calls.__setitem__("acquisition", calls["acquisition"] + 1), StageResult(stage="acquisition", status="SUCCESS", detail=""))[1])

    orchestrator.run("Acme Corp")

    assert calls == {"discovery": 1, "acquisition": 1}


# ---------------------------------------------------------------------------
# Embeddings stage's multi-pass retry loop
# ---------------------------------------------------------------------------


class _FakeEmbeddingService:
    """
    Scripted stand-in for EmbeddingGenerationService. Mirrors the real
    service's split between load_eligible_chunk_ids() (constant — always
    the initial full set, regardless of embedding status) and
    load_unembedded_chunk_ids() (the shrinking "still needs embedding"
    list across successive calls, used for progress tracking).
    """

    def __init__(self, remaining_after_each_pass: list[list[int]]):
        self._remaining_after_each_pass = list(remaining_after_each_pass)
        self.embed_many_calls = 0
        self.load_calls = 0

    def load_eligible_chunk_ids(self, session, company_filter=None):
        # Real method always returns EVERY chunk, regardless of embedding status — constant across calls.
        return self._remaining_after_each_pass[0]

    def load_unembedded_chunk_ids(self, session, company_filter=None):
        self.load_calls += 1
        # First call is the initial "what's still missing before we start" load;
        # subsequent calls happen after each embed_many() pass.
        index = min(self.load_calls - 1, len(self._remaining_after_each_pass) - 1)
        return self._remaining_after_each_pass[index]

    def embed_many(self, session_factory, ids, force=False):
        self.embed_many_calls += 1
        # Simulate "succeeded" count as (previous remaining - next remaining).
        before = len(self._remaining_after_each_pass[self.embed_many_calls - 1])
        after_index = min(self.embed_many_calls, len(self._remaining_after_each_pass) - 1)
        after = len(self._remaining_after_each_pass[after_index])
        succeeded = max(0, before - after)
        return [{"status": "SUCCESS", "chunk_id": i} for i in range(succeeded)]


def test_embeddings_stage_stops_after_two_consecutive_zero_progress_passes(monkeypatch):
    """Stops once settings.pipeline_embedding_consecutive_stall_limit (default 2) consecutive passes each make zero progress — not after a single stall (see next test)."""
    orchestrator = PipelineOrchestrator(embedding_retry_passes=5)  # would be 6 total passes if it didn't stop early
    fake_service = _FakeEmbeddingService(
        remaining_after_each_pass=[
            [1, 2, 3, 4, 5],  # initial: 5 eligible
            [4, 5],           # after pass 1: 3 succeeded, 2 remain
            [4, 5],           # after pass 2: 0 succeeded (stall #1)
            [4, 5],           # after pass 3: 0 succeeded (stall #2) -> should stop here
        ]
    )
    monkeypatch.setattr("src.pipeline.orchestrator.EmbeddingGenerationService", lambda: fake_service)
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)

    result = orchestrator._stage_embeddings("Acme Corp", force=False)

    assert fake_service.embed_many_calls == 3  # stopped after pass 3's SECOND consecutive zero-progress pass
    assert result.status == "PARTIAL"
    assert result.extra["still_missing"] == 2


def test_embeddings_stage_a_single_stall_does_not_stop_the_stage(monkeypatch):
    """
    Regression test for a real overnight scenario: one pass returned 0
    succeeded purely because Ollama had died in between passes, and the
    very next pass (after a restart) was fully healthy again. A single
    stall must not end the stage while a later pass can still make progress.
    """
    orchestrator = PipelineOrchestrator(embedding_retry_passes=5)
    fake_service = _FakeEmbeddingService(
        remaining_after_each_pass=[
            [1, 2, 3, 4, 5],  # initial: 5 eligible
            [1, 2, 3, 4, 5],  # after pass 1: 0 succeeded (single stall — e.g. Ollama was down)
            [],               # after pass 2: all 5 succeeded (Ollama recovered) — must have been attempted
        ]
    )
    monkeypatch.setattr("src.pipeline.orchestrator.EmbeddingGenerationService", lambda: fake_service)
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)

    result = orchestrator._stage_embeddings("Acme Corp", force=False)

    assert fake_service.embed_many_calls == 2  # pass 2 WAS attempted despite pass 1's stall
    assert result.status == "SUCCESS"
    assert result.extra["still_missing"] == 0


def test_embeddings_stage_consecutive_stall_limit_is_configurable(monkeypatch):
    """settings.pipeline_embedding_consecutive_stall_limit=1 restores the old single-stall-stops behavior for anyone who wants it."""
    from src.config.settings import settings
    monkeypatch.setattr(settings, "pipeline_embedding_consecutive_stall_limit", 1)

    orchestrator = PipelineOrchestrator(embedding_retry_passes=5)
    fake_service = _FakeEmbeddingService(
        remaining_after_each_pass=[
            [1, 2, 3, 4, 5],
            [4, 5],  # pass 1: 3 succeeded
            [4, 5],  # pass 2: 0 succeeded — with limit=1, should stop right here
        ]
    )
    monkeypatch.setattr("src.pipeline.orchestrator.EmbeddingGenerationService", lambda: fake_service)
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)

    result = orchestrator._stage_embeddings("Acme Corp", force=False)

    assert fake_service.embed_many_calls == 2


def test_embeddings_stage_reports_success_when_fully_complete(monkeypatch):
    orchestrator = PipelineOrchestrator(embedding_retry_passes=2)
    fake_service = _FakeEmbeddingService(
        remaining_after_each_pass=[
            [1, 2, 3],  # initial: 3 eligible
            [],         # after pass 1: all 3 succeeded
        ]
    )
    monkeypatch.setattr("src.pipeline.orchestrator.EmbeddingGenerationService", lambda: fake_service)
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)

    result = orchestrator._stage_embeddings("Acme Corp", force=False)

    assert result.status == "SUCCESS"
    assert result.extra["still_missing"] == 0
    assert fake_service.embed_many_calls == 1  # stopped immediately once nothing remained


def test_embeddings_stage_skipped_when_no_eligible_chunks(monkeypatch):
    orchestrator = PipelineOrchestrator()
    fake_service = _FakeEmbeddingService(remaining_after_each_pass=[[]])
    monkeypatch.setattr("src.pipeline.orchestrator.EmbeddingGenerationService", lambda: fake_service)
    import contextlib

    @contextlib.contextmanager
    def _fake_session_scope():
        yield MagicMock()

    monkeypatch.setattr("src.pipeline.orchestrator.session_scope", _fake_session_scope)

    result = orchestrator._stage_embeddings("Acme Corp", force=False)

    assert result.status == "SKIPPED"
    assert fake_service.embed_many_calls == 0


# ---------------------------------------------------------------------------
# StageResult / _run_stage wrapper
# ---------------------------------------------------------------------------


def test_run_stage_wraps_a_plain_return_value_as_success(orchestrator):
    result = orchestrator._run_stage("custom", lambda: "some plain string result")
    assert result.status == "SUCCESS"
    assert result.detail == "some plain string result"
    assert result.stage == "custom"


def test_run_stage_preserves_a_returned_stage_result_but_fills_in_duration(orchestrator):
    inner = StageResult(stage="custom", status="PARTIAL", detail="3/5 succeeded")
    result = orchestrator._run_stage("custom", lambda: inner)
    assert result.status == "PARTIAL"
    assert result.detail == "3/5 succeeded"
    assert result.duration_seconds >= 0.0


def test_run_stage_catches_o2v_error_and_returns_error_status(orchestrator):
    def _raise():
        raise O2VError("domain-specific failure")

    result = orchestrator._run_stage("custom", _raise)
    assert result.status == "ERROR"
    assert "domain-specific failure" in result.detail


def test_run_stage_catches_arbitrary_exception_and_returns_error_status(orchestrator):
    def _raise():
        raise ValueError("something unexpected")

    result = orchestrator._run_stage("custom", _raise)
    assert result.status == "ERROR"
    assert "something unexpected" in result.detail


# ---------------------------------------------------------------------------
# _ensure_providers_ready_upfront — proactive Ollama startup at the very
# beginning of run(), before discovery even begins, rather than only
# reactively when the embeddings/extraction stage discovers it's down.
# ---------------------------------------------------------------------------


def test_ensure_providers_ready_upfront_starts_ollama_when_embeddings_provider_is_ollama(monkeypatch, orchestrator):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "embeddings_provider", "ollama")
    monkeypatch.setattr(settings, "llm_provider", "openai")  # deliberately different, to prove embeddings alone is enough to trigger this

    calls = []
    monkeypatch.setattr("src.pipeline.orchestrator.ensure_ollama_running", lambda base_url, provider_name: calls.append((base_url, provider_name)) or True)

    orchestrator._ensure_providers_ready_upfront()

    assert len(calls) == 1
    assert calls[0][1] == "ollama"


def test_ensure_providers_ready_upfront_starts_ollama_when_llm_provider_is_ollama(monkeypatch, orchestrator):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "embeddings_provider", "openai")  # deliberately different
    monkeypatch.setattr(settings, "llm_provider", "ollama")

    calls = []
    monkeypatch.setattr("src.pipeline.orchestrator.ensure_ollama_running", lambda base_url, provider_name: calls.append((base_url, provider_name)) or True)

    orchestrator._ensure_providers_ready_upfront()

    assert len(calls) == 1


def test_ensure_providers_ready_upfront_does_nothing_when_neither_provider_is_ollama(monkeypatch, orchestrator):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "embeddings_provider", "openai")
    monkeypatch.setattr(settings, "llm_provider", "anthropic")

    calls = []
    monkeypatch.setattr("src.pipeline.orchestrator.ensure_ollama_running", lambda base_url, provider_name: calls.append((base_url, provider_name)) or True)

    orchestrator._ensure_providers_ready_upfront()

    assert calls == []  # neither provider is Ollama — nothing to proactively start


def test_ensure_providers_ready_upfront_attempts_only_once_even_when_both_providers_are_ollama(monkeypatch, orchestrator):
    """Embeddings and extraction both pointing at Ollama share the same local server — this should still be a single startup attempt, not two."""
    from src.config.settings import settings
    monkeypatch.setattr(settings, "embeddings_provider", "ollama")
    monkeypatch.setattr(settings, "llm_provider", "ollama")

    calls = []
    monkeypatch.setattr("src.pipeline.orchestrator.ensure_ollama_running", lambda base_url, provider_name: calls.append((base_url, provider_name)) or True)

    orchestrator._ensure_providers_ready_upfront()

    assert len(calls) == 1


def test_ensure_providers_ready_upfront_does_not_raise_when_ollama_fails_to_start(monkeypatch, orchestrator):
    """A failed proactive start must not abort the pipeline — the per-stage reactive check is still the real safety net."""
    from src.config.settings import settings
    monkeypatch.setattr(settings, "embeddings_provider", "ollama")
    monkeypatch.setattr("src.pipeline.orchestrator.ensure_ollama_running", lambda base_url, provider_name: False)

    orchestrator._ensure_providers_ready_upfront()  # must not raise


def test_run_calls_ensure_providers_ready_upfront_before_any_stage(monkeypatch, orchestrator):
    """Confirms run() actually wires this in — this is the point of the whole feature: warmed up BEFORE discovery, not reactively at the embeddings stage."""
    call_order = []
    monkeypatch.setattr(orchestrator, "_ensure_providers_ready_upfront", lambda: call_order.append("providers_ready"))
    _patch_all_stages(monkeypatch, orchestrator)  # this re-patches _ensure_providers_ready_upfront to a no-op — override back after
    monkeypatch.setattr(orchestrator, "_ensure_providers_ready_upfront", lambda: call_order.append("providers_ready"))
    monkeypatch.setattr(orchestrator, "_stage_discovery", lambda company_name: call_order.append("discovery") or StageResult(stage="discovery", status="SUCCESS", detail=""))

    orchestrator.run("Acme Corp")

    assert call_order[0] == "providers_ready"
    assert call_order[1] == "discovery"
