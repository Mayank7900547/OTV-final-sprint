"""Unit tests for `src/parser/base_parser.py` and `src/parser/utils.py`."""

from pathlib import Path

import pytest

from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.exceptions import EmptyDocumentError
from src.parser.utils import normalize_whitespace, truncate


class _MinimalParser(BaseParser):
    parser_name = "minimal"
    parser_version = "0.0.1"

    def parse(self, file_path: Path) -> ExtractedContent:  # pragma: no cover - not exercised directly
        raise NotImplementedError


def test_extracted_content_character_count_matches_raw_text():
    content = ExtractedContent(raw_text="hello world", page_text=[(1, "hello world")], page_count=1)
    assert content.character_count == 11


def test_extracted_content_defaults_are_none_or_empty():
    content = ExtractedContent(raw_text="x", page_text=[(1, "x")], page_count=1)
    assert content.title is None
    assert content.author is None
    assert content.extra_metadata == {}


def test_base_parser_validate_output_passes_for_nonempty_text():
    content = ExtractedContent(raw_text="some content", page_text=[(1, "some content")], page_count=1)
    _MinimalParser().validate_output(content)  # does not raise


def test_base_parser_validate_output_raises_for_empty_text():
    content = ExtractedContent(raw_text="", page_text=[], page_count=0)
    with pytest.raises(EmptyDocumentError):
        _MinimalParser().validate_output(content)


def test_base_parser_validate_output_raises_for_whitespace_only_text():
    content = ExtractedContent(raw_text="   \n\n  ", page_text=[(1, "   ")], page_count=1)
    with pytest.raises(EmptyDocumentError):
        _MinimalParser().validate_output(content)


def test_base_parser_supports_defaults_to_false():
    assert BaseParser.supports("pdf") is False


class TestNormalizeWhitespace:
    def test_collapses_repeated_spaces(self):
        assert normalize_whitespace("hello    world") == "hello world"

    def test_collapses_excessive_blank_lines(self):
        result = normalize_whitespace("line one\n\n\n\n\nline two")
        assert result == "line one\n\nline two"

    def test_preserves_single_line_breaks(self):
        result = normalize_whitespace("line one\nline two")
        assert result == "line one\nline two"

    def test_strips_leading_and_trailing_whitespace(self):
        assert normalize_whitespace("   hello   ") == "hello"

    def test_empty_string_returns_empty_string(self):
        assert normalize_whitespace("") == ""


class TestTruncate:
    def test_short_text_is_unchanged(self):
        assert truncate("hello", 100) == "hello"

    def test_long_text_is_cut_with_marker(self):
        result = truncate("a" * 200, 50)
        assert len(result) <= 50 + len(" [...truncated]")
        assert result.endswith("[...truncated]")

    def test_exact_length_is_unchanged(self):
        text = "a" * 10
        assert truncate(text, 10) == text
