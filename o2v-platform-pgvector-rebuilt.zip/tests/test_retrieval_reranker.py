"""Unit tests for `src/retrieval/reranker.py`."""

import pytest

from src.embeddings.exceptions import ProviderUnavailableError
from src.retrieval.exceptions import RankingError
from src.retrieval.reranker import DeterministicReranker, available_rerankers, get_reranker
from src.retrieval.types import EvidenceCandidate, RetrievalConfig


def _candidate(chunk_id, text=None, **overrides) -> EvidenceCandidate:
    base = dict(
        chunk_id=chunk_id, document_id="doc-1", company_id="co-1", page_number=1,
        section_title="Overview", document_type="Annual Report", chunk_text=text or f"Text {chunk_id}.",
        semantic_score=0.5, lexical_score=0.5, metadata_score=0.5,
    )
    base.update(overrides)
    return EvidenceCandidate(**base)


def test_available_rerankers_includes_deterministic_and_placeholders():
    rerankers = available_rerankers()
    for expected in ["deterministic", "cross_encoder", "local_llm", "commercial_llm"]:
        assert expected in rerankers


def test_get_reranker_unknown_name_raises_ranking_error():
    with pytest.raises(RankingError):
        get_reranker("not_a_real_reranker")


def test_get_reranker_deterministic_returns_correct_class():
    reranker = get_reranker("deterministic")
    assert isinstance(reranker, DeterministicReranker)


@pytest.mark.parametrize("name", ["cross_encoder", "local_llm", "commercial_llm"])
def test_placeholder_rerankers_construct_and_raise_on_rerank(name):
    reranker = get_reranker(name)
    with pytest.raises(ProviderUnavailableError):
        reranker.rerank([[_candidate(1)]], config=RetrievalConfig())


def test_deterministic_reranker_merges_dedupes_scores_and_diversifies():
    config = RetrievalConfig(final_evidence_k=10, diversity_max_per_document=10, diversity_max_per_section=10)
    reranker = DeterministicReranker()

    list_a = [_candidate(1, semantic_score=0.9, lexical_score=0.1, metadata_score=1.0)]
    list_b = [_candidate(2, semantic_score=0.1, lexical_score=0.9, metadata_score=0.4)]
    result = reranker.rerank([list_a, list_b], config=config)

    assert len(result) == 2
    assert result[0].final_score >= result[1].final_score


def test_deterministic_reranker_drops_near_duplicate_text():
    config = RetrievalConfig(final_evidence_k=10, diversity_max_per_document=10, diversity_max_per_section=10)
    reranker = DeterministicReranker()

    list_a = [_candidate(1, text="Our purpose is clear.", semantic_score=0.9)]
    list_b = [_candidate(2, text="Our purpose is clear.", semantic_score=0.1)]
    result = reranker.rerank([list_a, list_b], config=config)

    assert len(result) == 1


def test_deterministic_reranker_respects_final_evidence_k():
    config = RetrievalConfig(final_evidence_k=1, diversity_max_per_document=10, diversity_max_per_section=10)
    reranker = DeterministicReranker()
    list_a = [_candidate(1), _candidate(2), _candidate(3)]
    result = reranker.rerank([list_a], config=config)
    assert len(result) == 1


def test_deterministic_reranker_empty_input_returns_empty():
    reranker = DeterministicReranker()
    assert reranker.rerank([], config=RetrievalConfig()) == []
    assert reranker.rerank([[]], config=RetrievalConfig()) == []
