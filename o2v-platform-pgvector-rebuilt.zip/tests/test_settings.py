"""
Tests for src/config/settings.py.

We test `Settings` directly (not the module-level cached `settings`
singleton) so each test gets a fresh instance unaffected by env vars other
tests may have touched — a subtlety worth calling out since `get_settings()`
is intentionally cached (see settings.py docstring) and bypassing that
cache is exactly what a test needs but production code never should.
"""

from src.config.settings import Settings
from src.core.constants import Environment


def test_default_environment_is_dev(monkeypatch):
    monkeypatch.delenv("ENVIRONMENT", raising=False)
    s = Settings(_env_file=None)
    assert s.environment == Environment.DEV
    assert s.is_prod is False


def test_database_url_is_assembled_from_components():
    s = Settings(
        _env_file=None,
        db_host="myhost",
        db_port=5433,
        db_name="mydb",
        db_user="myuser",
        db_password="mypass",
    )
    assert s.database_url == "postgresql+psycopg2://myuser:mypass@myhost:5433/mydb"


def test_database_url_percent_encodes_at_sign_in_password():
    """
    Regression test for a genuine bug hit on a real developer machine: a
    Windows Postgres password of 'Md@7378450856' produced the connection
    string 'postgresql://postgres:Md@7378450856@localhost:5432/db', which
    every URL parser reads as password='Md', host='7378450856@localhost'
    — a corrupted, silently-wrong connection target, surfaced only as a
    downstream 'could not translate host name' DNS-lookup error with no
    hint the actual problem was password encoding.
    """
    s = Settings(
        _env_file=None,
        db_host="localhost",
        db_port=5432,
        db_name="o2v_platform",
        db_user="postgres",
        db_password="Md@7378450856",
    )
    assert s.database_url == "postgresql+psycopg2://postgres:Md%407378450856@localhost:5432/o2v_platform"
    # The one thing that actually matters: the '@' from the password must
    # not appear as a second, unescaped '@' in the URL — every character
    # after "://user:" and before the FIRST unescaped '@' is the password.
    userinfo_and_host = s.database_url.split("://", 1)[1]
    assert userinfo_and_host.count("@") == 1


def test_database_url_percent_encodes_other_reserved_characters():
    """Same class of bug as the '@' case above, for the other characters reserved in URI syntax that a real password could plausibly contain."""
    s = Settings(
        _env_file=None,
        db_host="localhost",
        db_port=5432,
        db_name="mydb",
        db_user="my:user",
        db_password="p@ss/word#1%",
    )
    url = s.database_url
    # Round-trip check: SQLAlchemy must be able to parse this back into
    # the exact original credentials, not a corrupted host/path split.
    from sqlalchemy.engine import make_url

    parsed = make_url(url)
    assert parsed.username == "my:user"
    assert parsed.password == "p@ss/word#1%"
    assert parsed.host == "localhost"
    assert parsed.database == "mydb"


def test_prod_environment_flag():
    s = Settings(_env_file=None, environment=Environment.PROD)
    assert s.is_prod is True
