"""
Unit tests for the pure-function validation checks in
`src/chunking/validation.py`. `check_duplicate_chunking` requires a real
database session and is covered in `test_chunking_service.py` instead.
"""

from dataclasses import dataclass, field

import pytest

from src.chunking.base_chunker import ChunkCandidate, ChunkerConfig
from src.chunking.exceptions import EmptyDocumentTextError
from src.chunking.validation import (
    find_duplicate_chunk_warnings,
    raise_if_invalid,
    validate_chunk_candidates,
    validate_parsed_document_has_text,
)


@dataclass
class _FakeParsedDocument:
    id: int = 1
    raw_text: str = ""


def _candidate(
    text: str, index: int, page_number: int | None = 1, section_title: str | None = None
) -> ChunkCandidate:
    return ChunkCandidate(text=text, page_number=page_number, section_title=section_title, chunk_index=index)


# ---------------------------------------------------------------------------
# validate_parsed_document_has_text
# ---------------------------------------------------------------------------


def test_validate_parsed_document_has_text_passes_with_content():
    validate_parsed_document_has_text(_FakeParsedDocument(raw_text="Some real content."))


def test_validate_parsed_document_has_text_raises_on_empty_string():
    with pytest.raises(EmptyDocumentTextError):
        validate_parsed_document_has_text(_FakeParsedDocument(raw_text=""))


def test_validate_parsed_document_has_text_raises_on_whitespace_only():
    with pytest.raises(EmptyDocumentTextError):
        validate_parsed_document_has_text(_FakeParsedDocument(raw_text="   \n\n  "))


# ---------------------------------------------------------------------------
# validate_chunk_candidates
# ---------------------------------------------------------------------------


def test_validate_chunk_candidates_empty_list_no_problems():
    problems = validate_chunk_candidates([], config=ChunkerConfig(), page_count=None)
    assert problems == []


def test_validate_chunk_candidates_flags_empty_chunk_text():
    candidates = [_candidate("Real text.", 0), _candidate("   ", 1)]
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=None)
    assert any("empty chunk" in p for p in problems)


def test_validate_chunk_candidates_flags_oversized_chunk():
    config = ChunkerConfig(chunk_size=10, chunk_overlap=2, min_chunk_size=2, max_chunk_size=20)
    candidates = [_candidate("x" * 25, 0)]
    problems = validate_chunk_candidates(candidates, config=config, page_count=None)
    assert any("max_chunk_size" in p for p in problems)


def test_validate_chunk_candidates_flags_page_number_out_of_range():
    candidates = [_candidate("Some text.", 0, page_number=99)]
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=5)
    assert any("page" in p for p in problems)


def test_validate_chunk_candidates_ignores_page_range_when_page_count_unknown():
    candidates = [_candidate("Some text.", 0, page_number=99)]
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=None)
    assert problems == []


def test_validate_chunk_candidates_no_longer_flags_duplicate_text():
    """
    Duplicate-text detection moved out of the fatal `validate_chunk_candidates`
    path entirely — see `find_duplicate_chunk_warnings` below and its
    docstring in validation.py for why. A substantial verbatim duplicate
    is no longer, by itself, grounds to reject a whole chunk set.
    """
    long_text = "Identical substantial chunk text. " * 5
    candidates = [_candidate(long_text, 0), _candidate(long_text, 1)]
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=None)
    assert problems == []


def test_find_duplicate_chunk_warnings_flags_substantial_duplicate_text():
    long_text = "Identical substantial chunk text. " * 5  # well over default min_chunk_size=100
    candidates = [_candidate(long_text, 0), _candidate(long_text, 1)]
    warnings = find_duplicate_chunk_warnings(candidates, ChunkerConfig())
    assert any("duplicat" in w for w in warnings)


def test_find_duplicate_chunk_warnings_ignores_short_duplicate_text():
    """
    Regression test for a genuine bug found against real SEC EDGAR
    filings: a 300K-character Apple proxy statement produced 2,202
    flagged 'duplicates' that turned out to be repeated page numbers
    ('19', '25') and section headings appearing in both a Table of
    Contents and the body — 99.5% of them under 200 characters, none
    over 1000. That's ordinary pagination artifact, not worth flagging
    even as a warning.
    """
    config = ChunkerConfig()  # default min_chunk_size=100
    candidates = [_candidate("19", 0), _candidate("Shareholder Engagement", 1), _candidate("19", 2)]
    warnings = find_duplicate_chunk_warnings(candidates, config)
    assert warnings == []


def test_find_duplicate_chunk_warnings_still_flags_duplicate_right_at_min_chunk_size_boundary():
    config = ChunkerConfig(min_chunk_size=50)
    exact_boundary_text = "x" * 50
    candidates = [_candidate(exact_boundary_text, 0), _candidate(exact_boundary_text, 1)]
    warnings = find_duplicate_chunk_warnings(candidates, config)
    assert any("duplicat" in w for w in warnings)


def test_find_duplicate_chunk_warnings_mix_of_short_and_long_duplicates_only_flags_long():
    config = ChunkerConfig()  # default min_chunk_size=100
    long_text = "Identical substantial chunk text. " * 5
    candidates = [
        _candidate("19", 0),
        _candidate(long_text, 1),
        _candidate("19", 2),
        _candidate(long_text, 3),
    ]
    warnings = find_duplicate_chunk_warnings(candidates, config)
    assert len(warnings) == 1
    assert "chunk 3 duplicates chunk 1" in warnings[0]
    assert "chunk 2 duplicates chunk 0" not in warnings[0]  # the short '19' pair must not appear


def test_find_duplicate_chunk_warnings_real_world_legitimate_repeated_content_not_a_bug_signal():
    """
    Regression test for real content pulled from an actual Apple proxy
    statement: a full sentence describing the Audit Committee's role
    appeared verbatim in both an 'Audit Committee' summary section and
    the detailed 'Audit and Finance Committee Report' section — 110
    characters, well above min_chunk_size, and genuinely legitimate
    document structure, not a chunker defect. This documents that such
    text is still detected (for logging/review) but is not, by itself,
    evidence of a bug worth failing the chunk set over — that decision
    is made at the call site (service.py logs it as a warning, doesn't
    raise), not inside this function.
    """
    real_sentence = (
        "Apple\u2019s financial statements and other financial information "
        "provided by Apple to its shareholders and others;"
    )
    candidates = [
        _candidate(real_sentence, 0, page_number=1, section_title="Audit Committee"),
        _candidate(real_sentence, 1, page_number=1, section_title="Audit and Finance Committee Report"),
    ]
    warnings = find_duplicate_chunk_warnings(candidates, ChunkerConfig())
    assert any("duplicat" in w for w in warnings)  # still detected/loggable...
    # ...but validate_chunk_candidates (the fatal path) doesn't see it at all:
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=None)
    assert problems == []


def test_validate_chunk_candidates_valid_set_has_no_problems():
    candidates = [_candidate("First unique chunk.", 0), _candidate("Second unique chunk.", 1)]
    problems = validate_chunk_candidates(candidates, config=ChunkerConfig(), page_count=10)
    assert problems == []


def test_raise_if_invalid_raises_when_problems_present():
    from src.chunking.exceptions import ChunkValidationError

    with pytest.raises(ChunkValidationError):
        raise_if_invalid(["something is wrong"])


def test_raise_if_invalid_no_op_when_no_problems():
    raise_if_invalid([])  # should not raise
