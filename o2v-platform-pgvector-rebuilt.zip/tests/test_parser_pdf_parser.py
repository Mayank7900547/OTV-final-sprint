"""
Unit tests for `src/parser/pdf_parser.py`.

Design decision: fixtures build REAL PDF bytes via `reportlab` (a
test-only dependency, see requirements.txt) rather than hand-crafting
minimal PDF byte strings. A hand-rolled `%PDF-1.4...%%EOF` stub (the
pattern `test_acquisition_integrity.py` uses for magic-byte validation) is
fine for "is this a PDF at all" checks, but `pypdf` needs a structurally
real PDF (xref table, page tree, content streams) to exercise actual text
extraction — that's what these tests are for.
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

import pytest
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas

from src.parser.exceptions import (
    EmptyDocumentError,
    EncryptedDocumentError,
    MalformedDocumentError,
)
from src.parser.pdf_parser import PDFParser


def _make_pdf(
    tmp_path: Path,
    filename: str = "doc.pdf",
    *,
    pages: list[str] | None = None,
    title: str | None = None,
    author: str | None = None,
    subject: str | None = None,
) -> Path:
    """Write a real multi-page PDF with the given per-page text and metadata."""
    pages = pages if pages is not None else ["Hello world. This is page one."]
    buffer = BytesIO()
    c = canvas.Canvas(buffer)
    if title:
        c.setTitle(title)
    if author:
        c.setAuthor(author)
    if subject:
        c.setSubject(subject)
    for text in pages:
        c.drawString(72, 720, text)
        c.showPage()
    c.save()

    path = tmp_path / filename
    path.write_bytes(buffer.getvalue())
    return path


def _make_encrypted_pdf(tmp_path: Path, filename: str = "encrypted.pdf") -> Path:
    plain = _make_pdf(tmp_path, "plain_for_encryption.pdf", pages=["Secret content."])
    reader = PdfReader(str(plain))
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.encrypt(user_password="s3cret", owner_password="0wner")
    path = tmp_path / filename
    with open(path, "wb") as fh:
        writer.write(fh)
    return path


def _make_empty_pdf(tmp_path: Path, filename: str = "empty.pdf") -> Path:
    """A structurally valid PDF with a single blank page — no text objects at all."""
    buffer = BytesIO()
    c = canvas.Canvas(buffer)
    c.showPage()
    c.save()
    path = tmp_path / filename
    path.write_bytes(buffer.getvalue())
    return path


def _make_malformed_pdf(tmp_path: Path, filename: str = "malformed.pdf") -> Path:
    path = tmp_path / filename
    path.write_bytes(b"%PDF-1.4\nthis is not a real xref table or page tree\n%%EOF")
    return path


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_parse_extracts_text_and_preserves_page_order(tmp_path):
    path = _make_pdf(tmp_path, pages=["First page content.", "Second page content."])
    parser = PDFParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.page_count == 2
    assert len(content.page_text) == 2
    assert content.page_text[0][0] == 1
    assert content.page_text[1][0] == 2
    assert "First page content" in content.page_text[0][1]
    assert "Second page content" in content.page_text[1][1]
    assert "First page content" in content.raw_text
    assert "Second page content" in content.raw_text


def test_parse_extracts_metadata_fields(tmp_path):
    path = _make_pdf(
        tmp_path,
        pages=["Body text."],
        title="Annual Report 2024",
        author="Acme Corp",
        subject="Financial Results",
    )
    parser = PDFParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.title == "Annual Report 2024"
    assert content.author == "Acme Corp"
    assert content.subject == "Financial Results"
    assert content.producer is not None  # reportlab always sets a Producer


def test_parse_reports_correct_page_count(tmp_path):
    path = _make_pdf(tmp_path, pages=["p1", "p2", "p3", "p4"])
    parser = PDFParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.page_count == 4


def test_character_count_matches_raw_text_length(tmp_path):
    path = _make_pdf(tmp_path, pages=["Some text."])
    parser = PDFParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.character_count == len(content.raw_text)


# ---------------------------------------------------------------------------
# max_pages truncation
# ---------------------------------------------------------------------------


def test_max_pages_truncates_extraction(tmp_path):
    path = _make_pdf(tmp_path, pages=["p1", "p2", "p3", "p4", "p5"])
    parser = PDFParser(language_detection_enabled=False, max_pages=2)

    content = parser.parse(path)

    assert len(content.page_text) == 2
    # page_count still reports the document's TRUE page count — only the
    # extraction was truncated, not the reported metadata.
    assert content.page_count == 5


# ---------------------------------------------------------------------------
# Edge cases: encrypted / malformed / empty
# ---------------------------------------------------------------------------


def test_parse_encrypted_pdf_raises_encrypted_document_error(tmp_path):
    path = _make_encrypted_pdf(tmp_path)
    parser = PDFParser(language_detection_enabled=False)

    with pytest.raises(EncryptedDocumentError):
        parser.parse(path)


def test_parse_malformed_pdf_raises_malformed_document_error(tmp_path):
    path = _make_malformed_pdf(tmp_path)
    parser = PDFParser(language_detection_enabled=False)

    with pytest.raises(MalformedDocumentError):
        parser.parse(path)


def test_parse_raises_malformed_document_error_when_is_encrypted_check_itself_fails(tmp_path, monkeypatch):
    """
    Regression test — found via a real batch run (5 companies), not
    written speculatively: `reader.is_encrypted` internally raised an
    unguarded `AttributeError: 'NoneType' object has no attribute 'get'`
    on a handful of real-world PDFs (a known pypdf edge case with
    unusual /Encrypt structures), which crashed the ENTIRE parsing
    stage for that company — not just that one document — since
    `parse_many`'s `ThreadPoolExecutor.map()` re-raises on the first
    failing document in submission order, silently dropping every
    document queued after it, even ones that would have parsed fine.
    This confirms is_encrypted is now wrapped the same way every other
    risky `reader.*` access in this file already is.
    """
    path = tmp_path / "looks_fine_but_is_encrypted_check_crashes.pdf"
    path.write_bytes(b"%PDF-1.4 minimal placeholder bytes")

    class ReaderWhoseIsEncryptedCrashes:
        @property
        def is_encrypted(self):
            raise AttributeError("'NoneType' object has no attribute 'get'")

    monkeypatch.setattr(
        "src.parser.pdf_parser.PdfReader", lambda _path: ReaderWhoseIsEncryptedCrashes()
    )
    parser = PDFParser(language_detection_enabled=False)

    with pytest.raises(MalformedDocumentError, match="encryption metadata"):
        parser.parse(path)


def test_parse_empty_pdf_raises_empty_document_error(tmp_path):
    path = _make_empty_pdf(tmp_path)
    parser = PDFParser(language_detection_enabled=False)

    with pytest.raises(EmptyDocumentError):
        parser.parse(path)


def test_parse_nonexistent_file_raises_malformed_document_error(tmp_path):
    parser = PDFParser(language_detection_enabled=False)

    with pytest.raises(MalformedDocumentError):
        parser.parse(tmp_path / "does_not_exist.pdf")


# ---------------------------------------------------------------------------
# supports()
# ---------------------------------------------------------------------------


def test_supports_pdf_type_only():
    assert PDFParser.supports("pdf") is True
    assert PDFParser.supports("html") is False
    assert PDFParser.supports("docx") is False
