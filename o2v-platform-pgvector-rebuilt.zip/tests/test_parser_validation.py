"""
Tests for `src/parser/validation.py`.

`validate_document_version_active`, `validate_file_readable`,
`validate_page_count`, and `validate_metadata_consistency` are pure
functions and are tested directly. `check_duplicate_parsing` needs a real
database (it queries `ParsedDocument`), so it uses the `db_session`
fixture and is skipped automatically if no test database is reachable —
same contract as every other DB-backed test module in this suite (see
conftest.py's module docstring).
"""

from __future__ import annotations

import uuid

import pytest

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.exceptions import (
    DocumentNotActiveError,
    DuplicateParsingError,
    MalformedDocumentError,
    ParsingValidationError,
)
from src.parser.models import ParsedDocument, ParsingStatusEnum
from src.parser.validation import (
    check_duplicate_parsing,
    validate_document_version_active,
    validate_file_readable,
    validate_metadata_consistency,
    validate_page_count,
)


def _version(status: DocumentVersionStatusEnum) -> DocumentVersion:
    return DocumentVersion(
        document_id=uuid.uuid4(),
        version_number=1,
        file_hash="a" * 64,
        storage_path="/tmp/does-not-matter.pdf",
        file_size=1024,
        status=status,
    )


def _make_real_document_version(session) -> DocumentVersion:
    """
    Create a real, persisted Company -> DocumentRegistry -> DocumentVersion
    chain. `check_duplicate_parsing`'s DB-backed tests need an actual row
    here, not a fabricated id — `ParsedDocument.document_version_id` has a
    foreign key to `document_versions.id`, so inserting a `ParsedDocument`
    against an id that was never created violates that constraint.
    """
    company = Company(name=f"Acme {uuid.uuid4()}", status="pending")
    session.add(company)
    session.flush()

    document = DocumentRegistry(
        company_id=company.id,
        document_name="Annual Report",
        document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value,
        document_year=2024,
        official_url=f"https://acme.com/{uuid.uuid4()}.pdf",
        source_domain="acme.com",
        discovery_method="sitemap_crawl",
        status=DocumentStatus.DISCOVERED.value,
    )
    session.add(document)
    session.flush()

    version = DocumentVersion(
        document_id=document.id,
        version_number=1,
        file_hash="a" * 64,
        storage_path="/tmp/does-not-matter.pdf",
        file_size=1024,
        status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()
    return version


# ---------------------------------------------------------------------------
# validate_document_version_active
# ---------------------------------------------------------------------------


def test_active_version_passes():
    validate_document_version_active(_version(DocumentVersionStatusEnum.ACTIVE))  # does not raise


def test_archived_version_raises():
    with pytest.raises(DocumentNotActiveError):
        validate_document_version_active(_version(DocumentVersionStatusEnum.ARCHIVED))


def test_corrupted_version_raises():
    with pytest.raises(DocumentNotActiveError):
        validate_document_version_active(_version(DocumentVersionStatusEnum.CORRUPTED))


# ---------------------------------------------------------------------------
# validate_file_readable
# ---------------------------------------------------------------------------


def test_file_readable_returns_path_for_existing_nonempty_file(tmp_path):
    f = tmp_path / "doc.pdf"
    f.write_bytes(b"%PDF-1.4\ncontent\n%%EOF")

    result = validate_file_readable(str(f))

    assert result == f


def test_file_readable_raises_for_missing_file(tmp_path):
    with pytest.raises(MalformedDocumentError):
        validate_file_readable(str(tmp_path / "missing.pdf"))


def test_file_readable_raises_for_empty_file(tmp_path):
    f = tmp_path / "empty.pdf"
    f.write_bytes(b"")

    with pytest.raises(MalformedDocumentError):
        validate_file_readable(str(f))


def test_file_readable_raises_for_directory(tmp_path):
    d = tmp_path / "a_directory.pdf"
    d.mkdir()

    with pytest.raises(MalformedDocumentError):
        validate_file_readable(str(d))


# ---------------------------------------------------------------------------
# validate_page_count
# ---------------------------------------------------------------------------


def test_page_count_none_is_valid():
    validate_page_count(None)  # does not raise


def test_page_count_zero_is_valid():
    validate_page_count(0)  # does not raise


def test_page_count_positive_is_valid():
    validate_page_count(42)  # does not raise


def test_page_count_negative_raises():
    with pytest.raises(ParsingValidationError):
        validate_page_count(-1)


# ---------------------------------------------------------------------------
# validate_metadata_consistency
# ---------------------------------------------------------------------------


def test_metadata_consistency_matching_counts_passes():
    validate_metadata_consistency(page_count=3, page_text_len=3)  # does not raise


def test_metadata_consistency_none_page_count_skips_check():
    validate_metadata_consistency(page_count=None, page_text_len=0)  # does not raise


def test_metadata_consistency_zero_page_count_skips_check():
    validate_metadata_consistency(page_count=0, page_text_len=0)  # does not raise


def test_metadata_consistency_mismatch_raises():
    with pytest.raises(ParsingValidationError):
        validate_metadata_consistency(page_count=5, page_text_len=3)


# ---------------------------------------------------------------------------
# check_duplicate_parsing (DB-backed)
# ---------------------------------------------------------------------------


def test_check_duplicate_parsing_returns_none_when_never_parsed(db_session):
    result = check_duplicate_parsing(db_session, document_version_id=999999, force=False)
    assert result is None


def test_check_duplicate_parsing_raises_when_already_parsed_and_not_forced(db_session):
    version = _make_real_document_version(db_session)
    row = ParsedDocument(
        document_id=version.document_id,
        document_version_id=version.id,
        parser_used="pdf_parser",
        parser_version="1.0.0",
        document_type="pdf",
        raw_text="some text",
        character_count=9,
        status=ParsingStatusEnum.SUCCESS,
    )
    db_session.add(row)
    db_session.flush()

    with pytest.raises(DuplicateParsingError):
        check_duplicate_parsing(db_session, document_version_id=version.id, force=False)


def test_check_duplicate_parsing_returns_existing_row_when_forced(db_session):
    version = _make_real_document_version(db_session)
    row = ParsedDocument(
        document_id=version.document_id,
        document_version_id=version.id,
        parser_used="pdf_parser",
        parser_version="1.0.0",
        document_type="pdf",
        raw_text="some text",
        character_count=9,
        status=ParsingStatusEnum.SUCCESS,
    )
    db_session.add(row)
    db_session.flush()

    result = check_duplicate_parsing(db_session, document_version_id=version.id, force=True)

    assert result is not None
    assert result.id == row.id
