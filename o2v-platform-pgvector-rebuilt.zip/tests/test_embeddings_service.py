"""
Integration tests for `src/embeddings/embedding_service.py`
(EmbeddingGenerationService). Requires a real Postgres test database —
skipped automatically if unreachable. Uses a fake `BaseEmbeddingProvider`
throughout (no network / no OpenAI API key needed) — the real
`OpenAIEmbeddingProvider` is unit-tested separately in
`test_embeddings_factory.py`.

Uses the same SAVEPOINT-based session fixture `test_chunking_service.py`
established, since `EmbeddingGenerationService` calls `session.commit()`
internally.
"""

from __future__ import annotations

import time
import uuid

import pytest
from sqlalchemy import event
from sqlalchemy.orm import sessionmaker

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.models import Chunk
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.embedding_service import EmbeddingGenerationService
from src.embeddings.exceptions import ProviderUnavailableError
from src.embeddings.models import Embedding, EmbeddingHistory, EmbeddingStatusEnum
from src.embeddings.telemetry import telemetry as embedding_telemetry
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum

# Import so the tables register on Base.metadata, same requirement as conftest.py.
from src.embeddings import models as _embeddings_models_module  # noqa: F401


@pytest.fixture
def embedding_session(_test_engine):
    """SAVEPOINT-based session fixture — see module docstring."""
    connection = _test_engine.connect()
    outer_transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()
    session.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def _restart_savepoint(sess, trans):
        if trans.nested and not trans._parent.nested:
            sess.begin_nested()

    yield session

    session.close()
    outer_transaction.rollback()
    connection.close()


@pytest.fixture(autouse=True)
def _reset_telemetry():
    embedding_telemetry.reset()
    yield
    embedding_telemetry.reset()


# ---------------------------------------------------------------------------
# Fake provider — deterministic, no network
# ---------------------------------------------------------------------------


class _FakeProvider(BaseEmbeddingProvider):
    provider_name = "fake"

    def __init__(self, *, model_name="fake-model", model_version="1", embedding_dimension=4, fail_times=0):
        super().__init__(model_name=model_name, model_version=model_version, embedding_dimension=embedding_dimension)
        self._fail_times = fail_times
        self._calls = 0
        self.batches_seen: list[list[str]] = []

    def embed_batch(self, texts):
        self._calls += 1
        self.batches_seen.append(list(texts))
        if self._calls <= self._fail_times:
            raise ProviderUnavailableError("simulated transient failure")
        return [[float(len(t))] * self.embedding_dimension for t in texts]

    def health_check(self, timeout=None):
        """Always healthy, independent of fail_times/batches_seen — keeps pre-flight-check plumbing from silently consuming a scripted failure or polluting call-count assertions in tests that aren't about the health check itself."""
        return True


class _AlwaysFailsProvider(BaseEmbeddingProvider):
    provider_name = "fake_broken"

    def embed_batch(self, texts):
        raise ProviderUnavailableError("permanently unavailable")

    def health_check(self, timeout=None):
        """Reports healthy even though embed_batch always raises — so existing tests exercising the retry/FAILED path via _embed_batch aren't short-circuited by the new pre-flight check. See _UnhealthyProvider for the case that tests the health check itself."""
        return True


class _UnhealthyProvider(BaseEmbeddingProvider):
    """Reports unhealthy without ever being asked to embed_batch() — for testing the pre-flight health check itself."""

    provider_name = "fake_unhealthy"

    def __init__(self, *, model_name="fake-model", model_version="1", embedding_dimension=4):
        super().__init__(model_name=model_name, model_version=model_version, embedding_dimension=embedding_dimension)
        self.embed_batch_calls = 0

    def embed_batch(self, texts):
        self.embed_batch_calls += 1
        raise AssertionError("embed_batch() should never be called when health_check() returns False")

    def health_check(self, timeout=None):
        return False


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _make_company(session, name="Acme Corp"):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company):
    doc = DocumentRegistry(
        company_id=company.id, document_name="Annual Report", document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value, document_year=2024,
        official_url=f"https://acme.com/{uuid.uuid4()}.pdf", source_domain="acme.com",
        discovery_method="sitemap_crawl", status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _make_version(session, document, tmp_path, *, version_number=1):
    path = tmp_path / f"report_{version_number}.pdf"
    path.write_bytes(b"%PDF-1.4 fake content")
    version = DocumentVersion(
        document_id=document.id, version_number=version_number, file_hash="d" * 64,
        storage_path=str(path), file_size=path.stat().st_size, status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()
    return version


def _make_parsed_document(session, document, version, *, raw_text="Default paragraph text for testing."):
    row = ParsedDocument(
        document_id=document.id, document_version_id=version.id, parser_used="pdf_parser", parser_version="1.0.0",
        document_type=DocumentType.PDF.value, page_count=1, raw_text=raw_text,
        page_text=[{"page_number": 1, "text": raw_text}], character_count=len(raw_text), status=ParsingStatusEnum.SUCCESS,
    )
    session.add(row)
    session.flush()
    return row


def _make_chunk(session, document, version, parsed, *, text="Default chunk text.", chunk_index=0):
    chunk = Chunk(
        chunk_id=f"{version.id}:{chunk_index}", document_id=document.id, document_version_id=version.id,
        parsed_document_id=parsed.id, chunk_index=chunk_index, page_number=1, section_title=None,
        text=text, character_count=len(text), token_estimate=max(1, len(text) // 4),
        chunker_used="recursive_chunker", chunker_version="1.0.0",
    )
    session.add(chunk)
    session.flush()
    return chunk


def _make_scenario(session, tmp_path, *, company_name="Acme Corp", texts=("Default chunk text.",)):
    company = _make_company(session, name=company_name)
    document = _make_document(session, company)
    version = _make_version(session, document, tmp_path)
    parsed = _make_parsed_document(session, document, version)
    chunks = [_make_chunk(session, document, version, parsed, text=t, chunk_index=i) for i, t in enumerate(texts)]
    return company, document, version, chunks


# ---------------------------------------------------------------------------
# embed_chunk / embed_chunks — happy path
# ---------------------------------------------------------------------------


def test_embed_chunk_success_persists_embedding(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path, texts=("Some chunk text here.",))
    chunk = chunks[0]

    service = EmbeddingGenerationService(provider=_FakeProvider())
    outcome = service.embed_chunk(embedding_session, chunk.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["embedding_dimension"] == 4

    rows = embedding_session.query(Embedding).filter(Embedding.chunk_id == chunk.id).all()
    assert len(rows) == 1
    assert rows[0].status == EmbeddingStatusEnum.ACTIVE
    assert rows[0].embedding_vector == [len("Some chunk text here."), len("Some chunk text here."), len("Some chunk text here."), len("Some chunk text here.")]
    assert rows[0].provider == "fake"
    assert rows[0].chunk_id == chunk.id


def test_embed_chunk_records_embedding_history(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())
    service.embed_chunk(embedding_session, chunks[0].id)

    history = embedding_session.query(EmbeddingHistory).filter(EmbeddingHistory.chunk_id == chunks[0].id).all()
    assert len(history) == 1
    assert history[0].run_status.value == "SUCCESS"
    assert history[0].attempt_number == 1


def test_embed_chunk_stores_required_vector_metadata(embedding_session, tmp_path):
    _, document, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())
    service.embed_chunk(embedding_session, chunks[0].id)

    row = embedding_session.query(Embedding).filter(Embedding.chunk_id == chunks[0].id).first()
    assert row.embedding_metadata["company"] == "Acme Corp"
    assert row.embedding_metadata["document_id"] == str(document.id)
    assert row.embedding_metadata["chunk_id"] == chunks[0].chunk_id
    assert row.embedding_metadata["chunk_index"] == 0
    assert row.embedding_metadata["document_type"] == DocumentType.PDF.value


def test_embed_chunks_batches_multiple_chunks_into_one_provider_call(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path, texts=("First chunk.", "Second chunk.", "Third chunk."))
    provider = _FakeProvider()
    service = EmbeddingGenerationService(provider=provider)

    outcomes = service.embed_chunks(embedding_session, [c.id for c in chunks])

    assert all(o["status"] == "SUCCESS" for o in outcomes)
    assert len(provider.batches_seen) == 1  # all 3 chunks fit in one batch (well under default batch_size)
    assert len(provider.batches_seen[0]) == 3


# ---------------------------------------------------------------------------
# embed_chunk — not found / empty text
# ---------------------------------------------------------------------------


def test_embed_chunk_returns_failed_for_unknown_id(embedding_session):
    service = EmbeddingGenerationService(provider=_FakeProvider())
    outcome = service.embed_chunk(embedding_session, 999_999_999)
    assert outcome["status"] == "FAILED"
    assert "not found" in outcome["error"].lower()


def test_embed_chunk_fails_for_empty_text(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path, texts=("Real text so Chunk validation passes.",))
    chunk = chunks[0]
    chunk.text = ""  # simulate an edge case bypassing Sprint 5's own validation
    embedding_session.flush()

    service = EmbeddingGenerationService(provider=_FakeProvider())
    outcome = service.embed_chunk(embedding_session, chunk.id)

    assert outcome["status"] == "FAILED"
    assert "no text" in outcome["error"].lower()


# ---------------------------------------------------------------------------
# Duplicate / versioning
# ---------------------------------------------------------------------------


def test_embed_chunk_skipped_on_second_call_without_force(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())

    first = service.embed_chunk(embedding_session, chunks[0].id)
    second = service.embed_chunk(embedding_session, chunks[0].id)

    assert first["status"] == "SUCCESS"
    assert second["status"] == "SKIPPED"

    active_count = (
        embedding_session.query(Embedding)
        .filter(Embedding.chunk_id == chunks[0].id, Embedding.status == EmbeddingStatusEnum.ACTIVE)
        .count()
    )
    assert active_count == 1


def test_embed_chunk_force_supersedes_old_embedding_and_creates_new_active_one(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())

    first = service.embed_chunk(embedding_session, chunks[0].id)
    second = service.embed_chunk(embedding_session, chunks[0].id, force=True)

    assert first["status"] == "SUCCESS"
    assert second["status"] == "SUCCESS"
    assert first["embedding_id"] != second["embedding_id"]

    rows = embedding_session.query(Embedding).filter(Embedding.chunk_id == chunks[0].id).all()
    assert len(rows) == 2

    active_rows = [r for r in rows if r.status == EmbeddingStatusEnum.ACTIVE]
    superseded_rows = [r for r in rows if r.status == EmbeddingStatusEnum.SUPERSEDED]
    assert len(active_rows) == 1  # no duplicate active embeddings for the same chunk
    assert len(superseded_rows) == 1
    assert active_rows[0].id == second["embedding_id"]


def test_no_duplicate_active_embeddings_enforced_at_db_level(embedding_session, tmp_path):
    """The partial unique index (uq_embedding_active_per_chunk) is a belt-and-suspenders backstop
    behind the service-layer check — this test exercises the service path, which is what actually
    guarantees the invariant in normal operation."""
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())
    service.embed_chunk(embedding_session, chunks[0].id)
    service.embed_chunk(embedding_session, chunks[0].id, force=True)
    service.embed_chunk(embedding_session, chunks[0].id, force=True)

    active_count = (
        embedding_session.query(Embedding)
        .filter(Embedding.chunk_id == chunks[0].id, Embedding.status == EmbeddingStatusEnum.ACTIVE)
        .count()
    )
    assert active_count == 1


# ---------------------------------------------------------------------------
# Failure / retry
# ---------------------------------------------------------------------------


def test_embed_chunk_retries_transient_provider_failures_then_succeeds(embedding_session, tmp_path, monkeypatch):
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_retry_backoff_seconds", 0.0)
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    provider = _FakeProvider(fail_times=2)  # fails twice, succeeds on the 3rd attempt
    service = EmbeddingGenerationService(provider=provider)

    outcome = service.embed_chunk(embedding_session, chunks[0].id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["retries"] == 2


def test_embed_chunk_fails_after_exhausting_retries(embedding_session, tmp_path, monkeypatch):
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_retry_backoff_seconds", 0.0)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_retry_limit", 1)
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_AlwaysFailsProvider(model_name="m", model_version="1", embedding_dimension=4))

    outcome = service.embed_chunk(embedding_session, chunks[0].id)

    assert outcome["status"] == "FAILED"
    assert "permanently unavailable" in outcome["error"]

    history = embedding_session.query(EmbeddingHistory).filter(EmbeddingHistory.chunk_id == chunks[0].id).all()
    assert len(history) == 1
    assert history[0].run_status.value == "FAILED"
    assert history[0].retries == 1  # embeddings_retry_limit monkeypatched to 1 above

    assert embedding_session.query(Embedding).filter(Embedding.chunk_id == chunks[0].id).count() == 0


def test_load_failed_chunk_ids_includes_permanently_failed_chunk(embedding_session, tmp_path, monkeypatch):
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_retry_backoff_seconds", 0.0)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_retry_limit", 0)
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_AlwaysFailsProvider(model_name="m", model_version="1", embedding_dimension=4))
    service.embed_chunk(embedding_session, chunks[0].id)

    ids = service.load_failed_chunk_ids(embedding_session)
    assert chunks[0].id in ids


def test_load_failed_chunk_ids_excludes_successfully_embedded_chunk(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path)
    service = EmbeddingGenerationService(provider=_FakeProvider())
    service.embed_chunk(embedding_session, chunks[0].id)

    ids = service.load_failed_chunk_ids(embedding_session)
    assert chunks[0].id not in ids


# ---------------------------------------------------------------------------
# load_eligible_chunk_ids
# ---------------------------------------------------------------------------


def test_load_eligible_chunk_ids_returns_all_chunks(embedding_session, tmp_path):
    _, _, _, chunks = _make_scenario(embedding_session, tmp_path, texts=("A.", "B."))
    service = EmbeddingGenerationService(provider=_FakeProvider())
    ids = service.load_eligible_chunk_ids(embedding_session)
    for chunk in chunks:
        assert chunk.id in ids


def test_load_eligible_chunk_ids_filters_by_company(embedding_session, tmp_path):
    _, _, _, chunks_a = _make_scenario(embedding_session, tmp_path, company_name="Alpha Corp")
    _, _, _, chunks_b = _make_scenario(embedding_session, tmp_path, company_name="Beta Corp")

    service = EmbeddingGenerationService(provider=_FakeProvider())
    ids = service.load_eligible_chunk_ids(embedding_session, company_filter="Alpha")

    assert chunks_a[0].id in ids
    assert chunks_b[0].id not in ids


# ---------------------------------------------------------------------------
# embed_many — concurrent batches
# ---------------------------------------------------------------------------


def test_embed_many_processes_all_chunks_across_batches(_test_engine, tmp_path, monkeypatch):
    """
    Exercises the real thread-pool path (`embed_many`), which needs a
    `session_factory` producing INDEPENDENT, COMMITTING sessions per
    worker thread — the SAVEPOINT-per-test fixture used everywhere else
    in this file is intentionally single-session and can't support that.
    Uses a sessionmaker bound directly to the isolated `_test_engine`
    (never the real `o2v_platform` database `session_scope` points at),
    with explicit cleanup at the end since these commits aren't rolled
    back automatically.
    """
    from contextlib import contextmanager

    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_batch_size", 2)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_max_concurrent_requests", 2)

    TestSessionLocal = sessionmaker(bind=_test_engine, future=True)

    @contextmanager
    def test_session_scope():
        session = TestSessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    company_name = f"Batch Co {uuid.uuid4()}"
    with test_session_scope() as setup_session:
        _, _, _, chunks = _make_scenario(
            setup_session, tmp_path, company_name=company_name,
            texts=("Chunk one.", "Chunk two.", "Chunk three.", "Chunk four.", "Chunk five."),
        )
        chunk_ids = [c.id for c in chunks]

    try:
        service = EmbeddingGenerationService(provider=_FakeProvider())
        outcomes = service.embed_many(test_session_scope, chunk_ids)

        assert len(outcomes) == 5
        assert all(o["status"] == "SUCCESS" for o in outcomes)

        with test_session_scope() as verify_session:
            count = verify_session.query(Embedding).filter(Embedding.chunk_id.in_(chunk_ids)).count()
            assert count == 5
    finally:
        # Explicit cleanup — this test's commits bypass the usual
        # SAVEPOINT-rollback isolation every other test in this file relies on.
        with test_session_scope() as cleanup_session:
            cleanup_session.query(Embedding).filter(Embedding.chunk_id.in_(chunk_ids)).delete(synchronize_session=False)
            cleanup_session.query(EmbeddingHistory).filter(EmbeddingHistory.chunk_id.in_(chunk_ids)).delete(synchronize_session=False)
            cleanup_session.query(Chunk).filter(Chunk.id.in_(chunk_ids)).delete(synchronize_session=False)
            company = cleanup_session.query(Company).filter(Company.name == company_name).first()
            if company:
                document = cleanup_session.query(DocumentRegistry).filter(DocumentRegistry.company_id == company.id).first()
                if document:
                    cleanup_session.query(ParsedDocument).filter(ParsedDocument.document_id == document.id).delete(synchronize_session=False)
                    cleanup_session.query(DocumentVersion).filter(DocumentVersion.document_id == document.id).delete(synchronize_session=False)
                    cleanup_session.query(DocumentRegistry).filter(DocumentRegistry.id == document.id).delete(synchronize_session=False)
                cleanup_session.query(Company).filter(Company.id == company.id).delete(synchronize_session=False)


# ---------------------------------------------------------------------------
# embed_many — pre-flight health check and circuit breaker
# (added after a real overnight run where every batch timed out against a
# resource-starved local Ollama server, taking hours to discover)
#
# These use a trivial fake session_factory rather than a real DB — the
# circuit-breaker/health-check control flow lives entirely in embed_many's
# handling of outcome dicts, not in _embed_batch's persistence logic
# (already covered by the tests above), so mocking _embed_batch directly
# keeps these tests fast and focused on the thing they're actually testing.
# ---------------------------------------------------------------------------

import contextlib


@contextlib.contextmanager
def _noop_session_factory():
    """A session_factory that never touches a real session — valid here because _embed_batch itself is monkeypatched out in every test below."""
    yield None


def test_embed_many_skips_everything_when_health_check_fails():
    provider = _UnhealthyProvider()
    service = EmbeddingGenerationService(provider=provider)

    outcomes = service.embed_many(_noop_session_factory, [1, 2, 3])

    assert len(outcomes) == 3
    assert all(o["status"] == "FAILED" for o in outcomes)
    assert all("health check" in o["error"].lower() for o in outcomes)
    assert provider.embed_batch_calls == 0  # never even attempted a real batch


def test_embed_many_proceeds_normally_when_health_check_passes(monkeypatch):
    """Sanity check that a healthy provider isn't accidentally blocked by the new pre-flight check."""
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_batch_size", 10)
    provider = _FakeProvider()  # health_check() -> True, per the override above
    service = EmbeddingGenerationService(provider=provider)
    monkeypatch.setattr(
        service, "_embed_batch",
        lambda session, batch_ids, force: [{"status": "SUCCESS", "chunk_id": cid} for cid in batch_ids],
    )

    outcomes = service.embed_many(_noop_session_factory, [1, 2, 3])

    assert len(outcomes) == 3
    assert all(o["status"] == "SUCCESS" for o in outcomes)


def test_embed_many_circuit_breaker_stops_after_consecutive_failed_batches(monkeypatch):
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_batch_size", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_max_concurrent_requests", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_circuit_breaker_threshold", 2)

    provider = _FakeProvider()  # health_check() -> True
    service = EmbeddingGenerationService(provider=provider)

    # Single worker (concurrency=1) makes completion order deterministic
    # and equal to submission order, so this test can reason about
    # "consecutive" the same way a human reading the log would. A small
    # sleep simulates a real batch call taking real time — without it, an
    # instantly-returning mock lets the worker thread race ahead and
    # drain the whole queue before the main thread's as_completed loop
    # can even observe results and act on them, which isn't representative
    # of the real network-call-bound case this feature targets.
    def _always_fails(session, batch_ids, force):
        time.sleep(0.05)
        return [{"status": "FAILED", "chunk_id": cid, "error": "simulated"} for cid in batch_ids]

    monkeypatch.setattr(service, "_embed_batch", _always_fails)

    outcomes = service.embed_many(_noop_session_factory, [1, 2, 3, 4, 5, 6, 7, 8])

    # Breaker should trip once 2 consecutive batches (1 chunk each, since
    # batch_size=1) fail — batches 3-8 should never even be submitted.
    # Allow for at most 1 extra already-in-flight batch: cancel() can only
    # stop a future that hasn't started running yet, and with a single
    # worker there's an inherent (bounded) race between the worker
    # immediately dequeuing the next task and the main thread reacting to
    # the trip — this is expected, documented behavior (see embed_many's
    # docstring: "already-in-progress batches will still finish"), not a
    # bug in the breaker.
    assert 2 <= len(outcomes) <= 3
    assert all(o["status"] == "FAILED" for o in outcomes)


def test_embed_many_circuit_breaker_resets_on_success(monkeypatch):
    """A successful batch in between failures resets the consecutive-failure count."""
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_batch_size", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_max_concurrent_requests", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_circuit_breaker_threshold", 2)

    provider = _FakeProvider()
    service = EmbeddingGenerationService(provider=provider)

    call_order = []

    def _fail_except_third(session, batch_ids, force):
        call_order.append(batch_ids[0])
        if batch_ids[0] == 3:
            return [{"status": "SUCCESS", "chunk_id": batch_ids[0]}]
        return [{"status": "FAILED", "chunk_id": batch_ids[0], "error": "simulated"}]

    monkeypatch.setattr(service, "_embed_batch", _fail_except_third)

    outcomes = service.embed_many(_noop_session_factory, [1, 2, 3, 4])

    # All 4 attempted — chunk 3's success breaks up what would otherwise
    # be a 2-in-a-row failure streak (1,2 fail; 3 succeeds; 4 fails —
    # never 2 CONSECUTIVE failures).
    assert len(outcomes) == 4
    assert sorted(call_order) == [1, 2, 3, 4]


def test_embed_many_circuit_breaker_disabled_when_threshold_zero(monkeypatch):
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_batch_size", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_max_concurrent_requests", 1)
    monkeypatch.setattr("src.embeddings.embedding_service.settings.embeddings_circuit_breaker_threshold", 0)

    provider = _FakeProvider()
    service = EmbeddingGenerationService(provider=provider)
    monkeypatch.setattr(
        service, "_embed_batch",
        lambda session, batch_ids, force: [{"status": "FAILED", "chunk_id": cid, "error": "simulated"} for cid in batch_ids],
    )

    outcomes = service.embed_many(_noop_session_factory, [1, 2, 3, 4, 5])

    # threshold=0 means disabled — every chunk is still attempted despite all failing.
    assert len(outcomes) == 5
