"""
Integration tests for `src/retrieval/retrieval_service.py` (RetrievalService).
Requires a real Postgres test database — skipped automatically if
unreachable. Uses a fake `BaseEmbeddingProvider` throughout (no network).

Uses the same SAVEPOINT-based session fixture `test_chunking_service.py`
/ `test_embeddings_service.py` established, since `RetrievalService.
retrieve_evidence` calls `session.commit()` internally.
"""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import event
from sqlalchemy.orm import sessionmaker

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.models import Chunk
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.vector_store import PostgresVectorStore
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.models.framework import Framework
from src.parser.models import ParsedDocument, ParsingStatusEnum
from src.retrieval.models import RetrievedEvidence
from src.retrieval.retrieval_service import RetrievalService
from src.retrieval.telemetry import telemetry as retrieval_telemetry
from src.retrieval.types import RetrievalConfig

from src.retrieval import models as _retrieval_models_module  # noqa: F401


@pytest.fixture
def retrieval_session(_test_engine):
    """SAVEPOINT-based session fixture — see module docstring."""
    connection = _test_engine.connect()
    outer_transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()
    session.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def _restart_savepoint(sess, trans):
        if trans.nested and not trans._parent.nested:
            sess.begin_nested()

    yield session

    session.close()
    outer_transaction.rollback()
    connection.close()


@pytest.fixture(autouse=True)
def _reset_telemetry():
    retrieval_telemetry.reset()
    yield
    retrieval_telemetry.reset()


class _FakeProvider(BaseEmbeddingProvider):
    provider_name = "fake"

    def __init__(self, *, vectors_by_text: dict, embedding_dimension=3, default_vector=None):
        super().__init__(model_name="fake-model", model_version="1", embedding_dimension=embedding_dimension)
        self._vectors_by_text = vectors_by_text
        self._default_vector = default_vector or [0.0, 0.0, 1.0]

    def embed_batch(self, texts):
        return [self._vectors_by_text.get(t, self._default_vector) for t in texts]


def _make_company(session, name="Acme Corp"):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company, *, document_type=DocumentType.PDF.value, document_category=DocumentCategory.ANNUAL_REPORT.value):
    doc = DocumentRegistry(
        company_id=company.id, document_name="Annual Report", document_category=document_category,
        document_type=document_type, document_year=2024,
        official_url=f"https://acme.com/{uuid.uuid4()}.pdf", source_domain="acme.com",
        discovery_method="sitemap_crawl", status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _make_version(session, document, tmp_path, *, version_number=1):
    path = tmp_path / f"report_{version_number}.pdf"
    path.write_bytes(b"%PDF-1.4 fake content")
    version = DocumentVersion(
        document_id=document.id, version_number=version_number, file_hash="a" * 64,
        storage_path=str(path), file_size=path.stat().st_size, status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()
    return version


def _make_parsed_document(session, document, version, *, raw_text="Default text."):
    row = ParsedDocument(
        document_id=document.id, document_version_id=version.id, parser_used="pdf_parser", parser_version="1.0.0",
        document_type=document.document_type, page_count=1, raw_text=raw_text,
        page_text=[{"page_number": 1, "text": raw_text}], character_count=len(raw_text), status=ParsingStatusEnum.SUCCESS,
    )
    session.add(row)
    session.flush()
    return row


def _make_chunk(session, document, version, parsed, *, text, chunk_index=0, section_title=None, page_number=1):
    chunk = Chunk(
        chunk_id=f"{version.id}:{chunk_index}", document_id=document.id, document_version_id=version.id,
        parsed_document_id=parsed.id, chunk_index=chunk_index, page_number=page_number, section_title=section_title,
        text=text, character_count=len(text), token_estimate=max(1, len(text) // 4),
        chunker_used="recursive_chunker", chunker_version="1.0.0",
    )
    session.add(chunk)
    session.flush()
    return chunk


def _embed_chunk(session, chunk, company, vector, *, dimension=3):
    row = Embedding(
        embedding_id=f"{chunk.id}:fake:model:1", chunk_id=chunk.id, document_id=chunk.document_id,
        provider="fake", model_name="model", model_version="1", embedding_dimension=dimension,
        status=EmbeddingStatusEnum.ACTIVE, is_active=True, vector_store_backend="postgres",
    )
    session.add(row)
    session.flush()
    PostgresVectorStore(session=session).insert_vector(embedding_row=row, vector=vector, metadata={"company": company.name})
    session.flush()
    return row


def _seed_framework(session, *, framework_name, component="Purpose", fields=None):
    fields = fields or [("Mission Statement", "An explicit 'why we exist' statement.", ["Annual Report"])]
    rows = [
        Framework(framework_name=framework_name, component_name=component, field_name=name, description=desc, document_sources=sources)
        for name, desc, sources in fields
    ]
    session.add_all(rows)
    session.flush()
    return rows


def _small_config(**overrides) -> RetrievalConfig:
    base = dict(
        candidate_k=50, final_evidence_k=10, similarity_threshold=0.3,
        semantic_weight=0.6, lexical_weight=0.25, metadata_weight=0.15,
        diversity_max_per_document=10, diversity_max_per_section=10,
        threshold_relaxation_step=0.1, threshold_relaxation_max_attempts=3,
        framework_name="RS Test FW",
    )
    base.update(overrides)
    return RetrievalConfig(**base)


def test_retrieve_evidence_success_persists_ranked_evidence(retrieval_session, tmp_path):
    framework_name = "RS Test 1"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 1")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="Our reason for existing is to help people.")
    _embed_chunk(retrieval_session, chunk, company, [1.0, 0.0, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [0.95, 0.05, 0.0]})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")

    assert outcome["status"] == "SUCCESS"
    assert outcome["final_evidence_count"] == 1

    rows = retrieval_session.query(RetrievedEvidence).filter(RetrievedEvidence.company_id == company.id).all()
    assert len(rows) == 1
    assert rows[0].chunk_id == chunk.id
    assert rows[0].component == "Purpose"
    assert rows[0].rank == 1
    assert rows[0].chunk_text == chunk.text


def test_retrieve_evidence_traceability_fields_are_populated(retrieval_session, tmp_path):
    framework_name = "RS Test 2"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 2")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(
        retrieval_session, document, version, parsed,
        text="Our reason for existing is to help people.", section_title="Overview", page_number=3,
    )
    _embed_chunk(retrieval_session, chunk, company, [1.0, 0.0, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [0.95, 0.05, 0.0]})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))
    service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")

    row = retrieval_session.query(RetrievedEvidence).filter(RetrievedEvidence.company_id == company.id).first()
    assert row.page_number == 3
    assert row.section_title == "Overview"
    assert row.document_id == document.id
    assert row.retrieval_timestamp is not None
    assert row.source_metadata is not None


def test_retrieve_evidence_surfaces_evidence_without_literal_component_keyword(retrieval_session, tmp_path):
    """
    The brief's explicit required test case, at the FULL SERVICE level:
    a chunk that never contains the word "purpose" must still be
    retrieved for the Purpose component via semantic similarity to the
    Phase 1 field description, while a chunk that says "purpose" but is
    embedded far away in vector space should NOT dominate the result.
    """
    framework_name = "RS Test 3"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 3")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)

    candidate_b = _make_chunk(
        retrieval_session, document, version, parsed, chunk_index=0,
        text="Our ambition is to remove barriers preventing entrepreneurs from accessing capital, technology and markets.",
    )
    assert "purpose" not in candidate_b.text.lower()

    unrelated_chunk = _make_chunk(
        retrieval_session, document, version, parsed, chunk_index=1,
        text="The purpose-built facility spans 40,000 square feet of warehouse space.",
    )

    _embed_chunk(retrieval_session, candidate_b, company, [0.9, 0.1, 0.0])
    _embed_chunk(retrieval_session, unrelated_chunk, company, [0.0, 0.0, 1.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(
        vectors_by_text={query_text: [0.88, 0.12, 0.0]},
        default_vector=[0.0, 0.0, 1.0],
    )
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name, similarity_threshold=0.5))

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")

    assert outcome["status"] == "SUCCESS"
    rows = retrieval_session.query(RetrievedEvidence).filter(RetrievedEvidence.company_id == company.id).all()
    retrieved_chunk_ids = {r.chunk_id for r in rows}

    assert candidate_b.id in retrieved_chunk_ids
    assert unrelated_chunk.id not in retrieved_chunk_ids


def test_retrieve_evidence_unknown_company_returns_failed(retrieval_session):
    framework_name = "RS Test 4"
    _seed_framework(retrieval_session, framework_name=framework_name)
    provider = _FakeProvider(vectors_by_text={})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(retrieval_session, company_id=uuid.uuid4(), component="Purpose")
    assert outcome["status"] == "FAILED"
    assert "not found" in outcome["error"].lower()


def test_retrieve_evidence_unknown_component_returns_failed(retrieval_session, tmp_path):
    framework_name = "RS Test 5"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 5")
    provider = _FakeProvider(vectors_by_text={})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="NotARealComponent")
    assert outcome["status"] == "FAILED"


def test_retrieve_evidence_no_relevant_evidence_after_relaxation(retrieval_session, tmp_path):
    framework_name = "RS Test 6"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 6")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="Completely unrelated filler content about widgets.")
    _embed_chunk(retrieval_session, chunk, company, [0.0, 1.0, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [1.0, 0.0, 0.0]})
    config = _small_config(framework_name=framework_name, similarity_threshold=0.99, threshold_relaxation_step=0.001, threshold_relaxation_max_attempts=1)
    service = RetrievalService(provider=provider, config=config)

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")
    assert outcome["status"] == "NO_RELEVANT_EVIDENCE"
    assert outcome["final_evidence_count"] == 0

    assert retrieval_session.query(RetrievedEvidence).filter(RetrievedEvidence.company_id == company.id).count() == 0


def test_retrieve_evidence_threshold_relaxation_recovers_candidates(retrieval_session, tmp_path):
    framework_name = "RS Test 7"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 7")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="A moderately related statement about goals.")
    _embed_chunk(retrieval_session, chunk, company, [0.5, 0.5, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [1.0, 0.0, 0.0]})
    config = _small_config(framework_name=framework_name, similarity_threshold=0.9, threshold_relaxation_step=0.2, threshold_relaxation_max_attempts=3)
    service = RetrievalService(provider=provider, config=config)

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")
    assert outcome["status"] == "SUCCESS"
    assert outcome["threshold_relaxations"] > 0


def test_retrieve_evidence_deduplicates_chunk_matched_by_multiple_queries(retrieval_session, tmp_path):
    framework_name = "RS Test 8"
    _seed_framework(
        retrieval_session, framework_name=framework_name,
        fields=[
            ("Mission Statement", "An explicit reason for existing.", ["Annual Report"]),
            ("Founding Rationale", "The problem the org was created to address.", ["Annual Report"]),
        ],
    )
    company = _make_company(retrieval_session, "RS Co 8")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="Our reason for existing addresses a real problem.")
    _embed_chunk(retrieval_session, chunk, company, [1.0, 0.0, 0.0])

    provider = _FakeProvider(vectors_by_text={
        "An explicit reason for existing.": [0.95, 0.05, 0.0],
        "The problem the org was created to address.": [0.9, 0.1, 0.0],
    })
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")
    assert outcome["status"] == "SUCCESS"
    assert outcome["final_evidence_count"] == 1


def test_retrieve_evidence_respects_diversity_cap_per_document(retrieval_session, tmp_path):
    framework_name = "RS Test 9"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 9")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)

    chunks = []
    vectors_by_text = {"An explicit 'why we exist' statement.": [1.0, 0.0, 0.0]}
    for i in range(5):
        c = _make_chunk(retrieval_session, document, version, parsed, chunk_index=i, text=f"Distinct reason statement number {i} for existing.")
        _embed_chunk(retrieval_session, c, company, [0.95, 0.05, 0.0])
        chunks.append(c)

    provider = _FakeProvider(vectors_by_text=vectors_by_text)
    config = _small_config(framework_name=framework_name, final_evidence_k=10, diversity_max_per_document=2)
    service = RetrievalService(provider=provider, config=config)

    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")
    assert outcome["status"] == "SUCCESS"
    assert outcome["final_evidence_count"] == 2


def test_retrieve_evidence_extra_filters_exclude_non_matching_document_type(retrieval_session, tmp_path):
    framework_name = "RS Test 10"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 10")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="Our reason for existing is clear.")
    _embed_chunk(retrieval_session, chunk, company, [1.0, 0.0, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [0.95, 0.05, 0.0]})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(
        retrieval_session, company_id=company.id, component="Purpose",
        extra_filters={"document_type": "definitely_not_a_real_type"},
    )
    assert outcome["status"] == "NO_RELEVANT_EVIDENCE"


def test_retrieve_evidence_rejects_unknown_filter_key(retrieval_session, tmp_path):
    framework_name = "RS Test 11"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 11")
    provider = _FakeProvider(vectors_by_text={})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))

    outcome = service.retrieve_evidence(
        retrieval_session, company_id=company.id, component="Purpose", extra_filters={"bogus_key": "value"},
    )
    assert outcome["status"] == "FAILED"


def test_retrieve_evidence_records_telemetry(retrieval_session, tmp_path):
    framework_name = "RS Test 12"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 12")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    parsed = _make_parsed_document(retrieval_session, document, version)
    chunk = _make_chunk(retrieval_session, document, version, parsed, text="Our reason for existing is clear.")
    _embed_chunk(retrieval_session, chunk, company, [1.0, 0.0, 0.0])

    query_text = "An explicit 'why we exist' statement."
    provider = _FakeProvider(vectors_by_text={query_text: [0.95, 0.05, 0.0]})
    service = RetrievalService(provider=provider, config=_small_config(framework_name=framework_name))
    service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")

    summary = retrieval_telemetry.get_summary()
    assert summary["retrieval_requests"] == 1
    assert summary["successful_retrievals"] == 1
    assert summary["active_provider"] == "fake"


def test_sprint5_chunk_to_sprint6_embedding_to_sprint7_retrieval_boundary(retrieval_session, tmp_path):
    """
    Exercises the REAL Sprint 5 (DocumentChunkingService) and Sprint 6
    (EmbeddingGenerationService) services to produce a Chunk and an
    Embedding, then runs Sprint 7 retrieval against that real output --
    not hand-built fixture rows. This is the brief's explicitly requested
    "at least one integration test covering the real Sprint 6 -> Sprint 7
    boundary."
    """
    from src.chunking.service import DocumentChunkingService
    from src.embeddings.embedding_service import EmbeddingGenerationService

    framework_name = "RS Test 13"
    _seed_framework(retrieval_session, framework_name=framework_name)
    company = _make_company(retrieval_session, "RS Co 13")
    document = _make_document(retrieval_session, company)
    version = _make_version(retrieval_session, document, tmp_path)
    raw_text = "Our reason for existing is to help small businesses access global markets."
    parsed = _make_parsed_document(retrieval_session, document, version, raw_text=raw_text)

    chunking_outcome = DocumentChunkingService().chunk_parsed_document(retrieval_session, parsed.id)
    assert chunking_outcome["status"] == "SUCCESS"
    chunk = retrieval_session.query(Chunk).filter(Chunk.parsed_document_id == parsed.id).first()
    assert chunk is not None

    query_text = "An explicit 'why we exist' statement."
    embed_provider = _FakeProvider(vectors_by_text={chunk.text: [0.9, 0.1, 0.0]})
    embedding_outcome = EmbeddingGenerationService(provider=embed_provider).embed_chunk(retrieval_session, chunk.id)
    assert embedding_outcome["status"] == "SUCCESS"

    retrieval_provider = _FakeProvider(vectors_by_text={query_text: [0.88, 0.12, 0.0]})
    service = RetrievalService(provider=retrieval_provider, config=_small_config(framework_name=framework_name))
    outcome = service.retrieve_evidence(retrieval_session, company_id=company.id, component="Purpose")

    assert outcome["status"] == "SUCCESS"
    row = retrieval_session.query(RetrievedEvidence).filter(RetrievedEvidence.company_id == company.id).first()
    assert row.chunk_id == chunk.id
    assert row.chunk_text == chunk.text
