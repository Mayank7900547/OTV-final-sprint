"""Unit tests for `src/parser/telemetry.py`."""

from src.parser.telemetry import ParserTelemetry


def test_initial_summary_is_all_zero():
    t = ParserTelemetry()
    summary = t.get_summary()

    assert summary["documents_parsed"] == 0
    assert summary["pages_processed"] == 0
    assert summary["characters_extracted"] == 0
    assert summary["average_parsing_time"] == 0.0
    assert summary["parser_failures"] == 0
    assert summary["unsupported_document_types"] == 0
    assert summary["skipped_documents"] == 0
    assert summary["success_rate"] == 0.0


def test_record_success_accumulates_counters():
    t = ParserTelemetry()
    t.record_success(pages=5, characters=1000, duration=2.0)
    t.record_success(pages=3, characters=500, duration=1.0)

    summary = t.get_summary()

    assert summary["documents_parsed"] == 2
    assert summary["pages_processed"] == 8
    assert summary["characters_extracted"] == 1500
    assert summary["average_parsing_time"] == 1.5


def test_record_failure_increments_failure_count():
    t = ParserTelemetry()
    t.record_failure()
    t.record_failure()

    assert t.get_summary()["parser_failures"] == 2


def test_record_unsupported_increments_unsupported_count():
    t = ParserTelemetry()
    t.record_unsupported()

    assert t.get_summary()["unsupported_document_types"] == 1


def test_record_skipped_increments_skipped_count():
    t = ParserTelemetry()
    t.record_skipped()

    assert t.get_summary()["skipped_documents"] == 1


def test_success_rate_computed_against_success_plus_failure():
    t = ParserTelemetry()
    t.record_success(pages=1, characters=10, duration=0.1)
    t.record_success(pages=1, characters=10, duration=0.1)
    t.record_success(pages=1, characters=10, duration=0.1)
    t.record_failure()

    # 3 successes, 1 failure -> 3/4
    assert t.get_summary()["success_rate"] == 0.75


def test_reset_clears_all_counters():
    t = ParserTelemetry()
    t.record_success(pages=1, characters=10, duration=1.0)
    t.record_failure()
    t.record_skipped()

    t.reset()

    summary = t.get_summary()
    assert summary["documents_parsed"] == 0
    assert summary["parser_failures"] == 0
    assert summary["skipped_documents"] == 0
