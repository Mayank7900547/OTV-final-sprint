"""Unit tests for `src/embeddings/utils.py`."""

import pytest

from src.embeddings.utils import batched, with_retries


# ---------------------------------------------------------------------------
# batched
# ---------------------------------------------------------------------------


def test_batched_splits_into_even_groups():
    result = list(batched([1, 2, 3, 4, 5, 6], 2))
    assert result == [[1, 2], [3, 4], [5, 6]]


def test_batched_handles_uneven_remainder():
    result = list(batched([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_batched_single_batch_when_size_exceeds_list_length():
    result = list(batched([1, 2, 3], 10))
    assert result == [[1, 2, 3]]


def test_batched_empty_list_yields_nothing():
    assert list(batched([], 5)) == []


def test_batched_rejects_non_positive_batch_size():
    with pytest.raises(ValueError):
        list(batched([1, 2, 3], 0))


# ---------------------------------------------------------------------------
# with_retries
# ---------------------------------------------------------------------------


def test_with_retries_returns_result_on_first_success():
    calls = []

    def func():
        calls.append(1)
        return "ok"

    result = with_retries(func, retry_limit=3, backoff_seconds=0, retryable_exceptions=(ValueError,))
    assert result == "ok"
    assert len(calls) == 1


def test_with_retries_retries_up_to_limit_then_succeeds():
    attempts = {"count": 0}

    def func():
        attempts["count"] += 1
        if attempts["count"] < 3:
            raise ValueError("transient")
        return "recovered"

    sleeps = []
    result = with_retries(
        func, retry_limit=5, backoff_seconds=1.0, retryable_exceptions=(ValueError,), sleep_fn=sleeps.append
    )
    assert result == "recovered"
    assert attempts["count"] == 3
    assert sleeps == [1.0, 2.0]  # linear backoff: backoff * attempt_number


def test_with_retries_raises_after_exhausting_retry_limit():
    def func():
        raise ValueError("always fails")

    with pytest.raises(ValueError):
        with_retries(func, retry_limit=2, backoff_seconds=0, retryable_exceptions=(ValueError,), sleep_fn=lambda s: None)


def test_with_retries_does_not_retry_non_retryable_exceptions():
    calls = []

    def func():
        calls.append(1)
        raise TypeError("not retryable")

    with pytest.raises(TypeError):
        with_retries(func, retry_limit=5, backoff_seconds=0, retryable_exceptions=(ValueError,), sleep_fn=lambda s: None)
    assert len(calls) == 1  # no retries attempted


def test_with_retries_calls_on_retry_callback_with_attempt_number_and_exception():
    calls = {"count": 0}
    retry_log = []

    def func():
        calls["count"] += 1
        if calls["count"] < 2:
            raise ValueError("fail once")
        return "ok"

    with_retries(
        func, retry_limit=3, backoff_seconds=0, retryable_exceptions=(ValueError,),
        on_retry=lambda attempt, exc: retry_log.append((attempt, str(exc))),
        sleep_fn=lambda s: None,
    )
    assert retry_log == [(1, "fail once")]


def test_with_retries_zero_retry_limit_means_single_attempt():
    calls = []

    def func():
        calls.append(1)
        raise ValueError("fails")

    with pytest.raises(ValueError):
        with_retries(func, retry_limit=0, backoff_seconds=0, retryable_exceptions=(ValueError,), sleep_fn=lambda s: None)
    assert len(calls) == 1
