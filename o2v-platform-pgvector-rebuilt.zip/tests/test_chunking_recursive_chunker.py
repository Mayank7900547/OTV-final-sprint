"""Unit tests for `src/chunking/recursive_chunker.py`."""

from src.chunking.base_chunker import ChunkerConfig, TextBlock
from src.chunking.recursive_chunker import RecursiveChunker, _split_text


def _config(**overrides) -> ChunkerConfig:
    defaults = dict(chunk_size=100, chunk_overlap=20, min_chunk_size=20, max_chunk_size=200)
    defaults.update(overrides)
    return ChunkerConfig(**defaults)


# ---------------------------------------------------------------------------
# _split_text — low-level recursive splitting
# ---------------------------------------------------------------------------


def test_split_text_returns_whole_text_when_under_limit():
    assert _split_text("short text", ["\n\n", " "], 100) == ["short text"]


def test_split_text_splits_on_paragraph_boundary():
    text = "Paragraph one is here.\n\nParagraph two is here."
    pieces = _split_text(text, ["\n\n", " "], 30)
    assert all(len(p) <= 30 for p in pieces)
    assert "Paragraph one is here." in pieces


def test_split_text_falls_back_to_word_boundary_when_no_paragraphs():
    text = " ".join(["word"] * 40)  # one giant "paragraph", no blank lines
    pieces = _split_text(text, ["\n\n", " "], 25)
    assert all(len(p) <= 25 for p in pieces)
    # No word should ever be broken mid-token by falling through to " ".
    for piece in pieces:
        for token in piece.split():
            assert token == "word"


def test_split_text_hard_splits_when_separators_exhausted():
    text = "a" * 55
    pieces = _split_text(text, [], 20)
    assert pieces == ["a" * 20, "a" * 20, "a" * 15]


def test_split_text_empty_string_returns_empty_list():
    assert _split_text("", ["\n\n"], 100) == []
    assert _split_text("   ", ["\n\n"], 100) == []


# ---------------------------------------------------------------------------
# RecursiveChunker.chunk() — end-to-end block chunking
# ---------------------------------------------------------------------------


def test_chunk_single_small_block_produces_one_chunk():
    chunker = RecursiveChunker()
    blocks = [TextBlock(text="A short paragraph of text.", page_number=1, section_title="Intro")]
    candidates = chunker.chunk(blocks, config=_config())

    assert len(candidates) == 1
    assert candidates[0].text == "A short paragraph of text."
    assert candidates[0].page_number == 1
    assert candidates[0].section_title == "Intro"


def test_chunk_respects_max_chunk_size_ceiling():
    chunker = RecursiveChunker()
    long_paragraph = " ".join([f"word{i}" for i in range(300)])
    blocks = [TextBlock(text=long_paragraph, page_number=1, section_title=None)]
    config = _config(chunk_size=100, max_chunk_size=150)

    candidates = chunker.chunk(blocks, config=config)

    assert len(candidates) > 1
    for candidate in candidates:
        assert candidate.character_count <= config.max_chunk_size


def test_chunk_no_candidate_is_empty():
    chunker = RecursiveChunker()
    blocks = [
        TextBlock(text="Real content here.", page_number=1, section_title=None),
        TextBlock(text="   ", page_number=1, section_title=None),  # whitespace-only block
    ]
    candidates = chunker.chunk(blocks, config=_config())
    assert all(c.text.strip() for c in candidates)
    assert len(candidates) == 1


def test_chunk_preserves_page_number_and_section_per_block():
    chunker = RecursiveChunker()
    blocks = [
        TextBlock(text="Section A content.", page_number=1, section_title="Section A"),
        TextBlock(text="Section B content.", page_number=2, section_title="Section B"),
    ]
    candidates = chunker.chunk(blocks, config=_config())

    by_section = {c.section_title: c for c in candidates}
    assert by_section["Section A"].page_number == 1
    assert by_section["Section B"].page_number == 2


def test_chunk_assigns_sequential_indices_across_blocks():
    chunker = RecursiveChunker()
    blocks = [
        TextBlock(text="First block of reasonable length here.", page_number=1, section_title=None),
        TextBlock(text="Second block of reasonable length here.", page_number=1, section_title=None),
    ]
    candidates = chunker.chunk(blocks, config=_config())
    assert [c.chunk_index for c in candidates] == list(range(len(candidates)))


# ---------------------------------------------------------------------------
# Overlap
# ---------------------------------------------------------------------------


def test_chunk_overlap_carries_trailing_text_into_next_chunk():
    chunker = RecursiveChunker()
    # Several distinct paragraphs, long enough in aggregate to force > 1 chunk.
    paragraphs = "\n\n".join(f"Paragraph number {i} has some unique content in it." for i in range(10))
    blocks = [TextBlock(text=paragraphs, page_number=1, section_title=None)]
    config = _config(chunk_size=120, chunk_overlap=30, max_chunk_size=200)

    candidates = chunker.chunk(blocks, config=config)

    assert len(candidates) > 1
    # The tail of chunk N should reappear at the head of chunk N+1 (the
    # sliding-window overlap), for every consecutive pair.
    for first, second in zip(candidates, candidates[1:]):
        overlap_candidate = first.text[-config.chunk_overlap :].strip()
        assert overlap_candidate[:15] in second.text


def test_zero_overlap_produces_no_shared_text_between_chunks():
    chunker = RecursiveChunker()
    paragraphs = "\n\n".join(f"Distinct paragraph {i} with unique filler content padded out." for i in range(8))
    blocks = [TextBlock(text=paragraphs, page_number=1, section_title=None)]
    config = _config(chunk_size=120, chunk_overlap=0, max_chunk_size=200)

    candidates = chunker.chunk(blocks, config=config)
    assert len(candidates) > 1
    # With zero overlap, no chunk's text should be a substring of another.
    texts = [c.text for c in candidates]
    for i, text in enumerate(texts):
        for j, other in enumerate(texts):
            if i != j:
                assert text != other


# ---------------------------------------------------------------------------
# Table handling
# ---------------------------------------------------------------------------


def test_small_table_block_kept_whole():
    chunker = RecursiveChunker()
    table_text = "Year    Revenue    Profit\n2023    1000       200\n2024    1200       260"
    blocks = [TextBlock(text=table_text, page_number=1, section_title=None, is_table=True)]
    config = _config(chunk_size=20, chunk_overlap=5, max_chunk_size=200)  # chunk_size tiny, but table still fits max

    candidates = chunker.chunk(blocks, config=config)

    assert len(candidates) == 1
    assert candidates[0].text == table_text
    assert candidates[0].extra_metadata["is_table"] is True


def test_oversized_table_splits_only_on_row_boundaries():
    chunker = RecursiveChunker()
    rows = [f"Row{i}    Value{i}    Extra{i}" for i in range(30)]
    table_text = "\n".join(rows)
    blocks = [TextBlock(text=table_text, page_number=1, section_title=None, is_table=True)]
    config = _config(chunk_size=50, max_chunk_size=100)

    candidates = chunker.chunk(blocks, config=config)

    assert len(candidates) > 1
    for candidate in candidates:
        # Every emitted line must be a complete original row, never a
        # fragment of one — i.e. splitting happened only between rows.
        for line in candidate.text.splitlines():
            assert line in rows


# ---------------------------------------------------------------------------
# Heading handling
# ---------------------------------------------------------------------------


def test_heading_block_always_kept_atomic():
    chunker = RecursiveChunker()
    blocks = [TextBlock(text="Risk Factors", page_number=1, section_title="Risk Factors", is_heading=True)]
    config = _config(chunk_size=5, chunk_overlap=1, min_chunk_size=1)  # deliberately smaller than the heading text

    candidates = chunker.chunk(blocks, config=config)

    assert len(candidates) == 1
    assert candidates[0].text == "Risk Factors"
    assert candidates[0].extra_metadata["is_heading"] is True


# ---------------------------------------------------------------------------
# Min-size enforcement
# ---------------------------------------------------------------------------


def test_small_trailing_fragment_is_folded_into_previous_chunk():
    chunker = RecursiveChunker()
    text = ("First paragraph with enough content to be its own chunk on its own merit here. "
            "\n\nS.")  # tiny trailing fragment
    blocks = [TextBlock(text=text, page_number=1, section_title=None)]
    config = _config(chunk_size=90, chunk_overlap=10, min_chunk_size=20, max_chunk_size=200)

    candidates = chunker.chunk(blocks, config=config)

    # The tiny trailing fragment should have been folded into the
    # previous chunk rather than existing as its own undersized chunk.
    assert all(c.character_count >= config.min_chunk_size for c in candidates)
