"""Unit tests for `src/chunking/metadata.py`."""

from src.chunking.metadata import estimate_tokens, is_heading_like, is_table_like


# ---------------------------------------------------------------------------
# estimate_tokens
# ---------------------------------------------------------------------------


def test_estimate_tokens_empty_text_is_zero():
    assert estimate_tokens("") == 0
    assert estimate_tokens("   ") == 0


def test_estimate_tokens_short_text_is_at_least_one():
    assert estimate_tokens("hi") == 1


def test_estimate_tokens_scales_roughly_with_length():
    short_estimate = estimate_tokens("a" * 40)
    long_estimate = estimate_tokens("a" * 400)
    assert long_estimate > short_estimate
    assert long_estimate == 100  # 400 chars / 4 chars-per-token


# ---------------------------------------------------------------------------
# is_heading_like
# ---------------------------------------------------------------------------


def test_is_heading_like_recognizes_title_case_short_line():
    assert is_heading_like("Risk Factors")


def test_is_heading_like_recognizes_all_caps_short_line():
    assert is_heading_like("FINANCIAL HIGHLIGHTS")


def test_is_heading_like_rejects_long_prose():
    prose = (
        "The company reported strong revenue growth this quarter, driven "
        "primarily by expansion into new international markets and an "
        "increase in average order value across the platform."
    )
    assert not is_heading_like(prose)


def test_is_heading_like_rejects_sentence_ending_in_period():
    assert not is_heading_like("This is a short sentence.")


def test_is_heading_like_rejects_multiline_paragraph():
    assert not is_heading_like("Heading Text\nBody continues here")


def test_is_heading_like_rejects_empty_string():
    assert not is_heading_like("")
    assert not is_heading_like("   ")


def test_is_heading_like_matches_known_heading_exactly_even_if_it_would_otherwise_fail_heuristic():
    # Lowercase, no title-casing — heuristic alone would reject this, but
    # an exact match against ground-truth HTML headings must still win.
    known = {"about us"}
    assert is_heading_like("about us", known_headings=known)


def test_is_heading_like_lowercase_line_without_known_headings_is_rejected():
    assert not is_heading_like("about us")


# ---------------------------------------------------------------------------
# is_table_like
# ---------------------------------------------------------------------------


def test_is_table_like_detects_multi_column_rows():
    table_text = "Year    Revenue    Profit\n2023    1000       200\n2024    1200       260"
    assert is_table_like(table_text)


def test_is_table_like_detects_pipe_delimited_rows():
    table_text = "Name | Value\nAlpha | 1\nBeta | 2"
    assert is_table_like(table_text)


def test_is_table_like_rejects_ordinary_prose():
    prose = "This is a normal paragraph with regular sentences and no columns at all."
    assert not is_table_like(prose)


def test_is_table_like_rejects_single_line():
    assert not is_table_like("Year    Revenue    Profit")


def test_is_table_like_rejects_empty_text():
    assert not is_table_like("")
