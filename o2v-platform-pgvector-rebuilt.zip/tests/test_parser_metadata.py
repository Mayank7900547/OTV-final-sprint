"""Unit tests for `src/parser/metadata.py`."""

from datetime import timezone

from src.parser.metadata import detect_language, normalize_metadata_value, parse_pdf_date


class TestParsePdfDate:
    def test_full_format_with_timezone(self):
        result = parse_pdf_date("D:20230415120530+00'00'")
        assert result is not None
        assert result.year == 2023
        assert result.month == 4
        assert result.day == 15
        assert result.hour == 12
        assert result.minute == 5
        assert result.second == 30
        assert result.tzinfo == timezone.utc

    def test_date_only_no_time(self):
        result = parse_pdf_date("D:20230415")
        assert result is not None
        assert result.year == 2023
        assert result.month == 4
        assert result.day == 15
        assert result.hour == 0

    def test_year_only(self):
        result = parse_pdf_date("D:2023")
        assert result is not None
        assert result.year == 2023
        assert result.month == 1
        assert result.day == 1

    def test_none_input_returns_none(self):
        assert parse_pdf_date(None) is None

    def test_empty_string_returns_none(self):
        assert parse_pdf_date("") is None

    def test_garbage_input_returns_none_not_raises(self):
        assert parse_pdf_date("not a date at all") is None

    def test_invalid_calendar_date_returns_none_not_raises(self):
        # Month 13, day 40 - matches the regex shape but isn't a real date.
        assert parse_pdf_date("D:20231340") is None


class TestNormalizeMetadataValue:
    def test_strips_whitespace(self):
        assert normalize_metadata_value("  Acme Corp  ") == "Acme Corp"

    def test_none_returns_none(self):
        assert normalize_metadata_value(None) is None

    def test_empty_or_whitespace_only_returns_none(self):
        assert normalize_metadata_value("") is None
        assert normalize_metadata_value("   ") is None

    def test_non_string_is_stringified(self):
        assert normalize_metadata_value(42) == "42"


class TestDetectLanguage:
    def test_disabled_returns_none(self):
        assert detect_language("This is a reasonably long piece of English text.", enabled=False) is None

    def test_empty_text_returns_none(self):
        assert detect_language("", enabled=True) is None

    def test_too_short_text_returns_none(self):
        assert detect_language("Hi.", enabled=True) is None

    def test_detects_english(self):
        text = (
            "The quick brown fox jumps over the lazy dog. This is a longer "
            "sample of English text intended to give the language detector "
            "enough signal to classify it correctly."
        )
        result = detect_language(text, enabled=True)
        assert result == "en"

    def test_never_raises_on_gibberish(self):
        # langdetect can raise LangDetectException on input with no
        # detectable features (e.g. pure punctuation/numbers) - this must
        # degrade to None, never propagate.
        result = detect_language("!!! 123 !!! 456 !!! 789 !!! 000 !!!", enabled=True)
        assert result is None or isinstance(result, str)
