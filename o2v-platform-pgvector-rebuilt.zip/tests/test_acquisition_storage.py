"""Tests for src/acquisition/storage.py (LocalDiskStorageBackend)."""

import pytest

from src.acquisition.exceptions import StorageError
from src.acquisition.storage import LocalDiskStorageBackend


@pytest.fixture
def backend(tmp_path):
    return LocalDiskStorageBackend(tmp_path / "base")


def test_init_creates_base_dir(tmp_path):
    base = tmp_path / "brand_new_base"
    assert not base.exists()
    LocalDiskStorageBackend(base)
    assert base.exists()


def test_save_copies_file_and_leaves_source_intact(backend, tmp_path):
    src = tmp_path / "source.pdf"
    src.write_bytes(b"pdf-bytes")

    dest = backend.save(src, "raw/company/2024/report.pdf")

    assert src.exists()  # save() copies, doesn't move
    from pathlib import Path

    assert Path(dest).read_bytes() == b"pdf-bytes"
    assert Path(dest) == backend.base_dir / "raw/company/2024/report.pdf"


def test_save_creates_nested_destination_directories(backend, tmp_path):
    src = tmp_path / "source.pdf"
    src.write_bytes(b"data")
    dest = backend.save(src, "a/b/c/d/file.pdf")
    from pathlib import Path

    assert Path(dest).exists()


def test_move_relocates_file_from_key_within_base_dir(backend, tmp_path):
    src = tmp_path / "staged.pdf"
    src.write_bytes(b"staged-content")
    # Save it under the backend first so we have a key-relative source.
    saved_path = backend.save(src, "staging/staged.pdf")

    dest = backend.move("staging/staged.pdf", "raw/final.pdf")

    from pathlib import Path

    assert not Path(saved_path).exists()  # moved away
    assert Path(dest).read_bytes() == b"staged-content"


def test_move_accepts_absolute_source_path(backend, tmp_path):
    src = tmp_path / "outside_base.pdf"
    src.write_bytes(b"external")

    dest = backend.move(str(src), "raw/from_absolute.pdf")

    from pathlib import Path

    assert not src.exists()
    assert Path(dest).read_bytes() == b"external"


def test_move_raises_storage_error_when_source_missing(backend):
    with pytest.raises(StorageError):
        backend.move("does/not/exist.pdf", "raw/wherever.pdf")


def test_delete_removes_existing_file_and_returns_true(backend, tmp_path):
    src = tmp_path / "to_delete.pdf"
    src.write_bytes(b"x")
    backend.save(src, "raw/to_delete.pdf")

    assert backend.delete("raw/to_delete.pdf") is True
    assert backend.exists("raw/to_delete.pdf") is False


def test_delete_returns_false_when_file_absent(backend):
    assert backend.delete("raw/never_existed.pdf") is False


def test_exists_true_and_false_cases(backend, tmp_path):
    assert backend.exists("raw/missing.pdf") is False
    src = tmp_path / "present.pdf"
    src.write_bytes(b"y")
    backend.save(src, "raw/present.pdf")
    assert backend.exists("raw/present.pdf") is True


def test_resolve_strips_leading_slash_from_key(backend, tmp_path):
    src = tmp_path / "leading_slash.pdf"
    src.write_bytes(b"z")
    dest = backend.save(src, "/raw/leading_slash.pdf")
    from pathlib import Path

    # Should resolve inside base_dir, not attempt an absolute-path write.
    assert Path(dest) == backend.base_dir / "raw/leading_slash.pdf"
