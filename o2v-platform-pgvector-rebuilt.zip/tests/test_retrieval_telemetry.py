"""Unit tests for `src/retrieval/telemetry.py`."""

from src.retrieval.telemetry import RetrievalTelemetry


def test_initial_summary_is_all_zero():
    t = RetrievalTelemetry()
    summary = t.get_summary()
    assert summary["retrieval_requests"] == 0
    assert summary["successful_retrievals"] == 0
    assert summary["failed_retrievals"] == 0
    assert summary["empty_result_count"] == 0
    assert summary["average_latency"] == 0.0
    assert summary["empty_result_rate"] == 0.0
    assert summary["active_provider"] == ""


def test_record_request_increments_counter():
    t = RetrievalTelemetry()
    t.record_request()
    t.record_request()
    assert t.get_summary()["retrieval_requests"] == 2


def test_record_success_accumulates_and_sets_provider():
    t = RetrievalTelemetry()
    t.record_success(duration=1.0, candidate_count=50, final_evidence_count=10, average_similarity=0.7, provider="ollama")
    summary = t.get_summary()
    assert summary["successful_retrievals"] == 1
    assert summary["average_candidate_count"] == 50.0
    assert summary["average_final_evidence_count"] == 10.0
    assert summary["average_similarity"] == 0.7
    assert summary["active_provider"] == "ollama"


def test_record_success_with_zero_evidence_counts_as_empty_result():
    t = RetrievalTelemetry()
    t.record_success(duration=0.5, candidate_count=10, final_evidence_count=0, average_similarity=0.0, provider="ollama")
    summary = t.get_summary()
    assert summary["empty_result_count"] == 1


def test_record_failure_increments_counter():
    t = RetrievalTelemetry()
    t.record_failure()
    assert t.get_summary()["failed_retrievals"] == 1


def test_empty_result_rate_computed_against_attempted_total():
    t = RetrievalTelemetry()
    t.record_success(duration=1.0, candidate_count=10, final_evidence_count=5, average_similarity=0.5, provider="ollama")
    t.record_success(duration=1.0, candidate_count=10, final_evidence_count=0, average_similarity=0.0, provider="ollama")
    t.record_failure()
    summary = t.get_summary()
    assert summary["empty_result_rate"] == round(1 / 3, 4)


def test_average_similarity_only_averages_non_empty_results():
    t = RetrievalTelemetry()
    t.record_success(duration=1.0, candidate_count=10, final_evidence_count=5, average_similarity=0.8, provider="ollama")
    t.record_success(duration=1.0, candidate_count=10, final_evidence_count=0, average_similarity=0.0, provider="ollama")
    summary = t.get_summary()
    assert summary["average_similarity"] == 0.8


def test_reset_clears_all_counters():
    t = RetrievalTelemetry()
    t.record_request()
    t.record_success(duration=1.0, candidate_count=10, final_evidence_count=5, average_similarity=0.5, provider="ollama")
    t.record_failure()
    t.reset()
    summary = t.get_summary()
    assert summary["retrieval_requests"] == 0
    assert summary["successful_retrievals"] == 0
    assert summary["failed_retrievals"] == 0
    assert summary["active_provider"] == ""
