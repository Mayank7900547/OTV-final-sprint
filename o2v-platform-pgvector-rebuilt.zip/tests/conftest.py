"""
Shared pytest fixtures.

Design decision, Sprint 1: tests deliberately avoided requiring a live
Postgres connection (framework YAML/CSV parsing logic is pure, no DB
needed). That docstring explicitly named Sprint 2 as when a real test-
database fixture should arrive — this is that fixture, added now,
additively, without touching any Sprint 1 test or fixture above.

Design decision, Sprint 2 (`db_session` fixture below): connects to a
SEPARATE database (`{settings.db_name}_test`, e.g. `o2v_platform_test`),
never the real `o2v_platform` database — a test suite that wrote into the
same database a developer is using for manual CLI testing would be a
constant source of confusing, mysterious extra rows. Each test runs
inside its own transaction that's rolled back on teardown (a standard
pytest-SQLAlchemy pattern), so tests never leak state into each other and
never require manually truncating tables between runs.

If no Postgres is reachable at all (a contributor without a database
running, e.g. just cloning the repo to read code), tests using
`db_session` are SKIPPED with a clear message, not failed — consistent
with Sprint 1's stated goal of `pytest` being runnable with zero external
setup for the tests that don't need one; the tests that DO need a
database degrade gracefully instead of blocking the whole suite.
"""

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from src.config.settings import settings
from src.database.base import Base

# Import models so their tables register on Base.metadata before create_all()
# runs — same requirement/reasoning as src/database/init_db.py.
from src.models import company as _company_model  # noqa: F401
from src.models import document as _document_model  # noqa: F401
from src.models import framework as _framework_model  # noqa: F401
from src.acquisition import models as _acquisition_model  # noqa: F401
from src.parser import models as _parser_model  # noqa: F401
from src.chunking import models as _chunking_model  # noqa: F401
from src.embeddings import models as _embeddings_model  # noqa: F401
from src.retrieval import models as _retrieval_model  # noqa: F401
from src.extraction import models as _extraction_model  # noqa: F401

_TEST_DB_NAME = f"{settings.db_name}_test"
# Reuses the same percent-encoding settings.database_url applies (see its
# docstring) — this was duplicated as a raw f-string here and hit the
# exact same '@'-in-password corruption bug in practice on a real
# developer machine, so it's now built the same way rather than
# re-deriving the encoding logic a second time.
from urllib.parse import quote_plus

_TEST_DATABASE_URL = (
    f"postgresql+psycopg2://{quote_plus(settings.db_user)}:{quote_plus(settings.db_password)}"
    f"@{settings.db_host}:{settings.db_port}/{_TEST_DB_NAME}"
)


@pytest.fixture
def tmp_yaml_file(tmp_path):
    """Return a helper that writes given text content to a temp .yaml file and returns its path."""

    def _write(content: str, filename: str = "framework.yaml"):
        path = tmp_path / filename
        path.write_text(content, encoding="utf-8")
        return path

    return _write


@pytest.fixture
def tmp_csv_file(tmp_path):
    """Return a helper that writes given text content to a temp .csv file and returns its path."""

    def _write(content: str, filename: str = "companies.csv"):
        path = tmp_path / filename
        path.write_text(content, encoding="utf-8")
        return path

    return _write


@pytest.fixture(scope="session")
def _test_engine():
    """
    Session-scoped engine against the dedicated test database, with schema
    created once per test run. Skips the whole session's DB-dependent tests
    (rather than erroring) if the test database isn't reachable — see
    module docstring.
    """
    engine = create_engine(_TEST_DATABASE_URL, future=True)
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception as exc:
        pytest.skip(
            f"Test database '{_TEST_DB_NAME}' not reachable ({exc}) — "
            f"skipping DB-dependent tests. Create it with: "
            f"CREATE DATABASE {_TEST_DB_NAME} OWNER {settings.db_user};"
        )

    Base.metadata.create_all(bind=engine)
    yield engine
    engine.dispose()


@pytest.fixture
def db_session(_test_engine):
    """
    A SQLAlchemy session scoped to a single test, wrapped in a transaction
    that's rolled back on teardown — see module docstring for why.
    """
    connection = _test_engine.connect()
    transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()

    yield session

    session.close()
    transaction.rollback()
    connection.close()
