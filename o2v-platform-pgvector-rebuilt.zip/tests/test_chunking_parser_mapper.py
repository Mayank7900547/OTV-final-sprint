"""
Unit tests for `src/chunking/parser_chunk_mapper.py`.

Uses a lightweight stand-in object (not the real `ParsedDocument` ORM
class) exposing just the attributes the mapper reads — avoids requiring a
database connection for what is otherwise pure-Python mapping logic.
"""

from dataclasses import dataclass, field

from src.chunking.parser_chunk_mapper import blocks_from_parsed_document


@dataclass
class _FakeParsedDocument:
    raw_text: str = ""
    page_text: list | None = None
    metadata_json: dict = field(default_factory=dict)


def test_blocks_from_paginated_document_preserves_page_numbers():
    doc = _FakeParsedDocument(
        page_text=[
            {"page_number": 1, "text": "First page paragraph."},
            {"page_number": 2, "text": "Second page paragraph."},
        ]
    )
    blocks = blocks_from_parsed_document(doc)

    pages = [b.page_number for b in blocks]
    assert pages == [1, 2]


def test_blocks_without_page_text_falls_back_to_raw_text_as_single_page():
    doc = _FakeParsedDocument(raw_text="Only raw text here, no pagination.", page_text=None)
    blocks = blocks_from_parsed_document(doc)

    assert len(blocks) == 1
    assert blocks[0].page_number is None
    assert blocks[0].text == "Only raw text here, no pagination."


def test_blocks_from_document_with_no_text_at_all_is_empty():
    doc = _FakeParsedDocument(raw_text="", page_text=None)
    assert blocks_from_parsed_document(doc) == []


def test_blocks_splits_page_text_into_paragraphs():
    doc = _FakeParsedDocument(
        page_text=[{"page_number": 1, "text": "Paragraph one.\n\nParagraph two."}]
    )
    blocks = blocks_from_parsed_document(doc)
    assert [b.text for b in blocks] == ["Paragraph one.", "Paragraph two."]


def test_known_html_heading_sets_section_title_for_following_paragraphs():
    doc = _FakeParsedDocument(
        page_text=[
            {
                "page_number": 1,
                "text": "About Us\n\nWe build great products.\n\nWe care about customers.",
            }
        ],
        metadata_json={"headings": [{"level": "h1", "text": "About Us"}]},
    )
    blocks = blocks_from_parsed_document(doc)

    heading_blocks = [b for b in blocks if b.is_heading]
    assert len(heading_blocks) == 1
    assert heading_blocks[0].text == "About Us"

    body_blocks = [b for b in blocks if not b.is_heading]
    assert all(b.section_title == "About Us" for b in body_blocks)


def test_section_title_persists_across_pages_until_next_heading():
    doc = _FakeParsedDocument(
        page_text=[
            {"page_number": 1, "text": "Risk Factors\n\nMarket risk applies broadly."},
            {"page_number": 2, "text": "Additional risk commentary continues here."},
        ],
        metadata_json={"headings": [{"level": "h2", "text": "Risk Factors"}]},
    )
    blocks = blocks_from_parsed_document(doc)

    body_blocks = [b for b in blocks if not b.is_heading]
    assert all(b.section_title == "Risk Factors" for b in body_blocks)
    # And page numbers are still tracked independently of the section.
    assert body_blocks[-1].page_number == 2


def test_paragraph_before_any_heading_has_no_section_title():
    doc = _FakeParsedDocument(page_text=[{"page_number": 1, "text": "Just a plain opening paragraph."}])
    blocks = blocks_from_parsed_document(doc)
    assert blocks[0].section_title is None


def test_pdf_style_document_uses_heading_heuristic_without_known_headings():
    doc = _FakeParsedDocument(
        page_text=[
            {
                "page_number": 1,
                "text": "Executive Summary\n\nThis quarter delivered strong results across the board.",
            }
        ],
        metadata_json={},  # no PDF headings metadata
    )
    blocks = blocks_from_parsed_document(doc)

    heading_blocks = [b for b in blocks if b.is_heading]
    assert len(heading_blocks) == 1
    assert heading_blocks[0].text == "Executive Summary"


def test_table_like_paragraph_flagged_as_table():
    doc = _FakeParsedDocument(
        page_text=[
            {
                "page_number": 1,
                "text": "Year    Revenue    Profit\n2023    1000       200\n2024    1200       260",
            }
        ]
    )
    blocks = blocks_from_parsed_document(doc)
    assert len(blocks) == 1
    assert blocks[0].is_table is True
