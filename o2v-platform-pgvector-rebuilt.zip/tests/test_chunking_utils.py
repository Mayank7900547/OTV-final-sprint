"""Unit tests for `src/chunking/utils.py`."""

from src.chunking.utils import split_paragraphs, split_sentences, truncate


def test_split_paragraphs_splits_on_blank_lines():
    text = "Para one.\n\nPara two.\n\n\nPara three."
    assert split_paragraphs(text) == ["Para one.", "Para two.", "Para three."]


def test_split_paragraphs_strips_and_drops_empties():
    text = "\n\n  First.  \n\n\n\n   \n\nSecond.\n\n"
    assert split_paragraphs(text) == ["First.", "Second."]


def test_split_paragraphs_empty_text_returns_empty_list():
    assert split_paragraphs("") == []
    assert split_paragraphs("   \n\n   ") == []


def test_split_paragraphs_single_paragraph_no_blank_lines():
    assert split_paragraphs("Just one paragraph, no breaks.") == ["Just one paragraph, no breaks."]


def test_split_sentences_splits_on_terminal_punctuation():
    text = "First sentence. Second sentence! Third one? Fourth."
    sentences = split_sentences(text)
    assert sentences == ["First sentence.", "Second sentence!", "Third one?", "Fourth."]


def test_split_sentences_does_not_split_on_abbreviation_periods_followed_by_lowercase():
    # A lowercase continuation after the period means our conservative
    # boundary regex should NOT treat it as a sentence break.
    text = "He works at e.g. a bank downtown."
    sentences = split_sentences(text)
    assert len(sentences) == 1


def test_split_sentences_empty_text_returns_empty_list():
    assert split_sentences("") == []


def test_truncate_returns_unchanged_text_under_limit():
    assert truncate("short", 100) == "short"


def test_truncate_cuts_and_marks_long_text():
    result = truncate("a" * 50, 10)
    assert result.startswith("a" * 10)
    assert result.endswith("[...truncated]")


def test_truncate_exact_length_is_unchanged():
    text = "a" * 10
    assert truncate(text, 10) == text
