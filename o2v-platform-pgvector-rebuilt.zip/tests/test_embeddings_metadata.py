"""
Unit tests for `src/embeddings/metadata.py`.

Uses lightweight stand-in objects (not real ORM instances) exposing just
the attributes `build_vector_metadata` reads — same approach
`test_chunking_parser_mapper.py` takes for `ParsedDocument`.
"""

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from src.embeddings.metadata import build_vector_metadata


@dataclass
class _FakeChunk:
    chunk_id: str = "1:0"
    page_number: int | None = 1
    section_title: str | None = "Overview"
    chunk_index: int = 0
    creation_timestamp: datetime | None = field(default_factory=lambda: datetime(2026, 1, 1, tzinfo=timezone.utc))


@dataclass
class _FakeDocument:
    id: uuid.UUID = field(default_factory=uuid.uuid4)
    document_type: str = "PDF"


@dataclass
class _FakeCompany:
    name: str = "Acme Corp"


def test_build_vector_metadata_includes_all_required_fields():
    chunk, document, company = _FakeChunk(), _FakeDocument(), _FakeCompany()
    metadata = build_vector_metadata(chunk, document, company)

    assert metadata["company"] == "Acme Corp"
    assert metadata["document_id"] == str(document.id)
    assert metadata["chunk_id"] == "1:0"
    assert metadata["page_number"] == 1
    assert metadata["section_title"] == "Overview"
    assert metadata["document_type"] == "PDF"
    assert metadata["chunk_index"] == 0
    assert metadata["creation_timestamp"] == "2026-01-01T00:00:00+00:00"


def test_build_vector_metadata_document_id_is_json_safe_string():
    chunk, document, company = _FakeChunk(), _FakeDocument(), _FakeCompany()
    metadata = build_vector_metadata(chunk, document, company)
    assert isinstance(metadata["document_id"], str)


def test_build_vector_metadata_handles_null_page_number_and_section():
    chunk = _FakeChunk(page_number=None, section_title=None)
    metadata = build_vector_metadata(chunk, _FakeDocument(), _FakeCompany())
    assert metadata["page_number"] is None
    assert metadata["section_title"] is None


def test_build_vector_metadata_handles_missing_creation_timestamp():
    chunk = _FakeChunk(creation_timestamp=None)
    metadata = build_vector_metadata(chunk, _FakeDocument(), _FakeCompany())
    assert metadata["creation_timestamp"] is None
