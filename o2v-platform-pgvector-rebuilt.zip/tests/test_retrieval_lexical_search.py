"""Integration tests for `src/retrieval/lexical_search.py`. Requires a real Postgres test database — skipped automatically if unreachable."""

from __future__ import annotations

import uuid

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.models import Chunk
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum
from src.retrieval.lexical_search import lexical_search

# Import so the table registers on Base.metadata, same requirement as conftest.py.
from src.retrieval import models as _retrieval_models_module  # noqa: F401


def _make_scenario(session, tmp_path, *, company_name="Lexical Test Co", texts=("Default chunk text.",)):
    company = Company(name=company_name, status="pending")
    session.add(company)
    session.flush()

    document = DocumentRegistry(
        company_id=company.id, document_name="Annual Report", document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value, document_year=2024,
        official_url=f"https://lextest.com/{uuid.uuid4()}.pdf", source_domain="lextest.com",
        discovery_method="sitemap_crawl", status=DocumentStatus.DISCOVERED.value,
    )
    session.add(document)
    session.flush()

    path = tmp_path / "report.pdf"
    path.write_bytes(b"%PDF-1.4 fake")
    version = DocumentVersion(
        document_id=document.id, version_number=1, file_hash="e" * 64,
        storage_path=str(path), file_size=path.stat().st_size, status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()

    parsed = ParsedDocument(
        document_id=document.id, document_version_id=version.id, parser_used="pdf_parser", parser_version="1.0.0",
        document_type=DocumentType.PDF.value, page_count=1, raw_text=" ".join(texts),
        page_text=[{"page_number": 1, "text": " ".join(texts)}], character_count=100, status=ParsingStatusEnum.SUCCESS,
    )
    session.add(parsed)
    session.flush()

    chunks = []
    for i, text in enumerate(texts):
        chunk = Chunk(
            chunk_id=f"{version.id}:{i}", document_id=document.id, document_version_id=version.id,
            parsed_document_id=parsed.id, chunk_index=i, page_number=1, section_title=None,
            text=text, character_count=len(text), token_estimate=max(1, len(text) // 4),
            chunker_used="recursive_chunker", chunker_version="1.0.0",
        )
        session.add(chunk)
        chunks.append(chunk)
    session.flush()

    return company, document, chunks


def test_lexical_search_finds_matching_chunk_by_keyword(db_session, tmp_path):
    _, _, chunks = _make_scenario(
        db_session, tmp_path,
        texts=("Our purpose is to expand access to capital for entrepreneurs.", "Unrelated content about logistics."),
    )
    results = lexical_search(db_session, "purpose capital entrepreneurs", top_k=10)
    chunk_ids = {r["chunk_id"] for r in results}
    assert chunks[0].id in chunk_ids
    assert chunks[1].id not in chunk_ids


def test_lexical_search_ranks_stronger_keyword_match_higher(db_session, tmp_path):
    _, _, chunks = _make_scenario(
        db_session, tmp_path,
        texts=(
            "Our purpose purpose purpose is central to everything we do as a purpose-driven company.",
            "This document mentions purpose exactly once in passing.",
        ),
    )
    results = lexical_search(db_session, "purpose", top_k=10)
    assert results[0]["chunk_id"] == chunks[0].id  # denser keyword match ranks first


def test_lexical_search_no_match_returns_empty_list(db_session, tmp_path):
    _make_scenario(db_session, tmp_path, texts=("Completely unrelated filler text about widgets.",))
    results = lexical_search(db_session, "zzsupercalifragilisticexpialidocious", top_k=10)
    assert results == []


def test_lexical_search_respects_top_k(db_session, tmp_path):
    _, _, chunks = _make_scenario(
        db_session, tmp_path,
        texts=tuple(f"Keyword match number {i} for testing purposes." for i in range(5)),
    )
    results = lexical_search(db_session, "keyword match testing", top_k=2)
    assert len(results) == 2


def test_lexical_search_scopes_by_company(db_session, tmp_path):
    company_a, _, chunks_a = _make_scenario(db_session, tmp_path, company_name="Lex Co A", texts=("Shared keyword phrase here.",))
    company_b, _, chunks_b = _make_scenario(db_session, tmp_path, company_name="Lex Co B", texts=("Shared keyword phrase here.",))

    results = lexical_search(db_session, "shared keyword phrase", top_k=10, company_id=company_a.id)
    chunk_ids = {r["chunk_id"] for r in results}
    assert chunks_a[0].id in chunk_ids
    assert chunks_b[0].id not in chunk_ids


def test_lexical_search_scopes_by_document(db_session, tmp_path):
    _, document, chunks = _make_scenario(db_session, tmp_path, texts=("Findable phrase in this document.",))
    results = lexical_search(db_session, "findable phrase document", top_k=10, document_id=document.id)
    assert chunks[0].id in {r["chunk_id"] for r in results}
