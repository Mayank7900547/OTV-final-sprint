"""Unit tests for `src/chunking/telemetry.py`."""

from src.chunking.telemetry import ChunkingTelemetry


def test_initial_summary_is_all_zero():
    t = ChunkingTelemetry()
    summary = t.get_summary()

    assert summary["documents_chunked"] == 0
    assert summary["chunks_created"] == 0
    assert summary["average_chunk_size"] == 0.0
    assert summary["average_processing_time"] == 0.0
    assert summary["validation_failures"] == 0
    assert summary["empty_chunks"] == 0
    assert summary["skipped_documents"] == 0
    assert summary["success_rate"] == 0.0


def test_record_success_accumulates_counters():
    t = ChunkingTelemetry()
    t.record_success(chunk_count=5, characters_processed=1000, duration=2.0)
    t.record_success(chunk_count=3, characters_processed=600, duration=1.0)

    summary = t.get_summary()

    assert summary["documents_chunked"] == 2
    assert summary["chunks_created"] == 8
    assert summary["average_processing_time"] == 1.5


def test_average_chunk_size_computed_from_total_characters_over_chunks():
    t = ChunkingTelemetry()
    t.record_success(chunk_count=4, characters_processed=800, duration=1.0)

    assert t.get_summary()["average_chunk_size"] == 200.0


def test_record_validation_failure_increments_counter():
    t = ChunkingTelemetry()
    t.record_validation_failure()
    t.record_validation_failure()

    assert t.get_summary()["validation_failures"] == 2


def test_record_empty_document_increments_counter():
    t = ChunkingTelemetry()
    t.record_empty_document()

    assert t.get_summary()["empty_chunks"] == 1


def test_record_skipped_increments_counter():
    t = ChunkingTelemetry()
    t.record_skipped()

    assert t.get_summary()["skipped_documents"] == 1


def test_success_rate_computed_against_success_plus_failures_plus_empty():
    t = ChunkingTelemetry()
    t.record_success(chunk_count=1, characters_processed=100, duration=0.1)
    t.record_success(chunk_count=1, characters_processed=100, duration=0.1)
    t.record_success(chunk_count=1, characters_processed=100, duration=0.1)
    t.record_validation_failure()

    assert t.get_summary()["success_rate"] == 0.75


def test_skipped_documents_do_not_affect_success_rate_denominator():
    t = ChunkingTelemetry()
    t.record_success(chunk_count=1, characters_processed=100, duration=0.1)
    t.record_skipped()

    # Skipped documents are excluded from the attempted-population math,
    # same convention `ParserTelemetry` follows for skipped documents.
    assert t.get_summary()["success_rate"] == 1.0


def test_reset_clears_all_counters():
    t = ChunkingTelemetry()
    t.record_success(chunk_count=2, characters_processed=200, duration=1.0)
    t.record_validation_failure()
    t.reset()

    summary = t.get_summary()
    assert summary["documents_chunked"] == 0
    assert summary["chunks_created"] == 0
    assert summary["validation_failures"] == 0
