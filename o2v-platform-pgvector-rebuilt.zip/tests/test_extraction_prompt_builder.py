"""Unit tests for `src/extraction/prompt_builder.py` — pure logic, no DB/network required."""

from __future__ import annotations

from src.extraction.prompt_builder import build_prompts
from src.extraction.types import EvidenceItem, FieldContext


def _field(**overrides) -> FieldContext:
    defaults = dict(
        framework_name="O2V",
        component_name="Purpose",
        field_name="Mission Statement",
        field_definition="An explicit statement of what the organization does day to day to fulfil its purpose.",
        expected_document_sources=["Annual Report", "About Us Page"],
    )
    defaults.update(overrides)
    return FieldContext(**defaults)


def _evidence(**overrides) -> EvidenceItem:
    defaults = dict(
        retrieval_id="req-1:1",
        chunk_text="Our mission is to organize the world's information.",
        document_id="doc-1",
        document_type="annual_report",
        document_year=2024,
        source_domain="example.com",
        page_number=5,
        section_title="Letter to Shareholders",
        final_score=0.87,
    )
    defaults.update(overrides)
    return EvidenceItem(**defaults)


def test_build_prompts_includes_company_component_field():
    system_prompt, user_prompt = build_prompts(company_name="Acme Corp", field=_field(), evidence=[_evidence()])
    assert "Acme Corp" in user_prompt
    assert "Purpose" in user_prompt
    assert "Mission Statement" in user_prompt
    assert _field().field_definition in user_prompt


def test_build_prompts_system_prompt_is_static_and_field_independent():
    """The system prompt must not hardcode this call's field name — it's shared across every field/company."""
    system_prompt_1, _ = build_prompts(company_name="Acme", field=_field(field_name="Mission Statement"), evidence=[])
    system_prompt_2, _ = build_prompts(company_name="Globex", field=_field(field_name="Core Values"), evidence=[])
    assert system_prompt_1 == system_prompt_2
    assert "Mission Statement" not in system_prompt_1
    assert "Core Values" not in system_prompt_1


def test_build_prompts_system_prompt_states_not_found_is_valid():
    system_prompt, _ = build_prompts(company_name="Acme", field=_field(), evidence=[])
    assert "Not Found" in system_prompt


def test_build_prompts_system_prompt_requires_json_only_output():
    system_prompt, _ = build_prompts(company_name="Acme", field=_field(), evidence=[])
    assert "JSON object" in system_prompt


def test_build_prompts_includes_evidence_text_and_retrieval_id():
    evidence = _evidence(chunk_text="A very specific evidence sentence about mission.")
    _, user_prompt = build_prompts(company_name="Acme", field=_field(), evidence=[evidence])
    assert "A very specific evidence sentence about mission." in user_prompt
    assert evidence.retrieval_id in user_prompt


def test_build_prompts_empty_evidence_says_so_explicitly():
    _, user_prompt = build_prompts(company_name="Acme", field=_field(), evidence=[])
    assert "No evidence was supplied" in user_prompt


def test_build_prompts_multiple_evidence_items_all_present():
    items = [
        _evidence(retrieval_id="req-1:1", chunk_text="First evidence sentence."),
        _evidence(retrieval_id="req-1:2", chunk_text="Second evidence sentence."),
    ]
    _, user_prompt = build_prompts(company_name="Acme", field=_field(), evidence=items)
    assert "First evidence sentence." in user_prompt
    assert "Second evidence sentence." in user_prompt
    assert "req-1:1" in user_prompt
    assert "req-1:2" in user_prompt


def test_build_prompts_truncates_oversized_evidence_text(monkeypatch):
    from src.config.settings import settings

    monkeypatch.setattr(settings, "extraction_evidence_max_chars_per_item", 20)
    long_text = "x" * 500
    _, user_prompt = build_prompts(company_name="Acme", field=_field(), evidence=[_evidence(chunk_text=long_text)])
    assert "[...truncated]" in user_prompt
    assert long_text not in user_prompt


def test_build_prompts_missing_field_definition_falls_back_gracefully():
    _, user_prompt = build_prompts(company_name="Acme", field=_field(field_definition=None), evidence=[])
    assert "FIELD DEFINITION:" in user_prompt


def test_build_prompts_no_expected_sources_falls_back_gracefully():
    _, user_prompt = build_prompts(company_name="Acme", field=_field(expected_document_sources=[]), evidence=[])
    assert "any official corporate publication" in user_prompt
