"""
Integration tests for `src/extraction/extraction_service.py` (ExtractionService).
Requires a real Postgres test database — skipped automatically if
unreachable (see `tests/conftest.py::db_session`).

Uses a scripted `_FakeLLMProvider` throughout (injected via
`ExtractionService(llm_provider=...)`, see that constructor arg's
docstring) — no real LLM provider, network, or API key is ever used here.
Evidence pools are built directly against `RetrievedEvidence` rows (real
Sprint 7 output shape), not a parallel structure — this is what exercises
the actual Sprint 7 -> Sprint 8 integration boundary.
"""

from __future__ import annotations

import json
import uuid

import pytest

from src.core.constants import DocumentCategory, DocumentStatus, DocumentType, EvidenceConfidence, ExtractionStatus
from src.extraction.exceptions import FrameworkFieldNotFoundError
from src.extraction.extraction_service import ExtractionService, available_components
from src.extraction.models import ExtractionResult
from src.extraction.telemetry import telemetry as extraction_telemetry
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.models.framework import Framework
from src.retrieval.models import RetrievedEvidence


@pytest.fixture(autouse=True)
def _reset_telemetry():
    extraction_telemetry.reset()
    yield
    extraction_telemetry.reset()


class _FakeLLMProvider:
    """Returns scripted raw-text responses in order, one per `complete()` call — lets a test simulate a malformed-then-corrected sequence for retry testing."""

    provider_name = "fake"

    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self.calls: list[dict] = []

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        self.calls.append({"system_prompt": system_prompt, "user_prompt": user_prompt})
        if not self._responses:
            raise AssertionError("_FakeLLMProvider ran out of scripted responses")
        return self._responses.pop(0)

    def health_check(self, timeout: float | None = None) -> bool:
        """Always healthy — matches BaseLLMProvider's interface; tests that specifically need an unhealthy provider use _UnhealthyLLMProvider instead."""
        return True


class _AlwaysRaisingLLMProvider:
    provider_name = "fake_unavailable"

    def __init__(self, exc):
        self._exc = exc
        self.calls = 0

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        self.calls += 1
        raise self._exc

    def health_check(self, timeout: float | None = None) -> bool:
        """Reports healthy even though complete() always raises — deliberately, so existing tests exercising the retry/PROVIDER_ERROR path aren't short-circuited by the new pre-flight check. See test_extract_field_skips_all_when_health_check_fails for the case that actually tests an unhealthy provider."""
        return True


class _UnhealthyLLMProvider:
    """Reports unhealthy without ever being asked to complete() — for testing the pre-flight health check itself."""

    provider_name = "fake_unhealthy"

    def __init__(self):
        self.complete_calls = 0

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        self.complete_calls += 1
        raise AssertionError("complete() should never be called when health_check() returns False")

    def health_check(self, timeout: float | None = None) -> bool:
        return False


def _success_json(*, exact_text, confidence="High", remarks=None, source_retrieval_id=None):
    return json.dumps(
        {"exact_text": exact_text, "confidence": confidence, "remarks": remarks, "source_retrieval_id": source_retrieval_id}
    )


def _make_company(session, name):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company, *, document_category=DocumentCategory.ANNUAL_REPORT.value, document_name="Annual Report 2024", year=2024):
    doc = DocumentRegistry(
        company_id=company.id, document_name=document_name, document_category=document_category,
        document_type=DocumentType.PDF.value, document_year=year,
        official_url=f"https://example.com/{uuid.uuid4()}.pdf", source_domain="example.com",
        discovery_method="sitemap_crawl", status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _seed_framework(session, *, framework_name, component, fields):
    """`fields` is a list of (field_name, description, document_sources) tuples."""
    rows = [
        Framework(framework_name=framework_name, component_name=component, field_name=name, description=desc, document_sources=sources)
        for name, desc, sources in fields
    ]
    session.add_all(rows)
    session.flush()
    return rows


def _make_evidence(session, *, company, document, component, request_id, rank, chunk_text, final_score=0.9, page_number=1, section_title=None):
    row = RetrievedEvidence(
        retrieval_id=f"{request_id}:{rank}", request_id=request_id, chunk_id=None,
        document_id=document.id, company_id=company.id, component=component, rank=rank,
        semantic_score=final_score, lexical_score=0.0, metadata_score=0.0, final_score=final_score,
        page_number=page_number, section_title=section_title, chunk_text=chunk_text,
        source_metadata={"document_year": document.document_year, "source_domain": document.source_domain, "chunk_index": rank},
    )
    session.add(row)
    session.flush()
    return row


PURPOSE_FIELDS = [
    ("Mission Statement", "An explicit 'why we exist' statement, distinct from mission/vision if present.", ["Annual Report"]),
]
BEHAVIOUR_FIELDS = [
    ("Code of Conduct", "The organization's documented standards of employee conduct and ethics.", ["Code of Conduct"]),
]
VALUE_AGENDA_FIELDS = [
    ("Strategic Priorities", "The organization's stated top strategic priorities for the short-to-medium term.", ["Annual Report"]),
]


# --------------------------------------------------------------------------
# 1-4: valid structured extraction / one per component / field-specific
# --------------------------------------------------------------------------


def test_purpose_extraction_success(db_session):
    fw = f"ES-Purpose-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Purpose Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(
        db_session, company=company, document=document, component="Purpose", request_id="req-p1", rank=1,
        chunk_text="Our mission is to organize the world's information and make it universally accessible.",
    )

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["confidence"] == "High"
    assert outcome["exact_text"] == evidence.chunk_text


def test_behaviour_extraction_success(db_session):
    fw = f"ES-Behaviour-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Behaviour", fields=BEHAVIOUR_FIELDS)
    company = _make_company(db_session, "Behaviour Co")
    document = _make_document(db_session, company, document_category=DocumentCategory.CODE_OF_CONDUCT.value)
    evidence = _make_evidence(
        db_session, company=company, document=document, component="Behaviour", request_id="req-b1", rank=1,
        chunk_text="Employees are expected to act with integrity and report ethical violations promptly.",
    )

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Behaviour", field_name="Code of Conduct", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["exact_text"] == evidence.chunk_text


def test_value_agenda_extraction_success(db_session):
    fw = f"ES-ValueAgenda-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Value Agenda", fields=VALUE_AGENDA_FIELDS)
    company = _make_company(db_session, "ValueAgenda Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(
        db_session, company=company, document=document, component="Value Agenda", request_id="req-v1", rank=1,
        chunk_text="Our top strategic priorities for the next three years are AI adoption, cloud migration, and sustainability.",
    )

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Value Agenda", field_name="Strategic Priorities", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["confidence"] == "High"


def test_extract_field_raises_for_unregistered_field(db_session):
    fw = f"ES-Missing-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Missing Field Co")

    service = ExtractionService(llm_provider=_FakeLLMProvider([]))
    with pytest.raises(FrameworkFieldNotFoundError):
        service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Nonexistent Field", framework_name=fw)


# --------------------------------------------------------------------------
# 5-6: exact evidence preservation, source traceability
# --------------------------------------------------------------------------


def test_exact_evidence_text_is_preserved_verbatim(db_session):
    fw = f"ES-Verbatim-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Verbatim Co")
    document = _make_document(db_session, company)
    original_text = "We exist to remove barriers preventing entrepreneurs from accessing capital, technology and markets."
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-e1", rank=1, chunk_text=original_text)

    fake_llm = _FakeLLMProvider([_success_json(exact_text=original_text, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["exact_text"] == original_text  # not paraphrased, not truncated, not reformatted


def test_source_traceability_fields_are_populated(db_session):
    fw = f"ES-Trace-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Trace Co")
    document = _make_document(db_session, company, document_name="Trace Annual Report", year=2023)
    evidence = _make_evidence(
        db_session, company=company, document=document, component="Purpose", request_id="req-t1", rank=1,
        chunk_text="Our purpose is to trace things.", page_number=42, section_title="CEO Letter",
    )

    fake_llm = _FakeLLMProvider([_success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["source_document_name"] == "Trace Annual Report"
    assert outcome["document_year"] == 2023
    assert outcome["page_number"] == 42
    assert outcome["section_title"] == "CEO Letter"
    assert outcome["source_url"] == document.official_url
    assert outcome["source_retrieval_id"] == evidence.retrieval_id

    # Also persisted to the staging store, not just returned in the outcome dict.
    row = db_session.query(ExtractionResult).filter(ExtractionResult.company_id == company.id).first()
    assert row.source_document_id == document.id
    assert row.page_number == 42


# --------------------------------------------------------------------------
# 9-11: Not Found, confidence, remarks
# --------------------------------------------------------------------------


def test_not_found_when_evidence_does_not_support_field(db_session):
    fw = f"ES-NotFound-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "NotFound Co")
    document = _make_document(db_session, company)
    _make_evidence(
        db_session, company=company, document=document, component="Purpose", request_id="req-nf1", rank=1,
        chunk_text="Our quarterly revenue grew 4% year over year.",
    )

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=None, confidence="Not Found", remarks="No explicit purpose/mission statement was present in the supplied evidence.")
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["confidence"] == "Not Found"
    assert outcome["exact_text"] is None
    assert outcome["remarks"]


def test_medium_confidence_requires_and_preserves_remarks(db_session):
    fw = f"ES-Medium-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Medium Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(
        db_session, company=company, document=document, component="Purpose", request_id="req-m1", rank=1,
        chunk_text="We aim to remove barriers preventing entrepreneurs from accessing capital and markets.",
    )

    remark_text = "Concept is clearly present but the literal term 'purpose' is never used."
    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=evidence.chunk_text, confidence="Medium", remarks=remark_text, source_retrieval_id=evidence.retrieval_id)
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["confidence"] == "Medium"
    assert outcome["remarks"] == remark_text


# --------------------------------------------------------------------------
# Concept-without-terminology recognition (Sprint 8 brief's explicit
# "IMPORTANT TEST") + irrelevant-evidence negative test
# --------------------------------------------------------------------------


def test_evidence_without_literal_terminology_is_still_extractable(db_session):
    """Sprint 7 already selected this evidence semantically — Sprint 8 must not require the literal framework keyword to be present."""
    fw = f"ES-NoKeyword-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "NoKeyword Co")
    document = _make_document(db_session, company)
    text_without_keyword = "We are here to remove barriers preventing entrepreneurs from accessing capital, technology and markets."
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-nk1", rank=1, chunk_text=text_without_keyword)

    fake_llm = _FakeLLMProvider([_success_json(exact_text=text_without_keyword, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert "purpose" not in outcome["exact_text"].lower()
    assert outcome["confidence"] == "High"


def test_irrelevant_evidence_is_not_forced_into_field(db_session):
    """Evidence that sounds generally relevant but doesn't satisfy the field definition must come back Not Found, not be force-fit."""
    fw = f"ES-Irrelevant-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Irrelevant Co")
    document = _make_document(db_session, company)
    _make_evidence(
        db_session, company=company, document=document, component="Purpose", request_id="req-irr1", rank=1,
        chunk_text="Our CEO's personal purpose in life is to run marathons on every continent.",
    )

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text=None, confidence="Not Found", remarks="The evidence mentions 'purpose' but refers to the CEO's personal life, not an organizational purpose statement.")
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["confidence"] == "Not Found"


# --------------------------------------------------------------------------
# 12-13: conflicting evidence, multiple evidence items
# --------------------------------------------------------------------------


def test_multiple_evidence_items_all_supplied_to_llm(db_session):
    fw = f"ES-Multi-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Multi Co")
    document = _make_document(db_session, company)
    e1 = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-mu1", rank=1, chunk_text="First candidate sentence about purpose.")
    e2 = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-mu1", rank=2, chunk_text="Second candidate sentence about purpose.")

    fake_llm = _FakeLLMProvider([_success_json(exact_text=e1.chunk_text, confidence="High", source_retrieval_id=e1.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    user_prompt = fake_llm.calls[0]["user_prompt"]
    assert e1.chunk_text in user_prompt
    assert e2.chunk_text in user_prompt


def test_conflicting_evidence_preserved_via_remarks(db_session):
    """The service doesn't resolve conflicts itself — it persists whatever the LLM reports, including a conflict remark citing the higher-priority source."""
    fw = f"ES-Conflict-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Conflict Co")
    annual_report = _make_document(db_session, company, document_category=DocumentCategory.ANNUAL_REPORT.value, document_name="Annual Report")
    about_us = _make_document(db_session, company, document_category=DocumentCategory.ABOUT_US.value, document_name="About Us Page")
    e1 = _make_evidence(db_session, company=company, document=annual_report, component="Purpose", request_id="req-cf1", rank=1, chunk_text="Our purpose is to lead in sustainable manufacturing.")
    e2 = _make_evidence(db_session, company=company, document=about_us, component="Purpose", request_id="req-cf1", rank=2, chunk_text="Our purpose is to be the world's most customer-centric company.")

    conflict_remark = "Annual Report and About Us page state different purpose statements; Annual Report (higher priority) used."
    fake_llm = _FakeLLMProvider([_success_json(exact_text=e1.chunk_text, confidence="Low", remarks=conflict_remark, source_retrieval_id=e1.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["confidence"] == "Low"
    assert outcome["remarks"] == conflict_remark
    assert outcome["exact_text"] == e1.chunk_text


# --------------------------------------------------------------------------
# 14: empty evidence input
# --------------------------------------------------------------------------


def test_no_evidence_returns_no_evidence_status_without_calling_llm(db_session):
    fw = f"ES-Empty-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Empty Co")

    fake_llm = _FakeLLMProvider([])  # would raise if called at all
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.NO_EVIDENCE.value
    assert fake_llm.calls == []

    row = db_session.query(ExtractionResult).filter(ExtractionResult.company_id == company.id).first()
    assert row.status == ExtractionStatus.NO_EVIDENCE.value


# --------------------------------------------------------------------------
# 16-17: malformed LLM output / JSON parsing failure (with retry recovery)
# --------------------------------------------------------------------------


def test_malformed_json_retries_then_succeeds(db_session):
    fw = f"ES-Retry-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Retry Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-r1", rank=1, chunk_text="Our purpose is clear.")

    fake_llm = _FakeLLMProvider([
        "this is not json at all",
        _success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id),
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["retries"] == 1
    assert len(fake_llm.calls) == 2
    # The retry prompt must include the original error so the model can self-correct.
    assert "could not be used" in fake_llm.calls[1]["user_prompt"]


def test_persistently_malformed_json_fails_after_retry_budget_exhausted(db_session, monkeypatch):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "llm_retry_limit", 1)
    monkeypatch.setattr(settings, "llm_retry_backoff_seconds", 0.0)

    fw = f"ES-RetryExhaust-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "RetryExhaust Co")
    document = _make_document(db_session, company)
    _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-re1", rank=1, chunk_text="Our purpose is clear.")

    fake_llm = _FakeLLMProvider(["not json", "still not json"])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.PARSE_ERROR.value
    assert outcome["error"]
    assert len(fake_llm.calls) == 2  # 1 initial + 1 retry (llm_retry_limit=1)


def test_provider_unavailable_after_retries_fails_gracefully(db_session, monkeypatch):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "llm_retry_limit", 1)
    monkeypatch.setattr(settings, "llm_retry_backoff_seconds", 0.0)

    from src.extraction.exceptions import LLMProviderUnavailableError

    fw = f"ES-ProviderDown-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "ProviderDown Co")
    document = _make_document(db_session, company)
    _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-pd1", rank=1, chunk_text="Our purpose is clear.")

    fake_llm = _AlwaysRaisingLLMProvider(LLMProviderUnavailableError("simulated outage"))
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["status"] == ExtractionStatus.PROVIDER_ERROR.value
    assert fake_llm.calls == 2  # 1 initial + 1 retry


# --------------------------------------------------------------------------
# 18: provider abstraction (service works identically regardless of which
# provider instance is injected — the real assertion is "the service layer
# never imports a concrete provider class", verified by these tests using
# a provider that isn't even registered in llm_factory at all)
# --------------------------------------------------------------------------


def test_service_works_with_any_object_implementing_complete(db_session):
    """The service only depends on `.complete()` existing — proven by using a provider class not registered in llm_factory.py at all."""
    fw = f"ES-Abstraction-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Abstraction Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-ab1", rank=1, chunk_text="Our purpose is abstraction.")

    fake_llm = _FakeLLMProvider([_success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)
    assert outcome["status"] == ExtractionStatus.SUCCESS.value
    assert outcome["llm_provider"] == "fake"


# --------------------------------------------------------------------------
# 20: Sprint 7 -> Sprint 8 integration (real RetrievedEvidence rows, most
# recent request_id selection, multi-request-id history)
# --------------------------------------------------------------------------


def test_extraction_uses_most_recent_retrieval_request(db_session):
    fw = f"ES-Recency-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Recency Co")
    document = _make_document(db_session, company)

    # Older retrieval run.
    _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-old", rank=1, chunk_text="Stale evidence from an old run.")
    # Newer retrieval run (should be the one used).
    fresh = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-new", rank=1, chunk_text="Fresh evidence from the latest run.")

    fake_llm = _FakeLLMProvider([_success_json(exact_text=fresh.chunk_text, confidence="High", source_retrieval_id=fresh.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcome = service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    assert outcome["request_id"] == "req-new"
    assert "Stale evidence" not in fake_llm.calls[0]["user_prompt"]
    assert "Fresh evidence" in fake_llm.calls[0]["user_prompt"]


def test_extract_component_runs_every_registered_field(db_session):
    fw = f"ES-Component-{uuid.uuid4()}"
    fields = [
        ("Mission Statement", "desc 1", ["Annual Report"]),
        ("Vision Statement", "desc 2", ["Annual Report"]),
    ]
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=fields)
    company = _make_company(db_session, "Component Co")
    document = _make_document(db_session, company)
    _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-c1", rank=1, chunk_text="Our mission and vision statement.")

    fake_llm = _FakeLLMProvider([
        _success_json(exact_text="mission text", confidence="High", source_retrieval_id="req-c1:1"),
        _success_json(exact_text="vision text", confidence="High", source_retrieval_id="req-c1:1"),
    ])
    service = ExtractionService(llm_provider=fake_llm)
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    assert len(outcomes) == 2
    assert {o["field_name"] for o in outcomes} == {"Mission Statement", "Vision Statement"}
    assert all(o["status"] == ExtractionStatus.SUCCESS.value for o in outcomes)


# --------------------------------------------------------------------------
# extract_component — pre-flight health check and circuit breaker
# (added after a real overnight run where every field timed out against a
# resource-starved local Ollama server, taking hours to discover)
# --------------------------------------------------------------------------


def test_extract_component_skips_all_fields_when_health_check_fails(db_session):
    fw = f"ES-Unhealthy-{uuid.uuid4()}"
    fields = [("Mission Statement", "desc", []), ("Core Values", "desc", [])]
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=fields)
    company = _make_company(db_session, "Unhealthy Co")
    document = _make_document(db_session, company)
    _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-u1", rank=1, chunk_text="Evidence that would never actually get used.")

    unhealthy_provider = _UnhealthyLLMProvider()
    service = ExtractionService(llm_provider=unhealthy_provider)
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    assert outcomes == []
    assert unhealthy_provider.complete_calls == 0  # never even attempted a real call


def test_extract_component_proceeds_normally_when_health_check_passes(db_session):
    """Sanity check that a healthy provider isn't accidentally blocked by the new pre-flight check."""
    fw = f"ES-Healthy-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Healthy Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-h1", rank=1, chunk_text="Our purpose is healthy.")

    fake_llm = _FakeLLMProvider([_success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    assert len(outcomes) == 1
    assert outcomes[0]["status"] == ExtractionStatus.SUCCESS.value


def test_extract_component_circuit_breaker_stops_after_consecutive_failures(db_session, monkeypatch):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "llm_circuit_breaker_threshold", 2)
    monkeypatch.setattr(settings, "llm_retry_limit", 0)  # fail fast, don't wait out retries in this test

    fw = f"ES-CircuitBreaker-{uuid.uuid4()}"
    fields = [(f"Field {i}", "desc", []) for i in range(5)]
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=fields)
    company = _make_company(db_session, "CircuitBreaker Co")
    document = _make_document(db_session, company)
    for i in range(5):
        _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-cb1", rank=i + 1, chunk_text=f"Evidence {i} for a field that will fail.")

    from src.extraction.exceptions import LLMProviderUnavailableError

    class _HealthyButFailingProvider:
        provider_name = "fake_flaky"

        def __init__(self):
            self.complete_calls = 0

        def complete(self, *, system_prompt, user_prompt):
            self.complete_calls += 1
            raise LLMProviderUnavailableError("simulated persistent outage")

        def health_check(self, timeout=None):
            return True  # provider looks reachable at the pre-flight check...

    flaky_provider = _HealthyButFailingProvider()
    service = ExtractionService(llm_provider=flaky_provider)
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    # ...but every real call fails, so the breaker should trip after 2
    # consecutive failures and stop well short of attempting all 5 fields.
    assert len(outcomes) == 2
    assert all(o["status"] == ExtractionStatus.PROVIDER_ERROR.value for o in outcomes)
    assert flaky_provider.complete_calls == 2  # confirms the remaining 3 fields were never even attempted


def test_extract_component_circuit_breaker_resets_on_success(db_session, monkeypatch):
    """A success in between failures resets the consecutive-failure count — the breaker should NOT trip on 1-fail, 1-succeed, 1-fail."""
    from src.config.settings import settings
    monkeypatch.setattr(settings, "llm_circuit_breaker_threshold", 2)
    monkeypatch.setattr(settings, "llm_retry_limit", 0)

    fw = f"ES-CircuitReset-{uuid.uuid4()}"
    fields = [("Field A", "desc", []), ("Field B", "desc", []), ("Field C", "desc", [])]
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=fields)
    company = _make_company(db_session, "CircuitReset Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-cr1", rank=1, chunk_text="Some evidence.")

    from src.extraction.exceptions import LLMProviderUnavailableError

    class _AlternatingProvider:
        provider_name = "fake_alternating"

        def __init__(self):
            self.call_count = 0

        def complete(self, *, system_prompt, user_prompt):
            self.call_count += 1
            if self.call_count == 2:  # Field B succeeds; A and C fail
                return _success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)
            raise LLMProviderUnavailableError("simulated transient failure")

        def health_check(self, timeout=None):
            return True

    provider = _AlternatingProvider()
    service = ExtractionService(llm_provider=provider)
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    # All 3 attempted (breaker never saw 2 CONSECUTIVE failures — success in the middle reset the streak).
    assert len(outcomes) == 3
    assert [o["status"] for o in outcomes] == [
        ExtractionStatus.PROVIDER_ERROR.value, ExtractionStatus.SUCCESS.value, ExtractionStatus.PROVIDER_ERROR.value,
    ]


def test_extract_component_circuit_breaker_disabled_when_threshold_zero(db_session, monkeypatch):
    from src.config.settings import settings
    monkeypatch.setattr(settings, "llm_circuit_breaker_threshold", 0)
    monkeypatch.setattr(settings, "llm_retry_limit", 0)

    fw = f"ES-CircuitDisabled-{uuid.uuid4()}"
    fields = [(f"Field {i}", "desc", []) for i in range(4)]
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=fields)
    company = _make_company(db_session, "CircuitDisabled Co")
    document = _make_document(db_session, company)
    for i in range(4):
        _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-cd1", rank=i + 1, chunk_text=f"Evidence {i}.")

    from src.extraction.exceptions import LLMProviderUnavailableError

    class _AlwaysFailingButHealthyProvider:
        provider_name = "fake_always_fails"

        def complete(self, *, system_prompt, user_prompt):
            raise LLMProviderUnavailableError("simulated outage")

        def health_check(self, timeout=None):
            return True

    service = ExtractionService(llm_provider=_AlwaysFailingButHealthyProvider())
    outcomes = service.extract_component(db_session, company_id=company.id, component="Purpose", framework_name=fw)

    # threshold=0 means disabled — every field is still attempted despite all failing.
    assert len(outcomes) == 4


def test_available_components_reflects_framework_registry(db_session):
    fw = f"ES-AvailComp-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    _seed_framework(db_session, framework_name=fw, component="Behaviour", fields=BEHAVIOUR_FIELDS)

    components = available_components(db_session, framework_name=fw)
    assert set(components) == {"Purpose", "Behaviour"}


# --------------------------------------------------------------------------
# Re-extraction upserts the same staging row (queryable/updatable store,
# not an append-only log) rather than accumulating duplicate rows.
# --------------------------------------------------------------------------


def test_re_extraction_updates_existing_row_not_duplicates(db_session):
    fw = f"ES-Upsert-{uuid.uuid4()}"
    _seed_framework(db_session, framework_name=fw, component="Purpose", fields=PURPOSE_FIELDS)
    company = _make_company(db_session, "Upsert Co")
    document = _make_document(db_session, company)
    evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-up1", rank=1, chunk_text="Our purpose, version one.")

    fake_llm = _FakeLLMProvider([_success_json(exact_text=evidence.chunk_text, confidence="High", source_retrieval_id=evidence.retrieval_id)])
    service = ExtractionService(llm_provider=fake_llm)
    service.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    updated_evidence = _make_evidence(db_session, company=company, document=document, component="Purpose", request_id="req-up2", rank=1, chunk_text="Our purpose, version two.")
    fake_llm_2 = _FakeLLMProvider([_success_json(exact_text=updated_evidence.chunk_text, confidence="High", source_retrieval_id=updated_evidence.retrieval_id)])
    service_2 = ExtractionService(llm_provider=fake_llm_2)
    service_2.extract_field(db_session, company_id=company.id, component="Purpose", field_name="Mission Statement", framework_name=fw)

    rows = db_session.query(ExtractionResult).filter(ExtractionResult.company_id == company.id).all()
    assert len(rows) == 1
    assert rows[0].exact_text == "Our purpose, version two."
