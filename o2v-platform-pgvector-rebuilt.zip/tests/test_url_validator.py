"""
Tests for src/discovery/url_validator.py.

These are the tests that actually prove the Sprint 2 brief's URL
validation requirement: Wikipedia, blogs, news sites, forums, and GitHub
mirrors are rejected, while a company's own domain/subdomains and SEC
EDGAR are accepted — all via the allowlist-first design (see that
module's docstring), not because any of these specific domains are named
anywhere in the implementation.
"""

from src.discovery.url_validator import validate_url


def test_company_own_domain_is_allowed():
    result = validate_url("https://www.apple.com/about/", company_website="apple.com")
    assert result.allowed is True
    assert result.domain == "www.apple.com"


def test_company_subdomain_is_allowed():
    result = validate_url("https://investor.apple.com/annual-reports", company_website="apple.com")
    assert result.allowed is True


def test_sec_edgar_domain_is_allowed_regardless_of_company_website():
    result = validate_url(
        "https://www.sec.gov/Archives/edgar/data/320193/x.htm", company_website="apple.com"
    )
    assert result.allowed is True


def test_sec_edgar_allowed_even_with_no_company_website():
    result = validate_url("https://data.sec.gov/submissions/CIK0000320193.json", company_website=None)
    assert result.allowed is True


def test_wikipedia_is_rejected():
    result = validate_url("https://en.wikipedia.org/wiki/Apple_Inc.", company_website="apple.com")
    assert result.allowed is False
    assert result.reason is not None


def test_blog_platform_is_rejected():
    result = validate_url("https://appleinsider.medium.com/some-post", company_website="apple.com")
    assert result.allowed is False


def test_news_site_is_rejected():
    result = validate_url("https://www.reuters.com/business/apple-earnings", company_website="apple.com")
    assert result.allowed is False


def test_github_mirror_is_rejected():
    result = validate_url("https://github.com/someone/apple-10k-mirror", company_website="apple.com")
    assert result.allowed is False


def test_unrelated_companys_own_domain_is_rejected():
    # A URL on a DIFFERENT company's real domain should not validate for
    # this company — otherwise the allowlist would be meaninglessly broad.
    result = validate_url("https://www.microsoft.com/investor-relations", company_website="apple.com")
    assert result.allowed is False


def test_no_company_website_rejects_arbitrary_domain():
    result = validate_url("https://www.apple.com/about/", company_website=None)
    assert result.allowed is False


def test_unparseable_url_is_rejected():
    result = validate_url("not a url at all", company_website="apple.com")
    assert result.allowed is False
    assert result.domain is None


def test_lookalike_domain_is_not_treated_as_subdomain():
    # "notapple.com" is NOT a subdomain of "apple.com" — string-suffix
    # matching must check for a "." boundary, not just str.endswith.
    result = validate_url("https://www.notapple.com/fake", company_website="apple.com")
    assert result.allowed is False
