"""Unit tests for `src/retrieval/utils.py` and `src/retrieval/validation.py`."""

import pytest

from src.retrieval.exceptions import MetadataFilterError, QueryGenerationError
from src.retrieval.utils import new_request_id
from src.retrieval.validation import validate_component_name, validate_metadata_filters


def test_new_request_id_returns_nonempty_string():
    request_id = new_request_id()
    assert isinstance(request_id, str)
    assert len(request_id) > 0


def test_new_request_id_is_unique_across_calls():
    ids = {new_request_id() for _ in range(100)}
    assert len(ids) == 100


def test_validate_metadata_filters_none_is_valid():
    validate_metadata_filters(None)  # should not raise


def test_validate_metadata_filters_empty_dict_is_valid():
    validate_metadata_filters({})  # should not raise


def test_validate_metadata_filters_allowed_keys_pass():
    validate_metadata_filters({"document_type": "Annual Report", "section": "Overview", "page": 1})


def test_validate_metadata_filters_rejects_unknown_key():
    with pytest.raises(MetadataFilterError):
        validate_metadata_filters({"not_a_real_filter": "value"})


def test_validate_component_name_passes_for_known_component():
    validate_component_name("Purpose", ["Purpose", "Behaviour", "Value Agenda"])


def test_validate_component_name_raises_for_unknown_component():
    with pytest.raises(QueryGenerationError):
        validate_component_name("NotARealComponent", ["Purpose", "Behaviour"])
