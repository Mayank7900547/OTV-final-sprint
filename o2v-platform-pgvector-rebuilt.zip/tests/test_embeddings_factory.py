"""
Unit tests for `src/embeddings/embedding_factory.py`.

`OpenAIEmbeddingProvider` tests inject a fake `client` (see the
provider's `client=` constructor param, added specifically so tests
never need a real API key or network access) — no real OpenAI API call
is ever made here.
"""

from types import SimpleNamespace

import httpx
import pytest

from src.embeddings.embedding_factory import (
    available_providers,
    get_provider,
    OllamaEmbeddingProvider,
    OpenAIEmbeddingProvider,
)
from src.embeddings.exceptions import EmbeddingConfigurationError, InvalidProviderResponseError, ProviderUnavailableError


# ---------------------------------------------------------------------------
# Registry / factory
# ---------------------------------------------------------------------------


def test_available_providers_includes_openai_and_all_placeholders():
    providers = available_providers()
    for expected in ["openai", "nomic", "bge", "e5", "sentence_transformers", "ollama", "lm_studio", "azure_openai"]:
        assert expected in providers


def test_get_provider_by_explicit_name_constructs_correct_class():
    provider = get_provider("openai", model_name="text-embedding-3-small", model_version="1", embedding_dimension=8)
    assert isinstance(provider, OpenAIEmbeddingProvider)
    assert provider.provider_name == "openai"


def test_get_provider_defaults_model_fields_from_settings():
    provider = get_provider("openai")
    assert provider.model_name  # populated from settings.embeddings_model_name
    assert provider.embedding_dimension > 0


def test_get_provider_unknown_name_raises_configuration_error():
    with pytest.raises(EmbeddingConfigurationError):
        get_provider("not_a_real_provider")


def test_get_provider_is_case_insensitive():
    provider = get_provider("OpenAI", embedding_dimension=8)
    assert isinstance(provider, OpenAIEmbeddingProvider)


# ---------------------------------------------------------------------------
# OpenAIEmbeddingProvider — with an injected fake client (no network)
# ---------------------------------------------------------------------------


def _fake_openai_response(vectors: list[list[float]]):
    """Builds a stand-in for the OpenAI SDK's `embeddings.create()` response shape."""
    data = [SimpleNamespace(embedding=vec, index=i) for i, vec in enumerate(vectors)]
    return SimpleNamespace(data=data)


class _FakeOpenAIClient:
    def __init__(self, vectors: list[list[float]]):
        self._vectors = vectors
        self.calls = []
        self.embeddings = SimpleNamespace(create=self._create)

    def _create(self, *, model, input, dimensions):
        self.calls.append({"model": model, "input": input, "dimensions": dimensions})
        return _fake_openai_response(self._vectors)


def test_openai_provider_embed_batch_returns_vectors_in_order():
    fake_client = _FakeOpenAIClient(vectors=[[1.0, 2.0], [3.0, 4.0]])
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, client=fake_client
    )
    vectors = provider.embed_batch(["hello", "world"])
    assert vectors == [[1.0, 2.0], [3.0, 4.0]]
    assert fake_client.calls[0]["input"] == ["hello", "world"]


def test_openai_provider_embed_batch_reorders_by_returned_index():
    # Response comes back with indices swapped — provider must reorder to match input order.
    vectors_out_of_order = [SimpleNamespace(embedding=[9.0, 9.0], index=1), SimpleNamespace(embedding=[1.0, 1.0], index=0)]
    fake_client = SimpleNamespace(
        embeddings=SimpleNamespace(create=lambda **kwargs: SimpleNamespace(data=vectors_out_of_order))
    )
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, client=fake_client
    )
    vectors = provider.embed_batch(["first", "second"])
    assert vectors == [[1.0, 1.0], [9.0, 9.0]]


def test_openai_provider_embed_batch_empty_input_returns_empty_list_without_calling_client():
    fake_client = _FakeOpenAIClient(vectors=[])
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, client=fake_client
    )
    assert provider.embed_batch([]) == []
    assert fake_client.calls == []


def test_openai_provider_raises_dimension_mismatch_if_response_wrong_size():
    fake_client = _FakeOpenAIClient(vectors=[[1.0, 2.0, 3.0]])  # 3-dim, but provider declared 2
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, client=fake_client
    )
    with pytest.raises(Exception):  # DimensionMismatchError, raised via validate_batch_response
        provider.embed_batch(["hello"])


def test_openai_provider_wraps_client_exceptions_as_provider_unavailable():
    def _raise(**kwargs):
        raise RuntimeError("connection refused")

    fake_client = SimpleNamespace(embeddings=SimpleNamespace(create=_raise))
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, client=fake_client
    )
    with pytest.raises(ProviderUnavailableError):
        provider.embed_batch(["hello"])


def test_openai_provider_without_api_key_or_client_raises_provider_unavailable():
    provider = OpenAIEmbeddingProvider(
        model_name="text-embedding-3-small", model_version="1", embedding_dimension=2, api_key=None, client=None
    )
    with pytest.raises(ProviderUnavailableError):
        provider.embed_batch(["hello"])


# ---------------------------------------------------------------------------
# Placeholder providers
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "provider_name", ["nomic", "bge", "e5", "sentence_transformers", "lm_studio", "azure_openai"]
)
def test_placeholder_providers_construct_successfully(provider_name):
    provider = get_provider(provider_name, model_name="whatever", model_version="1", embedding_dimension=8)
    assert provider.provider_name == provider_name


@pytest.mark.parametrize(
    "provider_name", ["nomic", "bge", "e5", "sentence_transformers", "lm_studio", "azure_openai"]
)
def test_placeholder_providers_raise_on_embed_batch(provider_name):
    provider = get_provider(provider_name, model_name="whatever", model_version="1", embedding_dimension=8)
    with pytest.raises(ProviderUnavailableError):
        provider.embed_batch(["hello"])


# ---------------------------------------------------------------------------
# OllamaEmbeddingProvider — with an injected fake httpx client (no network)
# ---------------------------------------------------------------------------


class _FakeOllamaResponse:
    def __init__(self, status_code: int, payload: dict | None = None, text: str = ""):
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text or str(payload)

    def raise_for_status(self):
        if self.status_code >= 400:
            request = httpx.Request("POST", "http://localhost:11434/api/embed")
            response = httpx.Response(self.status_code, request=request, text=self.text)
            raise httpx.HTTPStatusError("error", request=request, response=response)

    def json(self):
        return self._payload


class _FakeOllamaClient:
    def __init__(self, response: _FakeOllamaResponse):
        self._response = response
        self.calls = []

    def post(self, url, *, json):
        self.calls.append({"url": url, "json": json})
        return self._response


def test_ollama_provider_embed_batch_returns_vectors_in_order():
    fake_response = _FakeOllamaResponse(200, {"embeddings": [[1.0, 2.0], [3.0, 4.0]]})
    fake_client = _FakeOllamaClient(fake_response)
    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=fake_client
    )
    vectors = provider.embed_batch(["hello", "world"])
    assert vectors == [[1.0, 2.0], [3.0, 4.0]]
    assert fake_client.calls[0]["json"] == {"model": "nomic-embed-text", "input": ["hello", "world"]}
    assert fake_client.calls[0]["url"].endswith("/api/embed")


def test_ollama_provider_embed_batch_empty_input_returns_empty_list_without_calling_client():
    fake_client = _FakeOllamaClient(_FakeOllamaResponse(200, {"embeddings": []}))
    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=fake_client
    )
    assert provider.embed_batch([]) == []
    assert fake_client.calls == []


def test_ollama_provider_raises_provider_unavailable_on_http_error_status():
    fake_client = _FakeOllamaClient(_FakeOllamaResponse(404, text="model not found"))
    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=fake_client
    )
    with pytest.raises(ProviderUnavailableError, match="ollama pull"):
        provider.embed_batch(["hello"])


def test_ollama_provider_raises_provider_unavailable_on_connection_error():
    class _UnreachableClient:
        def post(self, url, *, json):
            raise httpx.ConnectError("connection refused")

    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=_UnreachableClient()
    )
    with pytest.raises(ProviderUnavailableError, match="is it running"):
        provider.embed_batch(["hello"])


def test_ollama_provider_raises_invalid_response_on_malformed_json_shape():
    fake_client = _FakeOllamaClient(_FakeOllamaResponse(200, {"unexpected": "shape"}))
    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=fake_client
    )
    with pytest.raises(InvalidProviderResponseError):
        provider.embed_batch(["hello"])


def test_ollama_provider_raises_dimension_mismatch_if_response_wrong_size():
    fake_client = _FakeOllamaClient(_FakeOllamaResponse(200, {"embeddings": [[1.0, 2.0, 3.0]]}))
    provider = OllamaEmbeddingProvider(
        model_name="nomic-embed-text", model_version="1", embedding_dimension=2, client=fake_client
    )
    with pytest.raises(Exception):  # DimensionMismatchError, via validate_batch_response
        provider.embed_batch(["hello"])


def test_ollama_provider_uses_configured_base_url():
    fake_client = _FakeOllamaClient(_FakeOllamaResponse(200, {"embeddings": [[1.0]]}))
    provider = OllamaEmbeddingProvider(
        model_name="m", model_version="1", embedding_dimension=1,
        base_url="http://custom-host:9999", client=fake_client,
    )
    provider.embed_batch(["hi"])
    assert fake_client.calls[0]["url"] == "http://custom-host:9999/api/embed"


def test_get_provider_ollama_defaults_from_settings():
    provider = get_provider("ollama")
    assert provider.provider_name == "ollama"
    assert provider.model_name  # populated from settings.embeddings_model_name
    assert provider.embedding_dimension > 0


def test_embeddings_provider_default_is_ollama_not_openai():
    """Architectural requirement: the platform must work without commercial API credits out of the box."""
    from src.config.settings import settings as _settings

    assert _settings.embeddings_provider == "ollama"
