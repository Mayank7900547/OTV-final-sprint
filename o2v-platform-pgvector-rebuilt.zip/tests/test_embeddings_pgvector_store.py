"""
Integration tests for `src/embeddings/vector_store.py`'s `PgVectorStore`.

Requires a real Postgres test database with the `vector` extension
enabled — skipped automatically if unreachable (same as
`test_embeddings_vector_store.py`) or if `enable_pgvector_support`
can't create the extension (e.g. it isn't installed on the server).

Design decision: reuses `_make_scenario`/`_embedding_row` from
`test_embeddings_vector_store.py` rather than redefining the same
Company/DocumentRegistry/DocumentVersion/ParsedDocument/Chunk scaffolding
here — `PgVectorStore` is exercised against the exact same fixture shape
`PostgresVectorStore` already is, so any behavioral difference in the
tests reflects the backends, not divergent test setup.
"""

from __future__ import annotations

import pytest

from src.embeddings.exceptions import VectorStorageError
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.vector_store import (
    PgVectorEmbedding,
    PgVectorStore,
    enable_pgvector_support,
    get_vector_store,
)
from tests.test_embeddings_vector_store import _embedding_row, _make_scenario

# Import so the tables register on Base.metadata, same requirement as conftest.py.
from src.embeddings import models as _embeddings_models_module  # noqa: F401


@pytest.fixture
def pgvector_enabled(_test_engine):
    """
    Enables the `vector` extension and creates `PgVectorEmbedding`'s table
    on `PgVectorBase.metadata` against the shared test engine. Skips
    (rather than fails) if the extension isn't available on the test
    Postgres instance — consistent with `db_session`'s graceful-skip
    behavior in conftest.py for missing infrastructure.
    """
    try:
        enable_pgvector_support(_test_engine)
    except Exception as exc:
        pytest.skip(f"pgvector extension not available on the test database ({exc}) — skipping pgvector tests.")


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def test_get_vector_store_pgvector_returns_pgvector_store(db_session):
    store = get_vector_store("pgvector", session=db_session)
    assert isinstance(store, PgVectorStore)


# ---------------------------------------------------------------------------
# PgVectorStore CRUD
# ---------------------------------------------------------------------------


def test_insert_vector_persists_vector_in_pgvector_table_not_json_column(pgvector_enabled, db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    vector = [0.1, 0.2, 0.3, 0.4]
    metadata = {"company": "Vector Test Co", "chunk_id": chunk.chunk_id}
    store.insert_vector(embedding_row=row, vector=vector, metadata=metadata)
    db_session.flush()

    assert store.get_vector(row.id) == pytest.approx(vector)
    assert row.embedding_metadata == metadata
    assert row.vector_store_backend == "pgvector"
    # The Sprint 6 JSON column stays NULL for this backend — the vector
    # lives in PgVectorEmbedding instead (see models.py's "external
    # vector store" docstring).
    assert row.embedding_vector is None

    pgv_row = db_session.query(PgVectorEmbedding).filter(PgVectorEmbedding.embedding_id == row.id).first()
    assert pgv_row is not None
    assert pgv_row.chunk_id == chunk.id


def test_get_vector_returns_none_for_unknown_id(pgvector_enabled, db_session):
    store = PgVectorStore(session=db_session)
    assert store.get_vector(999_999_999) is None


def test_update_vector_replaces_existing_vector_and_metadata(pgvector_enabled, db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"a": 1})
    db_session.flush()

    store.update_vector(row.id, vector=[9.0, 9.0, 9.0, 9.0], metadata={"a": 2})

    assert store.get_vector(row.id) == pytest.approx([9.0, 9.0, 9.0, 9.0])
    assert row.embedding_metadata == {"a": 2}


def test_update_vector_unknown_id_raises_vector_storage_error(pgvector_enabled, db_session):
    store = PgVectorStore(session=db_session)
    with pytest.raises(VectorStorageError):
        store.update_vector(999_999_999, vector=[1.0], metadata={})


def test_delete_vector_clears_stored_vector(pgvector_enabled, db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={})
    db_session.flush()

    store.delete_vector(row.id)
    assert store.get_vector(row.id) is None


def test_delete_vector_unknown_id_is_a_no_op(pgvector_enabled, db_session):
    store = PgVectorStore(session=db_session)
    store.delete_vector(999_999_999)  # should not raise


def test_filter_by_metadata_matches_active_embeddings_with_matching_field(pgvector_enabled, db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"company": "Vector Test Co"})
    db_session.flush()

    matches = store.filter_by_metadata({"company": "Vector Test Co"})
    assert row.id in matches


def test_filter_by_metadata_excludes_superseded_embeddings(pgvector_enabled, db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk, status=EmbeddingStatusEnum.SUPERSEDED)
    db_session.add(row)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"company": "Vector Test Co"})
    db_session.flush()

    matches = store.filter_by_metadata({"company": "Vector Test Co"})
    assert row.id not in matches


# ---------------------------------------------------------------------------
# similarity_search — real, index-pushed-to-Postgres implementation. See
# vector_store.py's module docstring for why this backend exists at all
# (the brute-force scan's 657-3680s-per-component retrieval time).
# ---------------------------------------------------------------------------


def test_similarity_search_returns_ranked_matches_by_cosine_similarity(pgvector_enabled, db_session, tmp_path):
    _, _, chunk_a = _make_scenario(db_session, tmp_path, company_name="Sim Test Co A")
    row_a = _embedding_row(chunk_a, dimension=3)
    db_session.add(row_a)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row_a, vector=[1.0, 0.0, 0.0], metadata={"company": "Sim Test Co A"})
    db_session.flush()

    results = store.similarity_search([1.0, 0.0, 0.0], top_k=5)

    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk_a.id
    assert results[0]["score"] == pytest.approx(1.0, abs=1e-6)


def test_similarity_search_respects_top_k(pgvector_enabled, db_session, tmp_path):
    _, _, chunk1 = _make_scenario(db_session, tmp_path, company_name="TopK Co 1")
    _, _, chunk2 = _make_scenario(db_session, tmp_path, company_name="TopK Co 2")
    row1 = _embedding_row(chunk1, dimension=2)
    row2 = _embedding_row(chunk2, dimension=2)
    db_session.add_all([row1, row2])
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=row1, vector=[1.0, 0.0], metadata={})
    store.insert_vector(embedding_row=row2, vector=[0.0, 1.0], metadata={})
    db_session.flush()

    results = store.similarity_search([1.0, 0.0], top_k=1)
    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk1.id  # closer match ranked first


def test_similarity_search_orders_and_limits_in_postgres_not_python(pgvector_enabled, db_session, tmp_path):
    """
    Not a behavioral difference from PostgresVectorStore's equivalent test —
    the point of this backend is *how* the ranking happens. This asserts
    the observable outcome (correct top_k ranking across more rows than
    top_k) that only holds if the ORDER BY/LIMIT actually ran in SQL.
    """
    _, _, near = _make_scenario(db_session, tmp_path, company_name="Near Co")
    _, _, mid = _make_scenario(db_session, tmp_path, company_name="Mid Co")
    _, _, far = _make_scenario(db_session, tmp_path, company_name="Far Co")

    rows = [_embedding_row(c, dimension=2) for c in (near, mid, far)]
    db_session.add_all(rows)
    db_session.flush()

    store = PgVectorStore(session=db_session)
    store.insert_vector(embedding_row=rows[0], vector=[1.0, 0.0], metadata={})
    store.insert_vector(embedding_row=rows[1], vector=[0.7, 0.7], metadata={})
    store.insert_vector(embedding_row=rows[2], vector=[0.0, 1.0], metadata={})
    db_session.flush()

    results = store.similarity_search([1.0, 0.0], top_k=2)
    assert [r["chunk_id"] for r in results] == [near.id, mid.id]
