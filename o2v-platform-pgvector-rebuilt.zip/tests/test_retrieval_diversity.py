"""Unit tests for `src/retrieval/diversity.py`."""

from src.retrieval.diversity import select_diverse_evidence
from src.retrieval.types import EvidenceCandidate, RetrievalConfig


def _candidate(chunk_id, document_id="doc-1", section_title="Overview", **overrides) -> EvidenceCandidate:
    base = dict(
        chunk_id=chunk_id, document_id=document_id, company_id="co-1", page_number=1,
        section_title=section_title, document_type="Annual Report", chunk_text=f"Text {chunk_id}.",
        final_score=1.0 - (chunk_id * 0.001),  # deterministic descending order by default
    )
    base.update(overrides)
    return EvidenceCandidate(**base)


def test_select_diverse_evidence_respects_final_evidence_k():
    config = RetrievalConfig(final_evidence_k=3, diversity_max_per_document=10, diversity_max_per_section=10)
    candidates = [_candidate(i, document_id=f"doc-{i}") for i in range(10)]
    selected = select_diverse_evidence(candidates, config=config)
    assert len(selected) == 3


def test_select_diverse_evidence_caps_per_document():
    config = RetrievalConfig(final_evidence_k=100, diversity_max_per_document=2, diversity_max_per_section=100)
    candidates = [_candidate(i, document_id="doc-1") for i in range(10)]
    selected = select_diverse_evidence(candidates, config=config)
    assert len(selected) == 2


def test_select_diverse_evidence_caps_per_section():
    config = RetrievalConfig(final_evidence_k=100, diversity_max_per_document=100, diversity_max_per_section=1)
    candidates = [_candidate(i, document_id="doc-1", section_title="Risk Factors") for i in range(10)]
    selected = select_diverse_evidence(candidates, config=config)
    assert len(selected) == 1


def test_select_diverse_evidence_different_sections_not_capped_together():
    config = RetrievalConfig(final_evidence_k=100, diversity_max_per_document=100, diversity_max_per_section=1)
    candidates = [
        _candidate(1, document_id="doc-1", section_title="Overview"),
        _candidate(2, document_id="doc-1", section_title="Risk Factors"),
    ]
    selected = select_diverse_evidence(candidates, config=config)
    assert len(selected) == 2


def test_select_diverse_evidence_null_section_title_not_capped():
    config = RetrievalConfig(final_evidence_k=100, diversity_max_per_document=100, diversity_max_per_section=1)
    candidates = [_candidate(i, document_id="doc-1", section_title=None) for i in range(5)]
    selected = select_diverse_evidence(candidates, config=config)
    # No section cap applies when section_title is None -- only the (generous) document cap matters.
    assert len(selected) == 5


def test_select_diverse_evidence_preserves_input_order_preference():
    config = RetrievalConfig(final_evidence_k=2, diversity_max_per_document=100, diversity_max_per_section=100)
    candidates = [_candidate(1, document_id="a"), _candidate(2, document_id="b"), _candidate(3, document_id="c")]
    selected = select_diverse_evidence(candidates, config=config)
    assert [c.chunk_id for c in selected] == [1, 2]


def test_select_diverse_evidence_empty_input_returns_empty():
    config = RetrievalConfig()
    assert select_diverse_evidence([], config=config) == []
