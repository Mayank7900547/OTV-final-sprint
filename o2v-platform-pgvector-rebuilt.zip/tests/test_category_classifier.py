"""Tests for src/discovery/category_classifier.py — pure logic, no network/DB."""

from src.core.constants import DocumentCategory, DocumentType
from src.discovery.category_classifier import classify_category, classify_document_type, extract_year


def test_classifies_sustainability_report():
    assert classify_category("https://apple.com/sustainability/2024-report.pdf") == DocumentCategory.SUSTAINABILITY_REPORT


def test_classifies_code_of_conduct():
    # "conduct-policy" is one of the CODE_OF_CONDUCT keywords, so this
    # correctly classifies — matches the real Apple Business Conduct
    # Policy URL used during earlier research in this project.
    assert classify_category("https://apple.com/compliance/pdfs/Business-Conduct-Policy.pdf") == DocumentCategory.CODE_OF_CONDUCT
    assert classify_category("https://apple.com/code-of-conduct.pdf") == DocumentCategory.CODE_OF_CONDUCT


def test_classifies_investor_relations():
    assert classify_category("https://investor.apple.com/investor-relations/default.aspx") == DocumentCategory.INVESTOR_RELATIONS


def test_classifies_proxy_statement_specific_before_generic():
    # "def-14a" should match the specific PROXY_STATEMENT rule, not fall
    # through to something else — priority ordering matters here.
    assert classify_category("https://apple.com/proxy/def-14a-2024.htm") == DocumentCategory.PROXY_STATEMENT


def test_classifies_governance_over_generic_report():
    # A URL containing both "governance" and generic report language should
    # resolve to the more specific Corporate Governance Report category.
    assert classify_category("https://apple.com/corporate-governance-report.pdf") == DocumentCategory.CORPORATE_GOVERNANCE_REPORT


def test_unclassifiable_url_returns_unknown():
    assert classify_category("https://apple.com/careers/openings") == DocumentCategory.UNKNOWN


def test_classify_document_type_pdf():
    assert classify_document_type("https://apple.com/report.pdf") == DocumentType.PDF


def test_classify_document_type_html():
    assert classify_document_type("https://apple.com/about/") == DocumentType.HTML
    assert classify_document_type("https://apple.com/about/index.html") == DocumentType.HTML


def test_extract_year_prefers_last_match():
    assert extract_year("https://apple.com/reports/2019/annual-report-2024.pdf") == 2024


def test_extract_year_returns_none_when_absent():
    assert extract_year("https://apple.com/about/") is None


def test_extract_year_ignores_implausible_numbers():
    # A 3-digit or 5-digit number should not be mistaken for a year.
    assert extract_year("https://apple.com/product/12345") is None
