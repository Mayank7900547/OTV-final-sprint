"""
Tests for src/acquisition/ssrf_guard.py.

All DNS resolution is mocked via `monkeypatch` on `socket.getaddrinfo` so
these tests never touch the real network and are deterministic regardless
of the sandbox's actual DNS/network availability.
"""

import socket

import pytest

from src.acquisition import ssrf_guard


def _fake_getaddrinfo(ip_addresses):
    """Build a fake socket.getaddrinfo returning the given IP(s) for any host."""

    def _resolve(host, port, *args, **kwargs):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, 0)) for ip in ip_addresses]

    return _resolve


def _raise_gaierror(host, port, *args, **kwargs):
    raise socket.gaierror("name resolution failed")


# ---------------------------------------------------------------------------
# Scheme / hostname structural checks (no DNS involved)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("scheme_url", ["ftp://example.com/file.pdf", "file:///etc/passwd", "javascript:alert(1)"])
def test_rejects_non_http_schemes(scheme_url):
    assert ssrf_guard.is_url_safe(scheme_url) is False


def test_rejects_url_with_no_hostname():
    assert ssrf_guard.is_url_safe("https://") is False


@pytest.mark.parametrize("hostname", ["localhost", "LOCALHOST", "metadata.google.internal"])
def test_rejects_explicitly_blocked_hostnames(monkeypatch, hostname):
    # Even if these somehow resolved to a "safe" IP, they're blocked
    # outright before DNS resolution is even attempted.
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["8.8.8.8"]))
    assert ssrf_guard.is_url_safe(f"http://{hostname}/") is False


# ---------------------------------------------------------------------------
# DNS resolution outcomes
# ---------------------------------------------------------------------------


def test_rejects_unresolvable_hostname(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _raise_gaierror)
    assert ssrf_guard.is_url_safe("https://this-domain-does-not-resolve.example/") is False


def test_accepts_public_ip_resolution(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["93.184.216.34"]))  # example.com-style public IP
    assert ssrf_guard.is_url_safe("https://example.com/report.pdf") is True


@pytest.mark.parametrize(
    "private_ip",
    [
        "127.0.0.1",  # loopback
        "10.0.0.5",  # RFC1918 private
        "172.16.0.5",  # RFC1918 private
        "192.168.1.1",  # RFC1918 private
        "169.254.1.1",  # link-local
        "224.0.0.1",  # multicast
        "0.0.0.0",  # unspecified
    ],
)
def test_rejects_private_and_reserved_ip_ranges(monkeypatch, private_ip):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo([private_ip]))
    assert ssrf_guard.is_url_safe(f"https://internal.example/") is False


def test_rejects_cloud_metadata_ip(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["169.254.169.254"]))
    assert ssrf_guard.is_url_safe("http://attacker-controlled.example/") is False


def test_rejects_when_any_resolved_ip_is_unsafe(monkeypatch):
    # A hostname that round-robins between a public and a private IP must
    # be rejected — "fails closed" per the module's docstring, not "passes
    # if at least one resolved IP looks safe".
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["93.184.216.34", "127.0.0.1"]))
    assert ssrf_guard.is_url_safe("https://mixed.example/") is False


def test_accepts_when_all_resolved_ips_are_public(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["93.184.216.34", "1.1.1.1"]))
    assert ssrf_guard.is_url_safe("https://multi-a-record.example/") is True


def test_rejects_ipv6_loopback(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["::1"]))
    assert ssrf_guard.is_url_safe("https://ipv6-loopback.example/") is False


def test_rejects_ipv6_unique_local_range(monkeypatch):
    # fc00::/7 is the IPv6 analogue of RFC1918 private space.
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["fd00::1"]))
    assert ssrf_guard.is_url_safe("https://ipv6-private.example/") is False


def test_accepts_public_ipv6(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo(["2606:4700:4700::1111"]))  # public (Cloudflare)
    assert ssrf_guard.is_url_safe("https://ipv6-public.example/") is True
