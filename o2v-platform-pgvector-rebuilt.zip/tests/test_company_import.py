"""
Tests for the CSV-parsing/validation portion of
src/services/company_service.import_companies_from_csv.

These tests exercise only the validation paths that raise BEFORE any
database access happens (missing file, missing header, empty name field) —
passing `session=None` is safe for these specific cases because the
function never reaches a line that uses `session` before raising. Full
end-to-end import (including the dedup-via-DB path) is left for an
integration test suite once Sprint 2 introduces a test database fixture
(see tests/conftest.py docstring).
"""

import pytest

from src.core.exceptions import CompanyImportError
from src.services.company_service import import_companies_from_csv


def test_missing_csv_file_raises(tmp_path):
    with pytest.raises(CompanyImportError, match="not found"):
        import_companies_from_csv(None, tmp_path / "nope.csv")


def test_missing_name_column_raises(tmp_csv_file):
    path = tmp_csv_file("ticker,website\nAAPL,https://apple.com\n")
    with pytest.raises(CompanyImportError, match="missing required column"):
        import_companies_from_csv(None, path)


def test_empty_name_value_raises(tmp_csv_file):
    path = tmp_csv_file("name,ticker\n,AAPL\n")
    with pytest.raises(CompanyImportError, match="'name' column is empty"):
        import_companies_from_csv(None, path)


def test_no_header_row_raises(tmp_csv_file):
    path = tmp_csv_file("")  # completely empty file -> DictReader.fieldnames is None
    with pytest.raises(CompanyImportError, match="no header row"):
        import_companies_from_csv(None, path)
