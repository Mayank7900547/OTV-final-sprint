"""
Tests for src/discovery/sec_edgar_client.py.

All network calls are mocked via `monkeypatch` on `http_client.get` — see
that module's docstring for why this is the one function tests patch. No
`respx`/`responses` dependency needed as a result.

The module-level `_ticker_cache` singleton is reset in a fixture before
each test, since it caches across calls by design (see its docstring) —
without resetting, a test that populates the cache would leak state into
the next test.
"""

import json

import pytest

from src.core.exceptions import DocumentSourceUnavailableError
from src.discovery import http_client, sec_edgar_client
from src.discovery.http_client import FetchResult

FAKE_TICKER_MAP = {
    "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."},
    "1": {"cik_str": 789019, "ticker": "MSFT", "title": "Microsoft Corp"},
}

FAKE_SUBMISSIONS = {
    "filings": {
        "recent": {
            "form": ["10-K", "8-K", "DEF 14A", "10-K"],
            "filingDate": ["2025-11-01", "2025-08-15", "2025-01-20", "2024-11-02"],
            "accessionNumber": [
                "0000320193-25-000100",
                "0000320193-25-000090",
                "0000320193-25-000010",
                "0000320193-24-000100",
            ],
            "primaryDocument": ["aapl-20250927.htm", "8k.htm", "def14a.htm", "aapl-20240928.htm"],
        }
    }
}


@pytest.fixture(autouse=True)
def _reset_ticker_cache():
    """Reset the module-level ticker cache before/after every test — see module docstring."""
    sec_edgar_client._ticker_cache = sec_edgar_client._TickerCikCache()
    yield
    sec_edgar_client._ticker_cache = sec_edgar_client._TickerCikCache()


def _mock_get(url_to_response: dict[str, FetchResult]):
    def _get(url: str) -> FetchResult:
        if url in url_to_response:
            return url_to_response[url]
        return FetchResult(ok=False, url=url, reason="not mocked")

    return _get


def test_discover_sec_filings_filters_to_relevant_forms(monkeypatch):
    responses = {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url=sec_edgar_client.TICKER_MAP_URL, status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
        sec_edgar_client.SUBMISSIONS_URL_TEMPLATE.format(cik="0000320193"): FetchResult(
            ok=True, url="submissions", status_code=200, text=json.dumps(FAKE_SUBMISSIONS)
        ),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sec_edgar_client.discover_sec_filings("AAPL")

    # 4 filings total, but only 10-K/10-K/DEF 14A are relevant — the 8-K is
    # correctly filtered out (not in _RELEVANT_FORM_TYPES).
    assert len(candidates) == 3
    categories = {c.document_category.value for c in candidates}
    assert categories == {"form_10k", "proxy_statement"}


def test_discover_sec_filings_extracts_year_from_filing_date(monkeypatch):
    responses = {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url=sec_edgar_client.TICKER_MAP_URL, status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
        sec_edgar_client.SUBMISSIONS_URL_TEMPLATE.format(cik="0000320193"): FetchResult(
            ok=True, url="submissions", status_code=200, text=json.dumps(FAKE_SUBMISSIONS)
        ),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sec_edgar_client.discover_sec_filings("AAPL")
    tenk_years = sorted(c.document_year for c in candidates if c.document_category.value == "form_10k")
    assert tenk_years == [2024, 2025]


def test_discover_sec_filings_constructs_correct_archive_url(monkeypatch):
    responses = {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url=sec_edgar_client.TICKER_MAP_URL, status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
        sec_edgar_client.SUBMISSIONS_URL_TEMPLATE.format(cik="0000320193"): FetchResult(
            ok=True, url="submissions", status_code=200, text=json.dumps(FAKE_SUBMISSIONS)
        ),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sec_edgar_client.discover_sec_filings("AAPL")
    latest_10k = next(c for c in candidates if c.document_category.value == "form_10k" and c.document_year == 2025)
    assert latest_10k.official_url == (
        "https://www.sec.gov/Archives/edgar/data/320193/000032019325000100/aapl-20250927.htm"
    )


def test_unknown_ticker_returns_empty_list_not_error(monkeypatch):
    responses = {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url=sec_edgar_client.TICKER_MAP_URL, status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sec_edgar_client.discover_sec_filings("NOTAREALTICKER")
    assert candidates == []


def test_none_ticker_returns_empty_list_without_any_http_call(monkeypatch):
    calls = []
    monkeypatch.setattr(http_client, "get", lambda url: calls.append(url) or FetchResult(ok=False, url=url))

    candidates = sec_edgar_client.discover_sec_filings(None)
    assert candidates == []
    assert calls == []  # a company with no ticker should never trigger a network call


def test_ticker_map_failure_raises_document_source_unavailable(monkeypatch):
    monkeypatch.setattr(
        http_client, "get", lambda url: FetchResult(ok=False, url=url, reason="503 Service Unavailable")
    )

    with pytest.raises(DocumentSourceUnavailableError):
        sec_edgar_client.discover_sec_filings("AAPL")


def test_submissions_failure_raises_document_source_unavailable(monkeypatch):
    responses = {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url=sec_edgar_client.TICKER_MAP_URL, status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    with pytest.raises(DocumentSourceUnavailableError):
        sec_edgar_client.discover_sec_filings("AAPL")  # submissions URL not in `responses` -> "not mocked" failure


def test_ticker_cache_is_reused_across_calls_within_a_run(monkeypatch):
    call_count = {"ticker_map": 0}

    def _get(url: str) -> FetchResult:
        if url == sec_edgar_client.TICKER_MAP_URL:
            call_count["ticker_map"] += 1
            return FetchResult(ok=True, url=url, status_code=200, text=json.dumps(FAKE_TICKER_MAP))
        if url == sec_edgar_client.SUBMISSIONS_URL_TEMPLATE.format(cik="0000320193"):
            return FetchResult(ok=True, url=url, status_code=200, text=json.dumps(FAKE_SUBMISSIONS))
        return FetchResult(ok=False, url=url, reason="not mocked")

    monkeypatch.setattr(http_client, "get", _get)

    sec_edgar_client.discover_sec_filings("AAPL")
    sec_edgar_client.discover_sec_filings("AAPL")

    # The ticker map is large static reference data — fetching it once and
    # reusing it across companies within a run is the whole point of
    # _TickerCikCache (see its docstring); this asserts that actually holds.
    assert call_count["ticker_map"] == 1
