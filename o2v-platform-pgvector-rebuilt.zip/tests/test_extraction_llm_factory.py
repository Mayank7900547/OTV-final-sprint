"""
Unit tests for `src/extraction/llm_factory.py`.

Every real provider (`OllamaLLMProvider`/`OpenAILLMProvider`/
`AnthropicLLMProvider`) tests inject a fake HTTP/SDK client (see each
provider's `client=` constructor param) — no real API key, no real
network call, no locally-running Ollama server required for any test here.
"""

from __future__ import annotations

from types import SimpleNamespace

import httpx
import pytest

from src.extraction.exceptions import InvalidLLMResponseError, LLMConfigurationError, LLMProviderUnavailableError
from src.extraction.llm_factory import (
    AnthropicLLMProvider,
    AzureOpenAILLMProvider,
    OllamaLLMProvider,
    OpenAILLMProvider,
    available_llm_providers,
    get_llm_provider,
)

# ---------------------------------------------------------------------------
# Registry / factory
# ---------------------------------------------------------------------------


def test_available_llm_providers_includes_all_three_real_and_placeholder():
    providers = available_llm_providers()
    for expected in ["ollama", "openai", "anthropic", "azure_openai"]:
        assert expected in providers


def test_get_llm_provider_by_explicit_name_constructs_correct_class():
    provider = get_llm_provider("openai", model_name="gpt-4o-mini")
    assert isinstance(provider, OpenAILLMProvider)
    assert provider.provider_name == "openai"


def test_get_llm_provider_defaults_from_settings():
    provider = get_llm_provider("ollama")
    assert provider.model_name  # populated from settings.llm_model_name
    assert provider.temperature == 0.0


def test_get_llm_provider_unknown_name_raises_configuration_error():
    with pytest.raises(LLMConfigurationError):
        get_llm_provider("not_a_real_provider")


def test_get_llm_provider_is_case_insensitive():
    provider = get_llm_provider("OpenAI")
    assert isinstance(provider, OpenAILLMProvider)


def test_get_llm_provider_allows_per_call_overrides():
    provider = get_llm_provider("ollama", model_name="custom-model", temperature=0.5, max_output_tokens=500)
    assert provider.model_name == "custom-model"
    assert provider.temperature == 0.5
    assert provider.max_output_tokens == 500


# ---------------------------------------------------------------------------
# Every provider implements the same abstract interface
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("name", ["ollama", "openai", "anthropic", "azure_openai"])
def test_every_registered_provider_is_constructible(name):
    provider = get_llm_provider(name)
    assert hasattr(provider, "complete")
    assert callable(provider.complete)


# ---------------------------------------------------------------------------
# OllamaLLMProvider — with an injected fake httpx client
# ---------------------------------------------------------------------------


class _FakeHttpxResponse:
    def __init__(self, json_data, status_code=200):
        self._json_data = json_data
        self.status_code = status_code
        self.text = str(json_data)

    def raise_for_status(self):
        if self.status_code >= 400:
            request = httpx.Request("POST", "http://fake")
            response = httpx.Response(self.status_code, request=request, text=self.text)
            raise httpx.HTTPStatusError("error", request=request, response=response)

    def json(self):
        return self._json_data


class _FakeOllamaClient:
    def __init__(self, response_json=None, raise_exc=None):
        self._response_json = response_json
        self._raise_exc = raise_exc
        self.calls = []

    def post(self, url, json):
        self.calls.append({"url": url, "json": json})
        if self._raise_exc:
            raise self._raise_exc
        return _FakeHttpxResponse(self._response_json)


def test_ollama_provider_complete_returns_message_content():
    fake_client = _FakeOllamaClient(response_json={"message": {"content": '{"confidence": "High"}'}})
    provider = OllamaLLMProvider(model_name="llama3.1", temperature=0.0, max_output_tokens=100, client=fake_client)
    result = provider.complete(system_prompt="sys", user_prompt="user")
    assert result == '{"confidence": "High"}'
    assert fake_client.calls[0]["json"]["model"] == "llama3.1"
    assert fake_client.calls[0]["json"]["format"] == "json"


def test_ollama_provider_network_error_raises_provider_unavailable():
    fake_client = _FakeOllamaClient(raise_exc=httpx.ConnectError("connection refused"))
    provider = OllamaLLMProvider(model_name="llama3.1", temperature=0.0, max_output_tokens=100, client=fake_client)
    with pytest.raises(LLMProviderUnavailableError):
        provider.complete(system_prompt="sys", user_prompt="user")


def test_ollama_provider_unexpected_response_shape_raises_invalid_response():
    fake_client = _FakeOllamaClient(response_json={"unexpected": "shape"})
    provider = OllamaLLMProvider(model_name="llama3.1", temperature=0.0, max_output_tokens=100, client=fake_client)
    with pytest.raises(InvalidLLMResponseError):
        provider.complete(system_prompt="sys", user_prompt="user")


# ---------------------------------------------------------------------------
# OpenAILLMProvider — with an injected fake SDK client
# ---------------------------------------------------------------------------


class _FakeOpenAIClient:
    def __init__(self, content: str):
        self._content = content
        self.calls = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        message = SimpleNamespace(content=self._content)
        choice = SimpleNamespace(message=message)
        return SimpleNamespace(choices=[choice])


def test_openai_provider_complete_returns_content():
    fake_client = _FakeOpenAIClient(content='{"confidence": "High"}')
    provider = OpenAILLMProvider(model_name="gpt-4o-mini", temperature=0.0, max_output_tokens=100, api_key="fake-key", client=fake_client)
    result = provider.complete(system_prompt="sys", user_prompt="user")
    assert result == '{"confidence": "High"}'
    assert fake_client.calls[0]["response_format"] == {"type": "json_object"}


def test_openai_provider_without_api_key_raises_provider_unavailable():
    provider = OpenAILLMProvider(model_name="gpt-4o-mini", temperature=0.0, max_output_tokens=100, api_key=None)
    with pytest.raises(LLMProviderUnavailableError):
        provider.complete(system_prompt="sys", user_prompt="user")


def test_openai_provider_sdk_error_wrapped_as_provider_unavailable():
    class _RaisingClient:
        chat = SimpleNamespace(completions=SimpleNamespace(create=lambda **kwargs: (_ for _ in ()).throw(RuntimeError("boom"))))

    provider = OpenAILLMProvider(model_name="gpt-4o-mini", temperature=0.0, max_output_tokens=100, api_key="fake-key", client=_RaisingClient())
    with pytest.raises(LLMProviderUnavailableError):
        provider.complete(system_prompt="sys", user_prompt="user")


# ---------------------------------------------------------------------------
# AnthropicLLMProvider — with an injected fake SDK client
# ---------------------------------------------------------------------------


class _FakeAnthropicClient:
    def __init__(self, text: str):
        self._text = text
        self.calls = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        block = SimpleNamespace(type="text", text=self._text)
        return SimpleNamespace(content=[block])


def test_anthropic_provider_complete_returns_text():
    fake_client = _FakeAnthropicClient(text='{"confidence": "High"}')
    provider = AnthropicLLMProvider(model_name="claude-sonnet-4-6", temperature=0.0, max_output_tokens=100, api_key="fake-key", client=fake_client)
    result = provider.complete(system_prompt="sys", user_prompt="user")
    assert result == '{"confidence": "High"}'
    assert fake_client.calls[0]["system"] == "sys"


def test_anthropic_provider_without_api_key_raises_provider_unavailable():
    provider = AnthropicLLMProvider(model_name="claude-sonnet-4-6", temperature=0.0, max_output_tokens=100, api_key=None)
    with pytest.raises(LLMProviderUnavailableError):
        provider.complete(system_prompt="sys", user_prompt="user")


def test_anthropic_provider_no_text_blocks_raises_invalid_response():
    class _EmptyClient:
        messages = SimpleNamespace(create=lambda **kwargs: SimpleNamespace(content=[]))

    provider = AnthropicLLMProvider(model_name="claude-sonnet-4-6", temperature=0.0, max_output_tokens=100, api_key="fake-key", client=_EmptyClient())
    with pytest.raises(InvalidLLMResponseError):
        provider.complete(system_prompt="sys", user_prompt="user")


# ---------------------------------------------------------------------------
# AzureOpenAILLMProvider — architecture placeholder
# ---------------------------------------------------------------------------


def test_azure_openai_placeholder_raises_provider_unavailable():
    provider = AzureOpenAILLMProvider(model_name="gpt-4o", temperature=0.0, max_output_tokens=100)
    with pytest.raises(LLMProviderUnavailableError):
        provider.complete(system_prompt="sys", user_prompt="user")
