"""Unit tests for `src/parser/html_parser.py`."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.parser.exceptions import EmptyDocumentError
from src.parser.html_parser import HTMLParser


def _write_html(tmp_path: Path, html: str, filename: str = "doc.html") -> Path:
    path = tmp_path / filename
    path.write_text(html, encoding="utf-8")
    return path


_SAMPLE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Acme Corp — About Us</title>
    <meta name="author" content="Acme Communications Team">
    <meta name="description" content="Learn about Acme Corp's mission.">
    <meta name="keywords" content="acme, corporate, mission">
    <style>.hidden { display: none; }</style>
    <script>console.log("should be ignored");</script>
</head>
<body>
    <h1>About Acme Corp</h1>
    <p>Acme Corp was founded to build better widgets for everyone.</p>
    <h2>Our Mission</h2>
    <p>We believe in <a href="https://acme.com/mission">doing the right thing</a>.</p>
    <div style="display:none">This text is hidden and must not appear.</div>
    <div hidden>This is also hidden.</div>
    <a href="#top">Fragment only link text.</a>
    <a href="/careers">Careers</a>
</body>
</html>
"""


def test_parse_extracts_visible_text_and_ignores_hidden_elements(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert "About Acme Corp" in content.raw_text
    assert "build better widgets" in content.raw_text
    assert "doing the right thing" in content.raw_text
    assert "should be ignored" not in content.raw_text  # <script>
    assert "hidden and must not appear" not in content.raw_text  # display:none
    assert "This is also hidden" not in content.raw_text  # [hidden] attribute


def test_parse_extracts_title(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.title == "Acme Corp — About Us"


def test_parse_extracts_meta_tags_into_metadata(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.author == "Acme Communications Team"
    assert content.subject == "Learn about Acme Corp's mission."
    assert content.keywords == "acme, corporate, mission"


def test_parse_extracts_headings(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    headings = content.extra_metadata["headings"]
    assert {"level": "h1", "text": "About Acme Corp"} in headings
    assert {"level": "h2", "text": "Our Mission"} in headings


def test_parse_extracts_hyperlinks_and_skips_fragment_only_hrefs(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    links = content.extra_metadata["links"]
    hrefs = [link["href"] for link in links]
    assert "https://acme.com/mission" in hrefs
    assert "/careers" in hrefs
    assert "#top" not in hrefs


def test_parse_uses_html_lang_attribute_when_no_detection_needed(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.language == "en"


def test_parse_normalizes_whitespace(tmp_path):
    html = "<html><body><p>Line   one.\n\n\n\n\nLine   two.</p></body></html>"
    path = _write_html(tmp_path, html)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert "   " not in content.raw_text
    assert "\n\n\n" not in content.raw_text


def test_parse_ignores_javascript_and_css_content(tmp_path):
    html = """
    <html><body>
        <script>var secret = "should never appear";</script>
        <style>body { color: red; /* should never appear */ }</style>
        <p>Real content.</p>
    </body></html>
    """
    path = _write_html(tmp_path, html)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert "should never appear" not in content.raw_text
    assert "Real content." in content.raw_text


def test_parse_empty_html_raises_empty_document_error(tmp_path):
    path = _write_html(tmp_path, "<html><head></head><body></body></html>")
    parser = HTMLParser(language_detection_enabled=False)

    with pytest.raises(EmptyDocumentError):
        parser.parse(path)


def test_parse_reports_page_count_of_one(tmp_path):
    path = _write_html(tmp_path, _SAMPLE_HTML)
    parser = HTMLParser(language_detection_enabled=False)

    content = parser.parse(path)

    assert content.page_count == 1
    assert len(content.page_text) == 1
    assert content.page_text[0][0] == 1


def test_supports_html_type_only():
    assert HTMLParser.supports("html") is True
    assert HTMLParser.supports("pdf") is False
