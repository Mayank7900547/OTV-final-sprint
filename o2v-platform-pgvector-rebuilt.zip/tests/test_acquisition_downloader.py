"""
Tests for src/acquisition/downloader.py (HttpDownloader).

`HttpDownloader.fetch` builds its own `httpx.AsyncClient` internally
rather than accepting one via dependency injection, so these tests
monkeypatch `httpx.AsyncClient` to force every client onto an
`httpx.MockTransport` — no real network call ever happens. The SSRF guard
(`ssrf_guard.is_url_safe`) and the rate limiter's `acquire()` are also
monkeypatched to no-ops: their own behavior is covered by
test_acquisition_ssrf_guard.py and test_acquisition_rate_limiter.py, so
here we only need to confirm the downloader *calls* them and *respects*
their outcome.
"""

import asyncio
from contextlib import asynccontextmanager

import httpx
import pytest

from src.acquisition import downloader as downloader_module
from src.acquisition.downloader import HttpDownloader
from src.acquisition.exceptions import AcquisitionError, FileTooLargeError, SSRFValidationError
from src.acquisition.rate_limiter import HostRateLimiter
from src.config.settings import settings


class _NoOpRateLimiter(HostRateLimiter):
    """A rate limiter whose throttle() never sleeps, so tests run instantly."""

    def throttle(self, url: str):
        return _noop_async_cm()


@asynccontextmanager
async def _noop_async_cm():
    yield


@pytest.fixture(autouse=True)
def _allow_all_urls(monkeypatch):
    """Bypass the real SSRF/DNS check by default; individual tests override this."""
    monkeypatch.setattr(downloader_module, "is_url_safe", lambda url: True)


@pytest.fixture(autouse=True)
def _generous_size_limits(monkeypatch):
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000_000)


def _install_mock_transport(monkeypatch, handler):
    """Force every httpx.AsyncClient constructed by the downloader onto handler."""

    real_async_client = httpx.AsyncClient

    def _factory(*args, **kwargs):
        kwargs["transport"] = httpx.MockTransport(handler)
        return real_async_client(*args, **kwargs)

    monkeypatch.setattr(downloader_module.httpx, "AsyncClient", _factory)


def _downloader():
    return HttpDownloader(rate_limiter=_NoOpRateLimiter())


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_fetch_writes_response_body_to_staging_path_and_returns_status_and_content_type(monkeypatch, tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"%PDF-1.4 fake pdf bytes %%EOF", headers={"Content-Type": "application/pdf"})

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    status_code, content_type = asyncio.run(_downloader().fetch("https://example.com/report.pdf", staging_path))

    assert status_code == 200
    assert content_type == "application/pdf"
    assert staging_path.read_bytes() == b"%PDF-1.4 fake pdf bytes %%EOF"


# ---------------------------------------------------------------------------
# Redirects
# ---------------------------------------------------------------------------


def test_fetch_follows_redirect_to_final_destination(monkeypatch, tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        if str(request.url) == "https://example.com/old-location.pdf":
            return httpx.Response(302, headers={"Location": "https://example.com/new-location.pdf"})
        return httpx.Response(200, content=b"final content", headers={"Content-Type": "application/pdf"})

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    status_code, _ = asyncio.run(_downloader().fetch("https://example.com/old-location.pdf", staging_path))

    assert status_code == 200
    assert staging_path.read_bytes() == b"final content"


def test_fetch_resolves_relative_redirect_location_against_current_url(monkeypatch, tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        if str(request.url) == "https://example.com/docs/old.pdf":
            return httpx.Response(302, headers={"Location": "/docs/new.pdf"})  # relative
        return httpx.Response(200, content=b"resolved", headers={"Content-Type": "application/pdf"})

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    asyncio.run(_downloader().fetch("https://example.com/docs/old.pdf", staging_path))
    assert staging_path.read_bytes() == b"resolved"


def test_fetch_raises_when_redirect_missing_location_header(monkeypatch, tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(302)  # no Location header

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(AcquisitionError):
        asyncio.run(_downloader().fetch("https://example.com/broken-redirect.pdf", staging_path))


def test_fetch_raises_after_exceeding_max_redirects(monkeypatch, tmp_path):
    call_count = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        call_count["n"] += 1
        n = call_count["n"]
        return httpx.Response(302, headers={"Location": f"https://example.com/hop-{n}.pdf"})

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"
    dl = HttpDownloader(rate_limiter=_NoOpRateLimiter(), max_redirects=2)

    with pytest.raises(AcquisitionError):
        asyncio.run(dl.fetch("https://example.com/start.pdf", staging_path))


def test_fetch_revalidates_ssrf_safety_on_each_redirect_hop(monkeypatch, tmp_path):
    checked_urls = []

    def _is_url_safe(url):
        checked_urls.append(url)
        return "internal" not in url

    monkeypatch.setattr(downloader_module, "is_url_safe", _is_url_safe)

    def handler(request: httpx.Request) -> httpx.Response:
        if str(request.url) == "https://example.com/start.pdf":
            return httpx.Response(302, headers={"Location": "https://internal.example/secret.pdf"})
        return httpx.Response(200, content=b"should never get here")

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(SSRFValidationError):
        asyncio.run(_downloader().fetch("https://example.com/start.pdf", staging_path))

    assert "https://example.com/start.pdf" in checked_urls
    assert "https://internal.example/secret.pdf" in checked_urls


# ---------------------------------------------------------------------------
# Size limits
# ---------------------------------------------------------------------------


def test_fetch_raises_file_too_large_when_content_length_header_exceeds_limit(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 100)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"x" * 50, headers={"Content-Length": "999999"})

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(FileTooLargeError):
        asyncio.run(_downloader().fetch("https://example.com/huge.pdf", staging_path))


def test_fetch_raises_file_too_large_when_stream_exceeds_limit_without_content_length_header(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10)

    def handler(request: httpx.Request) -> httpx.Response:
        # No Content-Length header at all -- the streaming guard must still catch it.
        return httpx.Response(200, content=b"x" * 1000)

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(FileTooLargeError):
        asyncio.run(_downloader().fetch("https://example.com/streamed-huge.pdf", staging_path))


# ---------------------------------------------------------------------------
# SSRF gating on the initial URL
# ---------------------------------------------------------------------------


def test_fetch_raises_ssrf_error_for_unsafe_initial_url(monkeypatch, tmp_path):
    monkeypatch.setattr(downloader_module, "is_url_safe", lambda url: False)

    def handler(request: httpx.Request) -> httpx.Response:  # pragma: no cover - should never be called
        raise AssertionError("HTTP request should never be sent for an unsafe URL")

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(SSRFValidationError):
        asyncio.run(_downloader().fetch("https://blocked.example/x.pdf", staging_path))


# ---------------------------------------------------------------------------
# HTTP error status codes
# ---------------------------------------------------------------------------


def test_fetch_raises_on_http_error_status(monkeypatch, tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, content=b"not found")

    _install_mock_transport(monkeypatch, handler)
    staging_path = tmp_path / "staged.part"

    with pytest.raises(httpx.HTTPStatusError):
        asyncio.run(_downloader().fetch("https://example.com/missing.pdf", staging_path))
