"""
Integration tests for `src/parser/service.py` (DocumentParserService).

Requires a real Postgres test database, exactly like
`test_acquisition_service.py` — skipped automatically if unreachable (see
`tests/conftest.py`'s module docstring). `DocumentParserService.
parse_document_version` calls `session.commit()` internally (once for the
success path, and separately for the failure-history path), so this
module uses the same SAVEPOINT-based `acq_session`-style fixture
`test_acquisition_service.py` already established, rather than the plain
`db_session` fixture.
"""

from __future__ import annotations

import contextlib
import uuid
from io import BytesIO

import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import event
from sqlalchemy.orm import sessionmaker

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingHistory, ParsingStatusEnum
from src.parser.service import DocumentParserService

# Import so the table registers on Base.metadata, same requirement as conftest.py.
from src.parser import models as _parser_models_module  # noqa: F401


@pytest.fixture
def parser_session(_test_engine):
    """SAVEPOINT-based session fixture — see module docstring."""
    connection = _test_engine.connect()
    outer_transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()
    session.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def _restart_savepoint(sess, trans):
        if trans.nested and not trans._parent.nested:
            sess.begin_nested()

    yield session

    session.close()
    outer_transaction.rollback()
    connection.close()


def _make_pdf_bytes(text: str = "Hello parsing world.") -> bytes:
    buffer = BytesIO()
    c = canvas.Canvas(buffer)
    c.drawString(72, 720, text)
    c.showPage()
    c.save()
    return buffer.getvalue()


def _make_company(session, name="Acme Corp"):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company, doc_type=DocumentType.PDF.value):
    doc = DocumentRegistry(
        company_id=company.id,
        document_name="Annual Report",
        document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=doc_type,
        document_year=2024,
        official_url=f"https://acme.com/{uuid.uuid4()}.pdf",
        source_domain="acme.com",
        discovery_method="sitemap_crawl",
        status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _make_version(
    session, document, tmp_path, *, status=DocumentVersionStatusEnum.ACTIVE, content: bytes | None = None,
    filename="report.pdf", version_number=1,
):
    path = tmp_path / filename
    path.write_bytes(content if content is not None else _make_pdf_bytes())
    version = DocumentVersion(
        document_id=document.id,
        version_number=version_number,
        file_hash="a" * 64,
        storage_path=str(path),
        file_size=path.stat().st_size,
        status=status,
    )
    session.add(version)
    session.flush()
    return version


def _fast_service():
    """Service configured to skip language detection (offline, deterministic tests)."""
    return DocumentParserService(parser_kwargs_builder=lambda doc_type: {"language_detection_enabled": False})


# ---------------------------------------------------------------------------
# parse_document_version — happy path
# ---------------------------------------------------------------------------


def test_parse_document_version_success_persists_parsed_document(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path)

    service = _fast_service()
    outcome = service.parse_document_version(parser_session, version.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["page_count"] == 1
    assert outcome["character_count"] > 0

    row = (
        parser_session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == version.id)
        .first()
    )
    assert row is not None
    assert row.status == ParsingStatusEnum.SUCCESS
    assert "Hello parsing world" in row.raw_text
    assert row.parser_used == "pdf_parser"


def test_parse_document_version_records_parsing_history(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path)

    service = _fast_service()
    service.parse_document_version(parser_session, version.id)

    history = (
        parser_session.query(ParsingHistory)
        .filter(ParsingHistory.document_version_id == version.id)
        .all()
    )
    assert len(history) == 1
    assert history[0].parsing_status == ParsingStatusEnum.SUCCESS
    assert history[0].attempt_number == 1


def test_parse_document_version_detects_html_type_from_registry_hint(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company, doc_type=DocumentType.HTML.value)
    html = b"<html><body><p>Some real HTML content here.</p></body></html>"
    version = _make_version(parser_session, document, tmp_path, content=html, filename="page.html")

    service = _fast_service()
    outcome = service.parse_document_version(parser_session, version.id)

    assert outcome["status"] == "SUCCESS"
    assert outcome["parser_used"] == "html_parser"


# ---------------------------------------------------------------------------
# parse_document_version — not found / not active
# ---------------------------------------------------------------------------


def test_parse_document_version_returns_failed_for_unknown_id(parser_session):
    service = _fast_service()
    outcome = service.parse_document_version(parser_session, 999_999_999)

    assert outcome["status"] == "FAILED"
    assert "not found" in outcome["error"].lower()


def test_parse_document_version_skips_non_active_version(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path, status=DocumentVersionStatusEnum.ARCHIVED)

    service = _fast_service()
    outcome = service.parse_document_version(parser_session, version.id)

    assert outcome["status"] == "FAILED"
    parsed = (
        parser_session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == version.id)
        .first()
    )
    assert parsed is None


# ---------------------------------------------------------------------------
# parse_document_version — duplicate prevention
# ---------------------------------------------------------------------------


def test_parse_document_version_is_skipped_on_second_call_without_force(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path)

    service = _fast_service()
    first = service.parse_document_version(parser_session, version.id)
    second = service.parse_document_version(parser_session, version.id)

    assert first["status"] == "SUCCESS"
    assert second["status"] == "SKIPPED"

    count = (
        parser_session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == version.id)
        .count()
    )
    assert count == 1


def test_parse_document_version_reparses_when_forced(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path)

    service = _fast_service()
    service.parse_document_version(parser_session, version.id)
    second = service.parse_document_version(parser_session, version.id, force=True)

    assert second["status"] == "SUCCESS"
    count = (
        parser_session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == version.id)
        .count()
    )
    # force=True updates the existing row in place rather than inserting a
    # second one - see service.py's `_persist_success`.
    assert count == 1


# ---------------------------------------------------------------------------
# parse_document_version — failure modes persist history without a ParsedDocument row
# ---------------------------------------------------------------------------


def test_parse_document_version_malformed_pdf_records_failed_history(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(
        parser_session, document, tmp_path, content=b"not a real pdf at all", filename="bad.pdf"
    )

    service = _fast_service()
    outcome = service.parse_document_version(parser_session, version.id)

    assert outcome["status"] == "FAILED"

    parsed = (
        parser_session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == version.id)
        .first()
    )
    assert parsed is None

    history = (
        parser_session.query(ParsingHistory)
        .filter(ParsingHistory.document_version_id == version.id)
        .all()
    )
    assert len(history) == 1
    assert history[0].parsing_status == ParsingStatusEnum.FAILED


# ---------------------------------------------------------------------------
# load_active_document_version_ids / load_failed_document_version_ids
# ---------------------------------------------------------------------------


def test_load_active_document_version_ids_excludes_archived(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    active = _make_version(parser_session, document, tmp_path, filename="active.pdf")
    _make_version(
        parser_session, document, tmp_path, status=DocumentVersionStatusEnum.ARCHIVED, filename="archived.pdf",
        version_number=2,
    )

    service = _fast_service()
    ids = service.load_active_document_version_ids(parser_session)

    assert active.id in ids
    assert len(ids) == 1


def test_load_active_document_version_ids_filters_by_company(parser_session, tmp_path):
    acme = _make_company(parser_session, name="Acme Corp")
    globex = _make_company(parser_session, name="Globex Inc")
    acme_doc = _make_document(parser_session, acme)
    globex_doc = _make_document(parser_session, globex)
    acme_version = _make_version(parser_session, acme_doc, tmp_path, filename="acme.pdf")
    _make_version(parser_session, globex_doc, tmp_path, filename="globex.pdf")

    service = _fast_service()
    ids = service.load_active_document_version_ids(parser_session, company_filter="Acme")

    assert ids == [acme_version.id]


def test_load_failed_document_version_ids_returns_only_unresolved_failures(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)

    failed_version = _make_version(
        parser_session, document, tmp_path, content=b"garbage", filename="fail.pdf"
    )
    ok_version = _make_version(parser_session, document, tmp_path, filename="ok.pdf", version_number=2)

    service = _fast_service()
    service.parse_document_version(parser_session, failed_version.id)
    service.parse_document_version(parser_session, ok_version.id)

    failed_ids = service.load_failed_document_version_ids(parser_session)

    assert failed_version.id in failed_ids
    assert ok_version.id not in failed_ids


def test_retry_after_fixing_underlying_file_succeeds_with_force(parser_session, tmp_path):
    company = _make_company(parser_session)
    document = _make_document(parser_session, company)
    version = _make_version(parser_session, document, tmp_path, content=b"garbage", filename="fixme.pdf")

    service = _fast_service()
    first = service.parse_document_version(parser_session, version.id)
    assert first["status"] == "FAILED"

    # Simulate an operator fixing the underlying file, then retrying with --force.
    import pathlib

    pathlib.Path(version.storage_path).write_bytes(_make_pdf_bytes("Fixed content."))
    second = service.parse_document_version(parser_session, version.id, force=True)

    assert second["status"] == "SUCCESS"
    history = (
        parser_session.query(ParsingHistory)
        .filter(ParsingHistory.document_version_id == version.id)
        .order_by(ParsingHistory.attempt_number)
        .all()
    )
    assert [h.parsing_status for h in history] == [ParsingStatusEnum.FAILED, ParsingStatusEnum.SUCCESS]
    assert history[1].attempt_number == 2
