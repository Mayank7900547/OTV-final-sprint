"""Unit tests for `src/retrieval/types.py`."""

import pytest

from src.retrieval.exceptions import RetrievalConfigurationError
from src.retrieval.types import EvidenceCandidate, RetrievalConfig, RetrievalQuery


def test_default_config_is_valid():
    config = RetrievalConfig()
    assert config.candidate_k == 200
    assert config.final_evidence_k == 100


def test_config_rejects_weights_not_summing_to_one():
    with pytest.raises(RetrievalConfigurationError):
        RetrievalConfig(semantic_weight=0.5, lexical_weight=0.5, metadata_weight=0.5)


def test_config_accepts_weights_summing_to_one_within_tolerance():
    RetrievalConfig(semantic_weight=0.5, lexical_weight=0.3, metadata_weight=0.2)  # should not raise


def test_config_rejects_non_positive_candidate_k():
    with pytest.raises(RetrievalConfigurationError):
        RetrievalConfig(candidate_k=0)


def test_config_rejects_non_positive_final_evidence_k():
    with pytest.raises(RetrievalConfigurationError):
        RetrievalConfig(final_evidence_k=0)


def test_config_rejects_out_of_range_similarity_threshold():
    with pytest.raises(RetrievalConfigurationError):
        RetrievalConfig(similarity_threshold=1.5)
    with pytest.raises(RetrievalConfigurationError):
        RetrievalConfig(similarity_threshold=-0.1)


def test_evidence_candidate_defaults():
    candidate = EvidenceCandidate(
        chunk_id=1, document_id="doc", company_id="co", page_number=1,
        section_title="Overview", document_type="PDF", chunk_text="Some text.",
    )
    assert candidate.semantic_score == 0.0
    assert candidate.matched_queries == []
    assert candidate.source_metadata == {}


def test_retrieval_query_document_sources_defaults_to_none():
    query = RetrievalQuery(text="Why does the org exist?", field_name="Mission Statement", component="Purpose")
    assert query.document_sources is None
