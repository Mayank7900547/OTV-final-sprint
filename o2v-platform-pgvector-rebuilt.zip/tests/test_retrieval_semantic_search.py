"""
Integration tests for `src/retrieval/semantic_search.py`. Requires a real
Postgres test database — skipped automatically if unreachable. Uses a
fake `BaseEmbeddingProvider` (no network / no real provider needed).
"""

from __future__ import annotations

import uuid

import pytest

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.models import Chunk
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.exceptions import ProviderUnavailableError
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.vector_store import PostgresVectorStore
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum
from src.retrieval.exceptions import VectorSearchError
from src.retrieval.semantic_search import semantic_search

from src.retrieval import models as _retrieval_models_module  # noqa: F401


class _FakeProvider(BaseEmbeddingProvider):
    provider_name = "fake"

    def __init__(self, *, vectors_by_text: dict, embedding_dimension=3):
        super().__init__(model_name="fake-model", model_version="1", embedding_dimension=embedding_dimension)
        self._vectors_by_text = vectors_by_text

    def embed_batch(self, texts):
        return [self._vectors_by_text[t] for t in texts]


class _AlwaysFailsProvider(BaseEmbeddingProvider):
    provider_name = "fake_broken"

    def embed_batch(self, texts):
        raise ProviderUnavailableError("simulated failure")


def _make_scenario(session, tmp_path, *, company_name="Semantic Test Co"):
    company = Company(name=company_name, status="pending")
    session.add(company)
    session.flush()

    document = DocumentRegistry(
        company_id=company.id, document_name="Annual Report", document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value, document_year=2024,
        official_url=f"https://semtest.com/{uuid.uuid4()}.pdf", source_domain="semtest.com",
        discovery_method="sitemap_crawl", status=DocumentStatus.DISCOVERED.value,
    )
    session.add(document)
    session.flush()

    path = tmp_path / "report.pdf"
    path.write_bytes(b"%PDF-1.4 fake")
    version = DocumentVersion(
        document_id=document.id, version_number=1, file_hash="f" * 64,
        storage_path=str(path), file_size=path.stat().st_size, status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()

    parsed = ParsedDocument(
        document_id=document.id, document_version_id=version.id, parser_used="pdf_parser", parser_version="1.0.0",
        document_type=DocumentType.PDF.value, page_count=1, raw_text="text",
        page_text=[{"page_number": 1, "text": "text"}], character_count=4, status=ParsingStatusEnum.SUCCESS,
    )
    session.add(parsed)
    session.flush()

    chunk = Chunk(
        chunk_id=f"{version.id}:0", document_id=document.id, document_version_id=version.id,
        parsed_document_id=parsed.id, chunk_index=0, page_number=1, section_title=None,
        text="Our ambition is to remove barriers preventing entrepreneurs from accessing capital.",
        character_count=80, token_estimate=15, chunker_used="recursive_chunker", chunker_version="1.0.0",
    )
    session.add(chunk)
    session.flush()

    return company, document, chunk


def _embed_chunk(session, chunk, company, vector, *, dimension=3):
    row = Embedding(
        embedding_id=f"{chunk.id}:fake:model:1", chunk_id=chunk.id, document_id=chunk.document_id,
        provider="fake", model_name="model", model_version="1", embedding_dimension=dimension,
        status=EmbeddingStatusEnum.ACTIVE, is_active=True, vector_store_backend="postgres",
    )
    session.add(row)
    session.flush()
    store = PostgresVectorStore(session=session)
    store.insert_vector(embedding_row=row, vector=vector, metadata={"company": company.name})
    session.flush()
    return row


def test_semantic_search_returns_closest_match(db_session, tmp_path):
    company, _, chunk = _make_scenario(db_session, tmp_path)
    _embed_chunk(db_session, chunk, company, [1.0, 0.0, 0.0])

    provider = _FakeProvider(vectors_by_text={"query text": [1.0, 0.0, 0.0]})
    results = semantic_search(
        db_session, provider, "query text", vector_store_backend="postgres", top_k=5,
    )

    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk.id
    assert results[0]["score"] == pytest.approx(1.0, abs=1e-6)


def test_semantic_search_applies_metadata_filters(db_session, tmp_path):
    company_a, _, chunk_a = _make_scenario(db_session, tmp_path, company_name="Sem Filter Co A")
    company_b, _, chunk_b = _make_scenario(db_session, tmp_path, company_name="Sem Filter Co B")
    _embed_chunk(db_session, chunk_a, company_a, [1.0, 0.0, 0.0])
    _embed_chunk(db_session, chunk_b, company_b, [1.0, 0.0, 0.0])

    provider = _FakeProvider(vectors_by_text={"query": [1.0, 0.0, 0.0]})
    results = semantic_search(
        db_session, provider, "query", vector_store_backend="postgres", top_k=5, filters={"company": company_a.name},
    )
    chunk_ids = {r["chunk_id"] for r in results}
    assert chunk_a.id in chunk_ids
    assert chunk_b.id not in chunk_ids


def test_semantic_search_raises_vector_search_error_on_provider_failure(db_session):
    provider = _AlwaysFailsProvider(model_name="m", model_version="1", embedding_dimension=3)
    with pytest.raises(VectorSearchError):
        semantic_search(db_session, provider, "query", vector_store_backend="postgres", top_k=5)


def test_semantic_search_surfaces_relevant_chunk_without_literal_keyword_match(db_session, tmp_path):
    """
    The brief's required test case: a chunk that never says "purpose" must
    still be findable via semantic similarity to a query about purpose,
    as long as the embedding space places them close together (here,
    faked deterministically via the injected provider — this test proves
    the RETRIEVAL MECHANISM surfaces the right chunk id/score when the
    embeddings are close, independent of any literal wording overlap).
    """
    company, _, chunk = _make_scenario(db_session, tmp_path)
    # chunk.text (seeded above) is deliberately keyword-free of "purpose":
    assert "purpose" not in chunk.text.lower()

    # Simulate a real embedding model placing this "ambition/barriers" chunk
    # close to a "why does the org exist" query in vector space.
    _embed_chunk(db_session, chunk, company, [0.9, 0.1, 0.0])
    provider = _FakeProvider(vectors_by_text={
        "What is the organization's fundamental reason for existence?": [0.88, 0.12, 0.0]
    })

    results = semantic_search(
        db_session, provider, "What is the organization's fundamental reason for existence?",
        vector_store_backend="postgres", top_k=5,
    )

    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk.id
    assert results[0]["score"] > 0.9  # high cosine similarity despite zero literal keyword overlap
