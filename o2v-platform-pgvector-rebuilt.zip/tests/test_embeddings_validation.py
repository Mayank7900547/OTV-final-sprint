"""
Unit tests for the pure-function validation checks in
`src/embeddings/validation.py`. `check_duplicate_active_embedding`
requires a real database session and is covered in
`test_embeddings_service.py` instead.
"""

from dataclasses import dataclass

import pytest

from src.embeddings.exceptions import EmbeddingValidationError, InvalidProviderResponseError
from src.embeddings.validation import (
    validate_chunk_has_text,
    validate_embedding_vector,
    validate_model_compatibility,
    validate_vector_metadata,
)


@dataclass
class _FakeChunk:
    id: int = 1
    text: str = ""


# ---------------------------------------------------------------------------
# validate_chunk_has_text
# ---------------------------------------------------------------------------


def test_validate_chunk_has_text_passes_with_content():
    validate_chunk_has_text(_FakeChunk(text="Some real content."))


def test_validate_chunk_has_text_raises_on_empty_string():
    with pytest.raises(EmbeddingValidationError):
        validate_chunk_has_text(_FakeChunk(text=""))


def test_validate_chunk_has_text_raises_on_whitespace_only():
    with pytest.raises(EmbeddingValidationError):
        validate_chunk_has_text(_FakeChunk(text="   \n  "))


# ---------------------------------------------------------------------------
# validate_embedding_vector
# ---------------------------------------------------------------------------


def test_validate_embedding_vector_passes_for_correct_shape():
    validate_embedding_vector([0.1, 0.2, 0.3], expected_dimension=3)


def test_validate_embedding_vector_raises_on_empty_vector():
    with pytest.raises(EmbeddingValidationError):
        validate_embedding_vector([], expected_dimension=3)


def test_validate_embedding_vector_raises_on_dimension_mismatch():
    with pytest.raises(EmbeddingValidationError):
        validate_embedding_vector([0.1, 0.2], expected_dimension=3)


def test_validate_embedding_vector_raises_on_nan():
    with pytest.raises(EmbeddingValidationError):
        validate_embedding_vector([0.1, float("nan"), 0.3], expected_dimension=3)


def test_validate_embedding_vector_raises_on_inf():
    with pytest.raises(EmbeddingValidationError):
        validate_embedding_vector([0.1, float("inf"), 0.3], expected_dimension=3)


# ---------------------------------------------------------------------------
# validate_vector_metadata
# ---------------------------------------------------------------------------


def _full_metadata(**overrides):
    base = {
        "company": "Acme Corp",
        "document_id": "abc-123",
        "chunk_id": "1:0",
        "page_number": 1,
        "section_title": "Overview",
        "document_type": "PDF",
        "creation_timestamp": "2026-01-01T00:00:00+00:00",
        "chunk_index": 0,
    }
    base.update(overrides)
    return base


def test_validate_vector_metadata_passes_when_all_required_fields_present():
    assert validate_vector_metadata(_full_metadata()) == []


def test_validate_vector_metadata_allows_null_page_number_and_section_title():
    metadata = _full_metadata(page_number=None, section_title=None)
    assert validate_vector_metadata(metadata) == []


def test_validate_vector_metadata_flags_missing_company():
    metadata = _full_metadata(company=None)
    problems = validate_vector_metadata(metadata)
    assert len(problems) == 1
    assert "company" in problems[0]


def test_validate_vector_metadata_flags_missing_document_id():
    metadata = _full_metadata(document_id="")
    problems = validate_vector_metadata(metadata)
    assert "document_id" in problems[0]


def test_validate_vector_metadata_flags_multiple_missing_fields():
    metadata = _full_metadata(company=None, document_type=None)
    problems = validate_vector_metadata(metadata)
    assert len(problems) == 1  # one combined message
    assert "company" in problems[0] and "document_type" in problems[0]


# ---------------------------------------------------------------------------
# validate_model_compatibility
# ---------------------------------------------------------------------------


def test_validate_model_compatibility_passes_when_dimensions_match():
    validate_model_compatibility("openai", declared_dimension=1536, provider_dimension=1536)


def test_validate_model_compatibility_raises_on_mismatch():
    with pytest.raises(InvalidProviderResponseError):
        validate_model_compatibility("openai", declared_dimension=1536, provider_dimension=768)
