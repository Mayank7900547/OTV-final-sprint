"""
Integration tests for src/acquisition/service.py (DocumentAcquisitionService).

Unlike the other `test_acquisition_*` modules (which test each acquisition
component in isolation with everything external mocked), this module
exercises the actual orchestration: retry semantics, version numbering,
archival of superseded files, and dedup-by-hash — all of which only mean
something against a real database and a real (if redirected-to-tmp_path)
filesystem.

Requires a real Postgres test database, exactly like
test_document_discovery_service.py — skipped automatically if unreachable
(see tests/conftest.py's module docstring). `DocumentAcquisitionService`
additionally calls `session.commit()` multiple times per document (once
per retry attempt, to persist DownloadHistory rows even if a later retry
also fails), which the plain `db_session` fixture in conftest.py can't
safely absorb without ending the outer test transaction early — so this
module defines its own `acq_session` fixture using the standard
SQLAlchemy "join a session into an external transaction via a SAVEPOINT
that's restarted after every commit" pattern. This keeps every commit the
service makes durable *within* the test, while the whole thing is still
rolled back at teardown, exactly like `db_session` is for every other
test module.
"""

import contextlib
import uuid
from pathlib import Path

import pytest
from sqlalchemy import event
from sqlalchemy.orm import sessionmaker

from src.acquisition import file_manager as file_manager_module
from src.acquisition.downloader import BaseDownloader
from src.acquisition.exceptions import FileIntegrityError
from src.acquisition.models import DocumentVersion, DownloadHistory, DownloadStatusEnum, DocumentVersionStatusEnum
from src.acquisition.service import DocumentAcquisitionService
from src.acquisition.storage import LocalDiskStorageBackend
from src.config.settings import settings
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.models.company import Company
from src.models.document import DocumentRegistry

# Import so its table registers on Base.metadata, same requirement as conftest.py.
from src.acquisition import models as _acquisition_models_module  # noqa: F401


@pytest.fixture
def acq_session(_test_engine):
    """
    Same real-Postgres-or-skip contract as `db_session` (see conftest.py),
    but safe for code under test that calls `session.commit()` internally
    — see module docstring for why `db_session` alone isn't sufficient
    here.
    """
    connection = _test_engine.connect()
    outer_transaction = connection.begin()
    SessionForTest = sessionmaker(bind=connection, future=True)
    session = SessionForTest()
    session.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def _restart_savepoint(sess, trans):
        if trans.nested and not trans._parent.nested:
            sess.begin_nested()

    yield session

    session.close()
    outer_transaction.rollback()
    connection.close()


@pytest.fixture(autouse=True)
def _isolated_file_storage(tmp_path, monkeypatch):
    """Redirect the acquisition module's file-storage singletons into tmp_path."""
    monkeypatch.setattr(file_manager_module, "storage_backend", LocalDiskStorageBackend(tmp_path / "data"))
    monkeypatch.setattr(file_manager_module, "STAGING_DIR", tmp_path / "staging")


@pytest.fixture(autouse=True)
def _fast_retries(monkeypatch):
    """Retry backoff would otherwise really sleep (2.0 ** attempt seconds) — make tests instant."""
    monkeypatch.setattr(settings, "acquisition_retry_backoff_factor", 1.0)


class _ScriptedDownloader(BaseDownloader):
    """
    Test double for HttpDownloader: returns a scripted sequence of outcomes,
    one per call to `fetch()`, so tests can drive exact retry/version
    scenarios without any real HTTP or DNS involved.

    Each scripted outcome is either:
      - (status_code, content_type, body_bytes) -> writes body_bytes to
        staging_path and returns (status_code, content_type)
      - an Exception instance/class -> raised instead of returning
    """

    def __init__(self, outcomes):
        self._outcomes = list(outcomes)
        self.calls = []

    async def fetch(self, url, staging_path):
        self.calls.append(url)
        outcome = self._outcomes.pop(0)
        if isinstance(outcome, Exception) or (isinstance(outcome, type) and issubclass(outcome, Exception)):
            raise outcome
        status_code, content_type, body = outcome
        staging_path.write_bytes(body)
        return status_code, content_type


def _valid_pdf(marker: bytes = b"content") -> bytes:
    return b"%PDF-1.4\n" + marker + b"\n%%EOF"


def _make_company(session, name="Acme Corp"):
    company = Company(name=name, status="pending")
    session.add(company)
    session.flush()
    return company


def _make_document(session, company, url="https://acme.com/annual-report.pdf"):
    doc = DocumentRegistry(
        company_id=company.id,
        document_name="Annual Report",
        document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value,
        document_year=2024,
        official_url=url,
        source_domain="acme.com",
        discovery_method="sitemap_crawl",
        status=DocumentStatus.DISCOVERED.value,
    )
    session.add(doc)
    session.flush()
    return doc


def _service_for(session, downloader):
    @contextlib.contextmanager
    def _factory():
        yield session

    return DocumentAcquisitionService(session_factory=_factory, downloader=downloader)


# ---------------------------------------------------------------------------
# Not found
# ---------------------------------------------------------------------------


def test_download_document_returns_failed_when_document_not_found(acq_session):
    downloader = _ScriptedDownloader([])
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(uuid.uuid4()))

    assert result["status"] == "FAILED"
    assert "not found" in result["error"].lower()


# ---------------------------------------------------------------------------
# First-ever successful download
# ---------------------------------------------------------------------------


def test_download_document_success_creates_version_one(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)
    body = _valid_pdf(b"first-version")
    downloader = _ScriptedDownloader([(200, "application/pdf", body)])
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(doc.id))

    assert result["status"] == "SUCCESS"
    assert result["version"] == 1
    assert Path(result["path"]).read_bytes() == body

    versions = acq_session.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).all()
    assert len(versions) == 1
    assert versions[0].status == DocumentVersionStatusEnum.ACTIVE
    assert versions[0].version_number == 1

    history = acq_session.query(DownloadHistory).filter(DownloadHistory.document_id == doc.id).all()
    assert len(history) == 1
    assert history[0].download_status == DownloadStatusEnum.SUCCESS


# ---------------------------------------------------------------------------
# Dedup-by-hash
# ---------------------------------------------------------------------------


def test_download_document_duplicate_content_is_skipped_not_versioned(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)
    body = _valid_pdf(b"identical-bytes")

    # First download establishes version 1.
    service1 = _service_for(acq_session, _ScriptedDownloader([(200, "application/pdf", body)]))
    import asyncio

    first = asyncio.run(service1.download_document(doc.id))
    assert first["status"] == "SUCCESS"

    # Second download fetches byte-identical content -> must be recognized
    # as a duplicate of the current ACTIVE version, not turned into v2.
    service2 = _service_for(acq_session, _ScriptedDownloader([(200, "application/pdf", body)]))
    second = asyncio.run(service2.download_document(doc.id))

    assert second["status"] == "DUPLICATE_SKIPPED"
    assert second["version"] == 1
    assert second["hash"] == first["hash"]

    versions = acq_session.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).all()
    assert len(versions) == 1  # still just v1 -- no new version created

    history = (
        acq_session.query(DownloadHistory)
        .filter(DownloadHistory.document_id == doc.id)
        .order_by(DownloadHistory.attempt_number)
        .all()
    )
    assert [h.download_status for h in history] == [DownloadStatusEnum.SUCCESS, DownloadStatusEnum.DUPLICATE_SKIPPED]


# ---------------------------------------------------------------------------
# New version + archival of the superseded file
# ---------------------------------------------------------------------------


def test_download_document_changed_content_creates_new_version_and_archives_old(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)

    service1 = _service_for(acq_session, _ScriptedDownloader([(200, "application/pdf", _valid_pdf(b"old-content"))]))
    import asyncio

    first = asyncio.run(service1.download_document(doc.id))
    old_path = Path(first["path"])
    assert old_path.exists()

    service2 = _service_for(acq_session, _ScriptedDownloader([(200, "application/pdf", _valid_pdf(b"NEW-content-different"))]))
    second = asyncio.run(service2.download_document(doc.id))

    assert second["status"] == "SUCCESS"
    assert second["version"] == 2
    assert second["hash"] != first["hash"]

    versions = (
        acq_session.query(DocumentVersion)
        .filter(DocumentVersion.document_id == doc.id)
        .order_by(DocumentVersion.version_number)
        .all()
    )
    assert len(versions) == 2
    v1, v2 = versions
    assert v1.version_number == 1
    assert v1.status == DocumentVersionStatusEnum.ARCHIVED
    assert v2.version_number == 2
    assert v2.status == DocumentVersionStatusEnum.ACTIVE

    # The v1 file was physically moved to archive/, and the raw/ path it
    # used to occupy is now reused by v2's promoted file (same
    # company/year/name -> same raw_target_key) — so `old_path` still
    # exists, but now holds v2's bytes, not v1's. The actual v1 content
    # lives at v1.storage_path under archive/.
    assert old_path.read_bytes() == _valid_pdf(b"NEW-content-different")
    assert Path(v1.storage_path).exists()
    assert Path(v1.storage_path) != old_path
    assert "archive" in v1.storage_path.replace("\\", "/")
    assert Path(v1.storage_path).read_bytes() == _valid_pdf(b"old-content")
    assert Path(v2.storage_path).read_bytes() == _valid_pdf(b"NEW-content-different")


# ---------------------------------------------------------------------------
# Retry semantics
# ---------------------------------------------------------------------------


def test_download_document_retries_transient_failure_then_succeeds(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_retries", 3)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)

    downloader = _ScriptedDownloader(
        [
            ConnectionError("transient network blip"),
            (200, "application/pdf", _valid_pdf(b"recovered")),
        ]
    )
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(doc.id))

    assert result["status"] == "SUCCESS"
    assert len(downloader.calls) == 2  # first attempt failed, second succeeded

    history = (
        acq_session.query(DownloadHistory)
        .filter(DownloadHistory.document_id == doc.id)
        .order_by(DownloadHistory.attempt_number)
        .all()
    )
    assert [h.download_status for h in history] == [DownloadStatusEnum.FAILED, DownloadStatusEnum.SUCCESS]
    assert history[0].attempt_number == 1
    assert history[1].attempt_number == 2
    assert history[0].error_message is not None


def test_download_document_gives_up_after_max_retries(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_max_retries", 2)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)

    downloader = _ScriptedDownloader([ConnectionError("down"), ConnectionError("still down")])
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(doc.id))

    assert result["status"] == "FAILED"
    assert len(downloader.calls) == 2  # exactly max_retries attempts, no more

    history = acq_session.query(DownloadHistory).filter(DownloadHistory.document_id == doc.id).all()
    assert len(history) == 2
    assert all(h.download_status == DownloadStatusEnum.FAILED for h in history)

    # No DocumentVersion should exist -- every attempt failed before a hash was ever computed.
    versions = acq_session.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).all()
    assert versions == []


def test_download_document_integrity_failure_is_recorded_as_corrupted_not_failed(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_max_retries", 1)
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)

    # Not a valid PDF (no magic bytes) -> FileIntegrityValidator rejects it,
    # which service.py maps to CORRUPTED (not the generic FAILED) status.
    downloader = _ScriptedDownloader([(200, "application/pdf", b"<html>not a pdf</html>")])
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(doc.id))

    assert result["status"] == "FAILED"  # overall outcome after exhausting retries
    history = acq_session.query(DownloadHistory).filter(DownloadHistory.document_id == doc.id).all()
    assert len(history) == 1
    assert history[0].download_status == DownloadStatusEnum.CORRUPTED
    assert "magic bytes" in history[0].error_message.lower()


def test_download_document_succeeds_for_real_world_html_document(acq_session, monkeypatch):
    """
    Regression test for a genuine bug (not synthetic): SEC EDGAR routinely
    serves 10-Ks/proxy statements as .htm, not PDF (e.g.
    https://www.sec.gov/Archives/edgar/data/320193/.../d79474def14a.htm).
    Before this fix, `validate_pdf_integrity` unconditionally rejected any
    `text/html` Content-Type, so every real EDGAR filing failed integrity
    validation after a genuinely successful HTTP 200 download — acquisition
    reported 0 succeeded / N failed despite the network layer working
    perfectly. This asserts the html-document_type path now succeeds
    end-to-end through the real service, not just the validator unit tests.
    """
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company, url="https://www.sec.gov/Archives/edgar/data/320193/000119312523000001/d79474def14a.htm")
    doc.document_type = DocumentType.HTML.value
    acq_session.flush()

    real_html = b"<!DOCTYPE html>\n<html><head><title>DEF 14A</title></head><body>Proxy statement content.</body></html>"
    downloader = _ScriptedDownloader([(200, "text/html; charset=utf-8", real_html)])
    service = _service_for(acq_session, downloader)

    import asyncio

    result = asyncio.run(service.download_document(doc.id))

    assert result["status"] == "SUCCESS"
    version = acq_session.query(DocumentVersion).filter(DocumentVersion.document_id == doc.id).first()
    assert version is not None
    assert version.status == DocumentVersionStatusEnum.ACTIVE


def test_download_document_cleans_up_staging_file_after_failed_attempt(acq_session, monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "acquisition_max_retries", 1)
    company = _make_company(acq_session)
    doc = _make_document(acq_session, company)

    downloader = _ScriptedDownloader([ConnectionError("boom")])
    service = _service_for(acq_session, downloader)

    import asyncio

    asyncio.run(service.download_document(doc.id))

    staging_dir = tmp_path / "staging"
    leftover_files = list(staging_dir.glob("*.part")) if staging_dir.exists() else []
    assert leftover_files == []


# ---------------------------------------------------------------------------
# process_all_pending_documents
# ---------------------------------------------------------------------------


def test_process_all_pending_documents_filters_by_company_name(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    acme = _make_company(acq_session, name="Acme Corp")
    globex = _make_company(acq_session, name="Globex Inc")
    acme_doc = _make_document(acq_session, acme, url="https://acme.com/report.pdf")
    globex_doc = _make_document(acq_session, globex, url="https://globex.com/report.pdf")

    downloader = _ScriptedDownloader([(200, "application/pdf", _valid_pdf(b"acme-only"))])
    service = _service_for(acq_session, downloader)

    import asyncio

    results = asyncio.run(service.process_all_pending_documents(company_filter="Acme"))

    assert len(results) == 1
    assert results[0]["status"] == "SUCCESS"
    # Only the Acme document should have been touched -- Globex's was never fetched.
    assert downloader.calls == ["https://acme.com/report.pdf"]

    globex_versions = acq_session.query(DocumentVersion).filter(DocumentVersion.document_id == globex_doc.id).all()
    assert globex_versions == []


def test_process_all_pending_documents_processes_all_when_no_filter(acq_session, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    acme = _make_company(acq_session, name="Acme Corp")
    globex = _make_company(acq_session, name="Globex Inc")
    _make_document(acq_session, acme, url="https://acme.com/report.pdf")
    _make_document(acq_session, globex, url="https://globex.com/report.pdf")

    downloader = _ScriptedDownloader(
        [
            (200, "application/pdf", _valid_pdf(b"one")),
            (200, "application/pdf", _valid_pdf(b"two")),
        ]
    )
    service = _service_for(acq_session, downloader)

    import asyncio

    results = asyncio.run(service.process_all_pending_documents())

    assert len(results) == 2
    assert all(r["status"] == "SUCCESS" for r in results)
