"""
Tests for src/registry/framework_loader.py.

These tests are the actual proof of the "add a framework without changing
code" requirement: valid_framework_yaml below is a MINIMAL, generic
framework (not O2V-specific), demonstrating the loader works for any
framework shape that follows the expected structure.
"""

import pytest

from src.core.exceptions import FrameworkValidationError
from src.registry.framework_loader import (
    flatten_framework,
    load_and_flatten,
    load_framework_yaml,
)

VALID_FRAMEWORK_YAML = """
framework_name: ESG
components:
  - component_name: Environmental
    fields:
      - field_name: Carbon Targets
        description: "Stated emissions reduction targets."
        document_sources: ["Sustainability Report"]
      - field_name: Water Usage
  - component_name: Social
    fields:
      - field_name: Labor Practices
        description: "Stated labor/human rights commitments."
"""


def test_load_valid_framework_yaml(tmp_yaml_file):
    path = tmp_yaml_file(VALID_FRAMEWORK_YAML)
    raw = load_framework_yaml(path)
    assert raw["framework_name"] == "ESG"
    assert len(raw["components"]) == 2


def test_flatten_framework_produces_flat_rows(tmp_yaml_file):
    path = tmp_yaml_file(VALID_FRAMEWORK_YAML)
    raw = load_framework_yaml(path)
    rows = flatten_framework(raw)

    assert len(rows) == 3
    assert rows[0]["component_name"] == "Environmental"
    assert rows[0]["field_name"] == "Carbon Targets"
    assert rows[0]["document_sources"] == ["Sustainability Report"]

    # Field with no explicit document_sources should default to an empty list,
    # not None and not a KeyError.
    assert rows[1]["field_name"] == "Water Usage"
    assert rows[1]["document_sources"] == []


def test_load_and_flatten_convenience_function(tmp_yaml_file):
    path = tmp_yaml_file(VALID_FRAMEWORK_YAML)
    framework_name, rows = load_and_flatten(path)
    assert framework_name == "ESG"
    assert len(rows) == 3


def test_missing_file_raises(tmp_path):
    with pytest.raises(FrameworkValidationError, match="not found"):
        load_framework_yaml(tmp_path / "does_not_exist.yaml")


def test_missing_top_level_key_raises(tmp_yaml_file):
    path = tmp_yaml_file("framework_name: ESG\n")  # missing 'components'
    with pytest.raises(FrameworkValidationError, match="missing required top-level key"):
        load_framework_yaml(path)


def test_empty_components_list_raises(tmp_yaml_file):
    path = tmp_yaml_file("framework_name: ESG\ncomponents: []\n")
    with pytest.raises(FrameworkValidationError, match="non-empty list"):
        load_framework_yaml(path)


def test_component_missing_fields_key_raises(tmp_yaml_file):
    bad_yaml = """
framework_name: ESG
components:
  - component_name: Environmental
"""
    path = tmp_yaml_file(bad_yaml)
    with pytest.raises(FrameworkValidationError, match="missing key"):
        load_framework_yaml(path)


def test_field_missing_field_name_raises(tmp_yaml_file):
    bad_yaml = """
framework_name: ESG
components:
  - component_name: Environmental
    fields:
      - description: "no field_name here"
"""
    path = tmp_yaml_file(bad_yaml)
    with pytest.raises(FrameworkValidationError, match="missing key"):
        load_framework_yaml(path)


def test_invalid_yaml_syntax_raises(tmp_yaml_file):
    path = tmp_yaml_file("framework_name: [unclosed")
    with pytest.raises(FrameworkValidationError, match="Invalid YAML"):
        load_framework_yaml(path)
