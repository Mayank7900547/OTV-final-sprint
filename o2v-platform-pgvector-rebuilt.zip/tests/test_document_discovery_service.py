"""
Integration tests for src/services/document_discovery_service.py.

These use the `db_session` fixture (real Postgres test database,
transaction-rollback isolation — see tests/conftest.py) combined with
mocked HTTP (same `monkeypatch` pattern as the other Sprint 2 test
files). This is the level where the pieces that are unit-tested in
isolation elsewhere (url_validator, category_classifier, sec_edgar_client,
sitemap_crawler) get exercised TOGETHER against a real database, which is
the only way to actually prove dedup-on-second-run, persisted status
values, and per-company failure isolation genuinely work end-to-end.
"""

import json

import pytest

from src.core.exceptions import DiscoveryError
from src.discovery import http_client, sec_edgar_client
from src.discovery.http_client import FetchResult
from src.services import company_service, document_discovery_service, document_service

FAKE_TICKER_MAP = {"0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."}}

FAKE_SUBMISSIONS = {
    "filings": {
        "recent": {
            "form": ["10-K"],
            "filingDate": ["2025-11-01"],
            "accessionNumber": ["0000320193-25-000100"],
            "primaryDocument": ["aapl-20250927.htm"],
        }
    }
}

FAKE_SITEMAP_XML = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://apple.com/sustainability/2024-report.pdf</loc></url>
</urlset>
"""


def _make_company(session, name="Apple Inc.", ticker="AAPL", website="apple.com"):
    return company_service.create_company(session, name=name, ticker=ticker, website=website)


def _mock_http(monkeypatch, responses: dict[str, FetchResult]):
    def _get(url: str) -> FetchResult:
        return responses.get(url, FetchResult(ok=False, url=url, reason="not mocked / 404"))

    monkeypatch.setattr(http_client, "get", _get)


def _reset_sec_ticker_cache():
    sec_edgar_client._ticker_cache = sec_edgar_client._TickerCikCache()


def _standard_responses():
    return {
        sec_edgar_client.TICKER_MAP_URL: FetchResult(
            ok=True, url="x", status_code=200, text=json.dumps(FAKE_TICKER_MAP)
        ),
        sec_edgar_client.SUBMISSIONS_URL_TEMPLATE.format(cik="0000320193"): FetchResult(
            ok=True, url="x", status_code=200, text=json.dumps(FAKE_SUBMISSIONS)
        ),
        "https://apple.com/sitemap.xml": FetchResult(
            ok=True, url="x", status_code=200, text=FAKE_SITEMAP_XML
        ),
    }


def test_discover_for_company_creates_documents(db_session, monkeypatch):
    _reset_sec_ticker_cache()
    _mock_http(monkeypatch, _standard_responses())

    company = _make_company(db_session)
    result = document_discovery_service.discover_for_company(db_session, company)

    # 1 SEC 10-K + 1 sitemap Sustainability Report = 2 created, nothing rejected/duplicate.
    assert result.created == 2
    assert result.skipped_duplicates == 0
    assert result.rejected == []
    assert result.error is None

    stored = document_service.list_documents(db_session, company_id=company.id)
    assert len(stored) == 2
    categories = {d.document_category for d in stored}
    assert categories == {"form_10k", "sustainability_report"}


def test_discover_for_company_second_run_is_deduplicated(db_session, monkeypatch):
    _reset_sec_ticker_cache()
    _mock_http(monkeypatch, _standard_responses())

    company = _make_company(db_session)
    first = document_discovery_service.discover_for_company(db_session, company)
    assert first.created == 2

    # Re-run discovery for the SAME company against the SAME (mocked)
    # sources — every candidate should now be recognized as already
    # registered, proving the (company_id, official_url) dedup actually
    # works across separate discovery runs, not just within one.
    second = document_discovery_service.discover_for_company(db_session, company)
    assert second.created == 0
    assert second.skipped_duplicates == 2

    stored = document_service.list_documents(db_session, company_id=company.id)
    assert len(stored) == 2  # still exactly 2 — nothing duplicated


def test_discover_for_company_rejects_disallowed_domain(db_session, monkeypatch):
    _reset_sec_ticker_cache()
    # A sitemap that points at a THIRD-PARTY domain, not apple.com or SEC —
    # this must be rejected by url_validator. Note the URL path contains
    # "sustainability", so it DOES pass category classification (correctly —
    # classification is about URL shape, not trustworthiness) and reaches
    # the validator, which is exactly where domain trust should be enforced.
    responses = _standard_responses()
    responses["https://apple.com/sitemap.xml"] = FetchResult(
        ok=True,
        url="x",
        status_code=200,
        text=(
            '<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            "<url><loc>https://en.wikipedia.org/wiki/Apple_Inc._sustainability</loc></url>"
            "</urlset>"
        ),
    )
    _mock_http(monkeypatch, responses)

    company = _make_company(db_session)
    result = document_discovery_service.discover_for_company(db_session, company)

    # The Wikipedia URL is correctly classified (it mentions
    # "sustainability") but correctly REJECTED at the domain-validation
    # step, proving rejection is enforced independently of — and after —
    # classification, not as a substitute for it.
    assert len(result.rejected) == 1
    rejected_url, reason = result.rejected[0]
    assert rejected_url == "https://en.wikipedia.org/wiki/Apple_Inc._sustainability"
    assert "en.wikipedia.org" in reason
    assert result.created == 1  # only the SEC 10-K survives


def test_discover_for_company_persists_document_metadata_correctly(db_session, monkeypatch):
    _reset_sec_ticker_cache()
    _mock_http(monkeypatch, _standard_responses())

    company = _make_company(db_session)
    document_discovery_service.discover_for_company(db_session, company)

    stored = document_service.list_documents(db_session, company_id=company.id)
    tenk = next(d for d in stored if d.document_category == "form_10k")

    assert tenk.document_year == 2025
    assert tenk.discovery_method == "sec_edgar_api"
    assert tenk.status == "discovered"
    assert tenk.source_domain == "www.sec.gov"
    assert tenk.company_id == company.id


def test_discover_for_all_companies_isolates_per_company_failure(db_session, monkeypatch):
    _reset_sec_ticker_cache()

    good_company = _make_company(db_session, name="Apple Inc.", ticker="AAPL", website="apple.com")
    # A second company whose ticker map lookup will succeed (ticker map is
    # fetched once, shared) but whose submissions URL is deliberately NOT
    # mocked, so its SEC lookup raises DocumentSourceUnavailableError — this
    # simulates "company 2's data source is broken" without affecting company 1.
    broken_company = company_service.create_company(
        db_session, name="Broken Corp.", ticker="BRKN", website="brokencorp.example.com"
    )

    ticker_map_with_both = {
        "0": {"cik_str": 320193, "ticker": "AAPL", "title": "Apple Inc."},
        "1": {"cik_str": 999999, "ticker": "BRKN", "title": "Broken Corp."},
    }
    responses = _standard_responses()
    responses[sec_edgar_client.TICKER_MAP_URL] = FetchResult(
        ok=True, url="x", status_code=200, text=json.dumps(ticker_map_with_both)
    )
    # Deliberately no entry for BRKN's submissions URL -> "not mocked / 404" -> DocumentSourceUnavailableError
    _mock_http(monkeypatch, responses)

    results = document_discovery_service.discover_for_all_companies(db_session)

    by_name = {r.company_name: r for r in results}
    assert by_name["Apple Inc."].created == 2
    assert by_name["Apple Inc."].error is None

    assert by_name["Broken Corp."].error is not None
    assert by_name["Broken Corp."].created == 0

    # Apple's documents must be persisted DESPITE Broken Corp.'s failure —
    # this is the actual proof of "company 37 failing doesn't block the batch."
    apple_docs = document_service.list_documents(db_session, company_id=good_company.id)
    assert len(apple_docs) == 2


def test_get_company_or_raise_raises_discovery_error_for_unknown_company(db_session):
    with pytest.raises(DiscoveryError, match="No company named"):
        document_discovery_service.get_company_or_raise(db_session, "Totally Fictional Co.")
