"""
Tests for src/acquisition/rate_limiter.py.

Note: the project's requirements.txt does not include pytest-asyncio, so
these tests drive the async `acquire()` coroutine with `asyncio.run(...)`
from ordinary sync test functions rather than depending on that plugin —
consistent with keeping the test suite runnable with exactly what's
already pinned in requirements.txt.
"""

import asyncio
import time

from src.acquisition.rate_limiter import HostRateLimiter

# OS timer precision varies by platform -- asyncio.sleep() on Windows in
# particular can return a few milliseconds early relative to the exact
# requested duration (an event-loop/timer-resolution characteristic, not
# a bug in HostRateLimiter's pacing math, which is otherwise exact -- see
# rate_limiter.py). A strict `elapsed >= delay` assertion is flaky across
# platforms as a result; this tolerance absorbs that without weakening
# what the test actually verifies (that pacing happened at all, not that
# it happened with sub-millisecond precision no OS guarantees anyway).
_TIMER_TOLERANCE_SECONDS = 0.02


def test_acquire_enforces_minimum_delay_between_requests_to_same_host():
    limiter = HostRateLimiter(requests_per_second=10.0, max_concurrent_per_host=5)  # delay = 0.1s

    async def _run():
        start = time.monotonic()
        await limiter.acquire("https://example.com/a.pdf")
        await limiter.acquire("https://example.com/b.pdf")
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed >= 0.1 - _TIMER_TOLERANCE_SECONDS


def test_acquire_does_not_delay_first_request():
    limiter = HostRateLimiter(requests_per_second=1.0, max_concurrent_per_host=5)  # delay = 1.0s

    async def _run():
        start = time.monotonic()
        await limiter.acquire("https://example.com/a.pdf")
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed < 0.5  # first request for a host should not be throttled


def test_acquire_tracks_delay_independently_per_host():
    limiter = HostRateLimiter(requests_per_second=2.0, max_concurrent_per_host=5)  # delay = 0.5s

    async def _run():
        start = time.monotonic()
        await limiter.acquire("https://host-a.com/x.pdf")
        await limiter.acquire("https://host-b.com/y.pdf")  # different host -> no cross-host delay
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed < 0.3


def test_acquire_treats_hostname_case_insensitively():
    limiter = HostRateLimiter(requests_per_second=5.0, max_concurrent_per_host=5)  # delay = 0.2s

    async def _run():
        start = time.monotonic()
        await limiter.acquire("https://Example.COM/a.pdf")
        await limiter.acquire("https://example.com/b.pdf")  # same host, different case
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed >= 0.2


def test_host_semaphore_initial_capacity_matches_max_concurrent_per_host():
    # `acquire()` only holds its per-host semaphore for the duration of the
    # timing/delay bookkeeping itself (see rate_limiter.py — the semaphore
    # is released as soon as `acquire()` returns, before the caller's
    # actual download runs). So `max_concurrent_per_host` bounds concurrent
    # *entries into the rate-limiting gate*, not concurrent in-flight
    # downloads to a host. This test checks the semaphore is configured
    # with the requested capacity, which is the guarantee this class
    # actually provides.
    limiter = HostRateLimiter(requests_per_second=100.0, max_concurrent_per_host=3)
    domain = "example.com"
    asyncio.run(limiter.acquire(f"https://{domain}/doc.pdf"))
    assert limiter._host_semaphores[domain]._value == 3  # no one holding it once acquire() returns


def test_burst_of_concurrent_acquires_to_same_host_are_rate_limited_in_aggregate():
    # Whether serialized via the per-host semaphore or the shared timing
    # lock, N concurrent acquire() calls to the same host must still
    # respect the configured requests_per_second in aggregate: the Nth
    # request cannot complete before (N-1) * delay has elapsed.
    limiter = HostRateLimiter(requests_per_second=10.0, max_concurrent_per_host=5)  # delay = 0.1s

    async def _run():
        start = time.monotonic()
        await asyncio.gather(*[limiter.acquire("https://example.com/doc.pdf") for _ in range(4)])
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed >= 0.3  # >= 3 * delay for 4 requests


def test_burst_of_concurrent_acquires_to_different_hosts_is_fast():
    limiter = HostRateLimiter(requests_per_second=2.0, max_concurrent_per_host=5)  # delay = 0.5s

    async def _run():
        start = time.monotonic()
        await asyncio.gather(
            limiter.acquire("https://host-a.com/doc.pdf"),
            limiter.acquire("https://host-b.com/doc.pdf"),
            limiter.acquire("https://host-c.com/doc.pdf"),
        )
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    # Different hosts track separate `_last_request_time` entries, so none
    # of these should wait on each other's delay.
    assert elapsed < 0.3


# ---------------------------------------------------------------------------
# throttle() — holds the slot for the caller's actual work, unlike acquire()
# ---------------------------------------------------------------------------


def test_throttle_caps_concurrent_in_flight_work_per_host():
    # Unlike acquire() (see its docstring), throttle() holds the per-host
    # semaphore for as long as the `async with` block is open -- so N
    # concurrent "downloads" simulated by sleeping *inside* the block must
    # never have more than max_concurrent_per_host running at once.
    limiter = HostRateLimiter(requests_per_second=1000.0, max_concurrent_per_host=2)
    in_flight = 0
    max_in_flight = 0
    lock = asyncio.Lock()

    async def _simulated_download():
        nonlocal in_flight, max_in_flight
        async with limiter.throttle("https://example.com/doc.pdf"):
            async with lock:
                in_flight += 1
                max_in_flight = max(max_in_flight, in_flight)
            await asyncio.sleep(0.05)  # stand-in for the actual body download
            async with lock:
                in_flight -= 1

    async def _run():
        await asyncio.gather(*[_simulated_download() for _ in range(5)])

    asyncio.run(_run())
    assert max_in_flight == 2  # never more than max_concurrent_per_host at once


def test_throttle_allows_full_parallelism_across_different_hosts():
    limiter = HostRateLimiter(requests_per_second=1000.0, max_concurrent_per_host=1)
    in_flight = 0
    max_in_flight = 0
    lock = asyncio.Lock()

    async def _simulated_download(host):
        nonlocal in_flight, max_in_flight
        async with limiter.throttle(f"https://{host}/doc.pdf"):
            async with lock:
                in_flight += 1
                max_in_flight = max(max_in_flight, in_flight)
            await asyncio.sleep(0.05)
            async with lock:
                in_flight -= 1

    async def _run():
        await asyncio.gather(
            _simulated_download("host-a.com"),
            _simulated_download("host-b.com"),
            _simulated_download("host-c.com"),
        )

    asyncio.run(_run())
    assert max_in_flight == 3  # independent per-host semaphores -> no cross-host blocking


def test_throttle_still_enforces_pacing_delay():
    limiter = HostRateLimiter(requests_per_second=10.0, max_concurrent_per_host=5)  # delay = 0.1s

    async def _run():
        start = time.monotonic()
        async with limiter.throttle("https://example.com/a.pdf"):
            pass
        async with limiter.throttle("https://example.com/b.pdf"):
            pass
        return time.monotonic() - start

    elapsed = asyncio.run(_run())
    assert elapsed >= 0.1 - _TIMER_TOLERANCE_SECONDS
