"""
Unit tests for `src/pipeline/ollama_manager.py`. All HTTP calls are
mocked (via monkeypatching `httpx.get`) and no real `ollama` process is
ever spawned — `subprocess.Popen` is monkeypatched too, so these tests
verify the CONTROL FLOW (does it attempt to start, does it poll, does it
give up correctly) without touching a real Ollama installation.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import httpx
import pytest

from src.pipeline import ollama_manager
from src.pipeline.ollama_manager import ensure_ollama_running, reset_startup_attempted_flag


@pytest.fixture(autouse=True)
def _reset_flag():
    """Every test starts with a clean 'haven't tried to start it yet' state — this module-level flag is exactly the kind of shared state that leaks between tests if not reset."""
    reset_startup_attempted_flag()
    yield
    reset_startup_attempted_flag()


def _fake_get_factory(responses: list):
    """Returns a fake httpx.get that yields responses in order — MagicMock with .status_code for success, or raises httpx.ConnectError for failure."""
    calls = {"n": 0}

    def _fake_get(url, timeout=None):
        response = responses[min(calls["n"], len(responses) - 1)]
        calls["n"] += 1
        if response == "unreachable":
            raise httpx.ConnectError("connection refused")
        mock = MagicMock()
        mock.status_code = response
        return mock

    _fake_get.call_count = lambda: calls["n"]
    return _fake_get


# ---------------------------------------------------------------------------
# Non-Ollama providers — always a no-op
# ---------------------------------------------------------------------------


def test_non_ollama_provider_returns_false_without_any_http_or_spawn_attempt(monkeypatch):
    spawn_called = []
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: spawn_called.append(True) or True)
    monkeypatch.setattr(httpx, "get", lambda *a, **k: (_ for _ in ()).throw(AssertionError("should never be called for a non-ollama provider")))

    result = ensure_ollama_running("http://localhost:11434", provider_name="openai")

    assert result is False
    assert spawn_called == []


# ---------------------------------------------------------------------------
# Already reachable — no spawn attempt needed
# ---------------------------------------------------------------------------


def test_already_reachable_returns_true_without_spawning(monkeypatch):
    spawn_called = []
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: spawn_called.append(True) or True)
    monkeypatch.setattr(httpx, "get", _fake_get_factory([200]))

    result = ensure_ollama_running("http://localhost:11434", provider_name="ollama")

    assert result is True
    assert spawn_called == []  # already up — never needed to start anything


# ---------------------------------------------------------------------------
# Unreachable -> spawn -> comes up within timeout
# ---------------------------------------------------------------------------


def test_unreachable_then_spawns_and_recovers(monkeypatch):
    spawn_called = []
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: spawn_called.append(True) or True)
    monkeypatch.setattr(ollama_manager.time, "sleep", lambda s: None)  # don't actually wait in tests
    # First check: unreachable. Then two more "still unreachable" polls, then finally up.
    monkeypatch.setattr(httpx, "get", _fake_get_factory(["unreachable", "unreachable", "unreachable", 200]))

    result = ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=100, poll_interval_seconds=0.01)

    assert result is True
    assert spawn_called == [True]  # spawned exactly once


def test_unreachable_and_spawn_fails_returns_false(monkeypatch):
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: False)  # e.g. 'ollama' not on PATH
    monkeypatch.setattr(httpx, "get", _fake_get_factory(["unreachable"]))

    result = ensure_ollama_running("http://localhost:11434", provider_name="ollama")

    assert result is False


def test_unreachable_spawns_but_never_comes_up_within_timeout(monkeypatch):
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: True)
    monkeypatch.setattr(ollama_manager.time, "sleep", lambda s: None)
    monkeypatch.setattr(httpx, "get", _fake_get_factory(["unreachable"]))  # never recovers

    # monotonic() needs to actually advance past the deadline even though
    # sleep() is mocked to be instant — fake a clock that jumps forward
    # each call so the while loop's deadline check eventually trips.
    clock = {"t": 0.0}

    def _fake_monotonic():
        clock["t"] += 1.0
        return clock["t"]

    monkeypatch.setattr(ollama_manager.time, "monotonic", _fake_monotonic)

    result = ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=3, poll_interval_seconds=0.01)

    assert result is False


# ---------------------------------------------------------------------------
# "Already tried once this process" guard
# ---------------------------------------------------------------------------


def test_does_not_attempt_a_second_spawn_in_the_same_process_after_a_failed_attempt(monkeypatch):
    spawn_calls = []
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: spawn_calls.append(True) or True)
    monkeypatch.setattr(ollama_manager.time, "sleep", lambda s: None)
    monkeypatch.setattr(httpx, "get", _fake_get_factory(["unreachable"]))  # never recovers

    clock = {"t": 0.0}

    def _fake_monotonic():
        clock["t"] += 1.0
        return clock["t"]

    monkeypatch.setattr(ollama_manager.time, "monotonic", _fake_monotonic)

    first = ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=2, poll_interval_seconds=0.01)
    second = ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=2, poll_interval_seconds=0.01)

    assert first is False
    assert second is False
    assert len(spawn_calls) == 1  # only the first call actually attempted to spawn


def test_reset_flag_allows_a_fresh_attempt(monkeypatch):
    spawn_calls = []
    monkeypatch.setattr(ollama_manager, "_spawn_ollama_serve", lambda: spawn_calls.append(True) or True)
    monkeypatch.setattr(ollama_manager.time, "sleep", lambda s: None)
    monkeypatch.setattr(httpx, "get", _fake_get_factory(["unreachable"]))

    clock = {"t": 0.0}

    def _fake_monotonic():
        clock["t"] += 1.0
        return clock["t"]

    monkeypatch.setattr(ollama_manager.time, "monotonic", _fake_monotonic)

    ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=2, poll_interval_seconds=0.01)
    reset_startup_attempted_flag()
    ensure_ollama_running("http://localhost:11434", provider_name="ollama", startup_timeout_seconds=2, poll_interval_seconds=0.01)

    assert len(spawn_calls) == 2  # reset allowed a second real attempt


# ---------------------------------------------------------------------------
# _spawn_ollama_serve — real subprocess.Popen call, but Popen itself mocked
# ---------------------------------------------------------------------------


def test_spawn_ollama_serve_returns_true_on_successful_popen(monkeypatch):
    monkeypatch.setattr(ollama_manager.subprocess, "Popen", lambda *a, **k: MagicMock())

    assert ollama_manager._spawn_ollama_serve() is True


def test_spawn_ollama_serve_returns_false_when_ollama_not_on_path(monkeypatch):
    def _raise(*a, **k):
        raise FileNotFoundError("ollama not found")

    monkeypatch.setattr(ollama_manager.subprocess, "Popen", _raise)

    assert ollama_manager._spawn_ollama_serve() is False


def test_spawn_ollama_serve_returns_false_on_os_error(monkeypatch):
    def _raise(*a, **k):
        raise OSError("permission denied")

    monkeypatch.setattr(ollama_manager.subprocess, "Popen", _raise)

    assert ollama_manager._spawn_ollama_serve() is False
