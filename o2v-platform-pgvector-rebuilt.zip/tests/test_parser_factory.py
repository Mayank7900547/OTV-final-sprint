"""Unit tests for `src/parser/parser_factory.py`."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.core.constants import DocumentType
from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.exceptions import UnsupportedDocumentError
from src.parser.html_parser import HTMLParser
from src.parser.parser_factory import ParserFactory
from src.parser.pdf_parser import PDFParser


class _FakeDocxParser(BaseParser):
    """Minimal stand-in used to prove the factory's registration mechanism is generic."""

    parser_name = "fake_docx_parser"
    parser_version = "0.1.0"

    @classmethod
    def supports(cls, document_type: str) -> bool:
        return document_type == "docx"

    def parse(self, file_path: Path) -> ExtractedContent:  # pragma: no cover - not exercised
        return ExtractedContent(raw_text="stub", page_text=[(1, "stub")], page_count=1)


def test_default_registrations_include_pdf_and_html():
    types = ParserFactory.supported_types()
    assert "pdf" in types
    assert "html" in types


def test_get_parser_returns_correct_instance_for_pdf():
    parser = ParserFactory.get_parser(DocumentType.PDF.value, language_detection_enabled=False)
    assert isinstance(parser, PDFParser)


def test_get_parser_returns_correct_instance_for_html():
    parser = ParserFactory.get_parser(DocumentType.HTML.value, language_detection_enabled=False)
    assert isinstance(parser, HTMLParser)


def test_get_parser_raises_unsupported_for_unknown_type():
    with pytest.raises(UnsupportedDocumentError):
        ParserFactory.get_parser("docx")


def test_register_new_parser_extends_factory_without_touching_existing_types():
    ParserFactory.register("docx", _FakeDocxParser)
    try:
        parser = ParserFactory.get_parser("docx")
        assert isinstance(parser, _FakeDocxParser)
        # Registering a new type must not disturb the existing ones.
        assert isinstance(ParserFactory.get_parser("pdf", language_detection_enabled=False), PDFParser)
    finally:
        del ParserFactory._registry["docx"]


def test_detect_document_type_prefers_trusted_hint_over_extension():
    # A .txt-suffixed path with a "pdf" hint (e.g. discovery misclassified
    # the extension but the registry's own document_type is authoritative)
    # should resolve to "pdf", not fail on the extension.
    result = ParserFactory.detect_document_type(Path("report.txt"), hint="pdf")
    assert result == "pdf"


def test_detect_document_type_falls_back_to_extension_when_no_hint():
    assert ParserFactory.detect_document_type(Path("report.pdf")) == "pdf"
    assert ParserFactory.detect_document_type(Path("page.html")) == "html"
    assert ParserFactory.detect_document_type(Path("page.htm")) == "html"


def test_detect_document_type_ignores_unregistered_hint():
    # A hint that isn't a registered type falls through to extension sniffing.
    result = ParserFactory.detect_document_type(Path("report.pdf"), hint="docx")
    assert result == "pdf"


def test_detect_document_type_raises_for_unknown_extension_and_no_hint():
    with pytest.raises(UnsupportedDocumentError):
        ParserFactory.detect_document_type(Path("report.xyz"))
