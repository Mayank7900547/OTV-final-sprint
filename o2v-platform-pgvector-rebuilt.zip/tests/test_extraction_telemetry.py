"""Unit tests for `src/extraction/telemetry.py` — mirrors `test_retrieval_telemetry.py`'s shape."""

from __future__ import annotations

import pytest

from src.core.constants import EvidenceConfidence, ExtractionStatus
from src.extraction.telemetry import ExtractionTelemetry


@pytest.fixture
def telemetry():
    t = ExtractionTelemetry()
    yield t


def test_initial_summary_is_all_zero(telemetry):
    summary = telemetry.get_summary()
    assert summary["extraction_requests"] == 0
    assert summary["successful_extractions"] == 0
    assert summary["average_latency"] == 0.0


def test_record_success_increments_successful(telemetry):
    telemetry.record_request()
    telemetry.record_outcome(
        status=ExtractionStatus.SUCCESS.value, confidence=EvidenceConfidence.HIGH.value,
        duration=1.5, retries=0, provider="ollama",
    )
    summary = telemetry.get_summary()
    assert summary["successful_extractions"] == 1
    assert summary["not_found_extractions"] == 0
    assert summary["active_provider"] == "ollama"


def test_record_success_not_found_counts_separately(telemetry):
    telemetry.record_request()
    telemetry.record_outcome(
        status=ExtractionStatus.SUCCESS.value, confidence=EvidenceConfidence.NOT_FOUND.value,
        duration=1.0, retries=1, provider="openai",
    )
    summary = telemetry.get_summary()
    assert summary["successful_extractions"] == 1
    assert summary["not_found_extractions"] == 1


def test_record_no_evidence_counts_separately_from_failures(telemetry):
    telemetry.record_request()
    telemetry.record_outcome(status=ExtractionStatus.NO_EVIDENCE.value, confidence=None, duration=0.01, retries=0, provider="ollama")
    summary = telemetry.get_summary()
    assert summary["no_evidence_count"] == 1
    assert summary["failed_extractions"] == 0


@pytest.mark.parametrize("status", [ExtractionStatus.PROVIDER_ERROR.value, ExtractionStatus.PARSE_ERROR.value])
def test_record_failures_increment_failed(telemetry, status):
    telemetry.record_request()
    telemetry.record_outcome(status=status, confidence=None, duration=2.0, retries=3, provider="ollama")
    summary = telemetry.get_summary()
    assert summary["failed_extractions"] == 1


def test_average_latency_and_retries_computed_correctly(telemetry):
    telemetry.record_request()
    telemetry.record_outcome(status=ExtractionStatus.SUCCESS.value, confidence="High", duration=1.0, retries=0, provider="ollama")
    telemetry.record_request()
    telemetry.record_outcome(status=ExtractionStatus.SUCCESS.value, confidence="High", duration=3.0, retries=2, provider="ollama")
    summary = telemetry.get_summary()
    assert summary["average_latency"] == 2.0
    assert summary["average_retries"] == 1.0


def test_reset_clears_all_counters(telemetry):
    telemetry.record_request()
    telemetry.record_outcome(status=ExtractionStatus.SUCCESS.value, confidence="High", duration=1.0, retries=0, provider="ollama")
    telemetry.reset()
    summary = telemetry.get_summary()
    assert summary["extraction_requests"] == 0
    assert summary["successful_extractions"] == 0
