"""Integration tests for `src/retrieval/query_generator.py`. Requires a real Postgres test database — skipped automatically if unreachable."""

from __future__ import annotations

import pytest

from src.models.framework import Framework
from src.retrieval.exceptions import QueryGenerationError
from src.retrieval.query_generator import available_components, generate_queries_for_component


def _seed_framework(session, *, framework_name="TestFW", component="Purpose"):
    rows = [
        Framework(
            framework_name=framework_name, component_name=component, field_name="Mission Statement",
            description="An explicit 'why we exist' statement, distinct from mission/vision if present.",
            document_sources=["Annual Report", "About Us Page"],
        ),
        Framework(
            framework_name=framework_name, component_name=component, field_name="Founding Rationale",
            description="The problem or gap in the world the organization was created to address.",
            document_sources=["Annual Report"],
        ),
    ]
    session.add_all(rows)
    session.flush()
    return rows


def test_generate_queries_for_component_returns_one_query_per_field(db_session):
    _seed_framework(db_session, framework_name="QG Test 1")
    queries = generate_queries_for_component(db_session, "Purpose", framework_name="QG Test 1")
    assert len(queries) == 2
    assert {q.field_name for q in queries} == {"Mission Statement", "Founding Rationale"}


def test_generate_queries_for_component_text_comes_from_description_not_field_name(db_session):
    _seed_framework(db_session, framework_name="QG Test 2")
    queries = generate_queries_for_component(db_session, "Purpose", framework_name="QG Test 2")
    mission_query = next(q for q in queries if q.field_name == "Mission Statement")
    assert mission_query.text == "An explicit 'why we exist' statement, distinct from mission/vision if present."


def test_generate_queries_for_component_carries_document_sources(db_session):
    _seed_framework(db_session, framework_name="QG Test 3")
    queries = generate_queries_for_component(db_session, "Purpose", framework_name="QG Test 3")
    mission_query = next(q for q in queries if q.field_name == "Mission Statement")
    assert mission_query.document_sources == ["Annual Report", "About Us Page"]


def test_generate_queries_for_component_respects_max_queries(db_session):
    _seed_framework(db_session, framework_name="QG Test 4")
    queries = generate_queries_for_component(db_session, "Purpose", framework_name="QG Test 4", max_queries=1)
    assert len(queries) == 1


def test_generate_queries_for_component_unknown_component_raises(db_session):
    _seed_framework(db_session, framework_name="QG Test 5")
    with pytest.raises(QueryGenerationError):
        generate_queries_for_component(db_session, "NotARealComponent", framework_name="QG Test 5")


def test_generate_queries_for_component_unknown_framework_raises(db_session):
    with pytest.raises(QueryGenerationError):
        generate_queries_for_component(db_session, "Purpose", framework_name="NotARealFramework")


def test_available_components_lists_distinct_components(db_session):
    _seed_framework(db_session, framework_name="QG Test 6", component="Purpose")
    _seed_framework(db_session, framework_name="QG Test 6", component="Behaviour")
    components = available_components(db_session, framework_name="QG Test 6")
    assert set(components) == {"Purpose", "Behaviour"}


def test_available_components_empty_framework_returns_empty_list(db_session):
    assert available_components(db_session, framework_name="TotallyUnseenFramework") == []
