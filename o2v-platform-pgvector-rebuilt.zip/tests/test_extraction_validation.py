"""Unit tests for `src/extraction/validation.py` — pure logic, no DB/network required."""

from __future__ import annotations

import pytest

from src.extraction.exceptions import ExtractionSchemaError, InvalidLLMResponseError
from src.extraction.validation import parse_and_validate, parse_json_response, validate_extraction_payload


# --------------------------------------------------------------------------
# parse_json_response
# --------------------------------------------------------------------------


def test_parse_json_response_parses_plain_json():
    result = parse_json_response('{"confidence": "High"}')
    assert result == {"confidence": "High"}


def test_parse_json_response_strips_markdown_code_fence():
    raw = '```json\n{"confidence": "High"}\n```'
    assert parse_json_response(raw) == {"confidence": "High"}


def test_parse_json_response_strips_bare_code_fence():
    raw = '```\n{"confidence": "High"}\n```'
    assert parse_json_response(raw) == {"confidence": "High"}


def test_parse_json_response_empty_raises():
    with pytest.raises(InvalidLLMResponseError):
        parse_json_response("")


def test_parse_json_response_malformed_raises():
    with pytest.raises(InvalidLLMResponseError):
        parse_json_response("{not valid json")


def test_parse_json_response_non_object_raises():
    with pytest.raises(InvalidLLMResponseError):
        parse_json_response("[1, 2, 3]")


# --------------------------------------------------------------------------
# validate_extraction_payload
# --------------------------------------------------------------------------


def test_valid_high_confidence_payload():
    payload = {
        "exact_text": "Our purpose is to organize the world's information.",
        "confidence": "High",
        "remarks": None,
        "source_retrieval_id": "req-1:1",
    }
    result = validate_extraction_payload(payload, valid_retrieval_ids={"req-1:1"})
    assert result["confidence"] == "High"
    assert result["exact_text"] == payload["exact_text"]


def test_valid_not_found_payload():
    payload = {
        "exact_text": None,
        "confidence": "Not Found",
        "remarks": "No evidence in the supplied documents addressed this field.",
        "source_retrieval_id": None,
    }
    result = validate_extraction_payload(payload)
    assert result["confidence"] == "Not Found"
    assert result["exact_text"] is None


def test_missing_confidence_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"exact_text": "some text"})


def test_invalid_confidence_value_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"confidence": "Definitely", "exact_text": "x"})


def test_not_found_with_exact_text_raises():
    """A model claiming Not Found but still supplying text is a contract violation — not silently accepted."""
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload(
            {"confidence": "Not Found", "exact_text": "some text anyway", "remarks": "explanation"}
        )


def test_high_confidence_without_exact_text_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"confidence": "High", "exact_text": None})


def test_high_confidence_with_blank_exact_text_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"confidence": "High", "exact_text": "   "})


@pytest.mark.parametrize("confidence", ["Medium", "Low", "Not Found"])
def test_remarks_required_for_non_high_confidence(confidence):
    payload = {"confidence": confidence, "exact_text": "some text" if confidence != "Not Found" else None}
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload(payload)


def test_source_retrieval_id_must_reference_supplied_evidence():
    """The model must not be able to cite evidence it was never given — a hallucinated retrieval_id is rejected."""
    payload = {
        "exact_text": "some text",
        "confidence": "High",
        "source_retrieval_id": "made-up-id",
    }
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload(payload, valid_retrieval_ids={"req-1:1", "req-1:2"})


def test_not_found_with_source_retrieval_id_raises():
    payload = {"confidence": "Not Found", "exact_text": None, "remarks": "nothing found", "source_retrieval_id": "req-1:1"}
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload(payload, valid_retrieval_ids={"req-1:1"})


def test_non_not_found_requires_source_retrieval_id_when_ids_known():
    payload = {"exact_text": "some text", "confidence": "High", "remarks": None, "source_retrieval_id": None}
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload(payload, valid_retrieval_ids={"req-1:1"})


def test_exact_text_wrong_type_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"confidence": "High", "exact_text": 12345})


def test_remarks_wrong_type_raises():
    with pytest.raises(ExtractionSchemaError):
        validate_extraction_payload({"confidence": "High", "exact_text": "x", "remarks": 999})


# --------------------------------------------------------------------------
# parse_and_validate (combined)
# --------------------------------------------------------------------------


def test_parse_and_validate_end_to_end():
    raw = (
        '```json\n'
        '{"exact_text": "We believe technology should serve everyone.", '
        '"confidence": "High", "remarks": null, "source_retrieval_id": "req-9:2"}\n'
        '```'
    )
    result = parse_and_validate(raw, valid_retrieval_ids={"req-9:2"})
    assert result["confidence"] == "High"
    assert result["source_retrieval_id"] == "req-9:2"


def test_parse_and_validate_propagates_parse_error():
    with pytest.raises(InvalidLLMResponseError):
        parse_and_validate("this is not json at all")


def test_parse_and_validate_propagates_schema_error():
    with pytest.raises(ExtractionSchemaError):
        parse_and_validate('{"confidence": "Somewhat"}')
