"""
Tests for src/discovery/sitemap_crawler.py.

All network calls are mocked via `monkeypatch` on `http_client.get`, same
pattern as tests/test_sec_edgar_client.py.
"""

from src.core.constants import DiscoveryMethod, DocumentCategory
from src.discovery import http_client, sitemap_crawler
from src.discovery.http_client import FetchResult

FAKE_SITEMAP_XML = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://apple.com/sustainability/2024-report.pdf</loc></url>
  <url><loc>https://apple.com/careers/openings</loc></url>
  <url><loc>https://apple.com/investor-relations/default.aspx</loc></url>
  <url><loc>https://apple.com/code-of-conduct.pdf</loc></url>
</urlset>
"""

MALFORMED_SITEMAP_XML = "<urlset><url><loc>not closed properly"


def _mock_get(url_to_response: dict[str, FetchResult]):
    def _get(url: str) -> FetchResult:
        if url in url_to_response:
            return url_to_response[url]
        return FetchResult(ok=False, url=url, reason="not mocked / 404")

    return _get


# --------------------------------------------------------------------------
# Sitemap parsing
# --------------------------------------------------------------------------


def test_discover_via_sitemap_keeps_only_classifiable_urls(monkeypatch):
    monkeypatch.setattr(
        http_client,
        "get",
        _mock_get({"https://apple.com/sitemap.xml": FetchResult(ok=True, url="x", status_code=200, text=FAKE_SITEMAP_XML)}),
    )

    candidates = sitemap_crawler.discover_via_sitemap("apple.com", "Apple Inc.")

    # 4 URLs in the sitemap, but "/careers/openings" doesn't match any
    # known category — it should be silently dropped, not included as
    # UNKNOWN.
    assert len(candidates) == 3
    categories = {c.document_category for c in candidates}
    assert categories == {
        DocumentCategory.SUSTAINABILITY_REPORT,
        DocumentCategory.INVESTOR_RELATIONS,
        DocumentCategory.CODE_OF_CONDUCT,
    }
    assert all(c.discovery_method == DiscoveryMethod.SITEMAP_CRAWL for c in candidates)


def test_discover_via_sitemap_returns_empty_when_sitemap_missing(monkeypatch):
    monkeypatch.setattr(http_client, "get", _mock_get({}))  # every URL 404s
    candidates = sitemap_crawler.discover_via_sitemap("apple.com", "Apple Inc.")
    assert candidates == []


def test_discover_via_sitemap_returns_empty_on_malformed_xml(monkeypatch):
    monkeypatch.setattr(
        http_client,
        "get",
        _mock_get({"https://apple.com/sitemap.xml": FetchResult(ok=True, url="x", status_code=200, text=MALFORMED_SITEMAP_XML)}),
    )
    candidates = sitemap_crawler.discover_via_sitemap("apple.com", "Apple Inc.")
    assert candidates == []  # graceful degradation, not an exception


def test_discover_via_sitemap_prepends_scheme_when_website_has_none(monkeypatch):
    calls = []

    def _get(url):
        calls.append(url)
        return FetchResult(ok=False, url=url, reason="404")

    monkeypatch.setattr(http_client, "get", _get)
    sitemap_crawler.discover_via_sitemap("apple.com", "Apple Inc.")
    assert calls == ["https://apple.com/sitemap.xml"]


# --------------------------------------------------------------------------
# Heuristic path probing
# --------------------------------------------------------------------------


def test_heuristic_probe_only_keeps_paths_that_respond_200(monkeypatch):
    responses = {
        "https://apple.com/sustainability": FetchResult(
            ok=True, url="x", status_code=200, text="<html>sustainability page</html>"
        ),
        # every other candidate path 404s implicitly via _mock_get's default
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_via_heuristic_probe("apple.com", "Apple Inc.")

    assert len(candidates) == 1
    assert candidates[0].document_category == DocumentCategory.SUSTAINABILITY_REPORT
    assert candidates[0].discovery_method == DiscoveryMethod.HEURISTIC_PROBE


def test_heuristic_probe_returns_empty_when_nothing_responds(monkeypatch):
    monkeypatch.setattr(http_client, "get", _mock_get({}))
    candidates = sitemap_crawler.discover_via_heuristic_probe("apple.com", "Apple Inc.")
    assert candidates == []


def test_heuristic_probe_assigns_known_category_without_reclassifying(monkeypatch):
    """
    Regression test: /business-conduct was already listed under
    CODE_OF_CONDUCT before this change, but classify_category
    ("/business-conduct") returns UNKNOWN — no keyword matches — so the
    OLD code (which re-classified every heuristic hit by keyword) would
    silently drop this candidate even on a 200 response. Heuristic
    probing now assigns the category directly from the dict key it came
    from, so this must be correctly tagged CODE_OF_CONDUCT.
    """
    responses = {
        "https://apple.com/business-conduct": FetchResult(ok=True, url="x", status_code=200, text="<html/>"),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_via_heuristic_probe("apple.com", "Apple Inc.")

    assert len(candidates) == 1
    assert candidates[0].document_category == DocumentCategory.CODE_OF_CONDUCT
    assert candidates[0].official_url == "https://apple.com/business-conduct"


def test_heuristic_probe_includes_subdomain_candidates(monkeypatch):
    """A conventional subdomain root (e.g. investor.apple.com) that responds 200 is discovered."""
    responses = {
        "https://investor.apple.com/": FetchResult(ok=True, url="x", status_code=200, text="<html/>"),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_via_heuristic_probe("apple.com", "Apple Inc.")

    assert len(candidates) == 1
    assert candidates[0].document_category == DocumentCategory.INVESTOR_RELATIONS
    assert candidates[0].official_url == "https://investor.apple.com/"
    assert candidates[0].discovery_method == DiscoveryMethod.HEURISTIC_PROBE


def test_heuristic_probe_subdomain_uses_bare_domain_even_with_www_prefix(monkeypatch):
    """The subdomain probe must use the bare registrable domain (apple.com), not www.apple.com."""
    calls = []

    def _get(url):
        calls.append(url)
        return FetchResult(ok=False, url=url, reason="404")

    monkeypatch.setattr(http_client, "get", _get)
    sitemap_crawler.discover_via_heuristic_probe("https://www.apple.com", "Apple Inc.")

    assert "https://investor.apple.com/" in calls
    assert "https://investor.www.apple.com/" not in calls


# --------------------------------------------------------------------------
# Top-level entry point: sitemap-first, heuristic fallback
# --------------------------------------------------------------------------


def test_discover_web_documents_uses_sitemap_results_when_available(monkeypatch):
    # No heuristic paths are mocked here, so they all 404 by default —
    # this isolates "does sitemap discovery work" from the merge behavior,
    # which gets its own dedicated test below.
    monkeypatch.setattr(
        http_client,
        "get",
        _mock_get({"https://apple.com/sitemap.xml": FetchResult(ok=True, url="x", status_code=200, text=FAKE_SITEMAP_XML)}),
    )
    candidates = sitemap_crawler.discover_web_documents("apple.com", "Apple Inc.")
    assert len(candidates) == 3
    assert all(c.discovery_method == DiscoveryMethod.SITEMAP_CRAWL for c in candidates)


def test_discover_web_documents_uses_heuristic_results_when_sitemap_is_empty(monkeypatch):
    responses = {
        # sitemap.xml itself 404s -> heuristic probing is the only source of results
        "https://apple.com/sustainability": FetchResult(ok=True, url="x", status_code=200, text="<html/>"),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_web_documents("apple.com", "Apple Inc.")
    assert len(candidates) == 1
    assert candidates[0].discovery_method == DiscoveryMethod.HEURISTIC_PROBE


def test_discover_web_documents_merges_sitemap_and_heuristic_even_when_sitemap_is_nonempty(monkeypatch):
    """
    Regression test for a real gap found during live testing against
    apple.com: the sitemap returned exactly one relevant match (an About
    Us page), and — under the OLD "sitemap found something, skip
    heuristic" logic — Sustainability/Code of Conduct/Investor Relations
    pages that only the heuristic probe would find were silently missed.

    This test constructs exactly that shape: a NON-EMPTY sitemap result
    plus a heuristic-only page, and asserts both end up in the final
    merged output.
    """
    thin_sitemap = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://apple.com/about-us</loc></url>
</urlset>
"""
    responses = {
        "https://apple.com/sitemap.xml": FetchResult(ok=True, url="x", status_code=200, text=thin_sitemap),
        # Only findable via heuristic probing — absent from the thin sitemap above.
        "https://apple.com/sustainability": FetchResult(ok=True, url="x", status_code=200, text="<html/>"),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_web_documents("apple.com", "Apple Inc.")

    categories = {c.document_category for c in candidates}
    methods = {c.document_category: c.discovery_method for c in candidates}
    assert categories == {DocumentCategory.ABOUT_US, DocumentCategory.SUSTAINABILITY_REPORT}
    assert methods[DocumentCategory.ABOUT_US] == DiscoveryMethod.SITEMAP_CRAWL
    assert methods[DocumentCategory.SUSTAINABILITY_REPORT] == DiscoveryMethod.HEURISTIC_PROBE


def test_discover_web_documents_dedupes_when_both_strategies_find_the_same_url(monkeypatch):
    # If the sitemap ALSO lists a URL the heuristic probe would separately
    # find, it must appear exactly once in the merged output — and the
    # sitemap version wins (see discover_web_documents docstring for why).
    sitemap_with_sustainability = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://apple.com/sustainability</loc></url>
</urlset>
"""
    responses = {
        "https://apple.com/sitemap.xml": FetchResult(ok=True, url="x", status_code=200, text=sitemap_with_sustainability),
        "https://apple.com/sustainability": FetchResult(ok=True, url="x", status_code=200, text="<html/>"),
    }
    monkeypatch.setattr(http_client, "get", _mock_get(responses))

    candidates = sitemap_crawler.discover_web_documents("apple.com", "Apple Inc.")
    assert len(candidates) == 1
    assert candidates[0].discovery_method == DiscoveryMethod.SITEMAP_CRAWL


def test_discover_web_documents_returns_empty_with_no_website(monkeypatch):
    calls = []
    monkeypatch.setattr(http_client, "get", lambda url: calls.append(url) or FetchResult(ok=False, url=url))
    candidates = sitemap_crawler.discover_web_documents(None, "Some Private Co.")
    assert candidates == []
    assert calls == []  # no website registered -> nothing to crawl, no network call at all
