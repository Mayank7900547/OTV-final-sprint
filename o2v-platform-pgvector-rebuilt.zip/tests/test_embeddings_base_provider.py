"""Unit tests for `src/embeddings/base_embedding_provider.py`, using a fake in-memory provider (no network)."""

import pytest

from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.exceptions import DimensionMismatchError, InvalidProviderResponseError


class _FakeProvider(BaseEmbeddingProvider):
    """Deterministic fake — returns a fixed-length vector of `[len(text)] * dimension` per input."""

    provider_name = "fake"

    def embed_batch(self, texts):
        return [[float(len(t))] * self.embedding_dimension for t in texts]


def _provider(dimension=4) -> _FakeProvider:
    return _FakeProvider(model_name="fake-model", model_version="1", embedding_dimension=dimension)


def test_embed_batch_returns_one_vector_per_text():
    provider = _provider()
    vectors = provider.embed_batch(["hello", "world!"])
    assert len(vectors) == 2
    assert all(len(v) == 4 for v in vectors)


def test_embed_single_returns_one_vector():
    provider = _provider()
    vector = provider.embed_single("hello")
    assert len(vector) == 4
    assert vector == [5.0, 5.0, 5.0, 5.0]


def test_validate_dimension_passes_for_matching_vector():
    provider = _provider(dimension=3)
    provider.validate_dimension([0.1, 0.2, 0.3])  # should not raise


def test_validate_dimension_raises_for_mismatched_vector():
    provider = _provider(dimension=3)
    with pytest.raises(DimensionMismatchError):
        provider.validate_dimension([0.1, 0.2])


def test_validate_batch_response_passes_for_correct_shape():
    provider = _provider(dimension=2)
    texts = ["a", "bb"]
    vectors = [[1.0, 2.0], [3.0, 4.0]]
    provider.validate_batch_response(texts, vectors)  # should not raise


def test_validate_batch_response_raises_on_length_mismatch():
    provider = _provider(dimension=2)
    with pytest.raises(InvalidProviderResponseError):
        provider.validate_batch_response(["a", "b", "c"], [[1.0, 2.0], [3.0, 4.0]])


def test_validate_batch_response_raises_on_empty_vector():
    provider = _provider(dimension=2)
    with pytest.raises(InvalidProviderResponseError):
        provider.validate_batch_response(["a"], [[]])


def test_validate_batch_response_raises_on_dimension_mismatch_within_batch():
    provider = _provider(dimension=2)
    with pytest.raises(DimensionMismatchError):
        provider.validate_batch_response(["a"], [[1.0, 2.0, 3.0]])


def test_provider_stores_model_name_version_and_dimension():
    provider = _FakeProvider(model_name="my-model", model_version="7", embedding_dimension=10)
    assert provider.model_name == "my-model"
    assert provider.model_version == "7"
    assert provider.embedding_dimension == 10
