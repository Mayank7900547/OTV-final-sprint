"""
Tests for src/acquisition/file_manager.py.

`file_manager.py` creates a module-level `storage_backend` singleton
bound to the REAL project `DATA_DIR` at import time. Tests must never let
that singleton touch the real `data/` directory on disk, so every test
that exercises storage-backed methods (`archive_existing_file`,
`promote_staging_to_raw`) monkeypatches the module-level `storage_backend`
to a fresh `LocalDiskStorageBackend` rooted at `tmp_path` instead.
"""

import pytest

from src.acquisition import file_manager
from src.acquisition.exceptions import StorageError
from src.acquisition.file_manager import EnterpriseFileManager
from src.acquisition.storage import LocalDiskStorageBackend


@pytest.fixture(autouse=True)
def _isolated_storage_backend(tmp_path, monkeypatch):
    """Redirect the module-level storage_backend singleton to a tmp dir for every test."""
    test_backend = LocalDiskStorageBackend(tmp_path / "data")
    monkeypatch.setattr(file_manager, "storage_backend", test_backend)
    return test_backend


@pytest.fixture(autouse=True)
def _isolated_staging_dir(tmp_path, monkeypatch):
    """Redirect STAGING_DIR so get_staging_path never touches the real project dir."""
    monkeypatch.setattr(file_manager, "STAGING_DIR", tmp_path / "staging")


# ---------------------------------------------------------------------------
# get_raw_target_key
# ---------------------------------------------------------------------------


def test_get_raw_target_key_builds_expected_layout():
    key = EnterpriseFileManager.get_raw_target_key("Acme Corp", 2024, "annual_report")
    assert key == "raw/Acme_Corp/2024/annual_report.pdf"


def test_get_raw_target_key_appends_pdf_extension_only_if_missing():
    key = EnterpriseFileManager.get_raw_target_key("Acme", 2024, "report.pdf")
    assert key == "raw/Acme/2024/report.pdf"
    assert not key.endswith(".pdf.pdf")


def test_get_raw_target_key_uses_undated_when_year_is_none():
    key = EnterpriseFileManager.get_raw_target_key("Acme", None, "report")
    assert key == "raw/Acme/undated/report.pdf"


def test_get_raw_target_key_strips_unsafe_characters_from_company_and_filename():
    key = EnterpriseFileManager.get_raw_target_key(
        "Acme/Corp <script>&Co.", 2024, "report:../../etc/passwd"
    )
    # Only alnum, space, underscore, hyphen survive from company; spaces -> underscores.
    company_segment = key.split("raw/")[1].split("/2024/")[0]
    assert "/" not in company_segment
    assert "<" not in key and ">" not in key and "&" not in key
    # The filename component keeps dots (a legitimate character, e.g.
    # "10-K.pdf") but strips "/" and ":" — so no traversal is possible even
    # though literal ".." characters can remain, since there's no path
    # separator left for them to act as a directory-traversal segment.
    filename_segment = key.rsplit("/", 1)[-1]
    assert "/" not in filename_segment
    assert ":" not in filename_segment


def test_get_raw_target_key_collapses_spaces_to_underscores_in_company():
    key = EnterpriseFileManager.get_raw_target_key("Big Company Name", 2024, "doc")
    assert "raw/Big_Company_Name/2024/doc.pdf" == key


def test_get_raw_target_key_is_case_and_content_stable_for_dedup_paths():
    # Same inputs -> same key, which matters because this key doubles as
    # the on-disk identity documents land at.
    k1 = EnterpriseFileManager.get_raw_target_key("Acme", 2024, "10-K")
    k2 = EnterpriseFileManager.get_raw_target_key("Acme", 2024, "10-K")
    assert k1 == k2


# ---------------------------------------------------------------------------
# get_staging_path
# ---------------------------------------------------------------------------


def test_get_staging_path_creates_parent_directory(tmp_path):
    path = EnterpriseFileManager.get_staging_path("doc-123")
    assert path.parent.exists()


def test_get_staging_path_includes_document_id_and_part_suffix():
    path = EnterpriseFileManager.get_staging_path("abc-123")
    assert "doc_abc-123_" in path.name
    assert path.name.endswith(".part")


def test_get_staging_path_is_unique_per_call():
    import time

    p1 = EnterpriseFileManager.get_staging_path("same-id")
    time.sleep(0.01)  # ensure the timestamp suffix actually advances between calls
    p2 = EnterpriseFileManager.get_staging_path("same-id")
    # Timestamp-suffixed, so two calls for the same doc id shouldn't collide.
    assert p1 != p2


# ---------------------------------------------------------------------------
# archive_existing_file
# ---------------------------------------------------------------------------


def test_archive_existing_file_raises_when_source_missing(tmp_path):
    with pytest.raises(StorageError):
        EnterpriseFileManager.archive_existing_file(
            str(tmp_path / "nonexistent.pdf"), "Acme", 2024, 1
        )


def test_archive_existing_file_moves_file_into_archive_namespace(tmp_path, _isolated_storage_backend):
    existing = tmp_path / "existing_version.pdf"
    existing.write_bytes(b"old-version-content")

    archived_dest = EnterpriseFileManager.archive_existing_file(str(existing), "Acme", 2024, 1)

    from pathlib import Path

    assert not existing.exists()  # moved away from its original location
    assert Path(archived_dest).exists()
    assert Path(archived_dest).read_bytes() == b"old-version-content"
    assert "archive/Acme/2024/" in archived_dest.replace("\\", "/")
    assert "_v1_" in Path(archived_dest).name


def test_archive_existing_file_uses_undated_when_year_missing(tmp_path):
    existing = tmp_path / "existing.pdf"
    existing.write_bytes(b"content")
    archived_dest = EnterpriseFileManager.archive_existing_file(str(existing), "Acme", None, 3)
    assert "archive/Acme/undated/" in archived_dest.replace("\\", "/")
    assert "_v3_" in archived_dest


# ---------------------------------------------------------------------------
# promote_staging_to_raw
# ---------------------------------------------------------------------------


def test_promote_staging_to_raw_moves_file_to_target_key(tmp_path):
    staging_file = tmp_path / "staged_download.part"
    staging_file.write_bytes(b"downloaded-pdf-bytes")

    target_key = EnterpriseFileManager.get_raw_target_key("Acme", 2024, "annual_report")
    final_path = EnterpriseFileManager.promote_staging_to_raw(staging_file, target_key)

    from pathlib import Path

    assert not staging_file.exists()
    assert Path(final_path).read_bytes() == b"downloaded-pdf-bytes"
    assert final_path.replace("\\", "/").endswith("raw/Acme/2024/annual_report.pdf")