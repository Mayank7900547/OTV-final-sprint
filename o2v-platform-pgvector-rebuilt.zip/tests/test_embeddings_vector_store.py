"""
Integration tests for `src/embeddings/vector_store.py`'s `PostgresVectorStore`
and the factory registry. Requires a real Postgres test database — skipped
automatically if unreachable, same as `test_chunking_service.py`.
"""

from __future__ import annotations

import uuid

import pytest

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.chunking.models import Chunk
from src.core.constants import DocumentCategory, DocumentStatus, DocumentType
from src.embeddings.exceptions import VectorStorageError
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.vector_store import (
    PostgresVectorStore,
    available_vector_stores,
    get_vector_store,
)
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum

# Import so the tables register on Base.metadata, same requirement as conftest.py.
from src.embeddings import models as _embeddings_models_module  # noqa: F401


def _make_scenario(session, tmp_path, *, company_name="Vector Test Co"):
    company = Company(name=company_name, status="pending")
    session.add(company)
    session.flush()

    document = DocumentRegistry(
        company_id=company.id,
        document_name="Annual Report",
        document_category=DocumentCategory.ANNUAL_REPORT.value,
        document_type=DocumentType.PDF.value,
        document_year=2024,
        official_url=f"https://vectest.com/{uuid.uuid4()}.pdf",
        source_domain="vectest.com",
        discovery_method="sitemap_crawl",
        status=DocumentStatus.DISCOVERED.value,
    )
    session.add(document)
    session.flush()

    path = tmp_path / "report.pdf"
    path.write_bytes(b"%PDF-1.4 fake")
    version = DocumentVersion(
        document_id=document.id, version_number=1, file_hash="c" * 64,
        storage_path=str(path), file_size=path.stat().st_size, status=DocumentVersionStatusEnum.ACTIVE,
    )
    session.add(version)
    session.flush()

    parsed = ParsedDocument(
        document_id=document.id, document_version_id=version.id, parser_used="pdf_parser", parser_version="1.0.0",
        document_type=DocumentType.PDF.value, page_count=1, raw_text="Some text.",
        page_text=[{"page_number": 1, "text": "Some text."}], character_count=10, status=ParsingStatusEnum.SUCCESS,
    )
    session.add(parsed)
    session.flush()

    chunk = Chunk(
        chunk_id=f"{version.id}:0", document_id=document.id, document_version_id=version.id,
        parsed_document_id=parsed.id, chunk_index=0, page_number=1, section_title=None,
        text="Some text.", character_count=10, token_estimate=3,
        chunker_used="recursive_chunker", chunker_version="1.0.0",
    )
    session.add(chunk)
    session.flush()

    return company, document, chunk


def _embedding_row(chunk, *, dimension=4, status=EmbeddingStatusEnum.ACTIVE):
    return Embedding(
        embedding_id=f"{chunk.id}:fake:model:1",
        chunk_id=chunk.id,
        document_id=chunk.document_id,
        provider="fake",
        model_name="model",
        model_version="1",
        embedding_dimension=dimension,
        status=status,
        is_active=(status == EmbeddingStatusEnum.ACTIVE),
        vector_store_backend="postgres",
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def test_available_vector_stores_includes_postgres_and_placeholders():
    backends = available_vector_stores()
    for expected in ["postgres", "chromadb", "faiss", "qdrant", "pinecone", "weaviate", "milvus"]:
        assert expected in backends


def test_get_vector_store_unknown_backend_raises(db_session):
    with pytest.raises(VectorStorageError):
        get_vector_store("not_a_real_backend", session=db_session)


def test_get_vector_store_postgres_returns_postgres_vector_store(db_session):
    store = get_vector_store("postgres", session=db_session)
    assert isinstance(store, PostgresVectorStore)


# ---------------------------------------------------------------------------
# PostgresVectorStore CRUD
# ---------------------------------------------------------------------------


def test_insert_vector_persists_vector_and_metadata(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    vector = [0.1, 0.2, 0.3, 0.4]
    metadata = {"company": "Vector Test Co", "chunk_id": chunk.chunk_id}
    store.insert_vector(embedding_row=row, vector=vector, metadata=metadata)
    db_session.flush()

    fetched = store.get_vector(row.id)
    assert fetched == vector
    assert row.embedding_metadata == metadata
    assert row.vector_store_backend == "postgres"


def test_get_vector_returns_none_for_unknown_id(db_session):
    store = PostgresVectorStore(session=db_session)
    assert store.get_vector(999_999_999) is None


def test_update_vector_replaces_existing_vector_and_metadata(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"a": 1})
    db_session.flush()

    store.update_vector(row.id, vector=[9.0, 9.0, 9.0, 9.0], metadata={"a": 2})

    assert store.get_vector(row.id) == [9.0, 9.0, 9.0, 9.0]
    assert row.embedding_metadata == {"a": 2}


def test_update_vector_unknown_id_raises_vector_storage_error(db_session):
    store = PostgresVectorStore(session=db_session)
    with pytest.raises(VectorStorageError):
        store.update_vector(999_999_999, vector=[1.0], metadata={})


def test_delete_vector_clears_stored_vector(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={})
    db_session.flush()

    store.delete_vector(row.id)
    assert store.get_vector(row.id) is None


def test_delete_vector_unknown_id_is_a_no_op(db_session):
    store = PostgresVectorStore(session=db_session)
    store.delete_vector(999_999_999)  # should not raise


def test_filter_by_metadata_matches_active_embeddings_with_matching_field(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"company": "Vector Test Co"})
    db_session.flush()

    matches = store.filter_by_metadata({"company": "Vector Test Co"})
    assert row.id in matches


def test_filter_by_metadata_excludes_superseded_embeddings(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk, status=EmbeddingStatusEnum.SUPERSEDED)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 2.0, 3.0, 4.0], metadata={"company": "Vector Test Co"})
    db_session.flush()

    matches = store.filter_by_metadata({"company": "Vector Test Co"})
    assert row.id not in matches


# ---------------------------------------------------------------------------
# similarity_search — real implementation as of Sprint 7 (see
# src/embeddings/vector_store.py's module docstring: this was always the
# anticipated override point). The base-class stub is still exercised by
# every OTHER vector store backend, which don't override it — see
# test_retrieval_semantic_search.py / test_retrieval_service.py for
# PostgresVectorStore.similarity_search's real behavior in context.
# ---------------------------------------------------------------------------


def test_similarity_search_returns_ranked_matches_by_cosine_similarity(db_session, tmp_path):
    _, _, chunk_a = _make_scenario(db_session, tmp_path, company_name="Sim Test Co A")
    row_a = _embedding_row(chunk_a, dimension=3)
    db_session.add(row_a)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row_a, vector=[1.0, 0.0, 0.0], metadata={"company": "Sim Test Co A"})
    db_session.flush()

    results = store.similarity_search([1.0, 0.0, 0.0], top_k=5)

    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk_a.id
    assert results[0]["score"] == pytest.approx(1.0, abs=1e-6)


def test_similarity_search_skips_dimension_mismatched_vectors(db_session, tmp_path):
    _, _, chunk = _make_scenario(db_session, tmp_path)
    row = _embedding_row(chunk, dimension=3)
    db_session.add(row)
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row, vector=[1.0, 0.0, 0.0], metadata={})
    db_session.flush()

    # Query vector has a different dimension -- should be silently skipped, not error.
    results = store.similarity_search([1.0, 0.0], top_k=5)
    assert results == []


def test_similarity_search_respects_top_k(db_session, tmp_path):
    _, _, chunk1 = _make_scenario(db_session, tmp_path, company_name="TopK Co 1")
    _, _, chunk2 = _make_scenario(db_session, tmp_path, company_name="TopK Co 2")
    row1 = _embedding_row(chunk1, dimension=2)
    row2 = _embedding_row(chunk2, dimension=2)
    db_session.add_all([row1, row2])
    db_session.flush()

    store = PostgresVectorStore(session=db_session)
    store.insert_vector(embedding_row=row1, vector=[1.0, 0.0], metadata={})
    store.insert_vector(embedding_row=row2, vector=[0.0, 1.0], metadata={})
    db_session.flush()

    results = store.similarity_search([1.0, 0.0], top_k=1)
    assert len(results) == 1
    assert results[0]["chunk_id"] == chunk1.id  # closer match ranked first
