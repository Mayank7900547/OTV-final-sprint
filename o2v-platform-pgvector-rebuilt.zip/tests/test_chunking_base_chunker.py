"""Unit tests for `src/chunking/base_chunker.py`."""

import pytest

from src.chunking.base_chunker import BaseChunker, ChunkCandidate, ChunkerConfig, TextBlock
from src.chunking.exceptions import ChunkerConfigurationError


# ---------------------------------------------------------------------------
# ChunkerConfig validation
# ---------------------------------------------------------------------------


def test_default_config_is_valid():
    config = ChunkerConfig()
    assert config.chunk_size == 1000
    assert config.chunk_overlap == 150


def test_config_rejects_non_positive_chunk_size():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(chunk_size=0)


def test_config_rejects_negative_overlap():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(chunk_overlap=-1)


def test_config_rejects_overlap_greater_than_or_equal_to_chunk_size():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(chunk_size=100, chunk_overlap=100)


def test_config_rejects_max_chunk_size_smaller_than_chunk_size():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(chunk_size=1000, max_chunk_size=500)


def test_config_rejects_min_chunk_size_greater_than_chunk_size():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(chunk_size=100, min_chunk_size=200)


def test_config_rejects_non_positive_min_chunk_size():
    with pytest.raises(ChunkerConfigurationError):
        ChunkerConfig(min_chunk_size=0)


# ---------------------------------------------------------------------------
# ChunkCandidate
# ---------------------------------------------------------------------------


def test_chunk_candidate_character_count_matches_text_length():
    candidate = ChunkCandidate(text="hello world", page_number=1, section_title=None)
    assert candidate.character_count == 11


# ---------------------------------------------------------------------------
# BaseChunker.chunk() — shared metadata propagation
# ---------------------------------------------------------------------------


class _StubChunker(BaseChunker):
    """A minimal concrete chunker used only to exercise the base class's shared behavior."""

    chunker_name = "stub_chunker"

    def split_blocks(self, blocks, *, config):
        return [
            ChunkCandidate(text=block.text, page_number=block.page_number, section_title=block.section_title)
            for block in blocks
        ]


def test_chunk_assigns_sequential_chunk_index():
    chunker = _StubChunker()
    blocks = [
        TextBlock(text="first", page_number=1, section_title=None),
        TextBlock(text="second", page_number=1, section_title=None),
        TextBlock(text="third", page_number=2, section_title=None),
    ]
    candidates = chunker.chunk(blocks, config=ChunkerConfig())

    assert [c.chunk_index for c in candidates] == [0, 1, 2]


def test_chunk_with_no_blocks_returns_empty_list():
    chunker = _StubChunker()
    assert chunker.chunk([], config=ChunkerConfig()) == []
