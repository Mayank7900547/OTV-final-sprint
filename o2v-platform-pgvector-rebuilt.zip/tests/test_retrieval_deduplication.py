"""Unit tests for `src/retrieval/deduplication.py`."""

from src.retrieval.deduplication import drop_near_duplicate_text, merge_by_chunk_id
from src.retrieval.types import EvidenceCandidate


def _candidate(chunk_id, text="Some unique text.", **overrides) -> EvidenceCandidate:
    base = dict(
        chunk_id=chunk_id, document_id="doc-1", company_id="co-1", page_number=1,
        section_title="Overview", document_type="Annual Report", chunk_text=text,
    )
    base.update(overrides)
    return EvidenceCandidate(**base)


# ---------------------------------------------------------------------------
# merge_by_chunk_id
# ---------------------------------------------------------------------------


def test_merge_by_chunk_id_combines_lists_without_duplicates():
    list_a = [_candidate(1), _candidate(2)]
    list_b = [_candidate(3)]
    merged = merge_by_chunk_id([list_a, list_b])
    assert {c.chunk_id for c in merged} == {1, 2, 3}


def test_merge_by_chunk_id_keeps_max_score_when_chunk_appears_in_multiple_queries():
    candidate_weak = _candidate(1, semantic_score=0.2, matched_queries=["Mission Statement"])
    candidate_strong = _candidate(1, semantic_score=0.9, matched_queries=["Purpose Statement"])
    merged = merge_by_chunk_id([[candidate_weak], [candidate_strong]])
    assert len(merged) == 1
    assert merged[0].semantic_score == 0.9


def test_merge_by_chunk_id_unions_matched_queries():
    candidate_a = _candidate(1, matched_queries=["Mission Statement"])
    candidate_b = _candidate(1, matched_queries=["Purpose Statement"])
    merged = merge_by_chunk_id([[candidate_a], [candidate_b]])
    assert set(merged[0].matched_queries) == {"Mission Statement", "Purpose Statement"}


def test_merge_by_chunk_id_keeps_max_metadata_score():
    candidate_a = _candidate(1, metadata_score=0.4)
    candidate_b = _candidate(1, metadata_score=1.0)
    merged = merge_by_chunk_id([[candidate_a], [candidate_b]])
    assert merged[0].metadata_score == 1.0


def test_merge_by_chunk_id_empty_input_returns_empty_list():
    assert merge_by_chunk_id([]) == []
    assert merge_by_chunk_id([[], []]) == []


# ---------------------------------------------------------------------------
# drop_near_duplicate_text
# ---------------------------------------------------------------------------


def test_drop_near_duplicate_text_removes_exact_duplicate_after_normalization():
    candidates = [
        _candidate(1, text="Our purpose is to help small businesses grow."),
        _candidate(2, text="  Our   purpose is to help small businesses grow.  "),
    ]
    kept = drop_near_duplicate_text(candidates)
    assert len(kept) == 1
    assert kept[0].chunk_id == 1  # first occurrence kept


def test_drop_near_duplicate_text_keeps_distinct_text():
    candidates = [
        _candidate(1, text="Our purpose is to help small businesses grow."),
        _candidate(2, text="Our behaviour reflects our commitment to integrity."),
    ]
    kept = drop_near_duplicate_text(candidates)
    assert len(kept) == 2


def test_drop_near_duplicate_text_case_insensitive():
    candidates = [_candidate(1, text="OUR PURPOSE"), _candidate(2, text="our purpose")]
    kept = drop_near_duplicate_text(candidates)
    assert len(kept) == 1


def test_drop_near_duplicate_text_empty_list_returns_empty():
    assert drop_near_duplicate_text([]) == []
