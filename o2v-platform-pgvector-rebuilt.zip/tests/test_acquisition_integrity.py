"""
Tests for src/acquisition/integrity.py.

`validate_document_integrity` is intentionally a cheap, structural check
per format (size bounds always; PDF gets magic bytes + EOF marker; HTML
gets an opening-tag sniff), not a full parse — Sprint 4's own
`html_parser.py`/PDF parser already own the real parse job downstream.
These tests exercise every branch of that structural check plus the
SHA-256 hashing helper it's paired with for dedup-by-hash in service.py.

`validate_pdf_integrity` (the original PDF-only method, kept as a
backward-compatible alias — see integrity.py's docstring) is tested
separately, at the bottom of this file, to confirm it still behaves
exactly as it did before this file started also accepting HTML.
"""

import pytest

from src.acquisition.integrity import FileIntegrityValidator
from src.config.settings import settings


def _write(path, data: bytes):
    path.write_bytes(data)
    return path


def _valid_pdf_bytes(padding: int = 0) -> bytes:
    # Real PDFs have more structure, but the validator only looks for the
    # leading magic bytes and a trailing %%EOF marker within the last 1KB —
    # see integrity.py's docstring-free but explicit implementation.
    body = b"%PDF-1.4\n" + (b"x" * padding) + b"\n%%EOF"
    return body


def _valid_html_bytes(padding: int = 0) -> bytes:
    return b"<html><head></head><body>" + (b"x" * padding) + b"</body></html>"


# ---------------------------------------------------------------------------
# calculate_sha256
# ---------------------------------------------------------------------------


def test_calculate_sha256_matches_known_digest(tmp_path):
    import hashlib

    content = b"the quick brown fox jumps over the lazy dog"
    f = _write(tmp_path / "sample.txt", content)
    expected = hashlib.sha256(content).hexdigest()
    assert FileIntegrityValidator.calculate_sha256(f) == expected


def test_calculate_sha256_is_deterministic_across_calls(tmp_path):
    f = _write(tmp_path / "sample.bin", b"\x00\x01\x02" * 1000)
    assert FileIntegrityValidator.calculate_sha256(f) == FileIntegrityValidator.calculate_sha256(f)


def test_calculate_sha256_differs_for_different_content(tmp_path):
    f1 = _write(tmp_path / "a.bin", b"aaaa")
    f2 = _write(tmp_path / "b.bin", b"bbbb")
    assert FileIntegrityValidator.calculate_sha256(f1) != FileIntegrityValidator.calculate_sha256(f2)


def test_calculate_sha256_handles_file_larger_than_chunk_size(tmp_path):
    # Forces the while-loop in calculate_sha256 to iterate multiple times
    # rather than reading everything in one chunk.
    f = _write(tmp_path / "big.bin", b"z" * 200_000)
    import hashlib

    expected = hashlib.sha256(b"z" * 200_000).hexdigest()
    assert FileIntegrityValidator.calculate_sha256(f, chunk_size=8192) == expected


# ---------------------------------------------------------------------------
# validate_document_integrity — existence / size bounds (format-independent)
# ---------------------------------------------------------------------------


def test_validate_rejects_nonexistent_file(tmp_path):
    missing = tmp_path / "does_not_exist.pdf"
    ok, reason = FileIntegrityValidator.validate_document_integrity(missing, document_type="pdf")
    assert ok is False
    assert "does not exist" in reason.lower()


def test_validate_rejects_file_below_min_size(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 1024)
    f = _write(tmp_path / "tiny.pdf", _valid_pdf_bytes(padding=0))  # well under 1024 bytes
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "below threshold" in reason.lower()


def test_validate_rejects_file_above_max_size(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 100)
    f = _write(tmp_path / "huge.pdf", _valid_pdf_bytes(padding=1000))
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "exceeds maximum" in reason.lower()


def test_validate_accepts_file_exactly_at_min_size_boundary(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 10)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    content = _valid_pdf_bytes(padding=0)
    assert len(content) >= 10
    f = _write(tmp_path / "boundary.pdf", content)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is True
    assert reason is None


# ---------------------------------------------------------------------------
# validate_document_integrity — document_type / Content-Type resolution
# ---------------------------------------------------------------------------


def test_validate_uses_document_type_over_content_type_when_both_given(tmp_path, monkeypatch):
    """DocumentRegistry's own document_type (set at discovery time) is authoritative — same convention ParserFactory uses for the same column."""
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "real.pdf", _valid_pdf_bytes(padding=50))
    # Content-Type header lies and says HTML; document_type (the trusted signal) says PDF.
    ok, reason = FileIntegrityValidator.validate_document_integrity(
        f, content_type_header="text/html", document_type="pdf"
    )
    assert ok is True
    assert reason is None


def test_validate_falls_back_to_content_type_when_document_type_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "page.html", _valid_html_bytes(padding=50))
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, content_type_header="text/html", document_type=None)
    assert ok is True
    assert reason is None


def test_validate_rejects_when_type_undeterminable(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "mystery.bin", b"x" * 100)
    ok, reason = FileIntegrityValidator.validate_document_integrity(
        f, content_type_header="application/json", document_type=None
    )
    assert ok is False
    assert "unsupported or undeterminable" in reason.lower()


def test_validate_rejects_unknown_document_type_value(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "mystery.bin", b"x" * 100)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="unknown")
    assert ok is False


# ---------------------------------------------------------------------------
# validate_document_integrity — PDF structural checks
# ---------------------------------------------------------------------------


def test_validate_pdf_rejects_missing_magic_bytes(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    # Looks like HTML, not a PDF, but big enough to pass the size check.
    f = _write(tmp_path / "fake.pdf", b"<html>" + b"x" * 50 + b"</html>\n%%EOF")
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "magic bytes" in reason.lower()


def test_validate_pdf_rejects_missing_eof_marker(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "truncated.pdf", b"%PDF-1.4\n" + b"x" * 50)  # no trailing %%EOF
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "end-of-file" in reason.lower()


def test_validate_pdf_accepts_well_formed_pdf(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "real.pdf", _valid_pdf_bytes(padding=200))
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is True
    assert reason is None


def test_validate_pdf_only_checks_last_1024_bytes_for_eof_marker(tmp_path, monkeypatch):
    # %%EOF sitting well outside the last-1KB window should NOT count —
    # confirms the implementation seeks to (file_size - 1024) rather than
    # scanning the whole file for the marker.
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 1_000_000)
    content = b"%PDF-1.4\n%%EOF\n" + (b"y" * 5000)  # EOF marker near the start, not the end
    f = _write(tmp_path / "misplaced_eof.pdf", content)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "end-of-file" in reason.lower()


def test_validate_pdf_magic_bytes_check_only_scans_first_1024_bytes(tmp_path, monkeypatch):
    # %PDF- appearing after the first 1KB should NOT count as a valid
    # header — confirms the implementation only reads the first 1024 bytes
    # when looking for the magic bytes.
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 1_000_000)
    content = (b"x" * 2000) + b"%PDF-1.4\n%%EOF"
    f = _write(tmp_path / "late_header.pdf", content)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="pdf")
    assert ok is False
    assert "magic bytes" in reason.lower()


# ---------------------------------------------------------------------------
# validate_document_integrity — HTML structural checks
# ---------------------------------------------------------------------------


def test_validate_html_accepts_well_formed_html(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "page.html", _valid_html_bytes(padding=100))
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is True
    assert reason is None


def test_validate_html_accepts_doctype_declaration(tmp_path, monkeypatch):
    """Real SEC EDGAR .htm filings and most real-world pages open with <!DOCTYPE html>, not a bare <html> tag."""
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    content = b"<!DOCTYPE html>\n<html><body>" + b"x" * 100 + b"</body></html>"
    f = _write(tmp_path / "page.html", content)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is True


def test_validate_html_is_case_insensitive(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "page.html", b"<!DOCTYPE HTML>\n<HTML><BODY>content</BODY></HTML>")
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is True


def test_validate_html_rejects_binary_garbage_mislabeled_as_html(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "garbage.html", b"\x00\x01\x02\x03" * 50)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is False
    assert "html" in reason.lower()


def test_validate_html_rejects_pdf_content_mislabeled_as_html(tmp_path, monkeypatch):
    """The registry said html, but the actual bytes are a PDF — should not be waved through."""
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "mislabeled.html", _valid_pdf_bytes(padding=50))
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is False


def test_validate_html_marker_only_scanned_in_first_2kb(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    content = (b"x" * 3000) + b"<html></html>"
    f = _write(tmp_path / "late_marker.html", content)
    ok, reason = FileIntegrityValidator.validate_document_integrity(f, document_type="html")
    assert ok is False


# ---------------------------------------------------------------------------
# validate_pdf_integrity — backward-compatible alias, unchanged behavior
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "content_type",
    ["text/html", "text/html; charset=utf-8", "application/json", "text/plain"],
)
def test_legacy_validate_pdf_integrity_still_rejects_disallowed_content_types(tmp_path, monkeypatch, content_type):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "mislabeled.pdf", _valid_pdf_bytes(padding=50))
    ok, reason = FileIntegrityValidator.validate_pdf_integrity(f, content_type_header=content_type)
    assert ok is False
    assert "Invalid Content-Type" in reason


def test_legacy_validate_pdf_integrity_still_accepts_application_pdf_content_type(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "good.pdf", _valid_pdf_bytes(padding=50))
    ok, reason = FileIntegrityValidator.validate_pdf_integrity(f, content_type_header="application/pdf")
    assert ok is True
    assert reason is None


def test_legacy_validate_pdf_integrity_still_accepts_well_formed_pdf(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "acquisition_min_file_size_bytes", 0)
    monkeypatch.setattr(settings, "acquisition_max_file_size_bytes", 10_000)
    f = _write(tmp_path / "real.pdf", _valid_pdf_bytes(padding=200))
    ok, reason = FileIntegrityValidator.validate_pdf_integrity(f)
    assert ok is True
    assert reason is None
