"""Unit tests for `src/embeddings/telemetry.py`."""

from src.embeddings.telemetry import EmbeddingTelemetry


def test_initial_summary_is_all_zero():
    t = EmbeddingTelemetry()
    summary = t.get_summary()

    assert summary["chunks_embedded"] == 0
    assert summary["tokens_processed"] == 0
    assert summary["average_embedding_latency"] == 0.0
    assert summary["batch_throughput"] == 0.0
    assert summary["failed_embeddings"] == 0
    assert summary["retry_count"] == 0
    assert summary["active_provider"] == ""
    assert summary["skipped_chunks"] == 0
    assert summary["success_rate"] == 0.0


def test_record_success_accumulates_counters_and_sets_active_provider():
    t = EmbeddingTelemetry()
    t.record_success(tokens=100, duration=1.0, provider="openai")
    t.record_success(tokens=50, duration=0.5, provider="openai")

    summary = t.get_summary()
    assert summary["chunks_embedded"] == 2
    assert summary["tokens_processed"] == 150
    assert summary["active_provider"] == "openai"
    assert summary["average_embedding_latency"] == 0.75


def test_record_batch_feeds_throughput_calculation():
    t = EmbeddingTelemetry()
    t.record_success(tokens=10, duration=2.0, provider="openai")
    t.record_batch(20)  # 20 chunks processed in the 2.0s recorded above

    assert t.get_summary()["batch_throughput"] == 10.0  # 20 chunks / 2.0s


def test_record_failure_increments_counter():
    t = EmbeddingTelemetry()
    t.record_failure()
    t.record_failure()
    assert t.get_summary()["failed_embeddings"] == 2


def test_record_retry_increments_counter():
    t = EmbeddingTelemetry()
    t.record_retry()
    assert t.get_summary()["retry_count"] == 1


def test_record_skipped_increments_counter():
    t = EmbeddingTelemetry()
    t.record_skipped()
    assert t.get_summary()["skipped_chunks"] == 1


def test_success_rate_computed_against_success_plus_failures():
    t = EmbeddingTelemetry()
    t.record_success(tokens=10, duration=0.1, provider="openai")
    t.record_success(tokens=10, duration=0.1, provider="openai")
    t.record_success(tokens=10, duration=0.1, provider="openai")
    t.record_failure()

    assert t.get_summary()["success_rate"] == 0.75


def test_skipped_chunks_do_not_affect_success_rate_denominator():
    t = EmbeddingTelemetry()
    t.record_success(tokens=10, duration=0.1, provider="openai")
    t.record_skipped()

    assert t.get_summary()["success_rate"] == 1.0


def test_reset_clears_all_counters():
    t = EmbeddingTelemetry()
    t.record_success(tokens=10, duration=1.0, provider="openai")
    t.record_failure()
    t.record_retry()
    t.reset()

    summary = t.get_summary()
    assert summary["chunks_embedded"] == 0
    assert summary["failed_embeddings"] == 0
    assert summary["retry_count"] == 0
    assert summary["active_provider"] == ""
