# AI Document Intelligence Platform — Architecture & Roadmap

## 0. Framing the actual design problem

The brief says "extract O2V's 3 components now, all 12 later, other frameworks eventually — without redesigning." That single constraint is the one that should drive every decision below. If I design for "3 fields from 100 companies," I get a script. If I design for "any number of structured organizational-intelligence fields, from any framework, from any company, forever," I get a platform. The difference is almost entirely in **how the schema and the extraction contract are modeled as data, not as code** — frameworks and components should be rows in a table the platform reads, never hardcoded logic. Everything below is built around that.

Second framing point: this is a **document-grounded structured-extraction platform with a human-in-the-loop QA layer**, not a chatbot and not a generic RAG app. That distinction matters for tech choices — we optimize for auditability (every field traces to a page/chunk) and reproducibility (same inputs → same outputs, versioned), not for conversational latency.

---

## 1. High-Level Architecture

```
                              ┌─────────────────────────┐
                              │   Admin / Ops Console    │  (internal web UI)
                              │  (registry mgmt, review, │
                              │   monitoring, re-runs)   │
                              └───────────┬─────────────┘
                                          │ REST/GraphQL
                              ┌───────────▼─────────────┐
                              │      Platform API        │  (FastAPI)
                              │  (auth, orchestration     │
                              │   triggers, query layer)  │
                              └───────────┬─────────────┘
                                          │
        ┌─────────────────────────────────┼─────────────────────────────────┐
        │                                 │                                 │
┌───────▼────────┐              ┌─────────▼─────────┐              ┌────────▼────────┐
│ Company Registry│              │  Orchestration Layer│              │ Ground Truth /   │
│    Service      │◄─────────────┤  (Prefect/Dagster)  ├─────────────►│ Evaluation Store  │
└───────┬────────┘              └─────────┬─────────┘              └────────┬────────┘
        │                                 │                                 │
        │                    ┌────────────┼────────────┬───────────┬────────┘
        │                    │            │            │           │
┌───────▼──────┐   ┌─────────▼──────┐ ┌───▼──────┐ ┌────▼─────┐ ┌──▼───────────┐
│  Discovery    │   │   Acquisition  │ │  Parsing │ │ Chunking │ │  Extraction   │
│  Worker Pool  │──►│  Worker Pool   │►│ & Normal- │►│ & Embed- │►│  Worker Pool  │
│ (LLM+search)  │   │ (fetch/scrape) │ │ ization   │ │  ding    │ │ (LLM extract) │
└───────┬──────┘   └─────────┬──────┘ └────┬─────┘ └────┬─────┘ └───────┬───────┘
        │                    │             │            │               │
        ▼                    ▼             ▼            ▼               ▼
┌───────────────┐   ┌────────────────┐ ┌─────────┐ ┌──────────┐ ┌───────────────┐
│ Manifest Store │   │ Raw Doc Store  │ │ Parsed  │ │  Vector  │ │ Extraction     │
│  (Postgres)    │   │ (S3/GCS/Blob)  │ │ Store   │ │    DB    │ │ Staging Store  │
└───────────────┘   └────────────────┘ │(Postgres│ │ (Qdrant) │ │  (Postgres)    │
                                        │/Parquet)│ └──────────┘ └───────┬───────┘
                                        └─────────┘                     │
                                                              ┌──────────▼──────────┐
                                                              │  Validation Service   │
                                                              │ (schema+grounding+NLI)│
                                                              └──────────┬──────────┘
                                                                         │
                                                     ┌───────────────────┼───────────────────┐
                                                     │                                        │
                                          ┌──────────▼──────────┐                 ┌───────────▼──────────┐
                                          │  Human Review Queue  │                 │  Ground Truth Store   │
                                          │  (review UI + audit)  │────promoted───►│ (versioned, immutable)│
                                          └───────────────────────┘                 └───────────┬──────────┘
                                                                                                 │
                                                                                     ┌───────────▼──────────┐
                                                                                     │  Export & Eval Layer  │
                                                                                     │ (CSV/JSON/eval sets)  │
                                                                                     └───────────────────────┘

Cross-cutting (touch every box above):
  ─ Message Queue (SQS/RabbitMQ/Redis Streams) — connects every worker pool
  ─ State/Checkpoint DB (Postgres) — one job-state row per (company, doc, field-group)
  ─ Observability Stack (structured logs, metrics, traces, dashboards)
  ─ Framework/Schema Registry (Postgres) — defines what "O2V Purpose field: Mission Statement" IS,
    read by Discovery, Extraction, and Validation — this is the extensibility hinge (Section 3)
  ─ Secrets/Config Management
```

---

## 2. Core Design Principle: Framework & Schema as Data

This is the single most important module in the whole system, because it's what lets "3 O2V fields today, 12 tomorrow, other frameworks later" happen **without a redesign**.

**Framework Registry (a Postgres schema, not code):**

```
frameworks            (framework_id, name, version, description)
components            (component_id, framework_id, name, description)      -- e.g. "Purpose", "Behaviour"
fields                (field_id, component_id, name, description,
                       extraction_guidance, expected_doc_types[])           -- e.g. "Mission Statement"
```

- **Why it exists**: every other service (Discovery, Extraction prompt builder, Validation) reads *from* this table instead of having field lists hardcoded. Adding O2V's remaining 9 components, or an entirely different framework (e.g., McKinsey 7S, a competitor's model), is a **data insert**, not a code change or redeploy.
- **Inputs**: framework definitions (initially your existing O2V research — Purpose/Behaviour/Value Agenda definitions and fields — get seeded here once).
- **Outputs**: structured schema consumed by the Extraction Worker to build its output contract (Pydantic model generated dynamically from these rows) and by Discovery to know which document types are relevant per field.
- **Dependencies**: none upstream; everything downstream depends on it.
- **Technology**: Postgres tables + a thin admin CRUD API; no need for anything fancier at this scale.

This one decision is what separates "an O2V script" from "a document intelligence platform."

---

## 3. Module Breakdown

### 3.1 Company Registry Service
- **Why**: single source of truth for "which companies, what metadata, what status." Everything else keys off `company_id`.
- **Inputs**: initial company master list (bulk import), manual additions via Admin Console.
- **Outputs**: `company_id`, canonical name, ticker, sector, HQ country, homepage domain, `last_processed_at`, current pipeline status.
- **Responsibilities**: dedup (don't create "Apple Inc." twice), status tracking, exposing a queryable list to the orchestrator.
- **Technology**: Postgres table + FastAPI CRUD endpoints.
- **Dependencies**: Framework Registry not required; independent.

### 3.2 Document Discovery Service
- **Why**: turns "Apple" into "these 6 specific URLs are Apple's official Annual Report, Code of Conduct, ESG Report, etc." Doing this *once* and caching it, rather than re-discovering documents live during every extraction, is both a cost and a consistency win.
- **Inputs**: `company_id` + the `expected_doc_types` pulled from the Framework Registry's `fields` table (so discovery knows what kinds of documents matter).
- **Outputs**: a **Document Manifest** row per (company, doc_type): candidate URL(s), confidence, discovered_at, discovery_method.
- **Responsibilities**: web search + LLM-assisted URL identification (this is the one place an LLM legitimately does open-ended search, because it runs once per company, not once per field-extraction).
- **Technology**: LLM (cheap/fast model tier) + a search API (Bing/Google Custom Search/Serper), output written to Postgres.
- **Dependencies**: Company Registry, Framework Registry.
- **Re-run policy**: scheduled refresh (e.g., quarterly) to catch new annual reports/updated docs — not a one-time-only step.

### 3.3 Document Acquisition (Fetch) Service
- **Why**: separates "know the URL" from "have the bytes" — lets discovery be cheap/fast while acquisition handles the messier reality of scraping (JS-rendered IR pages, PDF redirects, rate limits).
- **Inputs**: Document Manifest entries with status `pending_fetch`.
- **Outputs**: raw files written immutably to object storage, keyed `company_id/doc_type/year/hash.pdf`; a Raw Document record (checksum, byte size, content-type, fetch timestamp) in Postgres.
- **Responsibilities**: HTTP fetch, Playwright fallback for JS-heavy pages, retry/backoff, dedup via content hash (don't re-store an identical file).
- **Technology**: `httpx`/`requests`, Playwright, S3/GCS/Azure Blob.
- **Dependencies**: Document Discovery.

### 3.4 Parsing & Normalization Service
- **Why**: converts heterogeneous raw formats (PDF, HTML) into a single normalized internal representation — clean text **with page/section anchors preserved**, which is non-negotiable given your schema requires page numbers.
- **Inputs**: Raw Document records.
- **Outputs**: Parsed Document — ordered list of `{text, page_number, section_heading}` blocks, stored as Parquet/JSONL.
- **Responsibilities**: PDF layout parsing (tables, headers), HTML boilerplate stripping, OCR fallback for scanned docs.
- **Technology**: PyMuPDF (fast, text-heavy PDFs), Docling (complex layout/tables), Unstructured (HTML/mixed), Azure Document Intelligence (OCR fallback, used sparingly for cost).
- **Dependencies**: Document Acquisition.

### 3.5 Chunking & Embedding Service
- **Why**: extraction quality and cost both depend on retrieving the *right* small piece of text, not feeding whole documents to the LLM.
- **Inputs**: Parsed Documents.
- **Outputs**: chunks (with inherited page metadata) + their embeddings, written to the Vector DB.
- **Responsibilities**: semantic-aware chunking (not naive fixed-size), embedding generation, metadata tagging (`company_id`, `doc_type`, `page_range`) so retrieval can filter, not just similarity-search blindly.
- **Technology**: LangChain/LlamaIndex text splitters (plumbing only), an embedding model (Voyage AI embeddings pair natively with Claude, or OpenAI/Cohere embeddings), Qdrant as the vector store.
- **Dependencies**: Parsing.

### 3.6 Retrieval Service
- **Why**: given a specific field ("Purpose-linked KPIs" for Company X), pull the small set of chunks actually relevant — this is what keeps Stage 7 (Extraction) accurate and cheap.
- **Inputs**: `(company_id, field_id)` pair.
- **Outputs**: top-k relevant chunks, each with its page/source metadata intact.
- **Responsibilities**: metadata-filtered vector search (restrict to this company's own chunks — never cross-contaminate between companies), optional hybrid keyword+vector search for named-entity-heavy fields (e.g., exact KPI figures benefit from keyword matching too).
- **Technology**: Qdrant's filtered search API.
- **Dependencies**: Chunking/Embedding, Framework Registry (to know what each field is even asking for).

### 3.7 Extraction Service (LLM Worker Pool)
- **Why**: the actual "read the retrieved chunks, produce the structured field value with citation" step — the core value-add of the whole platform.
- **Inputs**: retrieved chunks + the field's schema/definition (dynamically assembled from the Framework Registry, not hardcoded).
- **Outputs**: structured JSON per field: `exact_text, source_chunk_id, page_number, confidence, reasoning`, written to an Extraction Staging Store (mutable, pre-validation).
- **Responsibilities**: prompt assembly (with prompt caching for the shared instruction block across all companies/fields), structured output enforcement (tool-use/JSON schema), "Not Found" as a legitimate first-class output.
- **Technology**: Anthropic API (Claude), Batch API for the bulk of volume (cost + no urgency), synchronous API reserved for re-runs/interactive debugging.
- **Dependencies**: Retrieval, Framework Registry.

### 3.8 Validation Service
- **Why**: this is what makes the output *ground truth* instead of *an LLM's claim* — see the three-layer approach from the prior design doc, now formalized as a standing service rather than a one-off script.
- **Inputs**: Extraction Staging records.
- **Outputs**: each record tagged `validated_pass`, `validated_fail:<reason>`, or `needs_human_review`.
- **Responsibilities**:
  1. Schema validation (Pydantic) — free, instant.
  2. Grounding validation — fuzzy-match the claimed "exact text" against the actual source chunk; reject/flag mismatches.
  3. Semantic/NLI validation — a second, cheaper LLM call asks "is this claim supported by this text, yes/no" — catches subtle hallucination schema-matching can't.
- **Technology**: Pydantic, a fuzzy-matching library (rapidfuzz), a smaller/cheaper model for the NLI pass.
- **Dependencies**: Extraction Service.

### 3.9 Human Review Service
- **Why**: no automated system should self-certify "ground truth" — a human gate on anything flagged Low-confidence or failing semantic validation is what makes this defensible as an eval/training dataset.
- **Inputs**: records tagged `needs_human_review`.
- **Outputs**: reviewer decision (`approve`, `edit`, `reject`) + audit trail (who, when, what changed).
- **Responsibilities**: present source chunk + extracted claim side-by-side; let reviewer correct or reject; log everything (this audit trail is itself valuable training signal later — a "why did the model get this wrong" dataset).
- **Technology**: a lightweight internal review UI (could start as a Retool/Airtable app, later a purpose-built React app or Label Studio) backed by the Platform API.
- **Dependencies**: Validation Service.

### 3.10 Ground Truth Store
- **Why**: the actual deliverable — must be versioned and immutable (never overwrite a prior version; append a new one), because this dataset will later be used as an eval set, and eval sets that silently mutate are worthless for tracking model improvement over time.
- **Inputs**: approved records from Human Review (or auto-approved High-confidence records that passed all validation layers, if you choose to skip human review for the highest-confidence tier).
- **Outputs**: versioned dataset snapshots (`v1`, `v2`, ...) in Parquet (efficient, queryable) with CSV/JSON exports generated on demand.
- **Responsibilities**: versioning, diffing between versions (what changed and why), export generation.
- **Technology**: Parquet on object storage, a simple versioning convention (`ground_truth/v{n}/`), a changelog.
- **Dependencies**: Human Review.

### 3.11 Export & Evaluation Layer
- **Why**: the dataset needs to serve two audiences — humans who want a CSV, and the eventual LangChain prototype that needs an eval harness.
- **Inputs**: a Ground Truth Store version.
- **Outputs**: CSV (your original schema), JSON (nested by company/component/field), and an **eval-ready format** (input: company+field → expected output: the ground truth value) for later scoring a live extraction system against this dataset.
- **Responsibilities**: format conversion, eval-set sampling/splitting (train/held-out, if this ever becomes a fine-tuning or few-shot-example source too).
- **Technology**: simple Python export scripts; no new infra.
- **Dependencies**: Ground Truth Store.

### 3.12 Orchestration Layer
- **Why**: the nervous system connecting every module above — this is what replaces "repeat manually for 100 companies."
- **Inputs**: Company Registry status, Job State DB.
- **Outputs**: triggers each worker pool for whichever (company, stage) units are ready to advance.
- **Responsibilities**: DAG definition (Discovery→Acquisition→Parsing→Chunking→Extraction→Validation→Review→Promotion), retry/backoff policy, concurrency limits (respecting API rate limits), scheduling (e.g., quarterly re-discovery).
- **Technology**: Prefect or Dagster (Dagster's asset-based model maps unusually well onto "each stage produces a durable asset the next stage consumes").
- **Dependencies**: everything — this is the coordination layer, not a data-producing one.

### 3.13 Platform API
- **Why**: the single entry point for the Admin Console, for triggering re-runs, and eventually for external consumers (e.g., the LangChain prototype querying ground truth).
- **Inputs/Outputs**: REST/GraphQL over all the above stores.
- **Technology**: FastAPI, with auth (even a simple API-key scheme at this stage; OAuth2/SSO if this becomes a real multi-user product).

### 3.14 Admin / Ops Console
- **Why**: a human needs to see "where is company 47 stuck," approve reviews, add a new company, or trigger a re-discovery — without touching a database directly.
- **Technology**: a small internal web app (Next.js/React), or, pragmatically for v1, Retool/Streamlit wired to the Platform API — don't over-invest here until the pipeline itself is proven.

### 3.15 Observability Stack
- **Why**: at 100+ companies running unattended, you need to know something failed *before* a human notices missing rows three weeks later.
- **Responsibilities**: structured logging (one log line per stage transition, JSON-formatted), metrics (companies/hour, cost/company, validation pass rate), dashboards, alerting (Slack/email on stuck jobs or budget overrun).
- **Technology**: OpenTelemetry for tracing, Prometheus+Grafana or a hosted equivalent (Datadog/Honeycomb) for metrics/dashboards, structured logs to CloudWatch/Loki.

---

## 4. Databases — what lives where and why

| Store | Technology | Contents | Why this technology |
|---|---|---|---|
| Framework/Schema Registry | Postgres | frameworks, components, fields | Relational integrity matters here — fields belong to components belong to frameworks |
| Company Registry | Postgres | company metadata, status | Same — simple relational data, needs transactional updates |
| Job/State/Checkpoint DB | Postgres | one row per (company, stage) with status + timestamps | Needs row-level locking for safe multi-worker claims |
| Document Manifest | Postgres | discovered URLs per (company, doc_type) | Relational, small |
| Raw Document Store | S3/GCS/Azure Blob | actual PDF/HTML bytes, immutable | Object storage is the right tool for large immutable blobs |
| Parsed Document Store | Parquet on object storage (or Postgres at small scale) | page-tagged text blocks | Parquet is efficient for large-scale columnar read later (analytics on the corpus itself) |
| Vector DB | Qdrant (FAISS acceptable at ≤100 companies) | chunk embeddings + metadata | Qdrant supports metadata filtering (critical — never let retrieval leak across companies) at production scale |
| Extraction Staging | Postgres | pre-validation LLM outputs | Needs to be queryable/updatable as validation runs |
| Ground Truth Store | Parquet + versioned folders on object storage | final, immutable, versioned dataset | Versioning discipline matters more than query speed here |
| Logs/Metrics | Loki/CloudWatch + Prometheus/Grafana | operational telemetry | Purpose-built observability tools, not a database |

---

## 5. Queues & Workers

- **Message queue**: Redis Streams (simplest, sufficient at this scale) or SQS (if already on AWS) connects every stage — each worker pool consumes from its own queue/topic and pushes to the next.
- **Worker pools** (one per stage, independently scalable): Discovery Workers, Acquisition Workers, Parsing Workers, Embedding Workers, Extraction Workers, Validation Workers. Each pool scales independently — e.g., Extraction Workers (LLM-call-bound, rate-limited) will always be the bottleneck and need the most careful concurrency tuning; Parsing Workers (CPU-bound, no external rate limit) can scale much wider.
- **Synchronization**: the Job/State DB (Postgres, row-level locks) is the only coordination point — a worker atomically claims a `(company_id, stage)` unit before processing it, so no two workers ever duplicate work, and no central "scheduler" bottleneck is needed beyond Postgres itself.

---

## 6. Versioning Strategy

Three independent things need versioning, and conflating them is a common mistake:

1. **Document versioning** — a company's Annual Report changes year to year; the Raw Document Store keys by year/hash, so old extractions remain traceable to the exact document version they came from, forever.
2. **Schema versioning** — the Framework Registry's `fields` can evolve (new field added, definition refined); every extraction record stores which `field_id` (and implicitly, which version of its definition) it was extracted against.
3. **Ground Truth dataset versioning** — `v1`, `v2`, ... snapshots, each immutable, each with a changelog entry describing what changed (new companies added, corrected rows, expanded field coverage). This is what lets you say "we evaluated the LangChain prototype against Ground Truth v3" and have that be a reproducible, auditable statement six months later.

---

## 7. Deployment Architecture

- **v1 (100 companies, proving the pipeline)**: single-region deployment, Docker Compose or a small Kubernetes cluster, SQLite acceptable in the very earliest prototype but Postgres recommended even at v1 to avoid a migration later, workers as simple scheduled containers/Prefect agents, object storage from day one (never local disk for raw docs, even at small scale — you want the immutability property from the start).
- **v2 (1,000 companies)**: Kubernetes with autoscaling worker deployments, managed Postgres (RDS/Cloud SQL), managed Qdrant, Prefect/Dagster Cloud for orchestration, CI/CD for the pipeline code itself (this is now a real deployed service, not a script).
- **v3 (10,000+ companies, multi-framework)**: same architecture, horizontally scaled — the only structural addition is likely a caching/CDN layer in front of frequently-re-fetched public documents, and possibly sharding the vector DB by industry/region if query latency becomes an issue. No DAG redesign needed — this is the payoff of the Framework Registry + stage-based architecture decided in Section 2.
- **Environments**: dev → staging → prod, with staging running against a small fixed sample of companies (e.g., the same 2–3 pilot companies from chat) so pipeline changes are validated before touching the full registry.

---

## 8. Future Extensibility — how "12 components" and "other frameworks" actually land

Because of the Framework Registry (Section 2):

- **Adding O2V's remaining 9 components**: insert rows into `components` and `fields`. Discovery automatically knows to look for new document types if specified; Extraction automatically builds the new schema; Validation automatically applies the same three-layer check. Zero code changes.
- **Adding a new framework entirely** (e.g., McKinsey 7S, a proprietary framework): same — insert a new `frameworks` row and its components/fields. The only genuinely new work is confirming the existing document types (Annual Report, ESG Report, etc.) are sufthe right sources for the new framework's fields — a content question, not an architecture question.
- **Multi-framework companies**: since extraction is keyed by `(company_id, field_id)` and fields belong to frameworks, a single company can have ground truth populated for O2V, 7S, and anything else simultaneously — the schema was built for this from day one, not bolted on.

---

## 9. Development Roadmap — milestones, each a working system

Each milestone below should be independently demoable — "here is a running thing," not "here is a spec."

**Milestone 1 — Company Registry**
Postgres table + minimal CRUD API + bulk import of your 100-company master list. Working system: query "list all companies + status" via API.

**Milestone 2 — Framework/Schema Registry**
Model your existing O2V research (Purpose/Behaviour/Value Agenda + their fields/definitions) as data in `frameworks/components/fields`. Working system: query "what fields exist for Purpose" via API — this de-risks the extensibility bet early, before any extraction code exists.

**Milestone 3 — Document Discovery**
LLM+search-based discovery script, run against Milestone 1's company list, writing to a Document Manifest table. Working system: a manifest of real URLs for all 100 companies, human-spot-checked for accuracy (this is where you validate the discovery approach before trusting it to run unattended).

**Milestone 4 — Document Acquisition**
Fetch worker that reads manifests and downloads to object storage with checksums. Working system: raw document store populated for all 100 companies, with a dashboard showing fetch success/failure rate.

**Milestone 5 — Parsing & Normalization**
PDF/HTML → page-tagged text blocks. Working system: browsable parsed output for a handful of companies, manually verified page-anchor accuracy against the source PDF.

**Milestone 6 — Chunking & Embedding + Vector DB**
Chunk parsed docs, embed, load into Qdrant (or FAISS for v1). Working system: a retrieval query ("show me chunks about DEI for Company X") returns sensible results.

**Milestone 7 — Job/State Checkpoint System**
Before building Extraction, get the state machine working end-to-end across Milestones 3–6 — this is the piece that makes everything resumable. Working system: kill a worker mid-run, restart, confirm it resumes correctly without reprocessing or losing anything.

**Milestone 8 — Extraction Service**
LLM extraction against retrieved chunks, using the dynamically-built schema from Milestone 2. Working system: structured JSON output for all fields, for a pilot batch of ~5 companies (reuse your Apple/Microsoft chat pilots as a manual comparison baseline).

**Milestone 9 — Validation Service**
Schema + grounding + semantic validation layers. Working system: a validation report showing pass/fail/needs-review breakdown across the pilot batch.

**Milestone 10 — Human Review UI**
Even a minimal Retool/Airtable-backed review flow. Working system: a reviewer can approve/edit/reject flagged records and see the audit trail.

**Milestone 11 — Ground Truth Store + Export**
Versioned promotion from approved reviews, CSV/JSON export. Working system: `ground_truth/v1/dataset.csv` — this is your first real deliverable, matching the schema you originally specified.

**Milestone 12 — Orchestration & Full Automation**
Wire Milestones 3–11 into a Prefect/Dagster DAG with retries, concurrency limits, and scheduling. Working system: trigger "process all 100 companies," walk away, come back to a populated (or clearly flagged, per-company) Ground Truth Store — this is the actual "no more manual chat repetition" milestone.

**Milestone 13 — Observability & Admin Console**
Dashboards, alerting, and a real (or Retool) UI over everything above. Working system: a single screen showing pipeline health across all 100 companies.

**Milestone 14 — Scale-out Validation (1,000 companies)**
Stress-test the same architecture at 10x volume — swap SQLite→Postgres if not already done, tune Extraction Worker concurrency against real rate limits, confirm cost-per-company is acceptable. Working system: the same platform, more companies, no code changes beyond config/infra scaling.

**Milestone 15 — Second Framework / Remaining O2V Components**
Add O2V's other 9 components and/or a second framework entirely, purely via Framework Registry data entries. Working system: proof that the extensibility bet from Section 2 actually paid off — if this milestone requires code changes, that's the signal something in Milestones 1–12 was hardcoded that shouldn't have been.

---

## 10. What I'd push back on if this were a real startup pitch

- **Don't build the Admin Console first.** It's tempting because it's visible, but it produces nothing without Milestones 1–11 behind it. Retool/Streamlit buys you 90% of the value at 10% of the cost until the pipeline itself is proven.
- **Don't skip the Human Review milestone to "move faster."** A dataset called "ground truth" that no human ever verified is a liability the moment someone downstream (an eval, a client deliverable, a fine-tuning run) trusts it more than it deserves.
- **Don't over-invest in the vector DB choice early.** FAISS is genuinely fine through Milestone 14; migrating to Qdrant is a config change, not a redesign, precisely because Retrieval is its own module with a clean interface (Section 3.6).
- **Do invest early in the Framework Registry**, even though it's the least visually impressive piece — it's the actual mechanism by which "without redesigning the architecture" becomes true rather than aspirational.
