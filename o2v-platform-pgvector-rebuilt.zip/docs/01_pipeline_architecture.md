# O2V Ground Truth Dataset — Production Data Engineering Architecture

## 0. Verdict up front

Your instinct is right: **the chat workflow does not scale past ~10 companies**, and even at 10 it's fragile — the Apple pilot alone took ~10 tool calls and burned a large fraction of a single turn's budget just to reach ~70% field coverage on ONE company. Extrapolated: 100 companies × similar depth ≈ 800–1,200 manual tool calls, spread across 20–30 chat turns, each one vulnerable to context loss, no resumability, and no way to re-run just "company 37" without re-deriving everything upstream of it.

**This should be an offline, API-driven, checkpointed batch pipeline — not a chat conversation.** Chat (this conversation) is the right place to *design, prototype, and spot-check* the pipeline. It is the wrong place to *run* it.

---

## 1. Chat interface vs. API — and why it matters

| Dimension | Chat (claude.ai) | API (direct or via orchestrator) |
|---|---|---|
| Session state | Ephemeral, resets on context overflow | Fully controlled, you persist what you want |
| Concurrency | Strictly serial — one tool call at a time | Arbitrary parallelism (N workers, rate-limit bound) |
| Resumability | None — a dropped turn loses in-flight work | Trivial — resume from last checkpoint file |
| Cost visibility | Opaque | Per-call token accounting, cacheable prompts |
| Auditability | Scroll-back through a transcript | Structured logs, one row per extraction |
| Retry logic | You manually re-ask | Programmatic retry/backoff |
| Tool access | Fixed toolset (web_search/web_fetch as given) | Your own scraper/parser stack, purpose-built |

**Answer to Q1:** Use the Anthropic API directly (or via a lightweight orchestrator), not claude.ai chat, for the *production run*. Keep chat for: (a) building/debugging the extraction prompt on 2–3 companies, (b) spot QA of a sample of outputs, (c) ad-hoc one-off lookups. This is exactly the "prototype in chat, industrialize via API" pattern — and it's also literally what LangChain-based automation (your stated end goal) requires as an input contract anyway.

---

## 2. Pipeline shape

Your proposed shape is close. The key fixes: **separate "get the document" from "read the document" from "extract fields,"** and add a **validation + human-review gate** before anything is called "ground truth." An LLM should never mark its own homework as final.

```
Stage 0  Company Master List (CSV/DB)          — input of record, one row per company
Stage 1  Document Discovery                    — find canonical URLs per doc type per company
Stage 2  Document Acquisition                  — download/fetch raw files, store immutably
Stage 3  Parsing & Normalization                — PDF/HTML → clean text + page anchors
Stage 4  Chunking & Indexing                    — semantic chunks, page-tagged, embedded
Stage 5  Retrieval (RAG)                        — per O2V field, pull top-k relevant chunks
Stage 6  Extraction (LLM)                       — structured JSON out, citing chunk/page
Stage 7  Automated Validation                   — schema check, hallucination check, citation check
Stage 8  Human-in-the-loop Review               — sample or full review of Low/Medium confidence rows
Stage 9  Ground Truth Store                     — versioned JSON/Parquet, CSV export on demand
Stage 10 Observability & Cost Ledger            — logs, dashboards, per-company/per-field cost
```

This differs from your sketch in three important ways:

1. **Discovery is its own stage**, separate from acquisition. You don't want an LLM guessing URLs live during extraction — you want a pre-built, versioned manifest of "these are the 6 official documents for Company X" that a human or a search-agent validated once, then reuse and re-fetch (for freshness) on a schedule.
2. **RAG sits between parsing and extraction, not "instead of" extraction.** Given a 300-page annual report, you do NOT want to stuff the whole document into every extraction call. Retrieve the ~10 chunks relevant to "Purpose-linked KPIs," then extract from those. This is a cost and accuracy issue, not just an architecture preference (Q6, below).
3. **Validation is two-layered**: automated (cheap, catches structural problems) and human (expensive, catches semantic/hallucination problems), and ground truth isn't "final" until it clears both — this is the actual definition of a *ground truth* dataset versus "an LLM's opinion of a company."

---

## 3. Eliminating manual uploads — automating for 100 (and eventually 10,000) companies

Manual upload doesn't survive past ~5 companies. Replace it with:

- **A company registry** (Postgres table or even a versioned CSV/Parquet in object storage) — one row per company: `company_id, name, ticker, sector, hq_country, doc_manifest_id, last_processed_at, status`.
- **A document manifest per company**, built once via a discovery agent (LLM + search API, run ONE time per company, then cached and only re-run on a schedule, e.g. quarterly) — this is where you *do* want an LLM-assisted search step, but it runs unattended, writes structured output, and never blocks on a human uploading a file.
- **A fetch worker** that reads the manifest and pulls documents itself (`requests`/`httpx` for HTML, direct PDF download, or Playwright for JS-heavy IR sites) — no human touches this step at all.
- **Idempotent storage**: raw documents land in object storage (S3/GCS/Azure Blob, or local disk for a smaller build) keyed by `company_id/doc_type/YYYY/filename` — never overwritten, so you always have the exact byte-identical source an extraction was run against (this is what makes "Source URL" and "Document Year" in your schema actually trustworthy instead of vibes).

This is the actual mechanism for "no manual uploads": the pipeline *pulls*, it is never *fed*.

---

## 4. Failure handling & checkpoints (Q4)

Company 37 failing should **never** block companies 38–100, and should **never** require re-running 1–36.

- **Unit of work = (company, document, field-group)**, not "the whole company" and definitely not "the whole batch." Granular units mean a single stuck company doesn't stall the batch and a single field failure doesn't discard 25 good ones.
- **State machine per unit**: `pending → discovered → fetched → parsed → chunked → extracted → validated → done` or `failed:<stage>`. Persist this in a lightweight metadata store (SQLite is fine at 100 companies; Postgres once you're past ~1,000).
- **Idempotent, resumable orchestration**: a job runner (see tools below) re-scans for anything not in `done` state and only (re)processes that. This gives you automatic resume-from-failure for free — there's no "resume from company 38" logic to hand-write; the state table IS the checkpoint.
- **Retry policy**: transient failures (timeout, rate limit, 5xx) get exponential backoff, 3 attempts. Structural failures (403, paywalled doc, dead URL) get flagged for human triage, not endless retry.
- **Poison-pill isolation**: if a single document repeatedly crashes the parser (corrupt PDF, oddly encoded HTML), quarantine it and continue — log it, don't let it take down the run.

---

## 5. Is LangChain useful during construction, or only later? (Q5)

**Both, but for different jobs — and it's a smaller piece than people assume.**

- **During construction**: LangChain's document loaders, text splitters, and a light orchestration layer are genuinely useful for the parsing/chunking/RAG stages (Stage 3–6) — mainly as glue so you're not hand-rolling every PDF loader. But treat it as *plumbing*, not the brain — the actual extraction quality comes from your prompt + schema + the underlying model, not from LangChain itself.
- **Not necessary for orchestration/scheduling** — that's a job for a real workflow engine (below), not LangChain's chains/agents abstractions, which add overhead without buying you retry/checkpoint semantics.
- **Later, for the prototype**: yes, this is where LangChain earns its keep more fully — the ground truth dataset becomes the eval set, and LangChain (or LlamaIndex) becomes the actual RAG-extraction application being evaluated against it.

So: light use now (loaders/splitters), heavier use later (the actual product).

---

## 6. RAG during construction vs. only at inference (Q6)

**Use RAG during construction too — for cost and grounding, not just at inference.**

Reasons:
- A 10-K + ESG report + Code of Conduct per company can easily be 400–600 pages combined. Sending all of it to the model for every one of ~20 fields is wasteful and actually *hurts* extraction quality (needle-in-haystack degradation) — you want the top 5-10 chunks relevant to "Diversity, Equity & Inclusion" fed to the model for that field, not the whole corpus.
- RAG at construction time also **produces exactly the citation trail your schema demands** — page number, source document, exact text — because a well-tagged chunk carries its own page/section metadata from the parsing stage. Extraction-with-RAG is naturally auditable in a way "read this 500-page PDF and tell me the DEI policy" is not.
- The chunks + embeddings you build during construction can be reused later as the actual RAG index for the LangChain prototype, so this isn't throwaway work — it's the deliverable's little sibling.

---

## 7. Tool stack — where each piece fits

| Tool | Role | Notes |
|---|---|---|
| **Python** | Glue language for the whole pipeline | Non-negotiable base |
| **Docling** or **PyMuPDF (fitz)** | PDF parsing with layout + page anchors | Docling handles tables/structure better; PyMuPDF is faster/lighter for plain text extraction. Use PyMuPDF for simple text-heavy PDFs (10-Ks), Docling for complex layouts (glossy sustainability reports with infographics) |
| **Unstructured** | Fallback/general-purpose parser | Good for messy HTML "About Us" pages and mixed file types |
| **Apache Tika** | Broad file-type coverage | Optional — mostly redundant with Unstructured/Docling unless you hit exotic formats |
| **Marker** | High-fidelity PDF→Markdown | Worth piloting for annual reports where table fidelity matters |
| **Azure Document Intelligence** | OCR + form/table extraction | Use only if a chunk of your ~100 companies have scanned/non-text PDFs; otherwise skip the cost |
| **LangChain** | Loaders, splitters, light chaining | See Q5 — plumbing, not brain |
| **LlamaIndex** | Alternative to LangChain for indexing/retrieval | Pick one, not both, to avoid stack sprawl; LlamaIndex is arguably cleaner for pure RAG-indexing use cases |
| **Anthropic API (Claude)** | The extraction model | Structured output via tool-use/JSON schema forcing; this is your Stage 6 |
| **OpenAI / Gemini API** | Optional cross-model validation | Run a subset of extractions through a second model family as a disagreement check (cheap ensemble QA) — not required, but a strong option for your Stage 7 |
| **FAISS** | Vector index | Simpler, file-based, fine at 100–1,000 companies |
| **Qdrant** | Vector index | Better choice once you're at 1,000–10,000 companies and need a real server, filtering by metadata (company/doc-type), and persistence across runs |
| **SQLite → Postgres** | State/checkpoint store | SQLite is enough at 100 companies; migrate to Postgres as volume grows |
| **Prefect or Dagster** | Orchestration/scheduling | This replaces "manually repeat for 100 companies" — DAG-based, retry-aware, checkpointed, has a UI to see what's stuck. (Airflow works too but is heavier than you need at this scale) |
| **Pydantic** | Schema enforcement for extracted JSON | Every extraction gets validated against a strict schema before it's allowed into the ground truth store |
| **Great Expectations** (optional) | Data quality checks on the final dataset | Nice-to-have once you're validating thousands of rows |

---

## 8. Parallel workers & synchronization (Q8)

Yes — this is one of the biggest wins of moving off chat.

- **Fan-out by company**: since companies are independent, run N workers (e.g., via Prefect task concurrency, or a simple `asyncio`/`multiprocessing` pool) each pulling the next `pending` company from the state store.
- **Synchronization mechanism**: the state store (Postgres row-level locking, or SQLite with `WAL` mode for smaller scale) is the single source of truth — a worker claims a company by atomically flipping its status to `in_progress`, so two workers never double-process the same company.
- **Rate-limit awareness**: the Anthropic API (and any search API) has a request/token-per-minute ceiling — your orchestrator should throttle worker count to stay under it rather than let 50 workers all 429 simultaneously. Prefect/Dagster both support concurrency limits natively.
- **Output convergence**: each worker writes its own company's rows independently (e.g., `output/company_id.json`); a separate, single-threaded "compaction" job merges all per-company files into the master dataset — avoids write contention entirely.

---

## 9. Automating validation (Q9)

Three layers, increasing in cost:

1. **Schema/structural validation (free, instant)**: every extracted field must conform to a Pydantic model — right types, required keys present, "Not Found" is a valid literal but an empty string is not, confidence must be one of High/Medium/Low, etc. Reject and re-run on failure.
2. **Grounding/citation validation (cheap, automated)**: for every extracted "Exact Extracted Text," programmatically check it's a near-exact substring match (fuzzy match with high threshold) of the source chunk it claims to cite. If the model paraphrased instead of quoting, or invented a page number, this catches it mechanically — no second LLM call needed.
3. **Semantic/hallucination validation (moderate cost)**: a second LLM pass (can be a cheaper/faster model) is given the source chunk + the extracted claim and asked "is this claim actually supported by this text, yes/no" — a lightweight NLI-style check. This is where cross-model ensembling (Q7) also plugs in cheaply.
4. **Human review gate**: anything that fails (2) or (3), or is marked Low confidence, routes to a review queue (even a simple spreadsheet or Airtable works at this scale) before being promoted to "ground truth: verified."

This is what makes the dataset actually *ground truth* rather than *an LLM's summary of documents* — the distinction matters a lot for anything downstream that will be used as an eval set.

---

## 10. Scaling from 100 → 1,000 → 10,000 without re-architecting

The design above holds at all three scales; only the *implementation* of each component changes:

| Component | 100 companies | 1,000 companies | 10,000 companies |
|---|---|---|---|
| State store | SQLite | Postgres | Postgres (partitioned) or a managed queue (SQS/Pub-Sub) feeding Postgres |
| Vector index | FAISS (local file) | Qdrant (single node) | Qdrant (clustered) or a managed vector DB |
| Orchestration | Prefect (local) | Prefect/Dagster (Cloud, few workers) | Same, autoscaled worker pool (Kubernetes) |
| Storage | Local disk | S3/GCS bucket | S3/GCS bucket + lifecycle policies |
| Human review | Spreadsheet | Airtable / lightweight review UI | Purpose-built review app (e.g., Label Studio) |
| Cost control | Manual spot-check | Sampling-based full audit | Statistical QA sampling + automated drift alerts |

Nothing structural changes — you're scaling the *infrastructure choices at each stage*, not redesigning the DAG. That's the actual test of whether an architecture is "right": does 100→10,000 require new boxes on the diagram, or just bigger boxes? Here it's the latter.

---

## 11. Cost optimization notes

- **Prompt caching**: Anthropic's prompt caching lets you cache the (long) extraction instructions + field schema across all companies — you pay full price once, then a fraction for every subsequent call. This alone can cut extraction cost significantly at 100+ companies since the instructions dominate token count more than any single document chunk.
- **Cheap-model triage, expensive-model extraction**: use a smaller/cheaper model for Stage 1 discovery (finding the right URLs) and Stage 7's semantic validation pass; reserve the strongest model for the actual Stage 6 extraction where accuracy matters most.
- **RAG over full-document stuffing**: already covered in Q6 — this is as much a cost lever as an accuracy one.
- **Batch API**: if using Anthropic's Message Batches API, non-urgent extraction jobs (which this is — it's an offline build, not a live chat) run at a meaningful discount vs. synchronous calls, with turnaround in hours rather than seconds. This is very likely your single best cost lever at 100+ companies.

---

## 12. Suggested folder structure

```
o2v-pipeline/
├── config/
│   ├── company_master_list.csv
│   ├── o2v_field_schema.yaml          # your already-defined fields/definitions
│   └── extraction_prompt.md
├── manifests/
│   └── <company_id>.json              # discovered doc URLs, per company
├── raw_docs/
│   └── <company_id>/<doc_type>/<year>/<filename>
├── parsed/
│   └── <company_id>/<doc_type>/chunks.jsonl   # page-tagged chunks
├── index/
│   └── faiss_or_qdrant/                # vector store
├── extractions/
│   └── <company_id>.json              # raw LLM output, pre-validation
├── validated/
│   └── <company_id>.json              # post schema+grounding checks
├── review_queue/
│   └── flagged_rows.csv               # human-review candidates
├── ground_truth/
│   ├── v1/dataset.parquet
│   ├── v1/dataset.csv                 # export for stakeholders
│   └── CHANGELOG.md                   # versioning history
├── state.db                            # SQLite/Postgres checkpoint store
├── logs/
│   └── run_<timestamp>.log
└── orchestration/
    └── flows.py                        # Prefect/Dagster DAG definitions
```

---

## 13. What I'd actually do first, concretely

Given you already have 2 fields' worth of pilot output (Apple, partially Microsoft) from this chat session:

1. Freeze the O2V field schema + extraction prompt as versioned config files (you already have these — just formalize into `config/`).
2. Stand up SQLite state store + a 100-row company registry from your master list.
3. Write the discovery step as a one-off script (can literally reuse the web_search pattern from this chat, just moved into a script calling the Anthropic API + a search API directly), run once, produces `manifests/`.
4. Write fetch → parse → chunk as straightforward Python (PyMuPDF + a text splitter) — no LLM needed for these stages at all.
5. Write the extraction step calling Claude via the Batch API with prompt caching, output forced into your Pydantic schema.
6. Add the two automated validators (schema + grounding) before anything is written to `ground_truth/`.
7. Only then bring a human reviewer into the loop for Low-confidence rows.

This turns "100 companies through a chat window" into "one script you run overnight," which is really the difference you're asking for.
