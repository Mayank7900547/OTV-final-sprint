"""
Validation checks for the chunking pipeline.

Design decision: a stateless module of functions (not a class), same
shape as `src/parser/validation.py` — every check here takes exactly the
data it needs and raises a specific `chunking.exceptions` subclass, so
`service.py` can call them as a straight-line sequence of guard clauses.
`validate_chunk_candidates` is the one exception — it runs the FATAL
per-set checks below and returns their combined findings rather than
raising on the first problem, because a caller (the service) wants to
know about every issue in a batch of ~dozens of chunks at once, not just
the first one, before deciding whether to persist or reject the set.

Design decision: duplicate-chunk detection (`find_duplicate_chunk_warnings`)
is deliberately NOT one of `validate_chunk_candidates`'s fatal checks —
see that function's own docstring for why, but in short: verified against
real SEC EDGAR proxy statements, substantial (100-400+ char) verbatim
duplicate sentences turned out to be completely legitimate document
structure (a summary/TOC-preview section repeating a sentence that also
appears in the full body section), not a chunker defect. There is no
length threshold that reliably separates "boilerplate noise" from
"genuine repeated content" for this document type, since real, meaningful
sentences legitimately repeat too. Treating any exact-text match as a
fatal, whole-document-killing error was discarding 100% of a real
document's chunks over a handful of ordinary repeated sentences.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from src.chunking.base_chunker import ChunkCandidate, ChunkerConfig
from src.chunking.exceptions import ChunkValidationError, DuplicateChunkingError, EmptyDocumentTextError
from src.chunking.models import Chunk
from src.parser.models import ParsedDocument


def validate_parsed_document_has_text(parsed_document: ParsedDocument) -> None:
    """A parsed document with no extractable text has nothing for Sprint 5 to segment."""
    if not parsed_document.raw_text or not parsed_document.raw_text.strip():
        raise EmptyDocumentTextError(
            f"ParsedDocument {parsed_document.id} has no extractable text to chunk."
        )


def check_duplicate_chunking(
    session: Session, document_version_id: int, *, force: bool
) -> list[Chunk]:
    """
    Look up existing `Chunk` rows for this document version.

    Returns the existing rows (so the service can decide to delete and
    replace them when `force=True`) rather than raising outright — same
    "force is a legitimate re-chunk trigger, not an error" reasoning as
    `parser/validation.py::check_duplicate_parsing`.
    """
    existing = (
        session.query(Chunk)
        .filter(Chunk.document_version_id == document_version_id)
        .order_by(Chunk.chunk_index.asc())
        .all()
    )
    if existing and not force:
        raise DuplicateChunkingError(
            f"DocumentVersion {document_version_id} was already chunked into {len(existing)} "
            f"chunk(s). Pass --force to re-chunk."
        )
    return existing


def validate_chunk_candidates(
    candidates: list[ChunkCandidate], *, config: ChunkerConfig, page_count: int | None
) -> list[str]:
    """
    Run every FATAL per-set validation check and return the list of
    problems found (empty list = valid). Called by the service before
    persisting; a non-empty result means the attempt is recorded as
    FAILED rather than SUCCESS/PARTIAL.

    Duplicate-chunk detection is intentionally excluded from this fatal
    set — call `find_duplicate_chunk_warnings` separately for that; see
    both docstrings for why.
    """
    problems: list[str] = []
    problems.extend(_validate_no_empty_chunks(candidates))
    problems.extend(_validate_chunk_sizes(candidates, config))
    problems.extend(_validate_page_references(candidates, page_count))
    return problems


def find_duplicate_chunk_warnings(candidates: list[ChunkCandidate], config: ChunkerConfig) -> list[str]:
    """
    Flags exact-text duplicates at or above `config.min_chunk_size` as a
    NON-FATAL warning (the caller should log these, not reject the chunk
    set over them) — a substantial duplicate chunk is *worth a look* as a
    possible chunker bug (e.g. an overlap computation re-emitting an
    entire fragment), but per this module's docstring, real-world SEC
    filings routinely and legitimately repeat substantial verbatim text
    as ordinary document structure, so it is not, by itself, reliable
    evidence of a defect worth discarding the document over.

    Duplicates SHORTER than `min_chunk_size` are not reported at all —
    page numbers, running headers, and repeated short section titles are
    a normal, expected side effect of pagination in any real multi-page
    document. A same-length threshold already exists for exactly this
    "too small to be a meaningful standalone unit" judgment —
    `_enforce_min_size` (in `recursive_chunker.py`) treats sub-
    `min_chunk_size` fragments as merge candidates rather than complete
    chunks — so reusing it here means a duplicate this function won't
    even mention is, by the same config value, one the chunker itself
    doesn't consider a real content unit either.
    """
    seen: dict[str, int] = {}
    duplicates: list[str] = []
    for candidate in candidates:
        key = candidate.text
        if len(key.strip()) < config.min_chunk_size:
            continue
        if key in seen:
            duplicates.append(f"chunk {candidate.chunk_index} duplicates chunk {seen[key]}")
        else:
            seen[key] = candidate.chunk_index
    if duplicates:
        return [f"{len(duplicates)} duplicated chunk(s) (non-fatal, logged for review): {duplicates}"]
    return []


def raise_if_invalid(problems: list[str]) -> None:
    if problems:
        raise ChunkValidationError("; ".join(problems))


def _validate_no_empty_chunks(candidates: list[ChunkCandidate]) -> list[str]:
    empty_indices = [c.chunk_index for c in candidates if not c.text.strip()]
    if empty_indices:
        return [f"{len(empty_indices)} empty chunk(s) at index/indices {empty_indices}"]
    return []


def _validate_chunk_sizes(candidates: list[ChunkCandidate], config: ChunkerConfig) -> list[str]:
    oversized = [c.chunk_index for c in candidates if c.character_count > config.max_chunk_size]
    if oversized:
        return [
            f"{len(oversized)} chunk(s) exceed max_chunk_size={config.max_chunk_size}: {oversized}"
        ]
    return []


def _validate_page_references(candidates: list[ChunkCandidate], page_count: int | None) -> list[str]:
    if not page_count:
        return []
    out_of_range = [
        c.chunk_index
        for c in candidates
        if c.page_number is not None and not (1 <= c.page_number <= page_count)
    ]
    if out_of_range:
        return [
            f"{len(out_of_range)} chunk(s) reference a page outside 1..{page_count}: {out_of_range}"
        ]
    return []
