"""
Maps a Sprint 4 `ParsedDocument` row into the `TextBlock` list Sprint 5
chunkers consume.

Design decision: this is the ONLY module that reads `ParsedDocument`'s
storage shape (`page_text` JSON, `metadata_json.headings`) — chunkers
themselves (`recursive_chunker.py`, any future chunker) only ever see
`TextBlock`s, never the ORM row. That's what lets a chunker be unit
tested with plain Python lists and lets this mapping evolve (e.g. to
read a differently-shaped `metadata_json` from a future parser) without
touching chunking logic at all.
"""

from __future__ import annotations

from src.chunking.base_chunker import TextBlock
from src.chunking.metadata import is_heading_like, is_table_like
from src.chunking.utils import split_paragraphs
from src.parser.models import ParsedDocument


def blocks_from_parsed_document(parsed_document: ParsedDocument) -> list[TextBlock]:
    """
    Build an ordered list of `TextBlock`s from a `ParsedDocument`.

    Walks `page_text` (falling back to `raw_text` as a single unpaginated
    page for formats/edge-cases where `page_text` is empty) in order,
    splits each page into paragraphs, and tracks the current section
    title as heading-like paragraphs are encountered — the current
    section persists across paragraphs and pages until the next heading,
    which is what "preserve section hierarchy" means in practice for a
    linear document.
    """
    pages = _pages_from_parsed_document(parsed_document)
    known_headings = _known_headings(parsed_document)

    blocks: list[TextBlock] = []
    current_section: str | None = None

    for page_number, page_text in pages:
        for paragraph in split_paragraphs(page_text):
            if is_heading_like(paragraph, known_headings):
                current_section = paragraph
                blocks.append(
                    TextBlock(
                        text=paragraph,
                        page_number=page_number,
                        section_title=current_section,
                        is_heading=True,
                    )
                )
                continue

            blocks.append(
                TextBlock(
                    text=paragraph,
                    page_number=page_number,
                    section_title=current_section,
                    is_table=is_table_like(paragraph),
                )
            )

    return blocks


def _pages_from_parsed_document(parsed_document: ParsedDocument) -> list[tuple[int | None, str]]:
    page_text = parsed_document.page_text
    if page_text:
        return [(entry.get("page_number"), entry.get("text", "")) for entry in page_text]
    # No paginated structure available (e.g. malformed/legacy row) — treat
    # the whole raw_text as a single unpaginated page rather than dropping
    # it, since Sprint 5 must still be able to chunk it.
    if parsed_document.raw_text:
        return [(None, parsed_document.raw_text)]
    return []


def _known_headings(parsed_document: ParsedDocument) -> set[str]:
    """
    Ground-truth headings for HTML documents, from
    `ParsedDocument.metadata_json["headings"]` (see `parser/html_parser.py`).
    Empty for PDFs and any document without that key — the heuristic in
    `metadata.is_heading_like` is the sole signal in that case.
    """
    metadata = parsed_document.metadata_json or {}
    headings = metadata.get("headings") or []
    return {h.get("text", "").strip() for h in headings if h.get("text", "").strip()}
