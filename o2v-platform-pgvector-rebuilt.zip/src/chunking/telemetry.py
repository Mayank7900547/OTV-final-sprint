"""
In-process metrics collector for a chunking run — mirrors
`src/parser/telemetry.py` (same field-per-counter, thread-locked shape),
since `DocumentChunkingService.chunk_many` uses the same `ThreadPoolExecutor`
batch pattern `DocumentParserService.parse_many` does (chunking is
CPU-bound text processing, not I/O-bound, exactly like parsing — see
`service.py`'s module docstring).
"""

from __future__ import annotations

import threading

from src.chunking.types import ChunkingSummary


class ChunkingTelemetry:
    def __init__(self):
        self.documents_chunked: int = 0
        self.chunks_created: int = 0
        self.total_characters_processed: int = 0
        self.total_duration_seconds: float = 0.0
        self.validation_failures: int = 0
        self.empty_chunks: int = 0
        self.skipped_documents: int = 0
        self._lock = threading.Lock()

    def record_success(self, chunk_count: int, characters_processed: int, duration: float) -> None:
        with self._lock:
            self.documents_chunked += 1
            self.chunks_created += chunk_count
            self.total_characters_processed += characters_processed
            self.total_duration_seconds += duration

    def record_validation_failure(self) -> None:
        with self._lock:
            self.validation_failures += 1

    def record_empty_document(self) -> None:
        with self._lock:
            self.empty_chunks += 1

    def record_skipped(self) -> None:
        with self._lock:
            self.skipped_documents += 1

    def get_summary(self) -> ChunkingSummary:
        with self._lock:
            attempted = self.documents_chunked + self.validation_failures + self.empty_chunks
            success_rate = round(self.documents_chunked / attempted, 4) if attempted else 0.0
            average_chunk_size = (
                round(self.total_characters_processed / self.chunks_created, 1)
                if self.chunks_created
                else 0.0
            )
            average_time = (
                round(self.total_duration_seconds / self.documents_chunked, 3)
                if self.documents_chunked
                else 0.0
            )
            return {
                "documents_chunked": self.documents_chunked,
                "chunks_created": self.chunks_created,
                "average_chunk_size": average_chunk_size,
                "average_processing_time": average_time,
                "validation_failures": self.validation_failures,
                "empty_chunks": self.empty_chunks,
                "skipped_documents": self.skipped_documents,
                "success_rate": success_rate,
            }

    def reset(self) -> None:
        """Used between CLI runs / by tests so telemetry doesn't accumulate across unrelated invocations."""
        with self._lock:
            self.__init__()  # noqa: PLC2801 - deliberate reinitialization, matches parser/telemetry.py's pattern


telemetry = ChunkingTelemetry()
