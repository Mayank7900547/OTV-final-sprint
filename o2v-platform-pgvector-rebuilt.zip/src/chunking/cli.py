"""Typer CLI integration for Sprint 5 Document Chunking — mirrors `src/parser/cli.py`'s shape."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from src.chunking.models import Chunk, ChunkingHistory
from src.chunking.service import DocumentChunkingService
from src.chunking.telemetry import telemetry
from src.chunking.utils import truncate
from src.database.connection import session_scope

chunking_app = typer.Typer(name="chunking", help="Sprint 5 Document Chunking CLI")
chunk_app = typer.Typer(help="Run chunking.")
show_app = typer.Typer(help="Inspect chunks, history, and statistics.")
chunking_app.add_typer(chunk_app, name="chunk")
chunking_app.add_typer(show_app, name="show")

console = Console()


def _print_outcome(outcome: dict) -> None:
    status = outcome.get("status")
    color = {"SUCCESS": "green", "FAILED": "red", "SKIPPED": "yellow"}.get(status, "white")
    line = f"[{color}]{status}[/{color}] ParsedDocument={outcome.get('parsed_document_id')}"
    if status == "SUCCESS":
        line += (
            f" chunks={outcome.get('chunks_created')} "
            f"avg_size={outcome.get('average_chunk_size')} time={outcome.get('chunking_duration')}s"
        )
    elif outcome.get("error"):
        line += f" — {outcome['error']}"
    console.print(line)


def _print_summary() -> None:
    summary = telemetry.get_summary()
    console.print("\n=== CHUNKING TELEMETRY ===")
    console.print(f"Chunked           : {summary['documents_chunked']}")
    console.print(f"Chunks created    : {summary['chunks_created']}")
    console.print(f"Validation fails  : {summary['validation_failures']}")
    console.print(f"Empty documents   : {summary['empty_chunks']}")
    console.print(f"Skipped           : {summary['skipped_documents']}")
    console.print(f"Avg chunk size    : {summary['average_chunk_size']}")
    console.print(f"Avg time (s)      : {summary['average_processing_time']}")
    console.print(f"Success rate      : {summary['success_rate']}")
    console.print("===========================")


# --------------------------------------------------------------------------
# chunk commands
# --------------------------------------------------------------------------


@chunk_app.command("document")
def chunk_document(
    parsed_document_id: int = typer.Argument(..., help="ParsedDocument id to chunk."),
    force: bool = typer.Option(False, "--force", help="Re-chunk even if already chunked."),
) -> None:
    """Chunk a single parsed document."""
    service = DocumentChunkingService()
    with session_scope() as session:
        outcome = service.chunk_parsed_document(session, parsed_document_id, force=force)
    _print_outcome(outcome)


@chunk_app.command("company")
def chunk_company(
    company: str = typer.Argument(..., help="Company name (substring match)."),
    force: bool = typer.Option(False, "--force", help="Re-chunk even if already chunked."),
) -> None:
    """Chunk every eligible parsed document belonging to a company."""
    service = DocumentChunkingService()
    with session_scope() as session:
        ids = service.load_eligible_parsed_document_ids(session, company_filter=company)

    if not ids:
        console.print(f"[yellow]No eligible parsed documents found for '{company}'.[/yellow]")
        return

    results = service.chunk_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


@chunk_app.command("all")
def chunk_all(force: bool = typer.Option(False, "--force", help="Re-chunk even if already chunked.")) -> None:
    """Chunk every eligible parsed document across all companies."""
    service = DocumentChunkingService()
    with session_scope() as session:
        ids = service.load_eligible_parsed_document_ids(session)

    if not ids:
        console.print("[yellow]No eligible parsed documents found.[/yellow]")
        return

    results = service.chunk_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


# --------------------------------------------------------------------------
# retry-failed
# --------------------------------------------------------------------------


@chunking_app.command("retry-failed")
def retry_failed(
    force: bool = typer.Option(True, "--force/--no-force", help="Force re-chunk (default on, since a prior attempt failed).")
) -> None:
    """Retry chunking for every parsed document whose most recent attempt failed."""
    service = DocumentChunkingService()
    with session_scope() as session:
        ids = service.load_failed_parsed_document_ids(session)

    if not ids:
        console.print("[green]No failed parsed documents to retry.[/green]")
        return

    console.print(f"Retrying {len(ids)} failed parsed document(s)...")
    results = service.chunk_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


# --------------------------------------------------------------------------
# show commands
# --------------------------------------------------------------------------


@show_app.command("chunks")
def show_chunks(
    parsed_document_id: int = typer.Argument(None, help="Show chunks for one ParsedDocument. Omit to list recent chunks."),
    limit: int = typer.Option(20, help="Max rows to display when listing."),
) -> None:
    """Show the chunks belonging to a parsed document, or list recently created chunks."""
    with session_scope() as session:
        if parsed_document_id is not None:
            rows = (
                session.query(Chunk)
                .filter(Chunk.parsed_document_id == parsed_document_id)
                .order_by(Chunk.chunk_index.asc())
                .all()
            )
            if not rows:
                console.print(f"[yellow]No chunks found for ParsedDocument {parsed_document_id}.[/yellow]")
                return

            table = Table(title=f"Chunks: ParsedDocument {parsed_document_id} (showing {len(rows)})")
            table.add_column("Index")
            table.add_column("Page")
            table.add_column("Section")
            table.add_column("Chars")
            table.add_column("Tokens")
            table.add_column("Text")
            for r in rows:
                table.add_row(
                    str(r.chunk_index), str(r.page_number or "-"), truncate(r.section_title or "-", 40),
                    str(r.character_count), str(r.token_estimate), truncate(r.text, 80),
                )
            console.print(table)
            return

        rows = session.query(Chunk).order_by(Chunk.creation_timestamp.desc()).limit(limit).all()

    table = Table(title=f"Recently Created Chunks (showing {len(rows)})")
    table.add_column("ChunkId")
    table.add_column("ParsedDoc")
    table.add_column("Index")
    table.add_column("Page")
    table.add_column("Chars")
    table.add_column("Text")
    for r in rows:
        table.add_row(
            r.chunk_id, str(r.parsed_document_id), str(r.chunk_index),
            str(r.page_number or "-"), str(r.character_count), truncate(r.text, 60),
        )
    console.print(table)


@show_app.command("chunk-statistics")
def show_chunk_statistics() -> None:
    """Show cumulative telemetry for this process's chunking activity."""
    _print_summary()


@show_app.command("chunking-history")
def show_chunking_history(parsed_document_id: int = typer.Argument(..., help="ParsedDocument id.")) -> None:
    """Show every recorded chunking attempt for a parsed document."""
    with session_scope() as session:
        rows = (
            session.query(ChunkingHistory)
            .filter(ChunkingHistory.parsed_document_id == parsed_document_id)
            .order_by(ChunkingHistory.attempt_number.asc())
            .all()
        )

    if not rows:
        console.print(f"[yellow]No chunking history for ParsedDocument {parsed_document_id}.[/yellow]")
        return

    table = Table(title=f"Chunking History: ParsedDocument {parsed_document_id}")
    table.add_column("Attempt")
    table.add_column("Chunker")
    table.add_column("Status")
    table.add_column("Chunks")
    table.add_column("Chars")
    table.add_column("Duration (s)")
    table.add_column("Error")
    for h in rows:
        table.add_row(
            str(h.attempt_number), f"{h.chunker_used} v{h.chunker_version}", h.chunking_status.value,
            str(h.chunks_produced or "-"), str(h.characters_processed or "-"),
            f"{h.duration_seconds:.3f}" if h.duration_seconds is not None else "-",
            truncate(h.error_message or "-", 80),
        )
    console.print(table)
