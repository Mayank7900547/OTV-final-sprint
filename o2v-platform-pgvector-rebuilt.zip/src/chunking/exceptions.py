"""
Sprint 5 domain exceptions extending the O2V core error hierarchy.

Design decision: shape mirrors `src/parser/exceptions.py` exactly — a
`ChunkingError` base (parallel to `ParserError`) with specific subclasses
for each distinct failure mode a caller (the CLI, the service layer)
might want to handle differently. Kept flat (all direct children of
`ChunkingError`) for the same reason `ParserError`'s hierarchy is flat:
none of these failure modes specialize one another.
"""

from src.core.exceptions import O2VError


class ChunkingError(O2VError):
    """Base exception for all Sprint 5 document chunking failures."""


class ParsedDocumentNotFoundError(ChunkingError):
    """Raised when the `ParsedDocument` id requested for chunking doesn't exist."""


class ParsedDocumentNotEligibleError(ChunkingError):
    """Raised when a `ParsedDocument`'s status (FAILED/SKIPPED) means it has no usable text to chunk."""


class EmptyDocumentTextError(ChunkingError):
    """Raised when a `ParsedDocument` has no extractable text to segment into chunks."""


class DuplicateChunkingError(ChunkingError):
    """Raised when a parsed document has already been chunked and re-chunking wasn't forced."""


class ChunkerConfigurationError(ChunkingError):
    """Raised when a chunker is configured with an invalid combination of size/overlap settings."""


class ChunkValidationError(ChunkingError):
    """Raised when a generated set of chunks fails post-generation validation (see validation.py)."""
