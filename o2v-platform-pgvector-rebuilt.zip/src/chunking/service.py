"""
Document Chunking Service — Sprint 5 orchestration layer.

Design decision: synchronous, thread-pool-based batch concurrency
(`chunk_many`), not `asyncio` — same reasoning as
`parser/service.py`'s module docstring: chunking is CPU-bound text
processing, exactly like parsing, so a `ThreadPoolExecutor` is the right
concurrency primitive, not a coroutine pool.

Design decision: every public method takes a `Session` explicitly rather
than opening its own — same reasoning as `DocumentParserService`/
`document_service.py`'s service-layer functions: no cross-`asyncio`-boundary
retry/locking logic here that would require the service to own its own
sessions.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from src.chunking.base_chunker import BaseChunker, ChunkerConfig
from src.chunking.exceptions import ChunkingError, ParsedDocumentNotEligibleError
from src.chunking.metadata import estimate_tokens
from src.chunking.models import Chunk, ChunkingHistory, ChunkingStatusEnum
from src.chunking.parser_chunk_mapper import blocks_from_parsed_document
from src.chunking.recursive_chunker import RecursiveChunker
from src.chunking.telemetry import telemetry
from src.chunking.types import ChunkOutcome
from src.chunking.validation import (
    check_duplicate_chunking,
    find_duplicate_chunk_warnings,
    validate_chunk_candidates,
    validate_parsed_document_has_text,
)
from src.config.logging_config import get_logger
from src.config.settings import settings
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.models import ParsedDocument, ParsingStatusEnum

logger = get_logger(__name__)

# ParsedDocument statuses that have usable text to chunk. FAILED/SKIPPED
# parses never produced raw_text worth segmenting.
_ELIGIBLE_PARSE_STATUSES = (ParsingStatusEnum.SUCCESS, ParsingStatusEnum.PARTIAL)


class DocumentChunkingService:
    def __init__(self, *, chunker: BaseChunker | None = None, config: ChunkerConfig | None = None):
        self._chunker = chunker or RecursiveChunker()
        # Overridable only for tests that need deterministic, small
        # chunk sizes without touching global settings — same override
        # pattern `DocumentParserService(parser_kwargs_builder=...)` uses.
        self._config = config or self._default_config()

    def _default_config(self) -> ChunkerConfig:
        return ChunkerConfig(
            chunk_size=settings.chunking_chunk_size,
            chunk_overlap=settings.chunking_chunk_overlap,
            min_chunk_size=settings.chunking_min_chunk_size,
            max_chunk_size=settings.chunking_max_chunk_size,
            separators=list(settings.chunking_separator_hierarchy),
            semantic_chunking_enabled=settings.chunking_semantic_chunking_enabled,
        )

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_eligible_parsed_document_ids(
        self, session: Session, company_filter: str | None = None
    ) -> list[int]:
        """IDs of every SUCCESS/PARTIAL `ParsedDocument` — the population Sprint 5 chunks, per the brief."""
        query = session.query(ParsedDocument.id).filter(
            ParsedDocument.status.in_(_ELIGIBLE_PARSE_STATUSES)
        )
        if company_filter:
            query = (
                query.join(DocumentRegistry, DocumentRegistry.id == ParsedDocument.document_id)
                .join(Company, Company.id == DocumentRegistry.company_id)
                .filter(Company.name.ilike(f"%{company_filter}%"))
            )
        return [row[0] for row in query.all()]

    def load_failed_parsed_document_ids(self, session: Session) -> list[int]:
        """
        IDs of `ParsedDocument`s whose most recent chunking attempt failed
        and that have no `Chunk` rows yet — the population `retry-failed`
        (CLI) operates on.
        """
        chunked_ids = {row[0] for row in session.query(Chunk.parsed_document_id).distinct().all()}
        failed_history_ids = {
            row[0]
            for row in session.query(ChunkingHistory.parsed_document_id)
            .filter(ChunkingHistory.chunking_status == ChunkingStatusEnum.FAILED)
            .all()
        }
        return sorted(failed_history_ids - chunked_ids)

    # ------------------------------------------------------------------
    # Single-document chunking
    # ------------------------------------------------------------------

    def chunk_parsed_document(
        self, session: Session, parsed_document_id: int, *, force: bool = False
    ) -> ChunkOutcome:
        """
        Chunk one `ParsedDocument` and persist the result.

        Never raises `ChunkingError` — every failure mode (not found, not
        eligible, empty text, duplicate-without-force, failed validation)
        is caught and turned into a FAILED/SKIPPED `ChunkOutcome` instead,
        the same "batch-safe" convention `DocumentParserService.
        parse_document_version` follows, so one bad document never aborts
        a `chunk all` run.
        """
        start = time.monotonic()
        parsed_document = session.query(ParsedDocument).filter(ParsedDocument.id == parsed_document_id).first()
        if parsed_document is None:
            telemetry.record_validation_failure()
            return {
                "status": "FAILED",
                "parsed_document_id": parsed_document_id,
                "error": "ParsedDocument not found",
            }

        attempt_number = (
            session.query(ChunkingHistory)
            .filter(ChunkingHistory.parsed_document_id == parsed_document_id)
            .count()
            + 1
        )
        started_at = datetime.now(timezone.utc)

        try:
            self._validate_eligible(parsed_document)
            validate_parsed_document_has_text(parsed_document)
            existing = check_duplicate_chunking(session, parsed_document.document_version_id, force=force)

            blocks = blocks_from_parsed_document(parsed_document)
            candidates = self._chunker.chunk(blocks, config=self._config)

            problems = validate_chunk_candidates(
                candidates, config=self._config, page_count=parsed_document.page_count
            )
            if problems:
                raise ChunkingError("; ".join(problems))

            # Non-fatal — see find_duplicate_chunk_warnings' docstring for
            # why exact-text duplicates are logged for review rather than
            # rejecting the whole chunk set: verified against real SEC
            # EDGAR filings, substantial duplicate text is routinely
            # legitimate document structure (a summary/TOC-preview section
            # repeating a sentence that also appears in the full body),
            # not reliable evidence of a chunker defect by itself.
            duplicate_warnings = find_duplicate_chunk_warnings(candidates, self._config)
            if duplicate_warnings:
                logger.warning(
                    "ParsedDocument %s: %s", parsed_document_id, "; ".join(duplicate_warnings)
                )

            duration = time.monotonic() - start
            rows = self._persist_success(
                session,
                existing=existing,
                parsed_document=parsed_document,
                candidates=candidates,
            )
            self._record_history(
                session,
                parsed_document_id=parsed_document_id,
                attempt_number=attempt_number,
                status=ChunkingStatusEnum.SUCCESS,
                started_at=started_at,
                chunks_produced=len(rows),
                characters_processed=parsed_document.character_count,
                duration=duration,
            )
            session.commit()

            total_chars = sum(r.character_count for r in rows)
            telemetry.record_success(len(rows), total_chars, duration)

            return {
                "status": "SUCCESS",
                "document_id": parsed_document.document_id,
                "document_version_id": parsed_document.document_version_id,
                "parsed_document_id": parsed_document_id,
                "chunks_created": len(rows),
                "average_chunk_size": round(total_chars / len(rows), 1) if rows else 0.0,
                "chunking_duration": round(duration, 3),
            }

        except ParsedDocumentNotEligibleError as exc:
            telemetry.record_skipped()
            return {"status": "SKIPPED", "parsed_document_id": parsed_document_id, "error": str(exc)}

        except ChunkingError as exc:
            from src.chunking.exceptions import DuplicateChunkingError, EmptyDocumentTextError

            duration = time.monotonic() - start
            if isinstance(exc, DuplicateChunkingError):
                telemetry.record_skipped()
                status_for_history = ChunkingStatusEnum.SKIPPED
                outcome_status = "SKIPPED"
            elif isinstance(exc, EmptyDocumentTextError):
                telemetry.record_empty_document()
                status_for_history = ChunkingStatusEnum.FAILED
                outcome_status = "FAILED"
            else:
                telemetry.record_validation_failure()
                status_for_history = ChunkingStatusEnum.FAILED
                outcome_status = "FAILED"

            self._record_failure_history(
                session,
                parsed_document_id=parsed_document_id,
                attempt_number=attempt_number,
                status=status_for_history,
                started_at=started_at,
                error_message=str(exc),
                duration=duration,
            )
            if outcome_status == "FAILED":
                logger.warning("Chunking failed for ParsedDocument %s: %s", parsed_document_id, exc)
            return {"status": outcome_status, "parsed_document_id": parsed_document_id, "error": str(exc)}

    def _validate_eligible(self, parsed_document: ParsedDocument) -> None:
        if parsed_document.status not in _ELIGIBLE_PARSE_STATUSES:
            raise ParsedDocumentNotEligibleError(
                f"ParsedDocument {parsed_document.id} has status {parsed_document.status.value}, "
                f"not SUCCESS/PARTIAL — skipping."
            )

    def _persist_success(
        self,
        session: Session,
        *,
        existing: list[Chunk],
        parsed_document: ParsedDocument,
        candidates,
    ) -> list[Chunk]:
        # A force re-chunk can legitimately produce a different chunk
        # count than the previous run (e.g. after a chunker version bump
        # or a config change) — delete-and-reinsert is simpler and safer
        # than trying to diff/reconcile old and new chunk sets row by row.
        for row in existing:
            session.delete(row)
        if existing:
            session.flush()

        rows: list[Chunk] = []
        for candidate in candidates:
            chunk_uid = f"{parsed_document.document_version_id}:{candidate.chunk_index}"
            row = Chunk(
                chunk_id=chunk_uid,
                document_id=parsed_document.document_id,
                document_version_id=parsed_document.document_version_id,
                parsed_document_id=parsed_document.id,
                chunk_index=candidate.chunk_index,
                page_number=candidate.page_number,
                section_title=candidate.section_title,
                text=candidate.text,
                character_count=candidate.character_count,
                token_estimate=estimate_tokens(candidate.text),
                chunk_metadata=candidate.extra_metadata,
                chunker_used=self._chunker.chunker_name,
                chunker_version=self._chunker.chunker_version,
            )
            session.add(row)
            rows.append(row)
        session.flush()
        return rows

    def _record_history(
        self,
        session: Session,
        *,
        parsed_document_id: int,
        attempt_number: int,
        status: ChunkingStatusEnum,
        started_at: datetime,
        duration: float,
        chunks_produced: int | None = None,
        characters_processed: int | None = None,
        error_message: str | None = None,
    ) -> None:
        session.add(
            ChunkingHistory(
                parsed_document_id=parsed_document_id,
                attempt_number=attempt_number,
                chunker_used=self._chunker.chunker_name,
                chunker_version=self._chunker.chunker_version,
                chunking_status=status,
                error_message=error_message,
                chunks_produced=chunks_produced,
                characters_processed=characters_processed,
                started_at=started_at,
                duration_seconds=duration,
            )
        )

    def _record_failure_history(
        self,
        session: Session,
        *,
        parsed_document_id: int,
        attempt_number: int,
        status: ChunkingStatusEnum,
        started_at: datetime,
        duration: float,
        error_message: str,
    ) -> None:
        session.add(
            ChunkingHistory(
                parsed_document_id=parsed_document_id,
                attempt_number=attempt_number,
                chunker_used=self._chunker.chunker_name,
                chunker_version=self._chunker.chunker_version,
                chunking_status=status,
                error_message=error_message,
                started_at=started_at,
                duration_seconds=duration,
            )
        )
        session.commit()

    # ------------------------------------------------------------------
    # Batch chunking
    # ------------------------------------------------------------------

    def chunk_many(
        self, session_factory, parsed_document_ids: list[int], *, force: bool = False
    ) -> list[ChunkOutcome]:
        """
        Chunk many parsed documents concurrently.

        `session_factory` (not a single shared `Session`) is required
        here for the same reason `DocumentParserService.parse_many`
        requires it: each worker thread needs its own SQLAlchemy session,
        since a `Session` is not thread-safe.
        """
        results: list[ChunkOutcome] = []

        def _run(parsed_document_id: int) -> ChunkOutcome:
            with session_factory() as worker_session:
                return self.chunk_parsed_document(worker_session, parsed_document_id, force=force)

        workers = max(1, settings.chunking_parallel_workers)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            for outcome in executor.map(_run, parsed_document_ids):
                results.append(outcome)
        return results
