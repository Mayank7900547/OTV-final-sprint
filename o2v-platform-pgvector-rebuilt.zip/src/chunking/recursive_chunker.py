"""
Recursive text-splitting chunker.

Design decision: hand-rolled, not LangChain's `RecursiveCharacterTextSplitter`
— the Sprint 5 brief explicitly excludes LangChain as a dependency. The
algorithm below follows the same well-established two-phase shape that
splitter is known for (recursively break oversized text on a separator
hierarchy, then greedily re-merge undersized fragments up to the target
size with overlap), just implemented directly against this codebase's
`TextBlock`/`ChunkCandidate` value objects instead of a generic
`Document` type.

Design decision: fragmentation and merging both happen PER `TextBlock`,
never across two blocks. A block boundary is a paragraph and (via
`parser_chunk_mapper.py`) a page/section boundary — merging fragments
across that boundary would mean a single chunk's `page_number` or
`section_title` no longer accurately describes all of its text, which
directly conflicts with "preserve page references" / "preserve section
hierarchy". The cost is that block-final chunks are sometimes smaller
than `chunk_size`; `_enforce_min_size` folds those into the previous
chunk where that's still possible without exceeding `max_chunk_size`.
"""

from __future__ import annotations

from src.chunking.base_chunker import BaseChunker, ChunkCandidate, ChunkerConfig, TextBlock


class RecursiveChunker(BaseChunker):
    chunker_name = "recursive_chunker"
    chunker_version = "1.0.0"

    def split_blocks(self, blocks: list[TextBlock], *, config: ChunkerConfig) -> list[ChunkCandidate]:
        candidates: list[ChunkCandidate] = []
        for block in blocks:
            candidates.extend(self._chunk_block(block, config))
        return candidates

    # ------------------------------------------------------------------
    # Per-block chunking
    # ------------------------------------------------------------------

    def _chunk_block(self, block: TextBlock, config: ChunkerConfig) -> list[ChunkCandidate]:
        if not block.text.strip():
            return []

        if block.is_table:
            # `_fragments_for_table` already respects `max_chunk_size` and
            # splits only on row boundaries — running these fragments
            # through `_merge_fragments`'s character-level overlap would
            # slice a trailing fragment's tail out of the MIDDLE of a
            # row, corrupting exactly the thing "avoid splitting tables"
            # protects. So table fragments are emitted as-is, no overlap.
            merged_texts = self._fragments_for_table(block.text, config)
        elif block.is_heading:
            merged_texts = [block.text]
        else:
            fragments = _split_text(block.text, config.separators, config.chunk_size)
            merged_texts = self._merge_fragments(fragments, config)
            merged_texts = self._enforce_min_size(merged_texts, config)

        return [
            ChunkCandidate(
                text=text,
                page_number=block.page_number,
                section_title=block.section_title,
                extra_metadata={
                    "is_heading": block.is_heading,
                    "is_table": block.is_table,
                    "separator_hierarchy": config.separators,
                },
            )
            for text in merged_texts
            if text.strip()
        ]

    def _fragments_for_table(self, text: str, config: ChunkerConfig) -> list[str]:
        """
        Tables are kept whole whenever they fit within `max_chunk_size`
        ("avoid splitting tables when possible"). Only a table too large
        even for `max_chunk_size` is split, and even then only on row
        (line) boundaries, never mid-row.
        """
        if len(text) <= config.max_chunk_size:
            return [text]

        lines = text.splitlines()
        fragments: list[str] = []
        buffer_lines: list[str] = []
        buffer_len = 0
        for line in lines:
            added_len = len(line) + (1 if buffer_lines else 0)
            if buffer_lines and buffer_len + added_len > config.max_chunk_size:
                fragments.append("\n".join(buffer_lines))
                buffer_lines, buffer_len = [line], len(line)
            else:
                buffer_lines.append(line)
                buffer_len += added_len
        if buffer_lines:
            fragments.append("\n".join(buffer_lines))
        return fragments

    def _merge_fragments(self, fragments: list[str], config: ChunkerConfig) -> list[str]:
        """
        Greedily re-merge fragments up to `chunk_size`, carrying
        `chunk_overlap` trailing characters of a finished chunk into the
        start of the next one — the standard sliding-window overlap
        pattern, applied only at merge points within this block.
        """
        chunks: list[str] = []
        buffer = ""

        for fragment in fragments:
            candidate = f"{buffer}\n\n{fragment}" if buffer else fragment
            if len(candidate) <= config.chunk_size or not buffer:
                buffer = candidate
                continue

            chunks.append(buffer)
            overlap_text = buffer[-config.chunk_overlap :].strip() if config.chunk_overlap > 0 else ""
            buffer = f"{overlap_text}\n\n{fragment}" if overlap_text else fragment

        if buffer:
            chunks.append(buffer)
        return chunks

    def _enforce_min_size(self, chunks: list[str], config: ChunkerConfig) -> list[str]:
        """
        Fold a trailing undersized chunk into its predecessor when doing
        so still fits within `max_chunk_size` — prevents a block ending
        with one short leftover paragraph from becoming its own tiny
        chunk when it could reasonably join the previous one.
        """
        if len(chunks) < 2:
            return chunks

        result = chunks[:-1]
        last = chunks[-1]
        if len(last) < config.min_chunk_size and len(result[-1]) + 2 + len(last) <= config.max_chunk_size:
            result[-1] = f"{result[-1]}\n\n{last}"
        else:
            result.append(last)
        return result


def _split_text(text: str, separators: list[str], max_size: int) -> list[str]:
    """
    Recursively split `text` on the first separator in `separators` that
    actually breaks it into pieces, falling through to the next separator
    for any piece still too large, down to a hard character-boundary
    split if every separator is exhausted (`separators` always ends with
    `""` in `ChunkerConfig`'s default, which triggers that fallback).

    This — plus `_merge_fragments` re-joining the pieces afterward — is
    the "recursive" in `RecursiveChunker`: unlike a naive fixed-width
    splitter, a boundary is only introduced where the text already had
    one (paragraph, then sentence, then word), and only as a last resort
    does a chunk boundary fall in the middle of a word.
    """
    stripped = text.strip()
    if not stripped:
        return []
    if len(stripped) <= max_size:
        return [stripped]
    if not separators:
        return [stripped[i : i + max_size] for i in range(0, len(stripped), max_size)]

    separator, *rest = separators

    if separator == "":
        return [stripped[i : i + max_size] for i in range(0, len(stripped), max_size)]

    parts = [p for p in stripped.split(separator) if p.strip()]
    if len(parts) <= 1:
        # This separator didn't actually break anything up (e.g. no blank
        # lines in a wall of text) — fall through to the next one.
        return _split_text(stripped, rest, max_size)

    fragments: list[str] = []
    buffer = ""
    for part in parts:
        candidate = f"{buffer}{separator}{part}" if buffer else part
        if len(candidate) <= max_size:
            buffer = candidate
            continue

        if buffer:
            fragments.append(buffer)
        if len(part) <= max_size:
            buffer = part
        else:
            fragments.extend(_split_text(part, rest, max_size))
            buffer = ""

    if buffer:
        fragments.append(buffer)
    return fragments
