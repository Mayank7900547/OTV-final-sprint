"""
Database models for Sprint 5 Document Chunking.

Design decision: shape mirrors `src/parser/models.py` exactly — `Integer`
autoincrement primary keys (not UUID) for these sprint-specific tables,
`relationship(..., backref=...)` for navigation from `ParsedDocument`, and
a `str, enum.Enum` status vocabulary. `ParsedDocument`/`ParsingHistory`
already established this pattern for "something derived from a document
version"; `Chunk`/`ChunkingHistory` follow it for the same reason.

`Chunk` links to `ParsedDocument` (not directly to `DocumentVersion` or
`DocumentRegistry`) because Sprint 5 segments the specific EXTRACTED TEXT
a parser produced — `ParsedDocument.raw_text`/`page_text` is what's
actually being split. `document_id` and `document_version_id` are carried
too, denormalized, purely so a query like "all chunks for this company's
Annual Reports" doesn't need to join through `parsed_documents` every
time; neither is the chunking target itself (see `parser/models.py`'s
docstring for the identical reasoning applied to `ParsedDocument.document_id`).

`chunk_id` is a separate, deterministic, human-readable identifier
(`"{document_version_id}:{chunk_index}"`) distinct from the integer `id`
primary key — it exists because a chunk's *identity* should be stable and
reconstructable from what produced it (same document version + same
position always yields the same `chunk_id`), which is the literal
definition of "deterministic chunks" from the Sprint 5 brief. The
autoincrement `id` remains the primary key/FK target because that's the
established convention for every other sprint-specific table in this
codebase.
"""

import enum

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

from src.database.base import Base


class ChunkingStatusEnum(str, enum.Enum):
    SUCCESS = "SUCCESS"
    PARTIAL = "PARTIAL"  # some chunks produced but validation flagged non-fatal issues
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"  # e.g. parsed document not eligible, duplicate chunking without --force


class Chunk(Base):
    """
    One semantic segment of a `ParsedDocument`'s extracted text.

    The `uq_chunk_version_index` constraint is the "no duplicated chunks"
    / "duplicate chunking prevention" requirement from the Sprint 5
    brief's validation section — re-chunking the same parsed document
    without `--force` is rejected at the service layer (see
    `validation.py`) before it would ever hit this constraint, but the DB
    constraint remains the last line of defense, matching the same
    belt-and-suspenders pattern `ParsedDocument.uq_parsed_document_version`
    already established in Sprint 4.
    """

    __tablename__ = "chunks"
    __table_args__ = (
        UniqueConstraint("document_version_id", "chunk_index", name="uq_chunk_version_index"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)

    chunk_id = Column(String(64), nullable=False, index=True)

    document_id = Column(
        PG_UUID(as_uuid=True),
        ForeignKey("document_registry.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    document_version_id = Column(
        Integer,
        ForeignKey("document_versions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    parsed_document_id = Column(
        Integer,
        ForeignKey("parsed_documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    chunk_index = Column(Integer, nullable=False)
    page_number = Column(Integer, nullable=True)
    section_title = Column(String(1000), nullable=True)

    text = Column(Text, nullable=False)
    character_count = Column(Integer, nullable=False, default=0)
    token_estimate = Column(Integer, nullable=False, default=0)

    # Chunk-generation details that don't warrant their own column (the
    # separator that produced the split, overlap character counts, source
    # page span for chunks that cross a page boundary, table/heading
    # flags) — kept as JSON for the same reason `ParsedDocument.metadata_json`
    # is: format/strategy-specific detail that would otherwise grow the
    # table's column count for every new chunker implementation.
    chunk_metadata = Column(JSON, nullable=True)

    chunker_used = Column(String(100), nullable=False)
    chunker_version = Column(String(20), nullable=False)

    creation_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    parsed_document = relationship("ParsedDocument", backref="chunks")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<Chunk id={self.id} chunk_id={self.chunk_id!r} "
            f"parsed_document_id={self.parsed_document_id} index={self.chunk_index}>"
        )


class ChunkingHistory(Base):
    """
    Append-only log of every chunking ATTEMPT for a parsed document,
    success or failure — mirrors `ParsingHistory`'s role for the parsing
    subsystem. `Chunk` rows hold only the latest good result; this table
    is what `show chunk statistics` / `retry failed chunking` (CLI) read
    from.
    """

    __tablename__ = "chunking_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    parsed_document_id = Column(
        Integer,
        ForeignKey("parsed_documents.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    attempt_number = Column(Integer, nullable=False, default=1)
    chunker_used = Column(String(100), nullable=False)
    chunker_version = Column(String(20), nullable=False)
    chunking_status = Column(SQLEnum(ChunkingStatusEnum), nullable=False)
    error_message = Column(Text, nullable=True)
    chunks_produced = Column(Integer, nullable=True)
    characters_processed = Column(Integer, nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=False)
    completed_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    duration_seconds = Column(Float, nullable=True)

    parsed_document = relationship("ParsedDocument", backref="chunking_history")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<ChunkingHistory id={self.id} parsed_document_id={self.parsed_document_id} "
            f"status={self.chunking_status} attempt={self.attempt_number}>"
        )
