"""
Abstract base chunker and the value objects that flow through the
chunking pipeline.

Design decision: chunkers consume/produce plain dataclasses (`TextBlock`
in, `ChunkCandidate` out), NOT `Chunk` ORM rows — same reasoning as
`parser/base_parser.py`'s `ExtractedContent`: keeping the chunker layer
persistence-agnostic is what makes `RecursiveChunker` independently
unit-testable without a database, and is what the Sprint 5 brief's
"support future semantic chunking" requirement actually depends on — a
future `SemanticChunker` only needs to be a second `BaseChunker`
subclass; `DocumentChunkingService` (see service.py) remains the only
place a `ChunkCandidate` gets turned into a `Chunk` row.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from src.chunking.exceptions import ChunkerConfigurationError


@dataclass
class TextBlock:
    """
    One structural unit of a parsed document's text, as produced by
    `parser_chunk_mapper.py` — roughly "one paragraph, on one page, in
    one section". This is the granularity chunk boundaries are allowed to
    fall between; a chunker should never split *within* the source text
    of a single `TextBlock` unless that block alone exceeds
    `ChunkerConfig.max_chunk_size`.
    """

    text: str
    page_number: int | None
    section_title: str | None
    is_heading: bool = False
    is_table: bool = False


@dataclass
class ChunkCandidate:
    """
    A single not-yet-persisted chunk produced by a chunker.

    `chunk_index` is assigned by `BaseChunker.chunk()` after a subclass
    returns its candidates (see `_propagate_metadata` below), so
    individual chunker implementations never need to track a running
    counter themselves.
    """

    text: str
    page_number: int | None
    section_title: str | None
    chunk_index: int = 0
    extra_metadata: dict = field(default_factory=dict)

    @property
    def character_count(self) -> int:
        return len(self.text)


@dataclass
class ChunkerConfig:
    """
    Configuration shared by every chunker implementation — the Sprint 5
    brief's "support configurable chunk size / overlap / min / max /
    separator hierarchy / future semantic chunking flag" requirements,
    collected in one place so `service.py` builds exactly one config
    object from `settings.py` and hands it to whichever chunker is active.
    """

    chunk_size: int = 1000
    chunk_overlap: int = 150
    min_chunk_size: int = 100
    max_chunk_size: int = 2000
    separators: list[str] = field(default_factory=lambda: ["\n\n", "\n", ". ", " ", ""])
    semantic_chunking_enabled: bool = False  # placeholder flag — no semantic chunker exists yet in Sprint 5

    def __post_init__(self) -> None:
        if self.chunk_size <= 0:
            raise ChunkerConfigurationError(f"chunk_size must be positive, got {self.chunk_size}.")
        if self.chunk_overlap < 0:
            raise ChunkerConfigurationError(f"chunk_overlap must be >= 0, got {self.chunk_overlap}.")
        if self.chunk_overlap >= self.chunk_size:
            raise ChunkerConfigurationError(
                f"chunk_overlap ({self.chunk_overlap}) must be smaller than chunk_size ({self.chunk_size})."
            )
        if self.min_chunk_size <= 0:
            raise ChunkerConfigurationError(f"min_chunk_size must be positive, got {self.min_chunk_size}.")
        if self.max_chunk_size < self.chunk_size:
            raise ChunkerConfigurationError(
                f"max_chunk_size ({self.max_chunk_size}) must be >= chunk_size ({self.chunk_size})."
            )
        if self.min_chunk_size > self.chunk_size:
            raise ChunkerConfigurationError(
                f"min_chunk_size ({self.min_chunk_size}) must be <= chunk_size ({self.chunk_size})."
            )


class BaseChunker(ABC):
    """
    Common interface every chunking strategy must implement.

    Design decision: `split_blocks()` is the single abstract method a
    subclass must provide — chunk-index assignment (shared metadata
    propagation) lives here in the base class, applied uniformly after
    any subclass runs, so a minimal new chunker really is "a subclass +
    one method" per the same extensibility bar Sprint 4's `BaseParser`
    set for parsers.
    """

    #: Short machine-readable name recorded on `Chunk.chunker_used`.
    chunker_name: str = "base"

    #: Bumped when a chunker's splitting logic changes in a way that would
    #: produce different chunks for the same input — recorded on every
    #: `ChunkingHistory` row, mirroring `BaseParser.parser_version`.
    chunker_version: str = "1.0.0"

    @abstractmethod
    def split_blocks(self, blocks: list[TextBlock], *, config: ChunkerConfig) -> list[ChunkCandidate]:
        """Split `blocks` into `ChunkCandidate`s according to `config`. Subclasses implement the algorithm."""

    def chunk(self, blocks: list[TextBlock], *, config: ChunkerConfig) -> list[ChunkCandidate]:
        """Public entry point: run the subclass's algorithm, then apply shared metadata propagation."""
        candidates = self.split_blocks(blocks, config=config)
        return self._propagate_metadata(candidates)

    def _propagate_metadata(self, candidates: list[ChunkCandidate]) -> list[ChunkCandidate]:
        """Assign sequential, deterministic `chunk_index` values — the one piece of metadata every chunker shares."""
        for index, candidate in enumerate(candidates):
            candidate.chunk_index = index
        return candidates
