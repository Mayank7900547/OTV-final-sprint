"""
Sprint 5 — Document Chunking & Content Segmentation.

Transforms `ParsedDocument` rows (Sprint 4 output) into deterministic,
metadata-rich `Chunk` rows suitable for a future embedding/retrieval
sprint to consume. This package deliberately does NOT do embeddings,
vector storage, retrieval, or LLM extraction — see each module's
docstring for how the boundary with Sprint 4 (upstream) and future
sprints (downstream) is kept clean.
"""
