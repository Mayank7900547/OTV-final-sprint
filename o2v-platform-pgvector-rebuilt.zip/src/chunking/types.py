"""Shared type definitions for Sprint 5 Document Chunking — mirrors `src/parser/types.py`."""

from typing import TypedDict
from uuid import UUID


class ChunkOutcome(TypedDict, total=False):
    """Standardized result dictionary returned after chunking one parsed document."""

    status: str  # SUCCESS, FAILED, PARTIAL, SKIPPED
    document_id: UUID  # UUID of the parent Document Registry entry
    document_version_id: int  # Integer id of the DocumentVersion the text came from
    parsed_document_id: int  # Integer id of the ParsedDocument that was chunked
    chunks_created: int
    average_chunk_size: float
    chunking_duration: float
    error: str  # Detailed error message (if status is FAILED)


class ChunkingSummary(TypedDict):
    """Aggregated telemetry summary for a chunking run — see `telemetry.py`."""

    documents_chunked: int
    chunks_created: int
    average_chunk_size: float
    average_processing_time: float
    validation_failures: int
    empty_chunks: int
    skipped_documents: int
    success_rate: float
