"""
Metadata-derivation helpers for the chunking pipeline: token estimation,
and the heading/table heuristics `parser_chunk_mapper.py` uses to
propagate section hierarchy and avoid splitting tabular content.

Design decision: no `tiktoken`/model-specific tokenizer dependency.
`requirements.txt` deliberately excludes it per the Sprint 5 scope ("NO
embeddings" implies no embedding-model-specific tokenizer either) — a
~4-characters-per-token heuristic is the standard rough estimate for
English text and is good enough for `Chunk.token_estimate`'s stated
purpose (sizing/telemetry), not exact billing or context-window math.
Whichever embedding model a later sprint chooses can compute an exact
count itself at that point.
"""

from __future__ import annotations

import re

_CHARS_PER_TOKEN_ESTIMATE = 4.0
_HEADING_MAX_LEN = 100
_TABLE_COLUMN_SPLIT_RE = re.compile(r"(\t|\s{2,}|\|)")


def estimate_tokens(text: str) -> int:
    """Rough token estimate — see module docstring for why this isn't an exact count."""
    if not text or not text.strip():
        return 0
    return max(1, round(len(text) / _CHARS_PER_TOKEN_ESTIMATE))


def is_heading_like(paragraph: str, known_headings: set[str] | None = None) -> bool:
    """
    Heuristic: is this paragraph more likely a section heading than body
    text?

    Used as a fallback for document types with no structured heading
    metadata (PDF). When `known_headings` is provided (HTML documents,
    whose `metadata_json.headings` — see `parser/html_parser.py` — gives
    us ground truth), an exact match always wins over the heuristic.
    """
    stripped = paragraph.strip()
    if not stripped:
        return False
    if known_headings and stripped in known_headings:
        return True
    if "\n" in stripped:
        return False
    if len(stripped) > _HEADING_MAX_LEN:
        return False
    if stripped.endswith((".", ",", ";", ":")):
        return False
    words = stripped.split()
    alpha_words = [w for w in words if w[:1].isalpha()]
    if not alpha_words:
        return False
    capitalized_ratio = sum(1 for w in alpha_words if w[0].isupper()) / len(alpha_words)
    return capitalized_ratio >= 0.7


def is_table_like(paragraph: str) -> bool:
    """
    Heuristic: does this paragraph look like tabular data (multiple
    columns per line, repeated across several lines) rather than prose?

    Deliberately conservative (requires 2+ column-separators on a
    majority of lines, and at least 2 lines) so ordinary prose with an
    occasional double space isn't misclassified — a false positive here
    just means a paragraph is kept atomic when it didn't need to be,
    which is a safe failure mode for "avoid splitting tables when possible".
    """
    lines = [line for line in paragraph.splitlines() if line.strip()]
    if len(lines) < 2:
        return False
    # A line with >=2 columns (i.e. >=1 column separator) reads as a table
    # row; requiring only one separator (not two) is what lets a simple
    # two-column "Name | Value" style table register, while still needing
    # a MAJORITY of lines in the paragraph to qualify before the whole
    # paragraph is treated as tabular.
    tabular_lines = sum(1 for line in lines if len(_TABLE_COLUMN_SPLIT_RE.findall(line)) >= 1)
    return (tabular_lines / len(lines)) >= 0.6
