"""Generic text-handling utilities shared by chunkers — mirrors `src/parser/utils.py`'s shape."""

from __future__ import annotations

import re

_BLANK_LINE_RE = re.compile(r"\n\s*\n+")


def split_paragraphs(text: str) -> list[str]:
    """
    Split `text` into paragraphs on blank-line boundaries.

    Used by `parser_chunk_mapper.py` to break a page's raw text into the
    units the chunker reasons about (a paragraph is the smallest span a
    chunk boundary should prefer to fall on, per the Sprint 5 brief's
    "respect paragraph boundaries" requirement).
    """
    if not text:
        return []
    parts = _BLANK_LINE_RE.split(text.strip())
    return [p.strip() for p in parts if p.strip()]


_SENTENCE_BOUNDARY_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'])")


def split_sentences(text: str) -> list[str]:
    """
    Best-effort sentence splitter used only as a fallback separator inside
    the recursive splitter — not a general-purpose NLP sentence tokenizer.
    Good enough for "respect sentence boundaries where possible" without
    adding an NLP dependency Sprint 5 doesn't otherwise need.
    """
    if not text:
        return []
    sentences = _SENTENCE_BOUNDARY_RE.split(text.strip())
    return [s.strip() for s in sentences if s.strip()]


def truncate(text: str, max_chars: int) -> str:
    """Truncate `text` to `max_chars`, appending a marker if it was cut — used for CLI previews only."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + " [...truncated]"
