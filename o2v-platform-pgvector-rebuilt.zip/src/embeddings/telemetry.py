"""
In-process metrics collector for an embedding run — mirrors
`src/chunking/telemetry.py`'s shape, extended with the fields the Sprint
6 brief specifically calls out that chunking telemetry didn't need:
tokens processed, batch throughput, retry count, and active provider.
"""

from __future__ import annotations

import threading

from src.embeddings.types import EmbeddingSummary


class EmbeddingTelemetry:
    def __init__(self):
        self.chunks_embedded: int = 0
        self.tokens_processed: int = 0
        self.total_duration_seconds: float = 0.0
        self.failed_embeddings: int = 0
        self.retry_count: int = 0
        self.skipped_chunks: int = 0
        self.active_provider: str = ""
        self.batches_processed: int = 0
        self.total_batch_size: int = 0
        self._lock = threading.Lock()

    def record_success(self, *, tokens: int, duration: float, provider: str) -> None:
        with self._lock:
            self.chunks_embedded += 1
            self.tokens_processed += tokens
            self.total_duration_seconds += duration
            self.active_provider = provider

    def record_batch(self, batch_size: int) -> None:
        with self._lock:
            self.batches_processed += 1
            self.total_batch_size += batch_size

    def record_failure(self) -> None:
        with self._lock:
            self.failed_embeddings += 1

    def record_retry(self) -> None:
        with self._lock:
            self.retry_count += 1

    def record_skipped(self) -> None:
        with self._lock:
            self.skipped_chunks += 1

    def get_summary(self) -> EmbeddingSummary:
        with self._lock:
            attempted = self.chunks_embedded + self.failed_embeddings
            success_rate = round(self.chunks_embedded / attempted, 4) if attempted else 0.0
            average_latency = (
                round(self.total_duration_seconds / self.chunks_embedded, 4) if self.chunks_embedded else 0.0
            )
            batch_throughput = (
                round(self.total_batch_size / self.total_duration_seconds, 2)
                if self.total_duration_seconds > 0
                else 0.0
            )
            return {
                "chunks_embedded": self.chunks_embedded,
                "tokens_processed": self.tokens_processed,
                "average_embedding_latency": average_latency,
                "batch_throughput": batch_throughput,
                "failed_embeddings": self.failed_embeddings,
                "retry_count": self.retry_count,
                "active_provider": self.active_provider,
                "skipped_chunks": self.skipped_chunks,
                "success_rate": success_rate,
            }

    def reset(self) -> None:
        """Used between CLI runs / by tests so telemetry doesn't accumulate across unrelated invocations."""
        with self._lock:
            self.__init__()  # noqa: PLC2801 - deliberate reinitialization, matches chunking/telemetry.py's pattern


telemetry = EmbeddingTelemetry()
