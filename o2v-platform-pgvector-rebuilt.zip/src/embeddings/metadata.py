"""
Builds the `VectorMetadata` every stored vector must carry, per the
Sprint 6 brief's "Vector Metadata" section.

Design decision: this is the ONLY module that reads across `Chunk` +
`DocumentRegistry` + `Company` to assemble metadata — same "one seam"
reasoning as `chunking/parser_chunk_mapper.py` being the sole reader of
`ParsedDocument`'s storage shape. `embedding_service.py` and
`vector_store.py` only ever see the resulting `VectorMetadata` dict, so
if a future sprint needs to add or rename a metadata field, this is the
one place that changes.
"""

from __future__ import annotations

from src.chunking.models import Chunk
from src.models.company import Company
from src.models.document import DocumentRegistry


def build_vector_metadata(chunk: Chunk, document: DocumentRegistry, company: Company) -> dict:
    """
    Assemble the required vector metadata fields (company, document_id,
    chunk_id, page_number, section_title, document_type, creation_timestamp,
    chunk_index) from a `Chunk` and its ancestor `DocumentRegistry`/`Company`
    rows. Returns a plain dict (not `VectorMetadata` directly) since
    `document_id`/`creation_timestamp` need string coercion for JSON
    storage — see inline comments.
    """
    return {
        "company": company.name,
        # UUID / datetime aren't JSON-serializable as-is; every backend
        # (Postgres JSON column today, an external vector DB's metadata
        # payload tomorrow) needs plain JSON-safe values.
        "document_id": str(document.id),
        "chunk_id": chunk.chunk_id,
        "page_number": chunk.page_number,
        "section_title": chunk.section_title,
        "document_type": document.document_type,
        "creation_timestamp": chunk.creation_timestamp.isoformat() if chunk.creation_timestamp else None,
        "chunk_index": chunk.chunk_index,
    }
