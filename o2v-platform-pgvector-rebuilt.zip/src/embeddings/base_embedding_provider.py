"""
Abstract base embedding provider — the plugin boundary every embedding
provider (OpenAI today; Nomic/BGE/E5/Sentence Transformers/Ollama/LM
Studio/Azure OpenAI as architecture placeholders — see
`embedding_factory.py`) must implement.

Design decision: mirrors `src/chunking/base_chunker.py`'s shape closely
— an abstract method a subclass must implement (`embed_batch`), plus
shared behavior in the base class (`embed_single`, `validate_dimension`)
so a minimal new provider really is "one class, one method", per the
brief's "Future providers should require only: 1. Create provider class.
2. Register provider. 3. No architecture changes."
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from src.embeddings.exceptions import DimensionMismatchError, InvalidProviderResponseError
from src.embeddings.types import EmbeddingVector


class BaseEmbeddingProvider(ABC):
    """
    Common interface every embedding provider must implement.

    `embedding_dimension` is an instance attribute (not a class constant)
    because some providers — OpenAI's `text-embedding-3-*` family among
    them — support a configurable output dimension for the same model
    name, so the dimension a given provider INSTANCE produces depends on
    how it was constructed, not just which class it is.
    """

    #: Short machine-readable name recorded on `Embedding.provider`.
    provider_name: str = "base"

    def __init__(self, *, model_name: str, model_version: str, embedding_dimension: int):
        self.model_name = model_name
        self.model_version = model_version
        self.embedding_dimension = embedding_dimension

    @abstractmethod
    def embed_batch(self, texts: list[str]) -> list[EmbeddingVector]:
        """
        Embed a batch of texts, returning one vector per input text, in
        the same order. Subclasses implement the actual provider call
        (HTTP request, local model inference, etc.) — everything else
        (dimension validation, single-text convenience, batching size
        limits) is handled uniformly by the base class / service layer.
        """

    def embed_single(self, text: str) -> EmbeddingVector:
        """Convenience wrapper for embedding exactly one text — the batch-of-one case every provider gets for free."""
        vectors = self.embed_batch([text])
        if len(vectors) != 1:
            raise InvalidProviderResponseError(
                f"{self.provider_name}: expected 1 vector for 1 input text, got {len(vectors)}."
            )
        return vectors[0]

    def validate_dimension(self, vector: EmbeddingVector) -> None:
        """Raise `DimensionMismatchError` if `vector`'s length doesn't match this provider's declared dimension."""
        if len(vector) != self.embedding_dimension:
            raise DimensionMismatchError(
                f"{self.provider_name} ({self.model_name}) declared embedding_dimension="
                f"{self.embedding_dimension} but returned a vector of length {len(vector)}."
            )

    def validate_batch_response(self, texts: list[str], vectors: list[EmbeddingVector]) -> None:
        """
        Shared response-shape validation every provider's `embed_batch`
        result must satisfy, regardless of provider — one vector per
        input text, each of the declared dimension, none empty.
        """
        if len(vectors) != len(texts):
            raise InvalidProviderResponseError(
                f"{self.provider_name}: requested {len(texts)} embeddings, provider returned {len(vectors)}."
            )
        for index, vector in enumerate(vectors):
            if not vector:
                raise InvalidProviderResponseError(f"{self.provider_name}: returned an empty vector at index {index}.")
            self.validate_dimension(vector)

    def health_check(self, timeout: float | None = None) -> bool:
        """
        Cheap, fast "is this provider even reachable right now" probe —
        deliberately NOT the same code path as `embed_batch`. Found in
        practice (a real overnight run against a resource-starved local
        Ollama server): without this, a dead/unreachable provider is only
        discovered after burning through a full retry budget's worth of
        full-length timeouts on the first real batch — with hundreds of
        batches queued, that can mean hours before anyone notices nothing
        is succeeding. This runs BEFORE `embed_many` starts working
        through the queue, so a dead provider is caught in `timeout`
        seconds, not by attrition.

        Default implementation: a batch-of-one `embed_batch(["ping"])`
        call — works for any provider without every subclass needing to
        implement it, but does exercise the real (possibly slow) code
        path. Providers with a cheaper, dedicated way to check
        reachability (e.g. Ollama's own root endpoint, independent of
        model-loading time) should override this with something faster —
        see `OllamaEmbeddingProvider.health_check`.

        Returns True/False rather than raising — this is a yes/no
        question for the caller to act on, not an error condition itself.
        """
        try:
            self.embed_batch(["ping"])
            return True
        except Exception:
            return False
