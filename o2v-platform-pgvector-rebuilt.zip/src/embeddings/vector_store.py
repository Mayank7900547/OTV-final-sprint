"""
Vector database abstraction.

Design decision: `BaseVectorStore` exposes exactly the operations the
Sprint 6 brief lists — insert/update/delete, metadata filtering, and a
`similarity_search` method that is an INTERFACE STUB (raises
`NotImplementedError` unconditionally, on every backend, including
Postgres) — because the brief is explicit that retrieval/similarity
search logic belongs to Sprint 7, not Sprint 6. Declaring the method now
(rather than omitting it) is what makes Sprint 7 additive: it overrides
one method per backend instead of redesigning this interface.

Design decision: `PostgresVectorStore` (the default, working backend)
persists through the `Embedding` ORM model from `models.py` — it does
NOT talk to Postgres directly via raw SQL/psycopg2, so it takes a
SQLAlchemy `Session` the same way every other Sprint 4/5/6 service-layer
class does. Chroma/FAISS/Qdrant/Pinecone/Weaviate/Milvus are registered
placeholders (same pattern as `embedding_factory.py`'s placeholder
providers) — swapping the active backend later means adding one class in
this file and changing `settings.embeddings_vector_db_backend`, nothing
in `embedding_service.py` changes, which is the literal meaning of "the
application should never depend directly on a specific vector database
implementation."
Design decision (Sprint 7 addition): `PostgresVectorStore.similarity_search`
now has a REAL implementation — brute-force cosine similarity computed in
Python over `Embedding.embedding_vector` rows, since there is no `pgvector`
extension installed and Sprint 6 deliberately stored vectors as plain JSON
(see `models.py`). This is the exact, anticipated "override one method per
backend" extension point Sprint 6's docstring called out — no other method
on this class changed, and every other backend still inherits the
`NotImplementedError` stub. Brute-force is the right tradeoff at this
project's stated scale ("thousands of chunks", not millions): correct and
dependency-free beats a fast-but-approximate ANN index nobody asked for
yet. If/when scale demands it, swapping in `pgvector` or an external ANN
backend changes this one method's body, not its callers.

Design decision (later addition): "if/when scale demands it" above
arrived sooner than expected — production retrieval was taking
657-3680 seconds per component because of exactly the brute-force
Python-side scan described above (~44k embeddings pulled out of
Postgres as JSON, decoded, and compared one at a time with no index).
`PgVectorStore` is that anticipated swap-in: it stores the real vector
in a `pgvector`-typed column (via `PgVectorEmbedding`, on its own
metadata registry — see that class's docstring for why) and pushes the
ranking/top-k work into Postgres itself via the `<=>` cosine-distance
operator, instead of looping in Python. It is registered alongside
`PostgresVectorStore`, not a replacement for it — selecting it is a
`settings.embeddings_vector_db_backend` change, same as any other
backend swap this module was designed for.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from datetime import datetime, timezone

from pgvector.sqlalchemy import Vector
from sqlalchemy import Column, DateTime, ForeignKey, Integer, func, text
from sqlalchemy.orm import DeclarativeBase, Session, relationship

from src.chunking.models import Chunk
from src.embeddings.exceptions import VectorStorageError
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.types import EmbeddingVector, VectorMetadata

_VECTOR_STORE_REGISTRY: dict[str, type["BaseVectorStore"]] = {}


def register_vector_store(name: str):
    """Class decorator: registers a `BaseVectorStore` subclass under `name` in the factory."""

    def decorator(cls: type["BaseVectorStore"]) -> type["BaseVectorStore"]:
        _VECTOR_STORE_REGISTRY[name] = cls
        return cls

    return decorator


def available_vector_stores() -> list[str]:
    return sorted(_VECTOR_STORE_REGISTRY)


def get_vector_store(name: str, *, session: Session) -> "BaseVectorStore":
    """The single choke point for vector store selection — see module docstring."""
    try:
        store_cls = _VECTOR_STORE_REGISTRY[name.lower()]
    except KeyError as exc:
        raise VectorStorageError(
            f"Unknown vector store backend {name!r}. Available: {available_vector_stores()}"
        ) from exc
    return store_cls(session=session)


def _cosine_similarity(a: EmbeddingVector, b: EmbeddingVector) -> float:
    """Standard cosine similarity, with a defined (zero) result for a zero-magnitude vector rather than a ZeroDivisionError."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class BaseVectorStore(ABC):
    """Common interface every vector database backend must implement."""

    backend_name: str = "base"

    def __init__(self, *, session: Session):
        self.session = session

    @abstractmethod
    def insert_vector(
        self,
        *,
        embedding_row: Embedding,
        vector: EmbeddingVector,
        metadata: VectorMetadata,
    ) -> None:
        """
        Persist `vector` (and its `metadata`) for the already-created
        `embedding_row`. `embedding_row` is created and added to the
        session by `embedding_service.py` BEFORE this is called, so a
        backend only needs to attach the vector data to it (Postgres) or
        push it to an external system keyed by `embedding_row.id`
        (future backends).
        """

    @abstractmethod
    def update_vector(self, embedding_id: int, *, vector: EmbeddingVector, metadata: VectorMetadata) -> None:
        """Replace the stored vector/metadata for an existing embedding id (used by re-embedding/versioning)."""

    @abstractmethod
    def delete_vector(self, embedding_id: int) -> None:
        """Remove a stored vector — used when superseding/retrying leaves an orphaned FAILED attempt."""

    @abstractmethod
    def get_vector(self, embedding_id: int) -> EmbeddingVector | None:
        """Fetch a single stored vector by embedding id, or None if not found/not stored by this backend."""

    @abstractmethod
    def filter_by_metadata(self, filters: dict) -> list[int]:
        """
        Return the embedding ids whose metadata matches every key/value
        in `filters` (exact match) — plain metadata filtering, distinct
        from similarity search, which this interface deliberately does
        NOT provide (see module docstring).
        """

    def similarity_search(self, query_vector: EmbeddingVector, *, top_k: int = 10, filters: dict | None = None):
        """
        Interface stub only — similarity search is Sprint 7 scope. Every
        backend inherits this NotImplementedError rather than each
        silently returning an empty/wrong result if called early.
        """
        raise NotImplementedError(
            "similarity_search is a Sprint 7 concern — Sprint 6 only generates and stores vectors."
        )


@register_vector_store("postgres")
class PostgresVectorStore(BaseVectorStore):
    """
    Default backend: stores the vector directly on the `Embedding` row's
    `embedding_vector` JSON column, using this project's existing
    Postgres database — no new infrastructure required to run Sprint 6
    end to end. See module docstring for how this stays swappable.
    """

    backend_name = "postgres"

    def insert_vector(self, *, embedding_row: Embedding, vector: EmbeddingVector, metadata: VectorMetadata) -> None:
        embedding_row.embedding_vector = list(vector)
        embedding_row.embedding_metadata = dict(metadata)
        embedding_row.vector_store_backend = self.backend_name

    def update_vector(self, embedding_id: int, *, vector: EmbeddingVector, metadata: VectorMetadata) -> None:
        row = self.session.query(Embedding).filter(Embedding.id == embedding_id).first()
        if row is None:
            raise VectorStorageError(f"Cannot update vector: Embedding {embedding_id} not found.")
        row.embedding_vector = list(vector)
        row.embedding_metadata = dict(metadata)
        row.updated_at = datetime.now(timezone.utc)
        self.session.flush()

    def delete_vector(self, embedding_id: int) -> None:
        row = self.session.query(Embedding).filter(Embedding.id == embedding_id).first()
        if row is None:
            return
        row.embedding_vector = None
        self.session.flush()

    def get_vector(self, embedding_id: int) -> EmbeddingVector | None:
        row = self.session.query(Embedding).filter(Embedding.id == embedding_id).first()
        if row is None or row.embedding_vector is None:
            return None
        return list(row.embedding_vector)

    def filter_by_metadata(self, filters: dict) -> list[int]:
        query = self.session.query(Embedding.id).filter(Embedding.status == EmbeddingStatusEnum.ACTIVE)
        for key, value in filters.items():
            # JSON containment filter — matches rows whose embedding_metadata
            # has {key: value} among its entries. Deliberately simple
            # (exact-match only, no range/fuzzy filtering) since anything
            # more elaborate starts to overlap with Sprint 7's retrieval scope.
            query = query.filter(Embedding.embedding_metadata[key].astext == str(value))
        return [row[0] for row in query.all()]

    def similarity_search(
        self, query_vector: EmbeddingVector, *, top_k: int = 10, filters: dict | None = None
    ) -> list[dict]:
        """
        Real implementation (Sprint 7) — see module docstring for the
        brute-force-cosine design decision. Returns plain dicts (not a
        Sprint 7 type) to keep this Sprint 6 module free of a dependency
        on `src.retrieval` — `retrieval/semantic_search.py` is what turns
        these into Sprint 7's own candidate objects.

        Each dict: `{embedding_id, chunk_id, document_id, score, metadata}`,
        sorted by `score` (cosine similarity, higher is better) descending.
        """
        query = self.session.query(Embedding).filter(
            Embedding.status == EmbeddingStatusEnum.ACTIVE,
            Embedding.embedding_vector.isnot(None),
        )
        for key, value in (filters or {}).items():
            query = query.filter(Embedding.embedding_metadata[key].astext == str(value))

        scored: list[tuple[float, Embedding]] = []
        for row in query.all():
            vector = row.embedding_vector
            if not vector or len(vector) != len(query_vector):
                # Dimension mismatch means a different provider/model produced
                # this vector — silently skip rather than error, since a
                # mixed-provider embedding table is a legitimate state (e.g.
                # mid-migration between providers), not a corruption.
                continue
            scored.append((_cosine_similarity(query_vector, vector), row))

        scored.sort(key=lambda pair: pair[0], reverse=True)
        return [
            {
                "embedding_id": row.id,
                "chunk_id": row.chunk_id,
                "document_id": row.document_id,
                "score": score,
                "metadata": row.embedding_metadata or {},
            }
            for score, row in scored[:top_k]
        ]


class PgVectorBase(DeclarativeBase):
    """
    Separate declarative base for the opt-in `pgvector`-backed store.

    Design decision: `PgVectorEmbedding` must NOT live on the shared
    `Base` from `database/base.py`. `embedding_service.py` — the module
    nearly every part of the app imports — imports this module
    (`vector_store.py`), so if `PgVectorEmbedding` were defined on
    `Base`, `Base.metadata.create_all()` in `init_db.py` (and
    `conftest.py`, which does the same) would try to create this table
    for EVERY installation, including ones that never call
    `enable_pgvector_support()` and don't have the Postgres `vector`
    extension installed — breaking `init_db`/the test suite for them.
    A dedicated metadata registry keeps this table invisible to
    `Base.metadata` and anything that iterates it, so it's created ONLY
    when `enable_pgvector_support()` is called explicitly. This was
    caught the hard way: an earlier version of this class lived on the
    shared `Base` and broke `Base.metadata.create_all()` for every
    caller that had never touched pgvector.
    """


class PgVectorEmbedding(PgVectorBase):
    """
    Opt-in `pgvector`-backed store for one `Embedding` row's vector, used
    only when `PgVectorStore` is the active backend. Kept as a separate
    table from `embeddings` — rather than adding a `pgvector.Vector`
    column onto `Embedding` directly — so nothing about the Sprint 6
    default (`Embedding.embedding_vector` JSON column,
    `PostgresVectorStore`) changes for anyone who hasn't opted in.
    `embedding_metadata` stays on `Embedding` itself (not duplicated
    here) — `PgVectorStore.filter_by_metadata` queries it there, exactly
    like `PostgresVectorStore` does; this table's only job is the vector
    data and the indexed similarity search it enables.

    Design decision: `embedding_id`/`chunk_id` reference the actual
    `Column` objects (`Embedding.__table__.c.id`, `Chunk.__table__.c.id`)
    rather than string table names (`"embeddings.id"`, `"chunks.id"`).
    SQLAlchemy resolves a string FK reference by looking up the target
    table within the SAME `MetaData` the referencing table is registered
    on — and `embeddings`/`chunks` live in `Base.metadata`, not
    `PgVectorBase.metadata`. A string reference here raised a "no such
    table" error at mapper-configuration time in practice; passing the
    `Column` object directly sidesteps metadata-based lookup entirely,
    so the FK still resolves correctly across the two registries.
    """

    __tablename__ = "pgvector_embeddings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    embedding_id = Column(
        ForeignKey(Embedding.__table__.c.id, ondelete="CASCADE"), nullable=False, unique=True, index=True
    )
    chunk_id = Column(ForeignKey(Chunk.__table__.c.id, ondelete="CASCADE"), nullable=False, index=True)

    # No fixed dimension declared: this project embeds with more than one
    # provider/model (see embeddings_factory.py), and those don't all
    # share a dimension. A fixed-length `Vector(n)` column would reject
    # every other provider's rows outright. The tradeoff (documented
    # here, not hidden) is that an ivfflat/hnsw ANN index — which
    # `pgvector` requires a fixed dimension for — isn't available on this
    # column; `similarity_search` below still gets the real win, which is
    # pushing the distance computation and top-k ordering into Postgres
    # instead of Python, with an exact (not approximate) scan.
    vector = Column(Vector(), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    embedding = relationship(Embedding, foreign_keys=[embedding_id])

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return f"<PgVectorEmbedding id={self.id} embedding_id={self.embedding_id}>"


def enable_pgvector_support(engine) -> None:
    """
    One-time, explicit opt-in for the `pgvector` backend: enables the
    Postgres `vector` extension, then creates `PgVectorEmbedding`'s table
    via `PgVectorBase.metadata` — deliberately NOT `Base.metadata`, so
    calling this never touches any other table (see `PgVectorBase`'s
    docstring). Not called anywhere automatically; a caller opting into
    `pgvector` runs this once against their database before selecting
    `"pgvector"` as `settings.embeddings_vector_db_backend`.
    """
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    PgVectorBase.metadata.create_all(bind=engine)


def migrate_existing_embeddings_to_pgvector(
    session: Session, *, batch_size: int = 500, clear_json_after: bool = False
) -> dict:
    """
    One-time backfill: copies every ACTIVE `Embedding` row's vector out of
    the Sprint 6 `embedding_vector` JSON column and into `PgVectorEmbedding`,
    then flips that row's `vector_store_backend` to `"pgvector"`.

    For carrying existing sprint 1-6 (embedded) and sprint 7 (retrieved)
    data forward onto a `pgvector`-backed database — e.g. after a
    `pg_dump`/`pg_restore` onto a new machine — WITHOUT re-running
    embedding generation. `RetrievedEvidence` (Sprint 7) needs no
    migration of its own: it denormalizes chunk text/metadata at
    retrieval time (see retrieval/models.py's docstring), not the vector
    itself, so a plain `pg_dump` already carries it forward unchanged.

    Idempotent and safe to interrupt/re-run: rows already migrated (an
    existing `PgVectorEmbedding` for that `embedding_id`) are skipped
    rather than duplicated or erroring, so a partial run followed by a
    second call finishes the rest without redoing completed work.

    `clear_json_after=False` by default: the JSON column is left
    populated after migration, so nothing is destroyed until the caller
    has verified `pgvector` search actually works. Passing `True` clears
    `embedding_vector` on every row this call touches (each in the same
    transaction as that row's `PgVectorEmbedding` insert and backend
    flip), which is the point at which the JSON copy stops being the
    source of truth and this stops being "vectors in two places."

    Returns `{"migrated": int, "already_migrated": int, "skipped_no_vector": int}`.
    """
    migrated = 0
    already_migrated = 0
    skipped_no_vector = 0

    query = session.query(Embedding).filter(
        Embedding.status == EmbeddingStatusEnum.ACTIVE,
    )

    batch: list[Embedding] = []

    def _flush_batch():
        nonlocal batch
        if batch:
            session.flush()
            batch = []

    for row in query.yield_per(batch_size):
        existing = session.query(PgVectorEmbedding).filter(PgVectorEmbedding.embedding_id == row.id).first()
        if existing is not None:
            already_migrated += 1
            continue

        if not row.embedding_vector:
            # Nothing to migrate — either already pgvector-only (JSON
            # column intentionally NULL, see models.py's docstring) or a
            # row that never got a JSON vector for some other reason.
            skipped_no_vector += 1
            continue

        pgv_row = PgVectorEmbedding(embedding=row, chunk_id=row.chunk_id, vector=list(row.embedding_vector))
        session.add(pgv_row)
        row.vector_store_backend = "pgvector"
        if clear_json_after:
            row.embedding_vector = None

        migrated += 1
        batch.append(row)
        if len(batch) >= batch_size:
            _flush_batch()

    _flush_batch()
    session.commit()

    return {"migrated": migrated, "already_migrated": already_migrated, "skipped_no_vector": skipped_no_vector}


@register_vector_store("pgvector")
class PgVectorStore(BaseVectorStore):
    """
    `pgvector`-backed store — see module docstring for why this exists.
    Vectors live in `PgVectorEmbedding.vector`; `Embedding.embedding_vector`
    stays NULL for rows using this backend (the documented "external
    vector store" state from `models.py`'s docstring — this is just that
    external store happening to also be Postgres).
    """

    backend_name = "pgvector"

    def insert_vector(self, *, embedding_row: Embedding, vector: EmbeddingVector, metadata: VectorMetadata) -> None:
        embedding_row.embedding_metadata = dict(metadata)
        embedding_row.vector_store_backend = self.backend_name
        # `embedding_row.id` doesn't exist yet at this point — insert_vector
        # runs before embedding_service.py flushes the new Embedding row.
        # Assigning the relationship (not embedding_id=embedding_row.id)
        # lets SQLAlchemy's dependency-ordered flush create embedding_row
        # first and resolve this row's FK from the resulting id, on the
        # same flush — no extra round-trip to fetch the id first.
        pgv_row = PgVectorEmbedding(embedding=embedding_row, chunk_id=embedding_row.chunk_id, vector=list(vector))
        self.session.add(pgv_row)

    def update_vector(self, embedding_id: int, *, vector: EmbeddingVector, metadata: VectorMetadata) -> None:
        row = self.session.query(Embedding).filter(Embedding.id == embedding_id).first()
        if row is None:
            raise VectorStorageError(f"Cannot update vector: Embedding {embedding_id} not found.")
        row.embedding_metadata = dict(metadata)
        row.updated_at = datetime.now(timezone.utc)

        pgv_row = self.session.query(PgVectorEmbedding).filter(PgVectorEmbedding.embedding_id == embedding_id).first()
        if pgv_row is None:
            pgv_row = PgVectorEmbedding(embedding_id=embedding_id, chunk_id=row.chunk_id, vector=list(vector))
            self.session.add(pgv_row)
        else:
            pgv_row.vector = list(vector)
            pgv_row.updated_at = datetime.now(timezone.utc)
        self.session.flush()

    def delete_vector(self, embedding_id: int) -> None:
        pgv_row = self.session.query(PgVectorEmbedding).filter(PgVectorEmbedding.embedding_id == embedding_id).first()
        if pgv_row is not None:
            self.session.delete(pgv_row)
        self.session.flush()

    def get_vector(self, embedding_id: int) -> EmbeddingVector | None:
        pgv_row = self.session.query(PgVectorEmbedding).filter(PgVectorEmbedding.embedding_id == embedding_id).first()
        if pgv_row is None:
            return None
        return list(pgv_row.vector)

    def filter_by_metadata(self, filters: dict) -> list[int]:
        # Metadata still lives on `Embedding` (see `PgVectorEmbedding`'s
        # docstring) — identical query to `PostgresVectorStore`'s.
        query = self.session.query(Embedding.id).filter(Embedding.status == EmbeddingStatusEnum.ACTIVE)
        for key, value in filters.items():
            query = query.filter(Embedding.embedding_metadata[key].astext == str(value))
        return [row[0] for row in query.all()]

    def similarity_search(
        self, query_vector: EmbeddingVector, *, top_k: int = 10, filters: dict | None = None
    ) -> list[dict]:
        """
        Real, index-pushed-to-Postgres implementation — the fix for the
        brute-force scan described in the module docstring. Ordering and
        `top_k` both happen in the SQL query via `<=>` (pgvector's cosine
        DISTANCE operator), not in a Python loop over every row.

        `score` is converted to similarity (`1 - distance`) so callers see
        the same "higher is better" convention `PostgresVectorStore`
        returns, even though pgvector's operator itself returns distance.
        """
        query = (
            self.session.query(
                PgVectorEmbedding.embedding_id,
                Embedding.chunk_id,
                Embedding.document_id,
                Embedding.embedding_metadata,
                PgVectorEmbedding.vector.cosine_distance(list(query_vector)).label("distance"),
            )
            .join(Embedding, Embedding.id == PgVectorEmbedding.embedding_id)
            .filter(Embedding.status == EmbeddingStatusEnum.ACTIVE)
        )
        for key, value in (filters or {}).items():
            query = query.filter(Embedding.embedding_metadata[key].astext == str(value))
        query = query.order_by("distance").limit(top_k)

        return [
            {
                "embedding_id": embedding_id,
                "chunk_id": chunk_id,
                "document_id": document_id,
                "score": 1.0 - distance,
                "metadata": metadata or {},
            }
            for embedding_id, chunk_id, document_id, metadata, distance in query.all()
        ]


# ---------------------------------------------------------------------------
# External-backend placeholders — registered and constructible, storage
# operations raise VectorStorageError naming the missing integration. See
# module docstring for why these exist without a working implementation.
# ---------------------------------------------------------------------------


class _PlaceholderVectorStore(BaseVectorStore):
    """Shared placeholder behavior for external vector databases not yet integrated."""

    integration_hint: str = "not yet implemented"

    def _unavailable(self):
        raise VectorStorageError(f"{self.backend_name} is registered as an architecture placeholder — {self.integration_hint}.")

    def insert_vector(self, *, embedding_row, vector, metadata) -> None:
        self._unavailable()

    def update_vector(self, embedding_id, *, vector, metadata) -> None:
        self._unavailable()

    def delete_vector(self, embedding_id) -> None:
        self._unavailable()

    def get_vector(self, embedding_id):
        self._unavailable()

    def filter_by_metadata(self, filters: dict) -> list[int]:
        self._unavailable()


@register_vector_store("chromadb")
class ChromaVectorStore(_PlaceholderVectorStore):
    backend_name = "chromadb"
    integration_hint = "add the chromadb client dependency and connection settings to enable it"


@register_vector_store("faiss")
class FAISSVectorStore(_PlaceholderVectorStore):
    backend_name = "faiss"
    integration_hint = "add the faiss-cpu/faiss-gpu dependency and an on-disk index path to enable it"


@register_vector_store("qdrant")
class QdrantVectorStore(_PlaceholderVectorStore):
    backend_name = "qdrant"
    integration_hint = "add the qdrant-client dependency and connection settings to enable it"


@register_vector_store("pinecone")
class PineconeVectorStore(_PlaceholderVectorStore):
    backend_name = "pinecone"
    integration_hint = "add the pinecone client dependency and an API key/environment to enable it"


@register_vector_store("weaviate")
class WeaviateVectorStore(_PlaceholderVectorStore):
    backend_name = "weaviate"
    integration_hint = "add the weaviate client dependency and connection settings to enable it"


@register_vector_store("milvus")
class MilvusVectorStore(_PlaceholderVectorStore):
    backend_name = "milvus"
    integration_hint = "add the pymilvus dependency and connection settings to enable it"
