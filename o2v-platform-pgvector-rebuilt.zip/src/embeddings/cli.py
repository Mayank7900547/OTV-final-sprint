"""Typer CLI integration for Sprint 6 Embedding Generation — mirrors `src/chunking/cli.py`'s shape."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from src.config.settings import settings
from src.database.connection import session_scope
from src.embeddings.embedding_factory import available_providers, get_provider
from src.embeddings.embedding_service import EmbeddingGenerationService
from src.embeddings.exceptions import EmbeddingConfigurationError, ProviderUnavailableError
from src.embeddings.models import Embedding, EmbeddingHistory
from src.embeddings.telemetry import telemetry
from src.embeddings.vector_store import available_vector_stores, enable_pgvector_support, migrate_existing_embeddings_to_pgvector

embeddings_app = typer.Typer(name="embeddings", help="Sprint 6 Embedding Generation CLI")
embed_app = typer.Typer(help="Run embedding generation.")
show_app = typer.Typer(help="Inspect embeddings, history, and statistics.")
embeddings_app.add_typer(embed_app, name="embed")
embeddings_app.add_typer(show_app, name="show")

console = Console()


def _print_outcome(outcome: dict) -> None:
    status = outcome.get("status")
    color = {"SUCCESS": "green", "FAILED": "red", "SKIPPED": "yellow"}.get(status, "white")
    line = f"[{color}]{status}[/{color}] Chunk={outcome.get('chunk_id')}"
    if status == "SUCCESS":
        line += (
            f" embedding_id={outcome.get('embedding_id')} provider={outcome.get('provider')} "
            f"model={outcome.get('model_name')} dim={outcome.get('embedding_dimension')} "
            f"time={outcome.get('embedding_duration')}s"
        )
    elif outcome.get("error"):
        line += f" — {outcome['error']}"
    console.print(line)


def _print_summary() -> None:
    summary = telemetry.get_summary()
    console.print("\n=== EMBEDDING TELEMETRY ===")
    console.print(f"Embedded          : {summary['chunks_embedded']}")
    console.print(f"Tokens processed  : {summary['tokens_processed']}")
    console.print(f"Failed            : {summary['failed_embeddings']}")
    console.print(f"Skipped           : {summary['skipped_chunks']}")
    console.print(f"Retries           : {summary['retry_count']}")
    console.print(f"Active provider   : {summary['active_provider'] or '-'}")
    console.print(f"Avg latency (s)   : {summary['average_embedding_latency']}")
    console.print(f"Batch throughput  : {summary['batch_throughput']} chunks/s")
    console.print(f"Success rate      : {summary['success_rate']}")
    console.print("============================")


# --------------------------------------------------------------------------
# embed commands
# --------------------------------------------------------------------------


@embed_app.command("document")
def embed_document(
    document_id: str = typer.Argument(..., help="DocumentRegistry id (UUID) whose chunks should be embedded."),
    force: bool = typer.Option(False, "--force", help="Re-embed even if an active embedding already exists."),
) -> None:
    """Embed every chunk belonging to a single document."""
    from src.chunking.models import Chunk

    service = EmbeddingGenerationService()
    with session_scope() as session:
        ids = [row[0] for row in session.query(Chunk.id).filter(Chunk.document_id == document_id).all()]

    if not ids:
        console.print(f"[yellow]No chunks found for document {document_id}.[/yellow]")
        return

    results = service.embed_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


@embed_app.command("company")
def embed_company(
    company: str = typer.Argument(..., help="Company name (substring match)."),
    force: bool = typer.Option(False, "--force", help="Re-embed even if an active embedding already exists."),
) -> None:
    """Embed every chunk belonging to a company."""
    service = EmbeddingGenerationService()
    with session_scope() as session:
        ids = service.load_eligible_chunk_ids(session, company_filter=company)

    if not ids:
        console.print(f"[yellow]No chunks found for '{company}'.[/yellow]")
        return

    results = service.embed_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


@embed_app.command("all")
def embed_all(force: bool = typer.Option(False, "--force", help="Re-embed even if an active embedding already exists.")) -> None:
    """Embed every chunk across all companies."""
    service = EmbeddingGenerationService()
    with session_scope() as session:
        ids = service.load_eligible_chunk_ids(session)

    if not ids:
        console.print("[yellow]No chunks found.[/yellow]")
        return

    results = service.embed_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


# --------------------------------------------------------------------------
# retry-failed
# --------------------------------------------------------------------------


@embeddings_app.command("retry-failed")
def retry_failed(
    force: bool = typer.Option(True, "--force/--no-force", help="Force re-embed (default on, since a prior attempt failed).")
) -> None:
    """Retry embedding for every chunk whose most recent attempt failed and has no active embedding."""
    service = EmbeddingGenerationService()
    with session_scope() as session:
        ids = service.load_failed_chunk_ids(session)

    if not ids:
        console.print("[green]No failed chunks to retry.[/green]")
        return

    console.print(f"Retrying {len(ids)} failed chunk(s)...")
    results = service.embed_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


# --------------------------------------------------------------------------
# show commands
# --------------------------------------------------------------------------


@show_app.command("embeddings")
def show_embeddings(
    chunk_id: int = typer.Argument(None, help="Show embeddings for one Chunk. Omit to list recent embeddings."),
    limit: int = typer.Option(20, help="Max rows to display when listing."),
) -> None:
    """Show the embedding(s) belonging to a chunk, or list recently created embeddings."""
    with session_scope() as session:
        if chunk_id is not None:
            rows = session.query(Embedding).filter(Embedding.chunk_id == chunk_id).order_by(Embedding.created_at.desc()).all()
            if not rows:
                console.print(f"[yellow]No embeddings found for Chunk {chunk_id}.[/yellow]")
                return
            table = Table(title=f"Embeddings: Chunk {chunk_id} (showing {len(rows)})")
        else:
            rows = session.query(Embedding).order_by(Embedding.created_at.desc()).limit(limit).all()
            table = Table(title=f"Recently Created Embeddings (showing {len(rows)})")

    table.add_column("EmbeddingId")
    table.add_column("Chunk")
    table.add_column("Provider")
    table.add_column("Model")
    table.add_column("Dim")
    table.add_column("Status")
    table.add_column("Backend")
    for r in rows:
        table.add_row(
            r.embedding_id, str(r.chunk_id), r.provider, r.model_name,
            str(r.embedding_dimension), r.status.value, r.vector_store_backend,
        )
    console.print(table)


@show_app.command("embedding-statistics")
def show_embedding_statistics() -> None:
    """Show cumulative telemetry for this process's embedding activity."""
    _print_summary()


@show_app.command("provider-status")
def show_provider_status() -> None:
    """Show the currently configured provider/vector-store backend and every registered option."""
    console.print(f"Configured provider       : {settings.embeddings_provider}")
    console.print(f"Configured model           : {settings.embeddings_model_name} (v{settings.embeddings_model_version})")
    console.print(f"Configured dimension       : {settings.embeddings_dimension}")
    console.print(f"Configured vector backend  : {settings.embeddings_vector_db_backend}")
    console.print(f"Registered providers       : {', '.join(available_providers())}")
    console.print(f"Registered vector backends : {', '.join(available_vector_stores())}")

    try:
        provider = get_provider()
        console.print(f"[green]Active provider constructs OK: {provider.provider_name}[/green]")
    except (EmbeddingConfigurationError, ProviderUnavailableError) as exc:
        console.print(f"[red]Active provider is not ready: {exc}[/red]")


@embeddings_app.command("migrate-to-pgvector")
def migrate_to_pgvector(
    clear_json: bool = typer.Option(
        False, "--clear-json",
        help="Also clear the old JSON embedding_vector column on rows this migrates. "
        "Leave off for a first, verifiable pass; re-run with this on once you've "
        "confirmed pgvector search works.",
    ),
) -> None:
    """
    One-time backfill: copy every ACTIVE embedding's vector out of the
    Sprint 6 JSON column and into the pgvector-backed table, so existing
    sprint 1-6/7 data (e.g. after a pg_dump/pg_restore onto a new
    machine) doesn't need to be re-embedded. Safe to re-run — already-
    migrated rows are skipped, not duplicated.
    """
    from src.database.connection import engine

    enable_pgvector_support(engine)
    with session_scope() as session:
        result = migrate_existing_embeddings_to_pgvector(session, clear_json_after=clear_json)
    console.print(
        f"[green]Migrated: {result['migrated']}[/green]  "
        f"[yellow]Already migrated: {result['already_migrated']}[/yellow]  "
        f"[dim]Skipped (no vector): {result['skipped_no_vector']}[/dim]"
    )
    if not clear_json and result["migrated"]:
        console.print(
            "[dim]JSON column left intact — re-run with --clear-json once you've "
            "verified pgvector search works.[/dim]"
        )


@show_app.command("embedding-history")
def show_embedding_history(chunk_id: int = typer.Argument(..., help="Chunk id.")) -> None:
    """Show every recorded embedding attempt for a chunk."""
    with session_scope() as session:
        rows = (
            session.query(EmbeddingHistory)
            .filter(EmbeddingHistory.chunk_id == chunk_id)
            .order_by(EmbeddingHistory.attempt_number.asc())
            .all()
        )

    if not rows:
        console.print(f"[yellow]No embedding history for Chunk {chunk_id}.[/yellow]")
        return

    table = Table(title=f"Embedding History: Chunk {chunk_id}")
    table.add_column("Attempt")
    table.add_column("Provider/Model")
    table.add_column("Status")
    table.add_column("Retries")
    table.add_column("Duration (s)")
    table.add_column("Error")
    for h in rows:
        table.add_row(
            str(h.attempt_number), f"{h.provider}/{h.model_name} v{h.model_version}", h.run_status.value,
            str(h.retries), f"{h.duration_seconds:.3f}" if h.duration_seconds is not None else "-",
            (h.error_message or "-")[:80],
        )
    console.print(table)
