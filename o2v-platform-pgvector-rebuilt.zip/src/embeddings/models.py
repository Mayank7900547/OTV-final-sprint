"""
Database models for Sprint 6 Embedding Generation.

Design decision: `Embedding` is the system-of-record for embedding
LIFECYCLE and METADATA (provider, model, version, status, dimension,
timestamps) regardless of which vector store backend is active — it is
NOT tied to the Postgres-as-vector-store choice. When
`PostgresVectorStore` is the active backend (Sprint 6's default —
external vector DB integrations are placeholders, see `vector_store.py`),
`embedding_vector` holds the actual floats and this table doubles as the
vector store. When a future sprint wires up a real Qdrant/Pinecone/etc
backend, `embedding_vector` stays NULL here and the vector lives in that
external system, addressed by `Embedding.id` — the row (and this whole
package) never needs to change shape either way. That's the concrete
mechanism behind the brief's "the application should never depend
directly on a specific vector database implementation".

Design decision: versioning is modeled the same way Sprint 4/5 modeled
"redo this and keep history" (`ParsedDocument`+`ParsingHistory`,
`Chunk`+`ChunkingHistory`) — `Embedding` holds only CURRENT rows (one
ACTIVE row per chunk+provider+model+version lineage), `EmbeddingHistory`
is the append-only attempt log. What's new here vs. Sprint 5 is that
"current" isn't simply "the latest row" — re-embedding after a model
upgrade must be able to keep an OLD version's embedding queryable
(`status=SUPERSEDED`) while exactly one version is `ACTIVE` per chunk,
per the brief's explicit "No duplicate active embeddings for the same
chunk" requirement. That's `uq_embedding_active_per_chunk`, a PARTIAL
unique index (only enforced `WHERE status = 'ACTIVE'`) rather than a
plain unique constraint on `chunk_id` — a plain constraint would make it
impossible to ever store a second (superseded) embedding for the same
chunk at all, which would break versioning entirely.
"""

import enum

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

from src.database.base import Base


class EmbeddingStatusEnum(str, enum.Enum):
    ACTIVE = "ACTIVE"  # the current, queryable embedding for this chunk+provider+model lineage
    SUPERSEDED = "SUPERSEDED"  # replaced by a newer re-embedding (model upgrade, dimension change, etc.)
    FAILED = "FAILED"  # generation was attempted and failed validation/storage — no usable vector
    SKIPPED = "SKIPPED"  # chunk not eligible, or already actively embedded and re-embed wasn't forced


class EmbeddingRunStatusEnum(str, enum.Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class Embedding(Base):
    """
    One semantic vector representation of a `Chunk`, from one
    provider/model/version. See module docstring for the versioning and
    vector-store-independence design decisions.
    """

    __tablename__ = "embeddings"
    __table_args__ = (
        # "No duplicate active embeddings for the same chunk" — a PARTIAL
        # unique index (only `WHERE status = 'ACTIVE'`), not a plain
        # unique constraint on `(chunk_id, provider, model_name,
        # model_version)`: that plain form was tried first and rejected —
        # it would also block the literal "support embedding
        # regeneration" requirement (re-embedding with an UNCHANGED
        # model/version, e.g. to pick up a corrected chunk text) once a
        # SUPERSEDED row for that lineage already existed. Only one row
        # may be ACTIVE per chunk; any number of SUPERSEDED rows may
        # share the same chunk+provider+model+version.
        Index(
            "uq_embedding_active_per_chunk",
            "chunk_id",
            unique=True,
            postgresql_where=text("status = 'ACTIVE'"),
        ),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    embedding_id = Column(String(64), nullable=False, index=True)

    chunk_id = Column(Integer, ForeignKey("chunks.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(PG_UUID(as_uuid=True), ForeignKey("document_registry.id", ondelete="CASCADE"), nullable=False, index=True)

    provider = Column(String(50), nullable=False, index=True)
    model_name = Column(String(200), nullable=False)
    model_version = Column(String(50), nullable=False)
    embedding_dimension = Column(Integer, nullable=False)

    # NULL when the active vector store backend is an external system
    # (see module docstring) — populated for the Postgres-backed default.
    embedding_vector = Column(JSON, nullable=True)

    embedding_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    status = Column(SQLEnum(EmbeddingStatusEnum), nullable=False, default=EmbeddingStatusEnum.ACTIVE)
    is_active = Column(Boolean, nullable=False, default=True)

    vector_store_backend = Column(String(50), nullable=False)
    token_count = Column(Integer, nullable=True)

    # Vector metadata (company, document_id, chunk_id, page_number,
    # section_title, document_type, creation_timestamp, chunk_index —
    # see types.py::VectorMetadata) plus provider-specific extras. JSONB
    # (not plain JSON) specifically because `vector_store.py`'s
    # `filter_by_metadata` needs the `->>`/`.astext` operator Postgres
    # only supports efficiently on `jsonb`.
    embedding_metadata = Column(JSONB, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    chunk = relationship("Chunk", backref="embeddings")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<Embedding id={self.id} chunk_id={self.chunk_id} provider={self.provider!r} "
            f"model={self.model_name!r} status={self.status}>"
        )


class EmbeddingHistory(Base):
    """
    Append-only log of every embedding ATTEMPT for a chunk, success or
    failure — mirrors `ChunkingHistory`'s role. `Embedding` rows hold only
    current lineage state; this table is what `show embedding statistics`
    / `retry failed embeddings` (CLI) read from.
    """

    __tablename__ = "embedding_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    chunk_id = Column(Integer, ForeignKey("chunks.id", ondelete="CASCADE"), nullable=False, index=True)
    attempt_number = Column(Integer, nullable=False, default=1)
    provider = Column(String(50), nullable=False)
    model_name = Column(String(200), nullable=False)
    model_version = Column(String(50), nullable=False)
    run_status = Column(SQLEnum(EmbeddingRunStatusEnum), nullable=False)
    error_message = Column(String(2000), nullable=True)
    retries = Column(Integer, nullable=False, default=0)
    token_count = Column(Integer, nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=False)
    completed_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    duration_seconds = Column(Float, nullable=True)

    chunk = relationship("Chunk", backref="embedding_history")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<EmbeddingHistory id={self.id} chunk_id={self.chunk_id} "
            f"status={self.run_status} attempt={self.attempt_number}>"
        )
