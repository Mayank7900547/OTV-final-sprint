"""
Sprint 6 domain exceptions extending the O2V core error hierarchy.

Design decision: same flat-hierarchy-under-one-base shape as
`src/chunking/exceptions.py` and `src/parser/exceptions.py` — every
failure mode Sprint 6 can hit is a direct child of `EmbeddingError`, none
specializes another, so callers can catch broadly (`except
EmbeddingError`) or narrowly (`except DimensionMismatchError`) as needed.
"""

from src.core.exceptions import O2VError


class EmbeddingError(O2VError):
    """Base exception for all Sprint 6 embedding generation and vector storage failures."""


class ChunkNotFoundError(EmbeddingError):
    """Raised when the `Chunk` id requested for embedding doesn't exist."""


class ProviderUnavailableError(EmbeddingError):
    """
    Raised when the configured embedding provider cannot serve a request —
    covers both genuinely unreachable providers (network/auth failure)
    and the architecture-placeholder providers (Nomic, BGE, E5, Sentence
    Transformers, Ollama, LM Studio, Azure OpenAI) that exist to prove out
    the plugin boundary but have no working implementation yet.
    """


class DimensionMismatchError(EmbeddingError):
    """Raised when a provider returns a vector whose length doesn't match its declared `embedding_dimension`."""


class InvalidProviderResponseError(EmbeddingError):
    """Raised when a provider's response is malformed in a way dimension checking alone wouldn't catch (e.g. empty batch, NaN values, wrong batch length)."""


class VectorStorageError(EmbeddingError):
    """Raised when the configured vector store backend fails to insert/update/delete a vector."""


class DuplicateEmbeddingError(EmbeddingError):
    """Raised when a chunk already has an active embedding for the requested provider/model/version and re-embedding wasn't forced."""


class EmbeddingConfigurationError(EmbeddingError):
    """Raised when an embedding provider or vector store is configured with an invalid combination of settings."""


class EmbeddingValidationError(EmbeddingError):
    """Raised when a generated embedding fails post-generation validation (see validation.py)."""
