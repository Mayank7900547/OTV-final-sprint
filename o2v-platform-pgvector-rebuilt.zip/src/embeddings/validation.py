"""
Validation checks for the embedding generation pipeline.

Design decision: same stateless-functions-not-a-class shape as
`src/chunking/validation.py` — each check takes exactly the data it
needs and raises a specific `embeddings.exceptions` subclass, so
`embedding_service.py` calls them as a straight-line sequence of guard
clauses.
"""

from __future__ import annotations

import math

from sqlalchemy.orm import Session

from src.chunking.models import Chunk
from src.embeddings.exceptions import (
    DuplicateEmbeddingError,
    EmbeddingValidationError,
    InvalidProviderResponseError,
)
from src.embeddings.models import Embedding, EmbeddingStatusEnum
from src.embeddings.types import EmbeddingVector, VectorMetadata


def validate_chunk_has_text(chunk: Chunk) -> None:
    """A chunk with no text has nothing for a provider to embed."""
    if not chunk.text or not chunk.text.strip():
        raise EmbeddingValidationError(f"Chunk {chunk.id} has no text to embed.")


def check_duplicate_active_embedding(
    session: Session, chunk_id: int, *, provider: str, model_name: str, model_version: str, force: bool
) -> Embedding | None:
    """
    Look up an existing ACTIVE embedding for this chunk+provider+model+version.

    Returns it (so the service can supersede it when `force=True`) rather
    than raising outright — same "force is a legitimate re-embed trigger,
    not an error" reasoning `chunking/validation.py::check_duplicate_chunking`
    established. Unlike chunking (which fully replaces a chunk set),
    embedding versioning keeps the old row around as SUPERSEDED rather
    than deleting it — see `models.py`'s module docstring.
    """
    existing = (
        session.query(Embedding)
        .filter(
            Embedding.chunk_id == chunk_id,
            Embedding.provider == provider,
            Embedding.model_name == model_name,
            Embedding.model_version == model_version,
            Embedding.status == EmbeddingStatusEnum.ACTIVE,
        )
        .first()
    )
    if existing and not force:
        raise DuplicateEmbeddingError(
            f"Chunk {chunk_id} already has an active {provider}/{model_name} (v{model_version}) "
            f"embedding. Pass --force to re-embed."
        )
    return existing


def validate_embedding_vector(vector: EmbeddingVector, *, expected_dimension: int) -> None:
    """
    Validate a generated vector's shape and content — empty-vector and
    dimension checks the provider's own `validate_dimension` also
    performs (defense in depth, same "belt and suspenders" reasoning used
    throughout this codebase), plus a NaN/Inf check no provider-level
    check covers, since a NaN can slip through a dimension check but
    would silently poison any downstream similarity computation.
    """
    if not vector:
        raise EmbeddingValidationError("Generated embedding vector is empty.")
    if len(vector) != expected_dimension:
        raise EmbeddingValidationError(
            f"Generated embedding vector has dimension {len(vector)}, expected {expected_dimension}."
        )
    for value in vector:
        if math.isnan(value) or math.isinf(value):
            raise EmbeddingValidationError("Generated embedding vector contains NaN/Inf values.")


def validate_vector_metadata(metadata: dict) -> list[str]:
    """
    Confirm every required `VectorMetadata` field (see types.py) is
    present and non-None where the brief requires it. `page_number` and
    `section_title` are legitimately nullable (see `Chunk` model), so
    they're excluded from the required set.
    """
    required_fields = [
        "company", "document_id", "chunk_id", "document_type", "creation_timestamp", "chunk_index",
    ]
    missing = [field for field in required_fields if metadata.get(field) in (None, "")]
    if missing:
        return [f"missing required metadata field(s): {missing}"]
    return []


def validate_model_compatibility(provider_name: str, declared_dimension: int, provider_dimension: int) -> None:
    """
    Guards against a misconfiguration where `settings.embeddings_dimension`
    doesn't match what the constructed provider instance was actually
    told to produce — catches a config typo before a single API call is
    made, rather than after paying for a batch of embeddings that will
    fail dimension validation anyway.
    """
    if declared_dimension != provider_dimension:
        raise InvalidProviderResponseError(
            f"{provider_name}: configured embedding_dimension={declared_dimension} does not match "
            f"the provider instance's embedding_dimension={provider_dimension}."
        )
