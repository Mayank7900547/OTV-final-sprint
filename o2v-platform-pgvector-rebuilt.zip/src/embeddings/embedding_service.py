"""
Embedding Generation Service — Sprint 6 orchestration layer.

Design decision: chunks are grouped into batches of `settings.
embeddings_batch_size` and each batch is sent to the provider as ONE
`embed_batch()` call — this is the brief's "Batch embedding" provider
requirement, not just an optimization. Batches run concurrently (up to
`settings.embeddings_max_concurrent_requests`) via `ThreadPoolExecutor`,
the same concurrency primitive `DocumentParserService`/
`DocumentChunkingService` use for the same reason: each batch is one
blocking network call (provider-bound, not CPU-bound, unlike chunking),
so a thread pool is the right fit — an `asyncio` rewrite would be a
bigger change than Sprint 6's scope justifies given every other service
in this codebase is synchronous.

Design decision: a provider failure fails the WHOLE batch (all chunks in
it are recorded FAILED and retried together), but post-embedding
validation (dimension/NaN/metadata checks) is evaluated PER CHUNK — a
transient network error genuinely affects every chunk in the batch
equally, whereas a validation problem (e.g. missing metadata due to a
data issue on one specific chunk) shouldn't fail chunks that validated
fine just because they shared a batch.
"""

from __future__ import annotations

import time
from concurrent.futures import CancelledError, ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from src.chunking.metadata import estimate_tokens
from src.chunking.models import Chunk
from src.config.logging_config import get_logger
from src.config.settings import settings
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.embedding_factory import get_provider
from src.embeddings.exceptions import (
    ChunkNotFoundError,
    DuplicateEmbeddingError,
    EmbeddingError,
    EmbeddingValidationError,
    ProviderUnavailableError,
)
from src.embeddings.metadata import build_vector_metadata
from src.embeddings.models import Embedding, EmbeddingHistory, EmbeddingRunStatusEnum, EmbeddingStatusEnum
from src.embeddings.telemetry import telemetry
from src.pipeline.ollama_manager import ensure_ollama_running
from src.embeddings.types import EmbeddingOutcome
from src.embeddings.utils import batched, with_retries
from src.embeddings.validation import (
    check_duplicate_active_embedding,
    validate_chunk_has_text,
    validate_embedding_vector,
    validate_vector_metadata,
)
from src.embeddings.vector_store import get_vector_store
from src.models.company import Company
from src.models.document import DocumentRegistry

logger = get_logger(__name__)


class EmbeddingGenerationService:
    def __init__(self, *, provider: BaseEmbeddingProvider | None = None, vector_store_backend: str | None = None):
        self._provider = provider or get_provider()
        self._vector_store_backend = vector_store_backend or settings.embeddings_vector_db_backend

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_eligible_chunk_ids(self, session: Session, company_filter: str | None = None) -> list[int]:
        """
        Every `Chunk` id — Sprint 5 only persists chunks that already
        passed validation (see `chunking/validation.py`), so "validated
        chunks" (per the brief) is simply every `Chunk` row. Whether a
        given chunk actually needs (re-)embedding is decided per-chunk
        during `embed_chunks` via `check_duplicate_active_embedding`, not
        filtered out here.
        """
        query = session.query(Chunk.id)
        if company_filter:
            query = (
                query.join(DocumentRegistry, DocumentRegistry.id == Chunk.document_id)
                .join(Company, Company.id == DocumentRegistry.company_id)
                .filter(Company.name.ilike(f"%{company_filter}%"))
            )
        return [row[0] for row in query.all()]

    def load_unembedded_chunk_ids(self, session: Session, company_filter: str | None = None) -> list[int]:
        """
        IDs of chunks that do NOT currently have an ACTIVE embedding —
        the actual "still needs embedding" set. Distinct from
        `load_eligible_chunk_ids` above, which deliberately returns
        EVERY chunk regardless of embedding status (see that method's
        docstring) and is the right input list to hand to `embed_many`
        (which itself skips already-embedded chunks per-chunk via
        `check_duplicate_active_embedding`) — but it is the WRONG list
        to use for tracking progress across retry passes, since it never
        shrinks as chunks get embedded. This method exists specifically
        for that progress-tracking need — see `pipeline/orchestrator.py`'s
        embeddings stage, which was incorrectly using
        `load_eligible_chunk_ids`'s always-full list for its stall/
        coverage accounting before this method existed, making a fully
        successful embedding run misreport as 0% coverage.
        """
        actively_embedded_chunk_ids = session.query(Embedding.chunk_id).filter(
            Embedding.status == EmbeddingStatusEnum.ACTIVE
        )
        query = session.query(Chunk.id).filter(Chunk.id.notin_(actively_embedded_chunk_ids))
        if company_filter:
            query = (
                query.join(DocumentRegistry, DocumentRegistry.id == Chunk.document_id)
                .join(Company, Company.id == DocumentRegistry.company_id)
                .filter(Company.name.ilike(f"%{company_filter}%"))
            )
        return [row[0] for row in query.all()]

    def load_failed_chunk_ids(self, session: Session) -> list[int]:
        """IDs of chunks whose most recent embedding attempt failed and that have no active embedding — the `retry-failed` (CLI) population."""
        actively_embedded = {
            row[0] for row in session.query(Embedding.chunk_id).filter(Embedding.status == EmbeddingStatusEnum.ACTIVE).distinct().all()
        }
        failed_history_ids = {
            row[0]
            for row in session.query(EmbeddingHistory.chunk_id)
            .filter(EmbeddingHistory.run_status == EmbeddingRunStatusEnum.FAILED)
            .all()
        }
        return sorted(failed_history_ids - actively_embedded)

    # ------------------------------------------------------------------
    # Single-chunk convenience wrapper
    # ------------------------------------------------------------------

    def embed_chunk(self, session: Session, chunk_id: int, *, force: bool = False) -> EmbeddingOutcome:
        """Embed exactly one chunk — a batch-of-one call through `embed_chunks`."""
        outcomes = self.embed_chunks(session, [chunk_id], force=force)
        if outcomes:
            return outcomes[0]
        return {"status": "FAILED", "chunk_id": chunk_id, "error": "No outcome produced."}

    # ------------------------------------------------------------------
    # Batch embedding (single session, sequential batches)
    # ------------------------------------------------------------------

    def embed_chunks(self, session: Session, chunk_ids: list[int], *, force: bool = False) -> list[EmbeddingOutcome]:
        """Embed `chunk_ids`, grouped into provider batches of `settings.embeddings_batch_size`, processed sequentially."""
        outcomes: list[EmbeddingOutcome] = []
        for batch_ids in batched(chunk_ids, settings.embeddings_batch_size):
            outcomes.extend(self._embed_batch(session, batch_ids, force=force))
        return outcomes

    def embed_many(self, session_factory, chunk_ids: list[int], *, force: bool = False) -> list[EmbeddingOutcome]:
        """
        Embed many chunks with batches running concurrently (up to
        `settings.embeddings_max_concurrent_requests`). `session_factory`
        (not a shared `Session`) is required because each worker thread
        needs its own SQLAlchemy session — a `Session` is not thread-safe.

        Two pieces of resilience layered on top of the raw batch loop,
        both added after a real overnight run against a resource-starved
        local Ollama server that spent hours failing every single batch
        with the same timeout, with no way to know that short of watching
        it scroll by:

        1. PRE-FLIGHT HEALTH CHECK — before touching any batch, a cheap
           `self._provider.health_check()` probe (seconds, not the full
           `embeddings_timeout_seconds`). If the provider is unreachable
           right now, every chunk is returned as FAILED immediately with
           a clear reason, instead of discovering the same thing batch by
           batch over a much longer period.

        2. CIRCUIT BREAKER — if `settings.embeddings_circuit_breaker_
           threshold` consecutive batches (in completion order) come back
           fully failed, no further not-yet-started batches are
           submitted. Chunks in batches that hadn't started are left
           untouched (not embedded, not marked as any special failure
           state) — a later `embed_many`/`embeddings retry-failed` call
           picks them up fresh once the underlying issue is resolved.
           This is a genuine stop, not a raised exception: the caller
           gets back whatever succeeded, plus enough information (via the
           log line) to know the run stopped early rather than finished.
        """
        batches = list(batched(chunk_ids, settings.embeddings_batch_size))
        if not batches:
            return []

        if not self._provider.health_check():
            # Attempt to auto-start Ollama specifically (no-op, returns
            # False immediately, for any other provider) — see
            # src/pipeline/ollama_manager.py's module docstring for why
            # this is scoped to Ollama only. On success, re-check health
            # once before falling through to the skip-everything path.
            base_url = getattr(self._provider, "_base_url", settings.embeddings_ollama_base_url)
            if ensure_ollama_running(base_url, provider_name=self._provider.provider_name) and self._provider.health_check():
                logger.info("Provider=%s recovered after auto-start — proceeding with the batch normally.", self._provider.provider_name)
            else:
                logger.warning(
                    "Pre-flight health check failed for provider=%s — provider is unreachable, "
                    "skipping all %s chunk(s) across %s batch(es) without attempting them. "
                    "Check the provider is running (e.g. 'ollama serve') and retry.",
                    self._provider.provider_name, len(chunk_ids), len(batches),
                )
                return [
                    {"status": "FAILED", "chunk_id": chunk_id, "error": f"Pre-flight health check failed for provider={self._provider.provider_name!r} — provider unreachable."}
                    for chunk_id in chunk_ids
                ]

        def _run(batch_ids: list[int]) -> list[EmbeddingOutcome]:
            with session_factory() as worker_session:
                return self._embed_batch(worker_session, batch_ids, force=force)

        workers = max(1, min(settings.embeddings_max_concurrent_requests, len(batches)))
        results: list[EmbeddingOutcome] = []
        threshold = settings.embeddings_circuit_breaker_threshold
        consecutive_failed_batches = 0
        circuit_tripped = False

        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_batch = {executor.submit(_run, batch_ids): batch_ids for batch_ids in batches}
            not_yet_done = set(future_to_batch)
            for future in as_completed(future_to_batch):
                not_yet_done.discard(future)
                try:
                    batch_result = future.result()
                except CancelledError:
                    # This future was cancelled by an earlier iteration of
                    # this same loop tripping the breaker (see below) —
                    # as_completed() still yields cancelled futures, it
                    # just means "done", not "succeeded". Nothing to
                    # record: these chunks were never attempted.
                    continue
                results.extend(batch_result)

                batch_fully_failed = bool(batch_result) and all(o.get("status") == "FAILED" for o in batch_result)
                consecutive_failed_batches = consecutive_failed_batches + 1 if batch_fully_failed else 0

                if threshold and consecutive_failed_batches >= threshold and not circuit_tripped:
                    circuit_tripped = True
                    cancelled = sum(1 for f in not_yet_done if f.cancel())
                    still_running = len(not_yet_done) - cancelled
                    logger.warning(
                        "Circuit breaker tripped after %s consecutive fully-failed batches — "
                        "cancelled %s not-yet-started batch(es); %s already-in-progress batch(es) "
                        "will still finish. %s chunk(s) embedded successfully before the trip.",
                        consecutive_failed_batches, cancelled, still_running,
                        sum(1 for o in results if o.get("status") == "SUCCESS"),
                    )

        return results

    # ------------------------------------------------------------------
    # Core batch logic
    # ------------------------------------------------------------------

    def _embed_batch(self, session: Session, chunk_ids: list[int], *, force: bool) -> list[EmbeddingOutcome]:
        outcomes: list[EmbeddingOutcome] = []
        eligible: list[tuple[Chunk, Embedding | None]] = []  # (chunk, existing_active_embedding_or_None)

        for chunk_id in chunk_ids:
            chunk = session.query(Chunk).filter(Chunk.id == chunk_id).first()
            if chunk is None:
                telemetry.record_failure()
                outcomes.append({"status": "FAILED", "chunk_id": chunk_id, "error": "Chunk not found"})
                continue

            try:
                validate_chunk_has_text(chunk)
                existing = check_duplicate_active_embedding(
                    session,
                    chunk_id,
                    provider=self._provider.provider_name,
                    model_name=self._provider.model_name,
                    model_version=self._provider.model_version,
                    force=force,
                )
                eligible.append((chunk, existing))
            except DuplicateEmbeddingError as exc:
                telemetry.record_skipped()
                self._record_history(
                    session, chunk_id=chunk_id, status=EmbeddingRunStatusEnum.SKIPPED,
                    started_at=datetime.now(timezone.utc), duration=0.0, error_message=str(exc),
                )
                outcomes.append({"status": "SKIPPED", "chunk_id": chunk_id, "error": str(exc)})
            except EmbeddingError as exc:
                telemetry.record_failure()
                self._record_history(
                    session, chunk_id=chunk_id, status=EmbeddingRunStatusEnum.FAILED,
                    started_at=datetime.now(timezone.utc), duration=0.0, error_message=str(exc),
                )
                session.commit()
                outcomes.append({"status": "FAILED", "chunk_id": chunk_id, "error": str(exc)})

        if not eligible:
            return outcomes

        texts = [chunk.text for chunk, _ in eligible]
        started_at = datetime.now(timezone.utc)
        start = time.monotonic()
        retries_used = 0

        def _attempt() -> list[list[float]]:
            return self._provider.embed_batch(texts)

        def _on_retry(attempt_number: int, exc: Exception) -> None:
            nonlocal retries_used
            retries_used = attempt_number
            telemetry.record_retry()
            logger.warning("Embedding batch attempt %s failed, retrying: %s", attempt_number, exc)

        try:
            vectors = with_retries(
                _attempt,
                retry_limit=settings.embeddings_retry_limit,
                backoff_seconds=settings.embeddings_retry_backoff_seconds,
                retryable_exceptions=(ProviderUnavailableError,),
                on_retry=_on_retry,
            )
        except ProviderUnavailableError as exc:
            duration = time.monotonic() - start
            for chunk, _ in eligible:
                telemetry.record_failure()
                self._record_history(
                    session, chunk_id=chunk.id, status=EmbeddingRunStatusEnum.FAILED,
                    started_at=started_at, duration=duration, error_message=str(exc), retries=retries_used,
                )
            session.commit()
            logger.warning("Embedding batch failed for %s chunk(s) after retries: %s", len(eligible), exc)
            outcomes.extend(
                {"status": "FAILED", "chunk_id": chunk.id, "error": str(exc), "retries": retries_used}
                for chunk, _ in eligible
            )
            return outcomes

        duration = time.monotonic() - start
        telemetry.record_batch(len(texts))

        vector_store = get_vector_store(self._vector_store_backend, session=session)

        for (chunk, existing), vector, text in zip(eligible, vectors, texts):
            outcome = self._persist_one(
                session,
                chunk=chunk,
                existing=existing,
                vector=vector,
                vector_store=vector_store,
                started_at=started_at,
                duration=duration / len(eligible),
                retries=retries_used,
            )
            outcomes.append(outcome)

        return outcomes

    def _persist_one(
        self,
        session: Session,
        *,
        chunk: Chunk,
        existing: Embedding | None,
        vector: list[float],
        vector_store,
        started_at: datetime,
        duration: float,
        retries: int,
    ) -> EmbeddingOutcome:
        try:
            validate_embedding_vector(vector, expected_dimension=self._provider.embedding_dimension)

            document = session.query(DocumentRegistry).filter(DocumentRegistry.id == chunk.document_id).first()
            if document is None:
                raise EmbeddingValidationError(f"Chunk {chunk.id} references a missing DocumentRegistry {chunk.document_id}.")
            company = session.query(Company).filter(Company.id == document.company_id).first()
            if company is None:
                raise EmbeddingValidationError(f"Document {document.id} references a missing Company {document.company_id}.")

            metadata = build_vector_metadata(chunk, document, company)
            problems = validate_vector_metadata(metadata)
            if problems:
                raise EmbeddingValidationError("; ".join(problems))

            if existing is not None:
                existing.status = EmbeddingStatusEnum.SUPERSEDED
                existing.is_active = False

            embedding_uid = f"{chunk.id}:{self._provider.provider_name}:{self._provider.model_name}:{self._provider.model_version}"
            row = Embedding(
                embedding_id=embedding_uid,
                chunk_id=chunk.id,
                document_id=chunk.document_id,
                provider=self._provider.provider_name,
                model_name=self._provider.model_name,
                model_version=self._provider.model_version,
                embedding_dimension=self._provider.embedding_dimension,
                status=EmbeddingStatusEnum.ACTIVE,
                is_active=True,
                vector_store_backend=self._vector_store_backend,
                token_count=estimate_tokens(chunk.text),
            )
            session.add(row)
            vector_store.insert_vector(embedding_row=row, vector=vector, metadata=metadata)
            session.flush()

            self._record_history(
                session, chunk_id=chunk.id, status=EmbeddingRunStatusEnum.SUCCESS,
                started_at=started_at, duration=duration, token_count=row.token_count, retries=retries,
            )
            session.commit()

            telemetry.record_success(tokens=row.token_count or 0, duration=duration, provider=self._provider.provider_name)

            return {
                "status": "SUCCESS",
                "chunk_id": chunk.id,
                "embedding_id": row.id,
                "document_id": chunk.document_id,
                "provider": self._provider.provider_name,
                "model_name": self._provider.model_name,
                "model_version": self._provider.model_version,
                "embedding_dimension": self._provider.embedding_dimension,
                "embedding_duration": round(duration, 4),
                "retries": retries,
            }

        except EmbeddingError as exc:
            session.rollback()
            telemetry.record_failure()
            self._record_history(
                session, chunk_id=chunk.id, status=EmbeddingRunStatusEnum.FAILED,
                started_at=started_at, duration=duration, error_message=str(exc), retries=retries,
            )
            session.commit()
            logger.warning("Embedding persistence failed for Chunk %s: %s", chunk.id, exc)
            return {"status": "FAILED", "chunk_id": chunk.id, "error": str(exc), "retries": retries}

    def _record_history(
        self,
        session: Session,
        *,
        chunk_id: int,
        status: EmbeddingRunStatusEnum,
        started_at: datetime,
        duration: float,
        error_message: str | None = None,
        token_count: int | None = None,
        retries: int = 0,
    ) -> None:
        attempt_number = session.query(EmbeddingHistory).filter(EmbeddingHistory.chunk_id == chunk_id).count() + 1
        session.add(
            EmbeddingHistory(
                chunk_id=chunk_id,
                attempt_number=attempt_number,
                provider=self._provider.provider_name,
                model_name=self._provider.model_name,
                model_version=self._provider.model_version,
                run_status=status,
                error_message=error_message,
                retries=retries,
                token_count=token_count,
                started_at=started_at,
                duration_seconds=duration,
            )
        )
