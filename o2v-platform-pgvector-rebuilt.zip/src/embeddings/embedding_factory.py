"""
Embedding provider registry and factory — the single place provider
selection happens, and the only file that needs a new class + one
`@register_provider(...)` line to add a provider (per the brief's
"Future providers should require only: 1. Create provider class. 2.
Register provider. 3. No architecture changes.").

Design decision: concrete provider classes live in this file rather than
one-file-per-provider (unlike, say, `parser/html_parser.py` vs
`parser/pdf_parser.py` being split out in Sprint 4) because the Sprint 6
brief's package structure explicitly enumerates the Sprint 6 file list
and doesn't include per-provider files — `embedding_factory.py` is
named as the provider-registration surface, so that's where providers
(including the placeholders) are defined and registered. Splitting them
out later, if the placeholder list grows further, is a pure refactor
that doesn't change `get_provider()`'s contract.

Design decision: OpenAI and Ollama both have real `embed_batch()`
implementations — OpenAI as a commercial, API-key-gated option; Ollama as
the local, no-cost default (see `settings.py`'s module comment on
`embeddings_provider` for why Ollama is the default, not OpenAI). Nomic /
BGE / E5 / Sentence Transformers / LM Studio / Azure OpenAI remain
architecture placeholders — registered, constructible, and passing
through `BaseEmbeddingProvider`'s shared validation — but their
`embed_batch()` raises `ProviderUnavailableError` naming the missing
dependency/integration. Each is exactly the same shape as the other two
providers, so wiring up a real implementation later is additive: one
class, no changes anywhere else in this file or in `embedding_service.py`.
"""

from __future__ import annotations

import httpx

from src.config.settings import settings
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.exceptions import (
    EmbeddingConfigurationError,
    InvalidProviderResponseError,
    ProviderUnavailableError,
)
from src.embeddings.types import EmbeddingVector

_PROVIDER_REGISTRY: dict[str, type[BaseEmbeddingProvider]] = {}


def register_provider(name: str):
    """Class decorator: registers a `BaseEmbeddingProvider` subclass under `name` in the factory."""

    def decorator(cls: type[BaseEmbeddingProvider]) -> type[BaseEmbeddingProvider]:
        _PROVIDER_REGISTRY[name] = cls
        return cls

    return decorator


def available_providers() -> list[str]:
    return sorted(_PROVIDER_REGISTRY)


def get_provider(name: str | None = None, **overrides) -> BaseEmbeddingProvider:
    """
    Construct a provider by name (defaulting to `settings.embeddings_provider`),
    with `model_name`/`model_version`/`embedding_dimension` defaulting from
    settings and overridable per call — the single choke point
    `EmbeddingGenerationService` (and the CLI) go through, so no other
    module ever imports a concrete provider class directly.
    """
    provider_name = (name or settings.embeddings_provider).lower()
    try:
        provider_cls = _PROVIDER_REGISTRY[provider_name]
    except KeyError as exc:
        raise EmbeddingConfigurationError(
            f"Unknown embedding provider {provider_name!r}. Available: {available_providers()}"
        ) from exc

    kwargs = {
        "model_name": overrides.pop("model_name", settings.embeddings_model_name),
        "model_version": overrides.pop("model_version", settings.embeddings_model_version),
        "embedding_dimension": overrides.pop("embedding_dimension", settings.embeddings_dimension),
    }
    kwargs.update(overrides)
    return provider_cls(**kwargs)


# ---------------------------------------------------------------------------
# OpenAI — the one provider with a real implementation in Sprint 6.
# ---------------------------------------------------------------------------


@register_provider("openai")
class OpenAIEmbeddingProvider(BaseEmbeddingProvider):
    provider_name = "openai"

    def __init__(
        self,
        *,
        model_name: str,
        model_version: str,
        embedding_dimension: int,
        api_key: str | None = None,
        timeout: float | None = None,
        client=None,
    ):
        super().__init__(model_name=model_name, model_version=model_version, embedding_dimension=embedding_dimension)
        self._api_key = api_key or settings.embeddings_openai_api_key
        self._timeout = timeout or settings.embeddings_timeout_seconds
        # Injectable for tests — avoids every test needing a real API key
        # or network access to exercise `embed_batch`'s validation logic.
        self._client = client

    def _get_client(self):
        if self._client is not None:
            return self._client
        if not self._api_key:
            raise ProviderUnavailableError(
                "OpenAI embedding provider requires an API key — set OPENAI_API_KEY "
                "(loaded as settings.embeddings_openai_api_key)."
            )
        try:
            import openai
        except ImportError as exc:
            raise ProviderUnavailableError(
                "The 'openai' package is not installed. Add it to requirements.txt to use this provider."
            ) from exc
        self._client = openai.OpenAI(api_key=self._api_key, timeout=self._timeout)
        return self._client

    def embed_batch(self, texts: list[str]) -> list[EmbeddingVector]:
        if not texts:
            return []

        client = self._get_client()
        try:
            response = client.embeddings.create(
                model=self.model_name,
                input=texts,
                dimensions=self.embedding_dimension,
            )
        except ProviderUnavailableError:
            raise
        except Exception as exc:  # provider SDK errors are re-raised as our domain exception
            raise ProviderUnavailableError(f"OpenAI embeddings request failed: {exc}") from exc

        # The API is documented to preserve input order, but sorting by
        # the returned `.index` is cheap insurance against relying on
        # that undocumented-in-practice guarantee.
        vectors = [item.embedding for item in sorted(response.data, key=lambda item: item.index)]
        self.validate_batch_response(texts, vectors)
        return vectors


# ---------------------------------------------------------------------------
# Ollama — the local, no-cost default provider (see settings.py).
# ---------------------------------------------------------------------------


@register_provider("ollama")
class OllamaEmbeddingProvider(BaseEmbeddingProvider):
    """
    Calls a locally-running Ollama server's `/api/embed` endpoint —
    requires no API key and no external network access, which is the
    whole point of it being the platform default. Requires Ollama itself
    to be installed and running, and the configured model to be pulled
    (`ollama pull nomic-embed-text` for the default model).
    """

    provider_name = "ollama"

    def __init__(
        self,
        *,
        model_name: str,
        model_version: str,
        embedding_dimension: int,
        base_url: str | None = None,
        timeout: float | None = None,
        client: httpx.Client | None = None,
    ):
        super().__init__(model_name=model_name, model_version=model_version, embedding_dimension=embedding_dimension)
        self._base_url = (base_url or settings.embeddings_ollama_base_url).rstrip("/")
        self._timeout = timeout or settings.embeddings_timeout_seconds
        # Injectable for tests — avoids every test needing a real,
        # locally-running Ollama server to exercise this provider's logic.
        self._client = client

    def _get_client(self) -> httpx.Client:
        if self._client is not None:
            return self._client
        self._client = httpx.Client(timeout=self._timeout)
        return self._client

    def embed_batch(self, texts: list[str]) -> list[EmbeddingVector]:
        if not texts:
            return []

        client = self._get_client()
        try:
            response = client.post(
                f"{self._base_url}/api/embed",
                json={"model": self.model_name, "input": texts},
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise ProviderUnavailableError(
                f"Ollama returned HTTP {exc.response.status_code} for model {self.model_name!r} — "
                f"is the model pulled? Try: ollama pull {self.model_name}. Response: {exc.response.text[:300]}"
            ) from exc
        except httpx.HTTPError as exc:
            raise ProviderUnavailableError(
                f"Could not reach Ollama at {self._base_url} — is it running? "
                f"Start it with 'ollama serve', or set EMBEDDINGS_OLLAMA_BASE_URL. ({exc})"
            ) from exc

        try:
            payload = response.json()
            vectors = payload["embeddings"]
        except (ValueError, KeyError, TypeError) as exc:
            raise InvalidProviderResponseError(
                f"Ollama returned an unexpected response shape (expected a JSON object with an "
                f"'embeddings' list): {exc}"
            ) from exc

        self.validate_batch_response(texts, vectors)
        return vectors

    def health_check(self, timeout: float | None = None) -> bool:
        """
        Fast override: a plain GET to Ollama's root endpoint (what
        `curl http://localhost:11434` hits — returns "Ollama is running")
        rather than the base class's default of a real `embed_batch` call.
        This is deliberately independent of `self._timeout`
        (`embeddings_timeout_seconds`, which can be tens of seconds) —
        it uses its own short `timeout` (default
        `settings.embeddings_health_check_timeout_seconds`) so a dead
        server is detected in a few seconds, not by waiting out the same
        long timeout the real embedding calls use.
        """
        check_timeout = timeout if timeout is not None else settings.embeddings_health_check_timeout_seconds
        try:
            response = httpx.get(self._base_url, timeout=check_timeout)
            return response.status_code == 200
        except httpx.HTTPError:
            return False


# ---------------------------------------------------------------------------
# Architecture placeholders — registered and constructible, not yet wired
# to a real backend. See module docstring.
# ---------------------------------------------------------------------------


class _PlaceholderEmbeddingProvider(BaseEmbeddingProvider):
    """Shared placeholder behavior: valid construction, `embed_batch` refuses to run."""

    integration_hint: str = "not yet implemented"

    def embed_batch(self, texts: list[str]) -> list[EmbeddingVector]:
        raise ProviderUnavailableError(
            f"{self.provider_name} is registered as an architecture placeholder — {self.integration_hint}."
        )


@register_provider("nomic")
class NomicEmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "nomic"
    integration_hint = "wire up the Nomic Atlas API client to enable it"


@register_provider("bge")
class BGEEmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "bge"
    integration_hint = "wire up a BGE model runner (e.g. via sentence-transformers or a local server) to enable it"


@register_provider("e5")
class E5EmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "e5"
    integration_hint = "wire up an E5 model runner to enable it"


@register_provider("sentence_transformers")
class SentenceTransformersEmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "sentence_transformers"
    integration_hint = "add the sentence-transformers dependency and a local inference call to enable it"


@register_provider("lm_studio")
class LMStudioEmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "lm_studio"
    integration_hint = "wire up a call to a running LM Studio server's OpenAI-compatible embeddings endpoint to enable it"


@register_provider("azure_openai")
class AzureOpenAIEmbeddingProvider(_PlaceholderEmbeddingProvider):
    provider_name = "azure_openai"
    integration_hint = "wire up the Azure OpenAI client (endpoint + deployment name) to enable it"
