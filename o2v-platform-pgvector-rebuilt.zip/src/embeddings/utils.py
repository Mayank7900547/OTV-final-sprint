"""
Generic helpers shared by the embedding pipeline: batching and a
retry-with-backoff wrapper.

Design decision: no numpy/torch dependency. Vectors are plain
`list[float]` everywhere in this package (see `types.py::EmbeddingVector`)
— Sprint 6 only generates and stores vectors, it never does math on them
(no similarity search, see `vector_store.py`'s module docstring), so
there's nothing here that benefits from a numeric array library.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


def batched(items: list[T], batch_size: int) -> Iterable[list[T]]:
    """Yield `items` split into consecutive chunks of at most `batch_size` — used to respect provider batch limits."""
    if batch_size <= 0:
        raise ValueError(f"batch_size must be positive, got {batch_size}.")
    for start in range(0, len(items), batch_size):
        yield items[start : start + batch_size]


def with_retries(
    func: Callable[[], T],
    *,
    retry_limit: int,
    backoff_seconds: float,
    retryable_exceptions: tuple[type[Exception], ...],
    on_retry: Callable[[int, Exception], None] | None = None,
    sleep_fn: Callable[[float], None] = time.sleep,
) -> T:
    """
    Call `func()`, retrying up to `retry_limit` additional times (so
    `retry_limit + 1` attempts total) on any exception in
    `retryable_exceptions`, with linear backoff (`backoff_seconds *
    attempt_number` between attempts).

    `sleep_fn` is injectable so tests exercise real retry/backoff logic
    without a real test run taking `retry_limit * backoff_seconds`
    seconds — a fake no-op sleep is a legitimate test double here, unlike
    faking the thing actually under test (the retry loop itself, which
    still runs for real).
    """
    last_exception: Exception | None = None
    for attempt in range(retry_limit + 1):
        try:
            return func()
        except retryable_exceptions as exc:  # noqa: PERF203 - retry loops inherently try/except per iteration
            last_exception = exc
            if attempt >= retry_limit:
                break
            if on_retry:
                on_retry(attempt + 1, exc)
            sleep_fn(backoff_seconds * (attempt + 1))
    assert last_exception is not None  # loop always either returns or sets this before breaking
    raise last_exception
