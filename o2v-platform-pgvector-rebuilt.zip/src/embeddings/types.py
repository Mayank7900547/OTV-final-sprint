"""Shared type definitions for Sprint 6 Embedding Generation — mirrors `src/chunking/types.py`."""

from typing import TypedDict
from uuid import UUID

#: A single embedding vector — plain floats, no numpy dependency required
#: anywhere in this package (see `utils.py`'s docstring for why).
EmbeddingVector = list[float]


class VectorMetadata(TypedDict):
    """
    The metadata every stored vector must carry, per the Sprint 6 brief's
    "Vector Metadata" section — built by `metadata.py::build_vector_metadata`
    and handed to `vector_store.py` unchanged, so every backend (Postgres
    today, Qdrant/Pinecone/etc later) receives the identical shape.
    """

    company: str
    document_id: str
    chunk_id: str
    page_number: int | None
    section_title: str | None
    document_type: str
    creation_timestamp: str
    chunk_index: int


class EmbeddingOutcome(TypedDict, total=False):
    """Standardized result dictionary returned after embedding one chunk."""

    status: str  # SUCCESS, FAILED, PARTIAL, SKIPPED
    chunk_id: int
    embedding_id: int
    document_id: UUID
    provider: str
    model_name: str
    model_version: str
    embedding_dimension: int
    embedding_duration: float
    retries: int
    error: str


class EmbeddingSummary(TypedDict):
    """Aggregated telemetry summary for an embedding run — see `telemetry.py`."""

    chunks_embedded: int
    tokens_processed: int
    average_embedding_latency: float
    batch_throughput: float
    failed_embeddings: int
    retry_count: int
    active_provider: str
    skipped_chunks: int
    success_rate: float
