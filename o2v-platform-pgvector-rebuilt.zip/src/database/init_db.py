"""
Database initialization.

Design decision: use `Base.metadata.create_all()` for Sprint 1 rather than
introducing Alembic migrations immediately.

This is a deliberate, temporary tradeoff, not an oversight: the schema is
still being established, and Alembic's value is in managing *changes* to
an already-deployed schema over time. Introducing a migration tool before
the first schema is even stable adds process overhead without yet solving
a real problem.

Sprint 2 adds a new table (Document Registry) via this same mechanism —
`create_all()` handles brand-new tables just fine; it's altering an
EXISTING table already holding data (adding/renaming/dropping a column on
`companies` or `frameworks`) that it can't express safely. That's the
actual trigger for introducing Alembic, whenever it first happens — not
simply "a later sprint," which the Sprint 1 version of this comment
implied a little too broadly.

Importing every model module here (even though we don't use the imported
names directly) is required so their table definitions register on
`Base.metadata` before `create_all()` runs — a common SQLAlchemy gotcha
worth calling out explicitly in a comment so it isn't "fixed" by removing
the "unused" imports later.
"""

from src.config.logging_config import get_logger
from src.database.base import Base
from src.database.connection import engine

# Import models so their tables register on Base.metadata.
# noqa: F401 — imported for side effect (table registration), not direct use.
from src.models import company as _company_model  # noqa: F401
from src.models import document as _document_model  # noqa: F401
from src.models import framework as _framework_model  # noqa: F401
from src.acquisition import models as _acquisition_model  # noqa: F401
from src.parser import models as _parser_model  # noqa: F401
from src.chunking import models as _chunking_model  # noqa: F401
from src.embeddings import models as _embeddings_model  # noqa: F401
from src.retrieval import models as _retrieval_model  # noqa: F401
from src.extraction import models as _extraction_model  # noqa: F401

logger = get_logger(__name__)


def init_db() -> None:
    """Create all tables that don't yet exist. Safe to call repeatedly (idempotent)."""
    logger.info("Initializing database schema...")
    Base.metadata.create_all(bind=engine)
    logger.info("Database schema is up to date.")
