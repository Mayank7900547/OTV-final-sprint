"""
Declarative base for all ORM models.

Design decision: a single shared `Base` in its own module (not inside
`connection.py` and not redefined per-model) so that:
1. `models/company.py` and `models/framework.py` (and every model added in
   later sprints) import the SAME base — required for `Base.metadata.create_all()`
   in `init_db.py` to know about every table.
2. There's no circular import risk between `database/connection.py` (which
   needs an engine) and `models/*.py` (which need `Base`) — both depend on
   this tiny module instead of on each other.
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Base class for all ORM models in the platform."""
