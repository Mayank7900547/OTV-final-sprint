"""
Database engine and session factory.

Design decision: expose a `session_scope()` context manager as the primary
way the rest of the app talks to the database, rather than handing out raw
sessions everywhere. This guarantees commit/rollback/close happens
consistently — a service function that forgets to close a session is a
real (and easy to introduce) bug; a context manager makes it structurally
impossible to forget.

The engine itself is created once at import time with `pool_pre_ping=True`
(cheap connectivity check before reusing a pooled connection) since this
app will run as long-lived CLI/worker processes where stale connections
after DB restarts are a realistic failure mode, even at Sprint 1 scale.
"""

from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from src.config.logging_config import get_logger
from src.config.settings import settings
from src.core.exceptions import DatabaseError, O2VError

logger = get_logger(__name__)

engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    future=True,
)

SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    future=True,
    # expire_on_commit=False is required because CLI commands read ORM
    # object attributes (e.g. company.name) AFTER `session_scope()` has
    # committed and closed the session — e.g. building a Rich table row per
    # company. With the default expire_on_commit=True, every attribute
    # becomes a lazy-load on first access post-commit, which fails with
    # DetachedInstanceError once the session is closed. Since this app's
    # session lifetime is intentionally short (one CLI command = one
    # session), we accept slightly-stale-until-next-read attributes in
    # exchange for objects remaining usable after the `with` block exits.
    expire_on_commit=False,
)


@contextmanager
def session_scope() -> Iterator[Session]:
    """
    Provide a transactional scope around a series of operations.

    Usage:
        with session_scope() as session:
            session.add(some_object)

    On success: commits. On any exception: rolls back and re-raises wrapped
    as a `DatabaseError` (see core/exceptions.py) so callers up the stack
    (CLI commands) can catch one predictable error type instead of needing
    to know about SQLAlchemy's internal exception hierarchy.
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except O2VError:
        # Application-level errors (e.g. CompanyImportError for a missing
        # CSV, FrameworkValidationError for bad YAML) are raised
        # deliberately by service code and already carry a specific,
        # actionable message and type. Re-raise unchanged so the CLI's
        # `except CompanyImportError` / `except FrameworkValidationError`
        # handlers still catch them — wrapping these in DatabaseError would
        # be actively misleading (the database did nothing wrong) and
        # would break every specific-exception handler in the CLI layer.
        session.rollback()
        raise
    except Exception as exc:
        # Anything NOT already an O2VError is an unexpected failure
        # (connection drop, constraint violation we didn't anticipate,
        # etc.) — these genuinely are database-layer problems, so wrapping
        # them as DatabaseError and logging the full traceback is correct
        # here, unlike the branch above.
        session.rollback()
        logger.exception("Unexpected database session failure, rolling back.")
        raise DatabaseError(str(exc)) from exc
    finally:
        session.close()


def check_connection() -> bool:
    """
    Lightweight connectivity check used by `o2v db status`.

    Returns True/False rather than raising, because this function's entire
    purpose is to be called from a health-check context where the caller
    wants a boolean, not a stack trace.
    """
    try:
        with engine.connect() as connection:
            connection.exec_driver_sql("SELECT 1")
        return True
    except Exception:
        logger.exception("Database connectivity check failed.")
        return False
