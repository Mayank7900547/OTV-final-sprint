"""
CLI entry point.

Design decision: Typer, not argparse or click directly. Typer is built on
click but gives us type-hint-driven argument parsing and auto-generated
`--help` text, which matters because this CLI is the ONLY interface to the
platform in Sprint 1 — no web UI exists yet — so its usability as a
standalone tool is not a nice-to-have.

Design decision: every command body is intentionally thin — open a DB
session, call a service function, format the result. All actual logic
lives in `services/` and `registry/` (see those modules' docstrings for
why). This is what will let a future FastAPI-based Platform API
(architecture doc, Section 3.13) reuse the exact same service functions
this CLI calls, without duplicating logic.
"""

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from src.config.logging_config import configure_logging, get_logger
from src.config.settings import settings
from src.core.exceptions import CompanyImportError, DiscoveryError, FrameworkValidationError, O2VError
from src.database.connection import check_connection, session_scope
from src.database.init_db import init_db
from src.registry.framework_loader import load_and_flatten
from src.services import company_service, document_discovery_service, document_service, framework_service
from src.utils.paths import ensure_data_dirs
from src.acquisition.cli import acquisition_app
from src.parser.cli import parser_app
from src.chunking.cli import chunking_app
from src.embeddings.cli import embeddings_app
from src.retrieval.cli import retrieval_app
from src.extraction.cli import extraction_app
from src.pipeline.cli import pipeline_app

app = typer.Typer(
    name="o2v",
    help="O2V AI Platform — CLI (Sprint 2: + Document Discovery, no AI yet).",
    add_completion=False,
)
company_app = typer.Typer(help="Manage the Company Registry.")
framework_app = typer.Typer(help="Manage the Framework Registry.")
db_app = typer.Typer(help="Database utilities.")
discover_app = typer.Typer(help="Run document discovery for companies.")
document_app = typer.Typer(help="View discovered documents.")

app.add_typer(company_app, name="company")
app.add_typer(framework_app, name="framework")
app.add_typer(db_app, name="db")
app.add_typer(discover_app, name="discover")
app.add_typer(document_app, name="document")
app.add_typer(acquisition_app, name="acquisition")
app.add_typer(parser_app, name="parser")
app.add_typer(chunking_app, name="chunking")
app.add_typer(embeddings_app, name="embeddings")
app.add_typer(retrieval_app, name="retrieval")
app.add_typer(extraction_app, name="extraction")
app.add_typer(pipeline_app, name="pipeline")

console = Console()
logger = get_logger(__name__)


def _handle_o2v_error(exc: O2VError) -> None:
    """Consistent error presentation across all commands (see core/exceptions.py docstring)."""
    console.print(f"[bold red]Error:[/bold red] {exc}")
    raise typer.Exit(code=1)


# --------------------------------------------------------------------------
# Top-level commands
# --------------------------------------------------------------------------


@app.command()
def init() -> None:
    """
    Initialize the platform: create data/log directories and database tables.

    This is the single command a new environment (fresh Docker container,
    fresh dev machine) needs to run before anything else works — it exists
    so "how do I get started" has exactly one answer, not a checklist.
    """
    configure_logging()
    console.print(f"[bold]Initializing {settings.app_name}[/bold] "
                  f"(environment: {settings.environment.value})")

    ensure_data_dirs()
    console.print("[green]Data/log directories ready.[/green]")

    try:
        init_db()
    except Exception as exc:  # noqa: BLE001 - top-level CLI boundary
        console.print(f"[bold red]Database initialization failed:[/bold red] {exc}")
        console.print(
            "[yellow]Check your .env database settings and that Postgres is running "
            "(see README > Running with Docker).[/yellow]"
        )
        raise typer.Exit(code=1)

    console.print("[green]Database schema ready.[/green]")
    console.print(
        "\n[bold]Next steps:[/bold]\n"
        "  o2v framework import data/frameworks/o2v.yaml\n"
        "  o2v company import data/companies/sample_companies.csv\n"
        "  o2v discover documents \"Apple Inc.\"\n"
        "  o2v db status"
    )


# --------------------------------------------------------------------------
# db commands
# --------------------------------------------------------------------------


@db_app.command("status")
def db_status() -> None:
    """Check database connectivity and report row counts for each registry."""
    configure_logging()
    connected = check_connection()

    if not connected:
        console.print("[bold red]Database: NOT reachable.[/bold red]")
        console.print(f"  Configured host: {settings.db_host}:{settings.db_port}/{settings.db_name}")
        raise typer.Exit(code=1)

    console.print("[bold green]Database: connected.[/bold green]")

    with session_scope() as session:
        company_count = company_service.count_companies(session)
        framework_count = framework_service.count_frameworks(session)
        document_count = document_service.count_documents(session)

    table = Table(title="Registry Status")
    table.add_column("Registry")
    table.add_column("Count", justify="right")
    table.add_row("Companies", str(company_count))
    table.add_row("Frameworks", str(framework_count))
    table.add_row("Documents", str(document_count))
    console.print(table)


# --------------------------------------------------------------------------
# company commands
# --------------------------------------------------------------------------


@company_app.command("import")
def company_import(
    csv_path: Path = typer.Argument(..., help="Path to a CSV file with a 'name' column.")
) -> None:
    """Bulk-import companies from a CSV file (skips companies that already exist by name)."""
    configure_logging()
    try:
        with session_scope() as session:
            result = company_service.import_companies_from_csv(session, csv_path)
    except CompanyImportError as exc:
        _handle_o2v_error(exc)
        return

    console.print(
        f"[green]Imported {len(result['created'])} new companies[/green] "
        f"out of {result['total_rows']} rows "
        f"({len(result['skipped_existing'])} already existed and were skipped)."
    )
    if result["skipped_existing"]:
        console.print(f"[yellow]Skipped:[/yellow] {', '.join(result['skipped_existing'])}")


@company_app.command("list")
def company_list(
    limit: int = typer.Option(50, help="Maximum number of companies to display."),
) -> None:
    """List companies in the registry."""
    configure_logging()
    with session_scope() as session:
        companies = company_service.list_companies(session, limit=limit)
        total = company_service.count_companies(session)

    table = Table(title=f"Companies (showing {len(companies)} of {total})")
    table.add_column("Name")
    table.add_column("Ticker")
    table.add_column("Sector")
    table.add_column("Country")
    table.add_column("Status")

    for c in companies:
        table.add_row(c.name, c.ticker or "-", c.sector or "-", c.country or "-", c.status)

    console.print(table)


# --------------------------------------------------------------------------
# framework commands
# --------------------------------------------------------------------------


@framework_app.command("import")
def framework_import(
    yaml_path: Path = typer.Argument(..., help="Path to a framework definition YAML file.")
) -> None:
    """
    Import (or re-sync) a framework definition from a YAML file.

    This is the command that proves "add a framework without changing code":
    write a new YAML file under data/frameworks/, run this command, done.
    """
    configure_logging()
    try:
        framework_name, rows = load_and_flatten(yaml_path)
        with session_scope() as session:
            result = framework_service.upsert_framework_fields(session, framework_name, rows)
    except FrameworkValidationError as exc:
        _handle_o2v_error(exc)
        return

    console.print(
        f"[green]Framework '{result['framework_name']}' imported:[/green] "
        f"{result['fields_written']} fields written."
    )


@framework_app.command("show")
def framework_show(
    framework_name: str = typer.Argument(
        None, help="Framework name to show fields for. Omit to list all registered frameworks."
    )
) -> None:
    """Show registered frameworks, or the fields of one specific framework."""
    configure_logging()
    with session_scope() as session:
        if framework_name is None:
            names = framework_service.list_framework_names(session)
            if not names:
                console.print(
                    "[yellow]No frameworks registered yet. "
                    "Try: o2v framework import data/frameworks/o2v.yaml[/yellow]"
                )
                return
            table = Table(title="Registered Frameworks")
            table.add_column("Framework Name")
            for name in names:
                table.add_row(name)
            console.print(table)
            return

        fields = framework_service.list_fields_for_framework(session, framework_name)
        if not fields:
            console.print(f"[yellow]No fields found for framework '{framework_name}'.[/yellow]")
            return

        table = Table(title=f"Framework: {framework_name}")
        table.add_column("Component")
        table.add_column("Field")
        table.add_column("Document Sources")
        for f in fields:
            sources = ", ".join(f.document_sources) if f.document_sources else "-"
            table.add_row(f.component_name, f.field_name, sources)
        console.print(table)


# --------------------------------------------------------------------------
# discover commands (Sprint 2)
# --------------------------------------------------------------------------


def _print_discovery_result(result) -> None:
    """Shared formatter for a single company's discovery outcome — used by both `discover documents` and `discover all`."""
    if result.error:
        console.print(f"[bold red]{result.company_name}: discovery failed — {result.error}[/bold red]")
        return

    console.print(
        f"[bold]{result.company_name}[/bold]: "
        f"[green]{result.created} created[/green], "
        f"{result.skipped_duplicates} duplicates skipped, "
        f"[yellow]{len(result.rejected)} rejected[/yellow], "
        f"[yellow]{len(result.unreachable)} unreachable[/yellow] "
        f"({result.total_candidates} candidates total)"
    )
    for url, reason in result.rejected:
        console.print(f"    [dim]rejected:[/dim] {url} — {reason}")


@discover_app.command("documents")
def discover_documents(
    company_name: str = typer.Argument(..., help="Exact company name, as shown in `o2v company list`.")
) -> None:
    """Discover official documents for a single company."""
    configure_logging()
    try:
        with session_scope() as session:
            company = document_discovery_service.get_company_or_raise(session, company_name)
            result = document_discovery_service.discover_for_company(session, company)
    except DiscoveryError as exc:
        _handle_o2v_error(exc)
        return

    _print_discovery_result(result)


@discover_app.command("all")
def discover_all() -> None:
    """Discover official documents for every company in the registry."""
    configure_logging()
    with session_scope() as session:
        results = document_discovery_service.discover_for_all_companies(session)

    for result in results:
        _print_discovery_result(result)

    total_created = sum(r.created for r in results)
    total_failed = sum(1 for r in results if r.error)
    console.print(
        f"\n[bold]Done.[/bold] {len(results)} companies processed, "
        f"{total_created} documents created, {total_failed} companies failed entirely."
    )


@discover_app.command("stats")
def discover_stats() -> None:
    """Show discovery statistics across the whole platform."""
    configure_logging()
    with session_scope() as session:
        total = document_service.count_documents(session)
        by_category = document_service.count_by_category(session)
        by_status = document_service.count_by_status(session)
        by_method = document_service.count_by_discovery_method(session)
        companies_with_docs = document_service.count_companies_with_documents(session)

    console.print(f"[bold]Total documents:[/bold] {total}")
    console.print(f"[bold]Companies with at least one document:[/bold] {companies_with_docs}\n")

    category_table = Table(title="By Category")
    category_table.add_column("Category")
    category_table.add_column("Count", justify="right")
    for category, count in by_category.items():
        category_table.add_row(category, str(count))
    console.print(category_table)

    status_table = Table(title="By Status")
    status_table.add_column("Status")
    status_table.add_column("Count", justify="right")
    for status, count in by_status.items():
        status_table.add_row(status, str(count))
    console.print(status_table)

    method_table = Table(title="By Discovery Method")
    method_table.add_column("Method")
    method_table.add_column("Count", justify="right")
    for method, count in by_method.items():
        method_table.add_row(method, str(count))
    console.print(method_table)


# --------------------------------------------------------------------------
# document commands (Sprint 2)
# --------------------------------------------------------------------------


@document_app.command("list")
def document_list(
    limit: int = typer.Option(50, help="Maximum number of documents to display."),
) -> None:
    """List discovered documents across all companies."""
    configure_logging()
    with session_scope() as session:
        documents = document_service.list_documents(session, limit=limit)
        total = document_service.count_documents(session)
        # Build a company_id -> name lookup so the table can show a readable
        # name instead of a raw UUID — a small extra query, worth it since
        # this command's whole purpose is human-readable output.
        companies = {c.id: c.name for c in company_service.list_companies(session, limit=10_000)}

    table = Table(title=f"Discovered Documents (showing {len(documents)} of {total})")
    table.add_column("Company")
    table.add_column("Category")
    table.add_column("Year")
    table.add_column("Method")
    table.add_column("Status")
    table.add_column("URL")

    for d in documents:
        table.add_row(
            companies.get(d.company_id, "?"),
            d.document_category,
            str(d.document_year) if d.document_year else "-",
            d.discovery_method,
            d.status,
            d.official_url,
        )
    console.print(table)


@document_app.command("show")
def document_show(
    company_name: str = typer.Argument(..., help="Exact company name, as shown in `o2v company list`.")
) -> None:
    """Show all discovered documents for a single company."""
    configure_logging()
    try:
        with session_scope() as session:
            company = document_discovery_service.get_company_or_raise(session, company_name)
            documents = document_service.list_documents(session, company_id=company.id, limit=10_000)
    except DiscoveryError as exc:
        _handle_o2v_error(exc)
        return

    if not documents:
        console.print(
            f"[yellow]No documents discovered yet for '{company_name}'. "
            f"Try: o2v discover documents \"{company_name}\"[/yellow]"
        )
        return

    table = Table(title=f"Documents: {company_name}")
    table.add_column("Category")
    table.add_column("Year")
    table.add_column("Type")
    table.add_column("Method")
    table.add_column("Status")
    table.add_column("URL")

    for d in documents:
        table.add_row(
            d.document_category,
            str(d.document_year) if d.document_year else "-",
            d.document_type,
            d.discovery_method,
            d.status,
            d.official_url,
        )
    console.print(table)


if __name__ == "__main__":
    app()
