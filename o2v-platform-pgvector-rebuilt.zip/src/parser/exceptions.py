"""
Sprint 4 domain exceptions extending the O2V core error hierarchy.

Design decision: shape mirrors `src/acquisition/exceptions.py` exactly — a
`ParserError` base (parallel to `AcquisitionError`) with specific
subclasses for each distinct failure mode a caller (the CLI, the service
layer) might want to handle differently. Kept as a flat hierarchy (all
direct children of `ParserError`) rather than nested, because none of
these failure modes are specializations of one another — an encrypted PDF
isn't a kind of malformed PDF, it's a different problem with a different
remedy (prompt for a password vs. reject the file).
"""

from src.core.exceptions import O2VError


class ParserError(O2VError):
    """Base exception for all Sprint 4 document parsing failures."""


class UnsupportedDocumentError(ParserError):
    """Raised when no registered parser can handle the document's detected type."""


class MalformedDocumentError(ParserError):
    """Raised when a document's structure is corrupt and cannot be safely parsed."""


class EncryptedDocumentError(ParserError):
    """Raised when a PDF is password-protected and cannot be opened with an empty password."""


class MetadataExtractionError(ParserError):
    """Raised when metadata extraction fails in a way that should abort parsing."""


class EmptyDocumentError(ParserError):
    """Raised when a document parses successfully but yields no extractable text."""


class DocumentNotActiveError(ParserError):
    """Raised when parsing is requested for a document version that isn't ACTIVE."""


class DuplicateParsingError(ParserError):
    """Raised when a document version has already been successfully parsed and re-parsing wasn't forced."""


class ParsingValidationError(ParserError):
    """Raised when a parsed result fails post-extraction validation (see validation.py)."""
