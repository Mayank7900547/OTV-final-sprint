"""
PDF parser.

Design decision: `pypdf` (the actively maintained successor to the
abandoned `PyPDF2`), not `pdfplumber`/`PyMuPDF`. Sprint 4 is explicitly
text + metadata extraction only (no layout/table extraction, no OCR yet —
that's a stated future placeholder), so a pure-Python, dependency-light
library that handles text extraction and metadata/encryption well is the
right amount of tool for this sprint. Swapping to a heavier library later
(for OCR or layout-aware extraction) only touches this one file, per the
package's extensibility design.
"""

from __future__ import annotations

from pathlib import Path

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from src.config.logging_config import get_logger
from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.exceptions import (
    EncryptedDocumentError,
    MalformedDocumentError,
    MetadataExtractionError,
)
from src.parser.metadata import detect_language, normalize_metadata_value, parse_pdf_date
from src.parser.utils import normalize_whitespace

logger = get_logger(__name__)


class PDFParser(BaseParser):
    """Extracts text and metadata from PDF documents, preserving page ordering."""

    parser_name = "pdf_parser"
    parser_version = "1.0.0"

    def __init__(self, *, language_detection_enabled: bool = True, max_pages: int | None = None):
        # `max_pages` is a config-driven guard (see settings.py's
        # `parsing_max_pages`) against pathological inputs (a scanned
        # 5,000-page filing) blowing the parsing time budget for one
        # document in a batch run — None means "no limit," the default.
        self.language_detection_enabled = language_detection_enabled
        self.max_pages = max_pages

    @classmethod
    def supports(cls, document_type: str) -> bool:
        return document_type == "pdf"

    def parse(self, file_path: Path) -> ExtractedContent:
        try:
            reader = PdfReader(str(file_path))
        except PdfReadError as exc:
            raise MalformedDocumentError(f"Could not open PDF '{file_path.name}': {exc}") from exc
        except Exception as exc:  # noqa: BLE001 - any other library-internal failure is still "malformed" to us
            raise MalformedDocumentError(f"Unexpected error opening PDF '{file_path.name}': {exc}") from exc

        try:
            is_encrypted = reader.is_encrypted
        except Exception as exc:  # noqa: BLE001
            # Design decision (found via code review after a real batch run
            # hit an unhandled 'NoneType' object has no attribute 'get'
            # here): `PdfReader()` succeeding does NOT guarantee every
            # later property access on `reader` is safe — `is_encrypted`
            # reads pypdf's internal encryption dictionary, which real-
            # world PDFs (unusual permission flags, non-standard /Encrypt
            # structures — common in some government/corporate filing
            # exporters) can leave in a state pypdf itself doesn't handle
            # cleanly. Every OTHER risky operation in this file already
            # converts library-internal failures into MalformedDocumentError
            # rather than letting them propagate raw (see the PdfReader()
            # and reader.pages guards immediately above/below) — this
            # brings is_encrypted in line with that same convention,
            # instead of being the one unguarded gap that could crash an
            # entire company's parsing stage over a single malformed file.
            raise MalformedDocumentError(
                f"Could not read encryption metadata of '{file_path.name}': {exc}"
            ) from exc

        if is_encrypted:
            # Many "encrypted" PDFs are only owner-password protected with
            # an empty user password (common for PDFs that restrict
            # printing/editing but not reading) — try that before giving up,
            # since rejecting those outright would be needlessly strict.
            try:
                if reader.decrypt("") == 0:
                    raise EncryptedDocumentError(
                        f"PDF '{file_path.name}' is password-protected and could not be opened."
                    )
            except EncryptedDocumentError:
                raise
            except Exception as exc:
                raise EncryptedDocumentError(
                    f"PDF '{file_path.name}' is encrypted and decryption failed: {exc}"
                ) from exc

        try:
            pages = reader.pages
            page_count = len(pages)
        except Exception as exc:  # noqa: BLE001
            raise MalformedDocumentError(f"Could not read page tree of '{file_path.name}': {exc}") from exc

        if self.max_pages is not None and page_count > self.max_pages:
            logger.warning(
                "PDF '%s' has %d pages, exceeding max_pages=%d; parsing first %d only.",
                file_path.name, page_count, self.max_pages, self.max_pages,
            )
            pages = pages[: self.max_pages]

        page_text: list[tuple[int, str]] = []
        for index, page in enumerate(pages, start=1):
            try:
                text = page.extract_text() or ""
            except Exception as exc:  # noqa: BLE001 - a single bad page shouldn't fail the whole document
                logger.warning("Failed to extract text from page %d of '%s': %s", index, file_path.name, exc)
                text = ""
            page_text.append((index, normalize_whitespace(text)))

        raw_text = "\n\n".join(text for _, text in page_text if text)

        metadata = self._extract_metadata(reader, file_path)
        metadata["language"] = detect_language(raw_text, enabled=self.language_detection_enabled)

        content = ExtractedContent(
            raw_text=raw_text,
            page_text=page_text,
            page_count=page_count,
            title=metadata.pop("title"),
            author=metadata.pop("author"),
            subject=metadata.pop("subject"),
            keywords=metadata.pop("keywords"),
            creator=metadata.pop("creator"),
            producer=metadata.pop("producer"),
            creation_date=metadata.pop("creation_date"),
            modified_date=metadata.pop("modified_date"),
            language=metadata.pop("language"),
            extra_metadata=metadata,
        )
        self.validate_output(content)
        return content

    def _extract_metadata(self, reader: PdfReader, file_path: Path) -> dict:
        try:
            info = reader.metadata or {}
        except Exception as exc:  # noqa: BLE001
            # Metadata extraction failing is NOT the same failure class as
            # the PDF being unreadable — text extraction may have already
            # succeeded above. Raising here (rather than swallowing) lets
            # the service layer decide whether a text-only parse still
            # counts as PARTIAL success; see service.py.
            raise MetadataExtractionError(
                f"Failed to read metadata dictionary of '{file_path.name}': {exc}"
            ) from exc

        return {
            "title": normalize_metadata_value(info.get("/Title")),
            "author": normalize_metadata_value(info.get("/Author")),
            "subject": normalize_metadata_value(info.get("/Subject")),
            "keywords": normalize_metadata_value(info.get("/Keywords")),
            "creator": normalize_metadata_value(info.get("/Creator")),
            "producer": normalize_metadata_value(info.get("/Producer")),
            "creation_date": parse_pdf_date(info.get("/CreationDate")),
            "modified_date": parse_pdf_date(info.get("/ModDate")),
        }
