"""Shared type definitions for Sprint 4 Document Parsing — mirrors `src/acquisition/types.py`."""

from typing import TypedDict
from uuid import UUID


class ParseOutcome(TypedDict, total=False):
    """Standardized result dictionary returned after a single document parse attempt."""

    status: str  # SUCCESS, FAILED, PARTIAL, SKIPPED
    document_id: UUID  # UUID of the parent Document Registry entry
    document_version_id: int  # Integer id of the DocumentVersion that was parsed
    parsed_document_id: int  # Integer id of the persisted ParsedDocument row (if any)
    parser_used: str
    page_count: int
    character_count: int
    parsing_duration: float
    error: str  # Detailed error message (if status is FAILED)


class ParsingSummary(TypedDict):
    """Aggregated telemetry summary for a parsing run — see `telemetry.py`."""

    documents_parsed: int
    pages_processed: int
    characters_extracted: int
    average_parsing_time: float
    parser_failures: int
    unsupported_document_types: int
    skipped_documents: int
    success_rate: float
