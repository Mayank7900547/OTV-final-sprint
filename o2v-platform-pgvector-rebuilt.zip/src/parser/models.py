"""
Database models for Sprint 4 Document Parsing.

Design decision: shape mirrors `src/acquisition/models.py` exactly —
`Integer` autoincrement primary keys (not UUID) for these two
sprint-specific tables, `relationship(..., backref=...)` for navigation
from `DocumentVersion`, and a `str, enum.Enum` status vocabulary. This is
the established pattern in this codebase for tables that record
"something that happened to a document version" (`DownloadHistory`
already does this for downloads; `ParsingHistory` does it for parse
attempts) as opposed to tables like `DocumentRegistry`/`Company` that are
the canonical registry entities themselves (those use UUID PKs).

`ParsedDocument` links to `DocumentVersion` (not directly to
`DocumentRegistry`) because Sprint 4 parses a specific downloaded FILE —
`DocumentVersion.storage_path` is what's actually on disk. `document_id`
is carried too, denormalized, purely so a query like "all parsed
documents for this company's Annual Reports" doesn't need to join through
`document_versions` every time; it is not the parsing target itself.
"""

import enum

from sqlalchemy import (
    JSON,
    BigInteger,
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

from src.database.base import Base


class ParsingStatusEnum(str, enum.Enum):
    SUCCESS = "SUCCESS"
    PARTIAL = "PARTIAL"  # text extracted but metadata extraction failed, or similar degraded outcome
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"  # e.g. unsupported type, document not ACTIVE, duplicate parse without --force


class ParsedDocument(Base):
    """
    The structured, machine-readable result of parsing one `DocumentVersion`.

    One row per successfully-or-partially parsed version — the `uq_parsed_document_version`
    constraint is the "duplicate parsing prevention" requirement from the
    Sprint 4 brief's validation section: re-parsing the same version
    without `--force` is rejected at the service layer (see
    `validation.py`) before it would ever hit this constraint, but the DB
    constraint remains the last line of defense, matching the same
    belt-and-suspenders pattern `DocumentRegistry.official_url`'s unique
    constraint already established in Sprint 2.
    """

    __tablename__ = "parsed_documents"
    __table_args__ = (
        UniqueConstraint("document_version_id", name="uq_parsed_document_version"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)

    document_id = Column(
        PG_UUID(as_uuid=True),
        ForeignKey("document_registry.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    document_version_id = Column(
        Integer,
        ForeignKey("document_versions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    parser_used = Column(String(100), nullable=False)
    parser_version = Column(String(20), nullable=False)
    document_type = Column(String(20), nullable=False)

    title = Column(String(1000), nullable=True)
    author = Column(String(500), nullable=True)
    subject = Column(String(1000), nullable=True)
    keywords = Column(String(1000), nullable=True)
    creator = Column(String(255), nullable=True)
    producer = Column(String(255), nullable=True)
    language = Column(String(20), nullable=True)

    page_count = Column(Integer, nullable=True)
    creation_date = Column(DateTime(timezone=True), nullable=True)
    modified_date = Column(DateTime(timezone=True), nullable=True)

    # Extra format-specific fields that don't warrant their own column
    # (HTML's headings/links/meta_tags, PDF's leftover /Info keys) — kept
    # as JSON rather than growing the table's column count for every
    # format-specific detail future parsers might add.
    metadata_json = Column(JSON, nullable=True)

    raw_text = Column(Text, nullable=False, default="")
    # List of {"page_number": int, "text": str} objects — JSON rather than
    # a child table because page text is always read/written as a whole
    # alongside its parent row, never queried per-page independently.
    page_text = Column(JSON, nullable=True)
    character_count = Column(Integer, nullable=False, default=0)

    parsing_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    parsing_duration = Column(Float, nullable=False, default=0.0)
    status = Column(SQLEnum(ParsingStatusEnum), nullable=False, default=ParsingStatusEnum.SUCCESS)
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    document_version = relationship("DocumentVersion", backref="parsed_document", uselist=False)

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<ParsedDocument id={self.id} document_version_id={self.document_version_id} "
            f"parser={self.parser_used} status={self.status}>"
        )


class ParsingHistory(Base):
    """
    Append-only log of every parse ATTEMPT for a document version, success
    or failure — mirrors `DownloadHistory`'s role for the acquisition
    subsystem. `ParsedDocument` holds only the latest good result; this
    table is what `show parsing history` / `retry failed parsing` (CLI)
    read from.
    """

    __tablename__ = "parsing_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_version_id = Column(
        Integer,
        ForeignKey("document_versions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    attempt_number = Column(Integer, nullable=False, default=1)
    parser_used = Column(String(100), nullable=False)
    parser_version = Column(String(20), nullable=False)
    parsing_status = Column(SQLEnum(ParsingStatusEnum), nullable=False)
    error_message = Column(Text, nullable=True)
    pages_processed = Column(Integer, nullable=True)
    characters_extracted = Column(Integer, nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=False)
    completed_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    duration_seconds = Column(Float, nullable=True)

    document_version = relationship("DocumentVersion", backref="parsing_history")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<ParsingHistory id={self.id} document_version_id={self.document_version_id} "
            f"status={self.parsing_status} attempt={self.attempt_number}>"
        )
