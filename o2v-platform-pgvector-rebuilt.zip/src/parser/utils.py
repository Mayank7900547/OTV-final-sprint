"""Generic text-handling utilities shared by parsers."""

from __future__ import annotations

import re

_WHITESPACE_RE = re.compile(r"[ \t\u00a0]+")
_BLANK_LINES_RE = re.compile(r"\n{3,}")


def normalize_whitespace(text: str) -> str:
    """
    Collapse runs of horizontal whitespace and excessive blank lines while
    preserving line breaks (which carry logical reading-order structure —
    losing them would run headings into body text).

    Applied identically by both `PDFParser` and `HTMLParser` so
    `ParsedDocument.raw_text` has consistent formatting regardless of
    source format, rather than each parser inventing its own cleanup.
    """
    if not text:
        return ""
    lines = [_WHITESPACE_RE.sub(" ", line).strip() for line in text.splitlines()]
    collapsed = "\n".join(lines)
    return _BLANK_LINES_RE.sub("\n\n", collapsed).strip()


def truncate(text: str, max_chars: int) -> str:
    """Truncate `text` to `max_chars`, appending a marker if it was cut — used for CLI previews only."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + " [...truncated]"
