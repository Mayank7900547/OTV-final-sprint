"""
Validation checks for the parsing pipeline.

Design decision: a stateless module of functions (not a class), same
shape as `discovery/url_validator.py` from Sprint 2 — every check here
takes exactly the data it needs and raises a specific `parser.exceptions`
subclass, so `service.py` can call them as a straight-line sequence of
guard clauses rather than threading a validator object through the whole
service.
"""

from __future__ import annotations

from pathlib import Path

from sqlalchemy.orm import Session

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.parser.exceptions import (
    DocumentNotActiveError,
    DuplicateParsingError,
    MalformedDocumentError,
    ParsingValidationError,
)
from src.parser.models import ParsedDocument


def validate_document_version_active(version: DocumentVersion) -> None:
    """The Sprint 4 brief scopes parsing to ACTIVE downloads only — an ARCHIVED/CORRUPTED version is superseded or already known-bad."""
    if version.status != DocumentVersionStatusEnum.ACTIVE:
        raise DocumentNotActiveError(
            f"DocumentVersion {version.id} is {version.status.value}, not ACTIVE — skipping."
        )


def validate_file_readable(storage_path: str) -> Path:
    """Confirm the file `DocumentVersion.storage_path` points at actually exists and is non-empty on disk."""
    path = Path(storage_path)
    if not path.exists() or not path.is_file():
        raise MalformedDocumentError(f"Stored file not found on disk: {storage_path}")
    if path.stat().st_size == 0:
        raise MalformedDocumentError(f"Stored file is empty: {storage_path}")
    return path


def check_duplicate_parsing(session: Session, document_version_id: int, *, force: bool) -> ParsedDocument | None:
    """
    Look up an existing `ParsedDocument` for this version.

    Returns the existing row (so the service can decide to overwrite it
    when `force=True`) rather than raising outright — `force` is a
    legitimate, expected re-parse trigger (e.g. after a parser version
    bump), not an error condition itself. Only the non-forced duplicate
    attempt is a `DuplicateParsingError`.
    """
    existing = (
        session.query(ParsedDocument)
        .filter(ParsedDocument.document_version_id == document_version_id)
        .first()
    )
    if existing is not None and not force:
        raise DuplicateParsingError(
            f"DocumentVersion {document_version_id} was already parsed at "
            f"{existing.parsing_timestamp} (parser={existing.parser_used}). "
            f"Pass --force to re-parse."
        )
    return existing


def validate_page_count(page_count: int | None) -> None:
    """A negative page count can only mean a bug in a parser's extraction, not a real document property."""
    if page_count is not None and page_count < 0:
        raise ParsingValidationError(f"Invalid page count extracted: {page_count}")


def validate_metadata_consistency(page_count: int | None, page_text_len: int) -> None:
    """`page_text` should have one entry per page for paginated formats — a mismatch signals a parser bug, not a document defect."""
    if page_count is not None and page_count > 0 and page_text_len != page_count:
        raise ParsingValidationError(
            f"Metadata inconsistency: page_count={page_count} but extracted "
            f"{page_text_len} page_text entries."
        )
