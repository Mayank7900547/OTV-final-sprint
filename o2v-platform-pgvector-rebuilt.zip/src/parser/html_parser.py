"""
HTML parser.

Design decision: `BeautifulSoup` with the `lxml` backend, not a regex-
based tag stripper. HTML "extract visible text in reading order while
ignoring script/style/hidden elements" is exactly the problem a real DOM
parser solves correctly and a regex approach gets subtly wrong (nested
tags, malformed markup, CDATA) — the same reasoning that led Sprint 2 to
use `xml.etree.ElementTree` for sitemap XML rather than string-scanning it.
"""

from __future__ import annotations

from pathlib import Path

from bs4 import BeautifulSoup

from src.config.logging_config import get_logger
from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.exceptions import MalformedDocumentError
from src.parser.metadata import detect_language, normalize_metadata_value
from src.parser.utils import normalize_whitespace

logger = get_logger(__name__)

# Tags whose content is never "visible text" — scripts and styles are
# markup/behavior, not content, and `<template>`/`<noscript>` content is
# either inert or a fallback that isn't actually rendered in the normal case.
_NON_CONTENT_TAGS = ("script", "style", "template", "noscript", "svg")

_HEADING_TAGS = ("h1", "h2", "h3", "h4", "h5", "h6")


class HTMLParser(BaseParser):
    """Extracts visible text, headings, links, and meta tags from HTML documents."""

    parser_name = "html_parser"
    parser_version = "1.0.0"

    def __init__(self, *, language_detection_enabled: bool = True):
        self.language_detection_enabled = language_detection_enabled

    @classmethod
    def supports(cls, document_type: str) -> bool:
        return document_type == "html"

    def parse(self, file_path: Path) -> ExtractedContent:
        try:
            raw_bytes = file_path.read_bytes()
        except OSError as exc:
            raise MalformedDocumentError(f"Could not read HTML file '{file_path.name}': {exc}") from exc

        try:
            soup = BeautifulSoup(raw_bytes, "lxml")
        except Exception as exc:  # noqa: BLE001
            raise MalformedDocumentError(f"Could not parse HTML in '{file_path.name}': {exc}") from exc

        self._strip_non_content(soup)

        raw_text = normalize_whitespace(soup.get_text(separator="\n"))
        title = normalize_metadata_value(soup.title.string) if soup.title else None
        headings = self._extract_headings(soup)
        links = self._extract_links(soup)
        meta_tags = self._extract_meta_tags(soup)

        language = meta_tags.get("language") or detect_language(
            raw_text, enabled=self.language_detection_enabled
        )

        content = ExtractedContent(
            raw_text=raw_text,
            # HTML has no native page concept — the whole document is one
            # logical page, keeping `page_text`'s shape identical to the
            # PDF parser's (see base_parser.py's ExtractedContent docstring).
            page_text=[(1, raw_text)],
            page_count=1,
            title=title,
            author=meta_tags.get("author"),
            subject=meta_tags.get("description"),
            keywords=meta_tags.get("keywords"),
            language=language,
            extra_metadata={
                "headings": headings,
                "links": links,
                "meta_tags": meta_tags,
            },
        )
        self.validate_output(content)
        return content

    def _strip_non_content(self, soup: BeautifulSoup) -> None:
        for tag_name in _NON_CONTENT_TAGS:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # `display:none`/`hidden` elements are present in the DOM but never
        # rendered — the Sprint 4 brief explicitly calls out "ignore hidden
        # elements" as distinct from "ignore JS/CSS," so this is a second,
        # separate pass rather than folded into the tag-name pass above.
        for tag in soup.find_all(attrs={"hidden": True}):
            tag.decompose()
        for tag in soup.find_all(style=True):
            style = tag.get("style", "")
            if "display:none" in style.replace(" ", "") or "display: none" in style:
                tag.decompose()

    def _extract_headings(self, soup: BeautifulSoup) -> list[dict]:
        headings = []
        for tag in soup.find_all(_HEADING_TAGS):
            text = normalize_metadata_value(tag.get_text(strip=True))
            if text:
                headings.append({"level": tag.name, "text": text})
        return headings

    def _extract_links(self, soup: BeautifulSoup) -> list[dict]:
        links = []
        for tag in soup.find_all("a", href=True):
            href = tag["href"].strip()
            if not href or href.startswith("#"):
                continue
            text = normalize_metadata_value(tag.get_text(strip=True)) or ""
            links.append({"href": href, "text": text})
        return links

    def _extract_meta_tags(self, soup: BeautifulSoup) -> dict:
        meta_tags: dict[str, str] = {}
        for tag in soup.find_all("meta"):
            key = tag.get("name") or tag.get("property")
            content = tag.get("content")
            if key and content:
                meta_tags[key.lower().replace("og:", "")] = content.strip()

        result = {}
        if "author" in meta_tags:
            result["author"] = meta_tags["author"]
        if "description" in meta_tags:
            result["description"] = meta_tags["description"]
        if "keywords" in meta_tags:
            result["keywords"] = meta_tags["keywords"]

        html_tag = soup.find("html")
        if html_tag and html_tag.get("lang"):
            result["language"] = html_tag["lang"].split("-")[0]

        result["_all"] = meta_tags
        return result
