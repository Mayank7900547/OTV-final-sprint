"""
Parser factory — detects a document's format and hands back the right
`BaseParser` implementation.

Design decision: a class-level registry dict (`_registry`), not a chain of
`if document_type == ...` branches. This is what makes the Sprint 4
extensibility requirement literally true — adding DOCX support later is
`ParserFactory.register(DocumentType.DOCX.value, DocxParser)` in that new
module's own registration call (see `register_default_parsers` below for
the pattern), never an edit to this file's branching logic.
"""

from __future__ import annotations

from pathlib import Path

from src.core.constants import DocumentType
from src.parser.base_parser import BaseParser
from src.parser.exceptions import UnsupportedDocumentError

# Extensions mapped to their DocumentType value — used only as a fallback
# when the caller doesn't already know the type (e.g. a CLI command given
# a bare file path). The DocumentRegistry's own `document_type` column
# (set at discovery time, Sprint 2) is the authoritative source whenever
# it's available; see `service.py`.
_EXTENSION_MAP = {
    ".pdf": DocumentType.PDF.value,
    ".htm": DocumentType.HTML.value,
    ".html": DocumentType.HTML.value,
}


class ParserFactory:
    """Registry + lookup for document-format parsers."""

    _registry: dict[str, type[BaseParser]] = {}

    @classmethod
    def register(cls, document_type: str, parser_cls: type[BaseParser]) -> None:
        """Register `parser_cls` as the handler for `document_type`. Re-registering overwrites (used by tests to inject fakes)."""
        cls._registry[document_type] = parser_cls

    @classmethod
    def get_parser(cls, document_type: str, **kwargs) -> BaseParser:
        """
        Instantiate the parser registered for `document_type`.

        Raises `UnsupportedDocumentError` — never `KeyError` — so callers
        only need to know about this package's exception hierarchy, per
        the same convention every other Sprint 4 module follows.
        """
        parser_cls = cls._registry.get(document_type)
        if parser_cls is None:
            raise UnsupportedDocumentError(
                f"No parser registered for document type '{document_type}'. "
                f"Supported types: {sorted(cls._registry)}"
            )
        return parser_cls(**kwargs)

    @classmethod
    def detect_document_type(cls, file_path: Path, hint: str | None = None) -> str:
        """
        Determine the document type for `file_path`.

        `hint` (typically `DocumentRegistry.document_type` from Sprint 2)
        is trusted first — it was set at discovery time from an authoritative
        signal (Content-Type header / source metadata) that a bare file
        extension can't always reproduce. Falls back to extension sniffing
        only when no hint is given, e.g. a CLI invocation against a raw path.
        """
        if hint and hint in cls._registry:
            return hint

        suffix = file_path.suffix.lower()
        detected = _EXTENSION_MAP.get(suffix)
        if detected is None:
            raise UnsupportedDocumentError(
                f"Could not determine document type for '{file_path.name}' "
                f"(hint={hint!r}, extension={suffix!r})."
            )
        return detected

    @classmethod
    def supported_types(cls) -> list[str]:
        return sorted(cls._registry)


def register_default_parsers() -> None:
    """
    Register Sprint 4's built-in parsers.

    Deliberately a function (called once, at package-init time via
    `__init__` import below) rather than decorator-based auto-registration
    magic — an explicit, readable list of "here is everything this package
    ships with" is worth more than a clever mechanism, especially since
    this is the exact list a future PR adding a DOCX parser needs to find
    and extend.
    """
    from src.parser.html_parser import HTMLParser
    from src.parser.pdf_parser import PDFParser

    ParserFactory.register(DocumentType.PDF.value, PDFParser)
    ParserFactory.register(DocumentType.HTML.value, HTMLParser)


register_default_parsers()
