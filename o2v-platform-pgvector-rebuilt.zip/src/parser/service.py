"""
Document Parser Service — Sprint 4 orchestration layer.

Design decision: synchronous, not `asyncio` like `DocumentAcquisitionService`.
Acquisition is I/O-bound (waiting on HTTP responses), which is exactly
what `asyncio` is for; parsing is CPU-bound (PDF/HTML text extraction),
where `asyncio` buys nothing and a thread pool is the right concurrency
primitive instead — hence `parsing_parallel_workers` (see settings.py)
driving a `ThreadPoolExecutor` in `parse_many`, not a semaphore-gated
coroutine pool.

Design decision: every public method takes a `Session` explicitly rather
than opening its own — same reasoning as `document_service.py`/
`company_service.py`'s service-layer functions in Sprints 1-2 (as opposed
to `DocumentAcquisitionService`, which manages its own sessions because it
owns retry/locking logic across an `async` boundary that a caller-supplied
session can't safely span). Parsing has no such requirement, so it follows
the simpler, more common pattern in this codebase.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy.orm import Session

from src.acquisition.models import DocumentVersion, DocumentVersionStatusEnum
from src.config.logging_config import get_logger
from src.config.settings import settings
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.exceptions import DuplicateParsingError, ParserError
from src.parser.models import ParsedDocument, ParsingHistory, ParsingStatusEnum
from src.parser.parser_factory import ParserFactory
from src.parser.telemetry import telemetry
from src.parser.types import ParseOutcome
from src.parser.validation import (
    check_duplicate_parsing,
    validate_document_version_active,
    validate_file_readable,
    validate_metadata_consistency,
    validate_page_count,
)

logger = get_logger(__name__)


class DocumentParserService:
    def __init__(self, *, parser_kwargs_builder=None):
        # Overridable only for tests that need to inject parser kwargs
        # (e.g. disabling language detection to keep unit tests fast and
        # offline) without touching global settings.
        self._parser_kwargs_builder = parser_kwargs_builder or self._default_parser_kwargs

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_active_document_version_ids(
        self, session: Session, company_filter: str | None = None
    ) -> list[int]:
        """IDs of every ACTIVE `DocumentVersion` — the population Sprint 4 parses, per the brief."""
        query = (
            session.query(DocumentVersion.id)
            .filter(DocumentVersion.status == DocumentVersionStatusEnum.ACTIVE)
        )
        if company_filter:
            query = (
                query.join(DocumentRegistry, DocumentRegistry.id == DocumentVersion.document_id)
                .join(Company, Company.id == DocumentRegistry.company_id)
                .filter(Company.name.ilike(f"%{company_filter}%"))
            )
        return [row[0] for row in query.all()]

    def load_failed_document_version_ids(self, session: Session) -> list[int]:
        """
        IDs of `DocumentVersion`s whose most recent parse attempt failed and
        that have no successful `ParsedDocument` row — the population
        `retry failed parsing` (CLI) operates on.
        """
        parsed_ok_ids = {
            row[0]
            for row in session.query(ParsedDocument.document_version_id)
            .filter(ParsedDocument.status.in_([ParsingStatusEnum.SUCCESS, ParsingStatusEnum.PARTIAL]))
            .all()
        }
        failed_history_ids = {
            row[0]
            for row in session.query(ParsingHistory.document_version_id)
            .filter(ParsingHistory.parsing_status == ParsingStatusEnum.FAILED)
            .all()
        }
        return sorted(failed_history_ids - parsed_ok_ids)

    # ------------------------------------------------------------------
    # Single-document parsing
    # ------------------------------------------------------------------

    def parse_document_version(
        self, session: Session, document_version_id: int, *, force: bool = False
    ) -> ParseOutcome:
        """
        Parse one `DocumentVersion` and persist the result.

        Never raises `ParserError` — every failure mode (unsupported type,
        malformed file, encrypted PDF, not-ACTIVE, duplicate-without-force)
        is caught and turned into a FAILED/SKIPPED `ParseOutcome` instead,
        the same "batch-safe" convention `DocumentAcquisitionService.
        download_document` follows, so a single bad document never aborts
        a `parse all` run. Genuine bugs (a session error, an unexpected
        library crash) still propagate — only the documented failure modes
        are swallowed.
        """
        start = time.monotonic()
        version = session.query(DocumentVersion).filter(DocumentVersion.id == document_version_id).first()
        if version is None:
            telemetry.record_failure()
            return {"status": "FAILED", "document_version_id": document_version_id, "error": "DocumentVersion not found"}

        attempt_number = (
            session.query(ParsingHistory)
            .filter(ParsingHistory.document_version_id == document_version_id)
            .count()
            + 1
        )
        started_at = datetime.now(timezone.utc)

        try:
            # Design decision: no `session.rollback()` anywhere in this
            # method, deliberately. Every validation/parsing step below
            # (active-check, duplicate-check, file-read, the parse itself)
            # is either a read or pure filesystem work — the ONLY database
            # writes in the whole success path are in `_persist_success` /
            # `_record_history`, which never run unless every check above
            # already passed. So there is never any partial write from THIS
            # attempt that a failure needs to undo. That also means we never
            # need to touch — and risk discarding — whatever else the
            # caller-supplied `session` already had pending from before this
            # call (a batch loop, another service's not-yet-committed work,
            # ...), which a `session.rollback()` here would do indiscriminately.
            validate_document_version_active(version)
            existing = check_duplicate_parsing(session, document_version_id, force=force)
            file_path = validate_file_readable(version.storage_path)

            registry_entry = (
                session.query(DocumentRegistry).filter(DocumentRegistry.id == version.document_id).first()
            )
            type_hint = registry_entry.document_type if registry_entry else None
            document_type = ParserFactory.detect_document_type(file_path, hint=type_hint)

            parser = ParserFactory.get_parser(document_type, **self._parser_kwargs_builder(document_type))
            content = self._parse_with_timeout(parser, file_path, settings.parsing_max_time_seconds)

            validate_page_count(content.page_count)
            validate_metadata_consistency(content.page_count, len(content.page_text))

            duration = time.monotonic() - start
            row = self._persist_success(
                session,
                existing=existing,
                document_id=version.document_id,
                document_version_id=document_version_id,
                document_type=document_type,
                parser=parser,
                content=content,
                duration=duration,
            )
            self._record_history(
                session,
                document_version_id=document_version_id,
                attempt_number=attempt_number,
                parser=parser,
                status=ParsingStatusEnum.SUCCESS,
                started_at=started_at,
                pages=content.page_count,
                characters=content.character_count,
                duration=duration,
            )
            session.commit()
            telemetry.record_success(content.page_count, content.character_count, duration)

            return {
                "status": "SUCCESS",
                "document_id": version.document_id,
                "document_version_id": document_version_id,
                "parsed_document_id": row.id,
                "parser_used": parser.parser_name,
                "page_count": content.page_count,
                "character_count": content.character_count,
                "parsing_duration": round(duration, 3),
            }

        except DuplicateParsingError as exc:
            # Read-only check - nothing to undo, nothing to commit.
            telemetry.record_skipped()
            return {"status": "SKIPPED", "document_version_id": document_version_id, "error": str(exc)}

        except ParserError as exc:
            # Nothing from this attempt was written (see the comment at the
            # top of the `try` block) - recording the failure is a plain
            # add+commit, not a recovery from a half-done write.
            duration = time.monotonic() - start
            self._record_failure_history(
                session,
                document_version_id=document_version_id,
                attempt_number=attempt_number,
                status=ParsingStatusEnum.FAILED,
                started_at=started_at,
                error_message=str(exc),
                duration=duration,
            )
            if type(exc).__name__ == "UnsupportedDocumentError":
                telemetry.record_unsupported()
            else:
                telemetry.record_failure()
            logger.warning("Parsing failed for DocumentVersion %s: %s", document_version_id, exc)
            return {"status": "FAILED", "document_version_id": document_version_id, "error": str(exc)}

    def _parse_with_timeout(self, parser: BaseParser, file_path: Path, timeout_seconds: float) -> ExtractedContent:
        """
        Run `parser.parse()` in a worker thread and enforce
        `parsing_max_time_seconds` — a pure-Python function call can't be
        preempted from another thread, so this bounds WAITING for it, not
        the underlying computation, which is the same tradeoff CPython
        forces on any timeout-around-sync-code pattern. Good enough for the
        pathological-input guard this setting exists for.
        """
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(parser.parse, file_path)
            try:
                return future.result(timeout=timeout_seconds)
            except FutureTimeoutError as exc:
                raise ParserError(
                    f"Parsing '{file_path.name}' exceeded the {timeout_seconds}s time limit."
                ) from exc

    def _persist_success(
        self,
        session: Session,
        *,
        existing: ParsedDocument | None,
        document_id,
        document_version_id: int,
        document_type: str,
        parser: BaseParser,
        content: ExtractedContent,
        duration: float,
    ) -> ParsedDocument:
        page_text_json = [{"page_number": num, "text": text} for num, text in content.page_text]

        fields = dict(
            document_id=document_id,
            document_version_id=document_version_id,
            parser_used=parser.parser_name,
            parser_version=parser.parser_version,
            document_type=document_type,
            title=content.title,
            author=content.author,
            subject=content.subject,
            keywords=content.keywords,
            creator=content.creator,
            producer=content.producer,
            language=content.language,
            page_count=content.page_count,
            creation_date=content.creation_date,
            modified_date=content.modified_date,
            metadata_json=content.extra_metadata,
            raw_text=content.raw_text,
            page_text=page_text_json,
            character_count=content.character_count,
            parsing_duration=duration,
            status=ParsingStatusEnum.SUCCESS,
            error_message=None,
        )

        if existing is not None:
            for key, value in fields.items():
                setattr(existing, key, value)
            existing.parsing_timestamp = datetime.now(timezone.utc)
            session.flush()
            return existing

        row = ParsedDocument(**fields)
        session.add(row)
        session.flush()
        return row

    def _record_history(
        self,
        session: Session,
        *,
        document_version_id: int,
        attempt_number: int,
        parser: BaseParser,
        status: ParsingStatusEnum,
        started_at: datetime,
        duration: float,
        pages: int | None = None,
        characters: int | None = None,
        error_message: str | None = None,
    ) -> None:
        session.add(
            ParsingHistory(
                document_version_id=document_version_id,
                attempt_number=attempt_number,
                parser_used=parser.parser_name,
                parser_version=parser.parser_version,
                parsing_status=status,
                error_message=error_message,
                pages_processed=pages,
                characters_extracted=characters,
                started_at=started_at,
                duration_seconds=duration,
            )
        )

    def _record_failure_history(
        self,
        session: Session,
        *,
        document_version_id: int,
        attempt_number: int,
        status: ParsingStatusEnum,
        started_at: datetime,
        duration: float,
        error_message: str,
    ) -> None:
        """
        Record a FAILED `ParsingHistory` row for an attempt that never
        produced a `BaseParser` instance to log against (e.g.
        `UnsupportedDocumentError` fires before a parser is selected), so
        `_record_history`'s `parser: BaseParser` parameter doesn't apply.

        A plain add+commit — see `parse_document_version`'s top-of-`try`
        comment for why nothing needs rolling back before this runs.
        """
        session.add(
            ParsingHistory(
                document_version_id=document_version_id,
                attempt_number=attempt_number,
                parser_used="unknown",
                parser_version="unknown",
                parsing_status=status,
                error_message=error_message,
                started_at=started_at,
                duration_seconds=duration,
            )
        )
        session.commit()

    def _default_parser_kwargs(self, document_type: str) -> dict:
        kwargs = {"language_detection_enabled": settings.parsing_language_detection_enabled}
        if document_type == "pdf":
            kwargs["max_pages"] = settings.parsing_max_pages
        return kwargs

    # ------------------------------------------------------------------
    # Batch parsing
    # ------------------------------------------------------------------

    def parse_many(
        self, session_factory, document_version_ids: list[int], *, force: bool = False
    ) -> list[ParseOutcome]:
        """
        Parse many document versions concurrently.

        `session_factory` (not a single shared `Session`) is required here
        because each worker thread needs its OWN SQLAlchemy session — a
        `Session` is not thread-safe, the same constraint that shapes
        `DocumentAcquisitionService`'s per-task session handling in Sprint
        3.1, just enforced by threads here instead of `asyncio` tasks.
        """
        results: list[ParseOutcome] = []

        def _run(doc_version_id: int) -> ParseOutcome:
            with session_factory() as worker_session:
                return self.parse_document_version(worker_session, doc_version_id, force=force)

        workers = max(1, settings.parsing_parallel_workers)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            for outcome in executor.map(_run, document_version_ids):
                results.append(outcome)
        return results
