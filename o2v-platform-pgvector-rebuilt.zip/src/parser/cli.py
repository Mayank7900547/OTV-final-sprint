"""Typer CLI integration for Sprint 4 Document Parsing — mirrors `src/acquisition/cli.py`'s shape."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from src.database.connection import session_scope
from src.parser.exceptions import ParserError
from src.parser.models import ParsedDocument, ParsingHistory
from src.parser.service import DocumentParserService
from src.parser.telemetry import telemetry
from src.parser.utils import truncate

parser_app = typer.Typer(name="parser", help="Sprint 4 Document Parsing CLI")
parse_app = typer.Typer(help="Run parsing.")
show_app = typer.Typer(help="Inspect parsed documents, history, and statistics.")
parser_app.add_typer(parse_app, name="parse")
parser_app.add_typer(show_app, name="show")

console = Console()


def _print_outcome(outcome: dict) -> None:
    status = outcome.get("status")
    color = {"SUCCESS": "green", "FAILED": "red", "SKIPPED": "yellow"}.get(status, "white")
    line = f"[{color}]{status}[/{color}] DocumentVersion={outcome.get('document_version_id')}"
    if status == "SUCCESS":
        line += (
            f" parser={outcome.get('parser_used')} pages={outcome.get('page_count')} "
            f"chars={outcome.get('character_count')} time={outcome.get('parsing_duration')}s"
        )
    elif outcome.get("error"):
        line += f" — {outcome['error']}"
    console.print(line)


# --------------------------------------------------------------------------
# parse commands
# --------------------------------------------------------------------------


@parse_app.command("document")
def parse_document(
    document_version_id: int = typer.Argument(..., help="DocumentVersion id to parse."),
    force: bool = typer.Option(False, "--force", help="Re-parse even if already parsed."),
) -> None:
    """Parse a single document version."""
    service = DocumentParserService()
    with session_scope() as session:
        outcome = service.parse_document_version(session, document_version_id, force=force)
    _print_outcome(outcome)


@parse_app.command("company")
def parse_company(
    company: str = typer.Argument(..., help="Company name (substring match)."),
    force: bool = typer.Option(False, "--force", help="Re-parse even if already parsed."),
) -> None:
    """Parse every ACTIVE document version belonging to a company."""
    service = DocumentParserService()
    with session_scope() as session:
        ids = service.load_active_document_version_ids(session, company_filter=company)

    if not ids:
        console.print(f"[yellow]No ACTIVE document versions found for '{company}'.[/yellow]")
        return

    results = service.parse_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


@parse_app.command("all")
def parse_all(force: bool = typer.Option(False, "--force", help="Re-parse even if already parsed.")) -> None:
    """Parse every ACTIVE document version across all companies."""
    service = DocumentParserService()
    with session_scope() as session:
        ids = service.load_active_document_version_ids(session)

    if not ids:
        console.print("[yellow]No ACTIVE document versions found.[/yellow]")
        return

    results = service.parse_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


def _print_summary() -> None:
    summary = telemetry.get_summary()
    console.print("\n=== PARSING TELEMETRY ===")
    console.print(f"Parsed        : {summary['documents_parsed']}")
    console.print(f"Failures      : {summary['parser_failures']}")
    console.print(f"Skipped       : {summary['skipped_documents']}")
    console.print(f"Unsupported   : {summary['unsupported_document_types']}")
    console.print(f"Pages         : {summary['pages_processed']}")
    console.print(f"Characters    : {summary['characters_extracted']}")
    console.print(f"Avg time (s)  : {summary['average_parsing_time']}")
    console.print(f"Success rate  : {summary['success_rate']}")
    console.print("==========================")


# --------------------------------------------------------------------------
# retry-failed
# --------------------------------------------------------------------------


@parser_app.command("retry-failed")
def retry_failed(force: bool = typer.Option(True, "--force/--no-force", help="Force re-parse (default on, since a prior attempt failed).")) -> None:
    """Retry parsing for every document version whose most recent attempt failed."""
    service = DocumentParserService()
    with session_scope() as session:
        ids = service.load_failed_document_version_ids(session)

    if not ids:
        console.print("[green]No failed document versions to retry.[/green]")
        return

    console.print(f"Retrying {len(ids)} failed document version(s)...")
    results = service.parse_many(session_scope, ids, force=force)
    for outcome in results:
        _print_outcome(outcome)
    _print_summary()


# --------------------------------------------------------------------------
# show commands
# --------------------------------------------------------------------------


@show_app.command("parsed")
def show_parsed(
    document_version_id: int = typer.Argument(None, help="Show one ParsedDocument. Omit to list recent ones."),
    limit: int = typer.Option(20, help="Max rows to display when listing."),
) -> None:
    """Show a parsed document's content/metadata, or list recently parsed documents."""
    with session_scope() as session:
        if document_version_id is not None:
            row = (
                session.query(ParsedDocument)
                .filter(ParsedDocument.document_version_id == document_version_id)
                .first()
            )
            if row is None:
                console.print(f"[yellow]No ParsedDocument found for DocumentVersion {document_version_id}.[/yellow]")
                return
            console.print(f"[bold]Title:[/bold] {row.title or '-'}")
            console.print(f"[bold]Author:[/bold] {row.author or '-'}")
            console.print(f"[bold]Parser:[/bold] {row.parser_used} v{row.parser_version}")
            console.print(f"[bold]Type:[/bold] {row.document_type}  [bold]Pages:[/bold] {row.page_count}")
            console.print(f"[bold]Language:[/bold] {row.language or '-'}")
            console.print(f"[bold]Status:[/bold] {row.status.value}")
            console.print(f"[bold]Characters:[/bold] {row.character_count}")
            console.print("\n[bold]Text preview:[/bold]")
            console.print(truncate(row.raw_text or "", 1000))
            return

        rows = (
            session.query(ParsedDocument)
            .order_by(ParsedDocument.parsing_timestamp.desc())
            .limit(limit)
            .all()
        )

    table = Table(title=f"Recently Parsed Documents (showing {len(rows)})")
    table.add_column("DocVersion")
    table.add_column("Parser")
    table.add_column("Type")
    table.add_column("Pages")
    table.add_column("Status")
    table.add_column("Title")
    for r in rows:
        table.add_row(
            str(r.document_version_id), r.parser_used, r.document_type,
            str(r.page_count or "-"), r.status.value, truncate(r.title or "-", 60),
        )
    console.print(table)


@show_app.command("parser-statistics")
def show_parser_statistics() -> None:
    """Show cumulative telemetry for this process's parsing activity."""
    _print_summary()


@show_app.command("parsing-history")
def show_parsing_history(document_version_id: int = typer.Argument(..., help="DocumentVersion id.")) -> None:
    """Show every recorded parse attempt for a document version."""
    with session_scope() as session:
        rows = (
            session.query(ParsingHistory)
            .filter(ParsingHistory.document_version_id == document_version_id)
            .order_by(ParsingHistory.attempt_number.asc())
            .all()
        )

    if not rows:
        console.print(f"[yellow]No parsing history for DocumentVersion {document_version_id}.[/yellow]")
        return

    table = Table(title=f"Parsing History: DocumentVersion {document_version_id}")
    table.add_column("Attempt")
    table.add_column("Parser")
    table.add_column("Status")
    table.add_column("Pages")
    table.add_column("Chars")
    table.add_column("Duration (s)")
    table.add_column("Error")
    for h in rows:
        table.add_row(
            str(h.attempt_number), f"{h.parser_used} v{h.parser_version}", h.parsing_status.value,
            str(h.pages_processed or "-"), str(h.characters_extracted or "-"),
            f"{h.duration_seconds:.3f}" if h.duration_seconds is not None else "-",
            truncate(h.error_message or "-", 80),
        )
    console.print(table)
