"""
Abstract base parser and the value object every concrete parser returns.

Design decision: parsers return a plain `ExtractedContent` dataclass, NOT
a `ParsedDocument` ORM row. Keeping the parser layer's output persistence-
agnostic is what makes `PDFParser`/`HTMLParser` independently unit-testable
without a database, and it's what the Sprint 4 brief's extensibility
requirement ("a new parser needs only a BaseParser subclass + factory
registration") actually depends on — a parser that already knew how to
write itself into `document_versions`/`parsed_documents` would have to
know about the ORM, the session, and the document registry, none of which
are the parser's concern. `DocumentParserService` (see service.py) is the
only place an `ExtractedContent` gets turned into a `ParsedDocument` row.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class ExtractedContent:
    """
    Structured result of parsing a single document file.

    `page_text` is a list of `(page_number, text)` pairs. For formats with
    no natural page concept (HTML), the whole document is page 1 — this
    keeps `ParsedDocument.page_text` shaped the same way regardless of
    source format, which is what lets `service.py` persist it without a
    format-specific branch.
    """

    raw_text: str
    page_text: list[tuple[int, str]]
    page_count: int
    title: str | None = None
    author: str | None = None
    subject: str | None = None
    keywords: str | None = None
    creator: str | None = None
    producer: str | None = None
    creation_date: datetime | None = None
    modified_date: datetime | None = None
    language: str | None = None
    extra_metadata: dict = field(default_factory=dict)

    @property
    def character_count(self) -> int:
        return len(self.raw_text)


class BaseParser(ABC):
    """
    Common interface every document-format parser must implement.

    Design decision: `parse()` is the single abstract method a subclass
    must provide — everything else (validation hooks, name/version
    reporting) has a sensible default so a minimal new parser really can
    be "a subclass + a factory registration" per the Sprint 4
    extensibility requirement, not a checklist of six methods to override.
    """

    #: Short machine-readable name recorded on `ParsedDocument.parser_used`.
    #: Subclasses MUST override this class attribute.
    parser_name: str = "base"

    #: Bumped when a parser's extraction logic changes in a way that would
    #: produce different output for the same input — recorded on every
    #: `ParsingHistory` row so re-parsing after a parser upgrade is
    #: distinguishable from a routine re-run.
    parser_version: str = "1.0.0"

    @abstractmethod
    def parse(self, file_path: Path) -> ExtractedContent:
        """
        Parse `file_path` and return its structured content.

        Implementations should raise the specific `src.parser.exceptions`
        subclass that best describes the failure (encrypted, malformed,
        empty, ...) rather than letting a raw library exception (e.g.
        `pypdf.errors.PdfReadError`) escape — callers (the service layer,
        the CLI) only ever need to know about this package's own
        exception hierarchy.
        """
        raise NotImplementedError

    def validate_output(self, content: ExtractedContent) -> None:
        """
        Shared post-extraction sanity check, run by every parser after
        `parse()` returns.

        Deliberately minimal here (empty-text check only) — the fuller
        validation pipeline (document ACTIVE, duplicate-parsing
        prevention, metadata consistency, page-count validity) is a
        service-level concern that needs database context a parser
        doesn't have; see `validation.py`. This hook exists so a
        format-specific parser CAN add its own extra checks by overriding
        it and calling `super().validate_output(content)` first.
        """
        from src.parser.exceptions import EmptyDocumentError

        if not content.raw_text or not content.raw_text.strip():
            raise EmptyDocumentError("Parsed document contains no extractable text.")

    @classmethod
    def supports(cls, document_type: str) -> bool:
        """
        Whether this parser handles the given `DocumentType` value.

        Overridden by every concrete parser; the default `False` means a
        BaseParser subclass that forgets to declare what it supports is
        never accidentally selected by the factory.
        """
        return False
