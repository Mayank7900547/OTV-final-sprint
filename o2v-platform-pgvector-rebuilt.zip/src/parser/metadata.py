"""
Metadata extraction helpers shared across parsers.

Design decision: date parsing and language detection live here, not
inside `pdf_parser.py`/`html_parser.py`, for the same reason
`discovery/url_validator.py` is its own module rather than inlined into
`sitemap_crawler.py` in Sprint 2 — these are cross-cutting concerns a
future DOCX/PPTX parser will need identically (a DOCX has a creation date
too), so they belong at the package level, not duplicated per format.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from src.config.logging_config import get_logger

logger = get_logger(__name__)

# Matches the PDF spec's date format: D:YYYYMMDDHHmmSSOHH'mm'
# (the "D:" prefix, timezone offset, and apostrophes are all optional —
# real-world PDFs are inconsistent about emitting the full form).
_PDF_DATE_RE = re.compile(
    r"^D:(?P<year>\d{4})(?P<month>\d{2})?(?P<day>\d{2})?"
    r"(?P<hour>\d{2})?(?P<minute>\d{2})?(?P<second>\d{2})?"
)


def parse_pdf_date(raw: str | None) -> datetime | None:
    """
    Convert a raw PDF metadata date string (e.g. ``D:20230415120000+00'00'``)
    to a timezone-aware `datetime`.

    Returns `None` rather than raising on anything that doesn't match —
    malformed creation/modification dates are common in real-world PDFs
    exported by older tools, and a missing date is a normal, expected
    outcome (see Sprint 4 brief: "Extract creation date ... when
    possible"), not a parsing failure that should abort the whole document.
    """
    if not raw:
        return None

    match = _PDF_DATE_RE.match(raw.strip())
    if not match:
        return None

    parts = match.groupdict()
    try:
        return datetime(
            year=int(parts["year"]),
            month=int(parts["month"] or 1),
            day=int(parts["day"] or 1),
            hour=int(parts["hour"] or 0),
            minute=int(parts["minute"] or 0),
            second=int(parts["second"] or 0),
            tzinfo=timezone.utc,
        )
    except ValueError:
        logger.warning("Unparseable PDF date value: %r", raw)
        return None


def normalize_metadata_value(value: object) -> str | None:
    """Trim a raw metadata value to a clean string, or `None` if it's effectively empty."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def detect_language(text: str, *, enabled: bool = True) -> str | None:
    """
    Best-effort language detection over extracted text.

    Design decision: this ALWAYS degrades gracefully to `None` — a missing
    `langdetect` install, an empty/too-short text sample, or a low-
    confidence result are all treated the same way (no language recorded)
    rather than raising, because language is explicitly a "when possible"
    field per the Sprint 4 brief, never a required one. `enabled=False`
    (see `config/settings.py`'s `parsing_language_detection_enabled`) skips
    the attempt entirely, which matters for large batch runs where the
    extra per-document cost isn't wanted.
    """
    if not enabled or not text or len(text.strip()) < 20:
        return None

    try:
        from langdetect import LangDetectException, detect
    except ImportError:  # pragma: no cover - exercised only without the optional dep installed
        logger.debug("langdetect not installed; skipping language detection.")
        return None

    try:
        return detect(text[:5000])
    except LangDetectException:
        return None
