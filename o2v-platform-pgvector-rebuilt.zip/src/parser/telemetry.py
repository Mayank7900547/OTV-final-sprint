"""
In-process metrics collector for a parsing run — mirrors
`src/acquisition/telemetry.py` (same field-per-counter shape), but
synchronous rather than `asyncio`-locked, since `DocumentParserService`
runs synchronously (parsing is CPU-bound, not I/O-bound like downloading —
see `service.py`'s module docstring for why that changes the concurrency
model).
"""

from __future__ import annotations

import threading

from src.parser.types import ParsingSummary


class ParserTelemetry:
    def __init__(self):
        self.documents_parsed: int = 0
        self.pages_processed: int = 0
        self.characters_extracted: int = 0
        self.total_duration_seconds: float = 0.0
        self.parser_failures: int = 0
        self.unsupported_document_types: int = 0
        self.skipped_documents: int = 0
        self._lock = threading.Lock()

    def record_success(self, pages: int, characters: int, duration: float) -> None:
        with self._lock:
            self.documents_parsed += 1
            self.pages_processed += pages
            self.characters_extracted += characters
            self.total_duration_seconds += duration

    def record_failure(self) -> None:
        with self._lock:
            self.parser_failures += 1

    def record_unsupported(self) -> None:
        with self._lock:
            self.unsupported_document_types += 1

    def record_skipped(self) -> None:
        with self._lock:
            self.skipped_documents += 1

    def get_summary(self) -> ParsingSummary:
        with self._lock:
            attempted = self.documents_parsed + self.parser_failures
            success_rate = round(self.documents_parsed / attempted, 4) if attempted else 0.0
            average_time = (
                round(self.total_duration_seconds / self.documents_parsed, 3)
                if self.documents_parsed
                else 0.0
            )
            return {
                "documents_parsed": self.documents_parsed,
                "pages_processed": self.pages_processed,
                "characters_extracted": self.characters_extracted,
                "average_parsing_time": average_time,
                "parser_failures": self.parser_failures,
                "unsupported_document_types": self.unsupported_document_types,
                "skipped_documents": self.skipped_documents,
                "success_rate": success_rate,
            }

    def reset(self) -> None:
        """Used between CLI runs / by tests so telemetry doesn't accumulate across unrelated invocations."""
        with self._lock:
            self.__init__()  # noqa: PLC2801 - deliberate reinitialization, not a foot-gun here (single-threaded reset path)


telemetry = ParserTelemetry()
