"""
Sprint 4 — Document Parsing & Structured Content Extraction.

Design decision: mirrors `src/acquisition/`'s package shape (models,
exceptions, types, service, telemetry, cli living as siblings) rather than
inventing a new layout — Sprint 3.1 already established what an
enterprise-grade subsystem package looks like in this codebase, and
Sprint 4 is a sibling subsystem (parsing what Sprint 3.1 downloaded), not
a reason to explore a new structure.

This module deliberately parses ONLY. No chunking, embeddings, vector
storage, LangChain, retrieval, or LLM extraction lives here — see the
Sprint 4 brief. Those are future sprints' concern.
"""

from src.parser.base_parser import BaseParser, ExtractedContent
from src.parser.parser_factory import ParserFactory

__all__ = ["BaseParser", "ExtractedContent", "ParserFactory"]
