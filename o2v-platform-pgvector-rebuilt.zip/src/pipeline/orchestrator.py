"""
End-to-end pipeline orchestrator: runs discovery through extraction for one
company as a single command, rather than requiring each of Sprints 2-8's
CLI commands to be invoked by hand in sequence.

Design decision: every stage is wrapped so a stage that errors, times out,
or only partially completes does NOT stop the pipeline — it's logged
clearly and the orchestrator moves on to the next stage with whatever data
the partial stage produced. This is a direct, explicit product decision
(not a "just in case" default): on real-world hardware, a stage like
embeddings or extraction can hit genuine resource limits (a local LLM
provider running out of memory, say) that no amount of retrying fixes.
`EmbeddingGenerationService.embed_many` and `ExtractionService.
extract_component` already have circuit breakers for exactly this (see
their docstrings) — this orchestrator's job is the same idea one level up:
don't let one struggling stage block the whole run. 95% embedding
coverage is still enough evidence for a useful retrieval/extraction pass;
waiting indefinitely for 100% before moving on is the wrong trade-off.

Design decision: stages call the same service methods the individual
Sprint 2-8 CLI commands call (`discover_for_company`,
`process_all_pending_documents`, `parse_many`, `chunk_many`, `embed_many`,
`retrieve_evidence`, `extract_component`) directly, in-process — not by
shelling out to `python -m src.cli.main ...` as subprocesses. This keeps
one Python process, one set of settings, and lets errors surface as
normal exceptions the orchestrator can catch per-stage, rather than
parsing subprocess exit codes/stdout.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field

from sqlalchemy.orm import Session

from src.acquisition.service import DocumentAcquisitionService
from src.acquisition.telemetry import telemetry as acquisition_telemetry
from src.chunking.service import DocumentChunkingService
from src.config.logging_config import get_logger
from src.config.settings import settings
from src.core.exceptions import O2VError
from src.database.connection import session_scope
from src.embeddings.embedding_service import EmbeddingGenerationService
from src.extraction.extraction_service import ExtractionService
from src.models.company import Company
from src.parser.service import DocumentParserService
from src.pipeline.ollama_manager import ensure_ollama_running
from src.retrieval.retrieval_service import RetrievalService
from src.services import document_discovery_service

logger = get_logger(__name__)

DEFAULT_COMPONENTS = ["Purpose", "Behaviour", "Value Agenda"]


@dataclass
class StageResult:
    """Outcome of one pipeline stage — always produced, even when the stage errored or was skipped, so the orchestrator's final summary can report on every stage uniformly."""

    stage: str
    status: str  # "SUCCESS" | "PARTIAL" | "SKIPPED" | "ERROR"
    detail: str
    duration_seconds: float = 0.0
    extra: dict = field(default_factory=dict)


class PipelineOrchestrator:
    """Runs discovery -> acquisition -> parsing -> chunking -> embeddings -> retrieval -> extraction for one company, stage by stage, never letting one stage's trouble block the rest."""

    def __init__(self, *, embedding_retry_passes: int | None = None):
        self._embedding_retry_passes = (
            embedding_retry_passes if embedding_retry_passes is not None else settings.pipeline_embedding_retry_passes
        )

    def _resolve_company(self, session: Session, company_name: str) -> Company | None:
        return (
            session.query(Company)
            .filter(Company.name.ilike(f"%{company_name}%"))
            .first()
        )

    def _run_stage(self, stage_name: str, fn) -> StageResult:
        """
        Shared "run this stage, never let it raise past here" wrapper.
        `fn` returns either a `StageResult` itself (for stages that can
        distinguish SUCCESS/PARTIAL on their own, e.g. "N/M succeeded") or
        any other value, in which case a plain SUCCESS is recorded with
        that value's str() as the detail.
        """
        started = time.monotonic()
        try:
            outcome = fn()
        except O2VError as exc:
            duration = round(time.monotonic() - started, 2)
            logger.warning("Pipeline stage %r failed: %s — continuing to the next stage regardless.", stage_name, exc)
            return StageResult(stage=stage_name, status="ERROR", detail=str(exc), duration_seconds=duration)
        except Exception as exc:  # noqa: BLE001 - a stage's unexpected failure must never take down the whole pipeline
            duration = round(time.monotonic() - started, 2)
            logger.warning("Pipeline stage %r raised an unexpected error: %s — continuing to the next stage regardless.", stage_name, exc)
            return StageResult(stage=stage_name, status="ERROR", detail=f"Unexpected error: {exc}", duration_seconds=duration)

        duration = round(time.monotonic() - started, 2)
        if isinstance(outcome, StageResult):
            outcome.duration_seconds = duration
            return outcome
        return StageResult(stage=stage_name, status="SUCCESS", detail=str(outcome), duration_seconds=duration)

    # ------------------------------------------------------------------
    # Individual stages
    # ------------------------------------------------------------------

    def _stage_discovery(self, company_name: str) -> StageResult:
        with session_scope() as session:
            company = document_discovery_service.get_company_or_raise(session, company_name)
            result = document_discovery_service.discover_for_company(session, company)
        return StageResult(
            stage="discovery", status="SUCCESS",
            detail=f"{result.created} created, {result.skipped_duplicates} duplicates skipped, {len(result.rejected)} rejected, {len(result.unreachable)} unreachable.",
        )

    def _stage_acquisition(self, company_name: str) -> StageResult:
        service = DocumentAcquisitionService(session_factory=session_scope)
        asyncio.run(service.process_all_pending_documents(company_filter=company_name))
        summary = acquisition_telemetry.get_summary()
        status = "SUCCESS" if summary["failures"] == 0 else "PARTIAL"
        return StageResult(
            stage="acquisition", status=status,
            detail=f"{summary['downloads_succeeded']} succeeded, {summary['duplicates_skipped']} skipped, {summary['failures']} failed.",
        )

    def _stage_parsing(self, company_name: str, *, force: bool) -> StageResult:
        service = DocumentParserService()
        with session_scope() as session:
            ids = service.load_active_document_version_ids(session, company_filter=company_name)
        if not ids:
            return StageResult(stage="parsing", status="SKIPPED", detail="No ACTIVE document versions found — did acquisition produce anything?")
        results = service.parse_many(session_scope, ids, force=force)
        succeeded = sum(1 for r in results if r.get("status") == "SUCCESS")
        status = "SUCCESS" if succeeded == len(results) else ("PARTIAL" if succeeded else "ERROR")
        return StageResult(stage="parsing", status=status, detail=f"{succeeded}/{len(results)} document(s) parsed.")

    def _stage_chunking(self, company_name: str, *, force: bool) -> StageResult:
        service = DocumentChunkingService()
        with session_scope() as session:
            ids = service.load_eligible_parsed_document_ids(session, company_filter=company_name)
        if not ids:
            return StageResult(stage="chunking", status="SKIPPED", detail="No eligible parsed documents found — did parsing produce anything?")
        results = service.chunk_many(session_scope, ids, force=force)
        succeeded = sum(1 for r in results if r.get("status") == "SUCCESS")
        status = "SUCCESS" if succeeded == len(results) else ("PARTIAL" if succeeded else "ERROR")
        return StageResult(stage="chunking", status=status, detail=f"{succeeded}/{len(results)} document(s) chunked.")

    def _stage_embeddings(self, company_name: str, *, force: bool) -> StageResult:
        """
        Runs embed_many in a loop, picking up whatever's still missing
        each pass (chunks with an active embedding are always skipped
        automatically, so re-running is safe). Stops when either fully
        done, `self._embedding_retry_passes` is reached, or
        `settings.pipeline_embedding_consecutive_stall_limit` consecutive
        passes each make zero progress.

        Requiring multiple consecutive stalls (not just one) before
        giving up — rather than the single-zero-progress-pass stop this
        used to have — matters in practice: a real overnight run saw a
        pass fail entirely (0 succeeded) purely because Ollama had died
        in between passes, followed by a fully healthy pass immediately
        after a manual restart. embed_many's own pre-flight check now
        auto-restarts Ollama when it can (see
        `src/pipeline/ollama_manager.py`), so most of that specific
        problem is handled a layer down — but tolerating one still-bad
        pass here too (rather than stopping at the first zero) means a
        pass that stalls for some OTHER transient reason doesn't
        prematurely end the stage while there's still real progress to
        be made.
        """
        service = EmbeddingGenerationService()
        with session_scope() as session:
            all_ids = service.load_eligible_chunk_ids(session, company_filter=company_name)
        if not all_ids:
            return StageResult(stage="embeddings", status="SKIPPED", detail="No eligible chunks found — did chunking produce anything?")

        total = len(all_ids)
        with session_scope() as session:
            ids = all_ids if force else service.load_unembedded_chunk_ids(session, company_filter=company_name)
        consecutive_stalls = 0
        stall_limit = settings.pipeline_embedding_consecutive_stall_limit
        for pass_number in range(1 + max(0, self._embedding_retry_passes)):
            if not ids:
                break  # fully done, don't burn a pass (and a log line) doing nothing
            results = service.embed_many(session_scope, ids, force=force)
            succeeded_this_pass = sum(1 for r in results if r.get("status") == "SUCCESS")
            with session_scope() as session:
                ids = service.load_unembedded_chunk_ids(session, company_filter=company_name)
            logger.info(
                "Embeddings pass %s: %s succeeded this pass, %s chunk(s) still remaining.",
                pass_number + 1, succeeded_this_pass, len(ids),
            )
            if not ids:
                break  # fully done

            consecutive_stalls = consecutive_stalls + 1 if succeeded_this_pass == 0 else 0
            if consecutive_stalls >= stall_limit:
                logger.warning(
                    "Embeddings stage: %s consecutive pass(es) made zero progress — stopping "
                    "for now with %s chunk(s) still missing. A later pipeline/embeddings run "
                    "will pick up exactly where this left off.",
                    consecutive_stalls, len(ids),
                )
                break

        coverage_pct = round(100 * (total - len(ids)) / total, 1) if total else 100.0
        status = "SUCCESS" if not ids else ("PARTIAL" if coverage_pct > 0 else "ERROR")
        return StageResult(
            stage="embeddings", status=status,
            detail=f"{total - len(ids)}/{total} chunk(s) embedded ({coverage_pct}% coverage), {len(ids)} still missing.",
            extra={"coverage_pct": coverage_pct, "still_missing": len(ids)},
        )

    def _stage_retrieval(self, session: Session, company: Company, components: list[str], framework_name: str | None) -> StageResult:
        service = RetrievalService()
        per_component = []
        for component in components:
            outcome = service.retrieve_evidence(session, company_id=company.id, component=component, framework_name=framework_name)
            per_component.append((component, outcome))
        succeeded = sum(1 for _, o in per_component if o.get("status") == "SUCCESS")
        status = "SUCCESS" if succeeded == len(components) else ("PARTIAL" if succeeded else "ERROR")
        detail = "; ".join(f"{c}: {o.get('status')}" for c, o in per_component)
        return StageResult(stage="retrieval", status=status, detail=detail)

    def _stage_extraction(
        self, session: Session, company: Company, components: list[str], framework_name: str | None, *, force: bool = False
    ) -> StageResult:
        service = ExtractionService()
        per_component_counts = []
        for component in components:
            outcomes = service.extract_component(session, company_id=company.id, component=component, framework_name=framework_name, force=force)
            succeeded = sum(1 for o in outcomes if o.get("status") == "SUCCESS")
            per_component_counts.append((component, succeeded, len(outcomes)))
        total_succeeded = sum(s for _, s, _ in per_component_counts)
        total_attempted = sum(t for _, _, t in per_component_counts)
        status = "SUCCESS" if total_attempted and total_succeeded == total_attempted else ("PARTIAL" if total_succeeded else "ERROR")
        detail = "; ".join(f"{c}: {s}/{t} field(s)" for c, s, t in per_component_counts)
        return StageResult(stage="extraction", status=status, detail=detail)

    # ------------------------------------------------------------------
    # Public entrypoint
    # ------------------------------------------------------------------

    def _ensure_providers_ready_upfront(self) -> None:
        """
        Proactively starts Ollama ONCE, right at the beginning of the
        whole pipeline run — before discovery even begins — rather than
        waiting for the embeddings/extraction stage to discover it's
        down and start it reactively at that point (see
        `EmbeddingGenerationService.embed_many`/`ExtractionService.
        extract_component`'s own pre-flight checks, which still do this
        as a safety net for the case Ollama dies again mid-run).

        The benefit: discovery/acquisition/parsing/chunking typically
        take real time (minutes) before embeddings is even reached — if
        Ollama needs starting, that startup/model-load window now
        overlaps with those earlier stages instead of blocking the
        embeddings stage specifically the moment it begins.

        Only relevant if Ollama is actually the configured provider for
        embeddings and/or extraction — `ensure_ollama_running` is a
        documented no-op for any other provider name (OpenAI/Anthropic
        are remote APIs; there's no local process to start for them).
        Checks both `settings.embeddings_provider` and
        `settings.llm_provider` since they're independently configurable
        and a real deployment could use Ollama for one but not the
        other; both point at the same local server
        (`embeddings_ollama_base_url`/`llm_ollama_base_url` default to
        the same address), so this is at most one real startup attempt
        regardless of how many of the two are Ollama.
        """
        relevant_base_url = None
        if settings.embeddings_provider == "ollama":
            relevant_base_url = settings.embeddings_ollama_base_url
        elif settings.llm_provider == "ollama":
            relevant_base_url = settings.llm_ollama_base_url

        if relevant_base_url is None:
            return  # neither embeddings nor extraction is configured for Ollama — nothing to proactively start

        logger.info("Proactively checking/starting Ollama before the pipeline begins, so it's warmed up well before the embeddings stage needs it.")
        if not ensure_ollama_running(relevant_base_url, provider_name="ollama"):
            logger.warning(
                "Could not confirm Ollama is running at pipeline start — continuing anyway. "
                "Each stage that actually needs it will retry this check when it starts."
            )

    def run(
        self,
        company_name: str,
        *,
        components: list[str] | None = None,
        framework_name: str | None = None,
        force: bool = False,
        skip_discovery: bool = False,
        skip_acquisition: bool = False,
    ) -> list[StageResult]:
        """
        Run every stage for `company_name`, in order, continuing
        regardless of any single stage's outcome. `skip_discovery`/
        `skip_acquisition` exist for the common case of re-running the
        pipeline against data that was already discovered/downloaded in
        an earlier run — those two stages are the ones most likely to
        hit real external-network conditions (SEC EDGAR rate limits, a
        company's own site being briefly unreachable) that don't need
        repeating once the documents are already sitting in the registry.
        """
        self._ensure_providers_ready_upfront()
        components = components or DEFAULT_COMPONENTS
        results: list[StageResult] = []

        if not skip_discovery:
            results.append(self._run_stage("discovery", lambda: self._stage_discovery(company_name)))
        else:
            results.append(StageResult(stage="discovery", status="SKIPPED", detail="Skipped by request (--skip-discovery)."))

        if not skip_acquisition:
            results.append(self._run_stage("acquisition", lambda: self._stage_acquisition(company_name)))
        else:
            results.append(StageResult(stage="acquisition", status="SKIPPED", detail="Skipped by request (--skip-acquisition)."))

        results.append(self._run_stage("parsing", lambda: self._stage_parsing(company_name, force=force)))
        results.append(self._run_stage("chunking", lambda: self._stage_chunking(company_name, force=force)))
        results.append(self._run_stage("embeddings", lambda: self._stage_embeddings(company_name, force=force)))

        def _retrieval_and_extraction():
            with session_scope() as session:
                company = self._resolve_company(session, company_name)
                if company is None:
                    return StageResult(stage="retrieval", status="ERROR", detail=f"No company found matching {company_name!r}.")
                retrieval_result = self._stage_retrieval(session, company, components, framework_name)
            return retrieval_result

        results.append(self._run_stage("retrieval", _retrieval_and_extraction))

        def _extraction():
            with session_scope() as session:
                company = self._resolve_company(session, company_name)
                if company is None:
                    return StageResult(stage="extraction", status="ERROR", detail=f"No company found matching {company_name!r}.")
                return self._stage_extraction(session, company, components, framework_name, force=force)

        results.append(self._run_stage("extraction", _extraction))

        return results
