"""Typer CLI integration for the pipeline orchestrator — one command chaining discovery through extraction, for one company or a batch of them."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from src.pipeline.orchestrator import DEFAULT_COMPONENTS, PipelineOrchestrator

pipeline_app = typer.Typer(name="pipeline", help="End-to-end pipeline orchestrator (discovery -> extraction) for one company or a batch.")

console = Console()

_STATUS_COLOR = {"SUCCESS": "green", "PARTIAL": "yellow", "SKIPPED": "dim", "ERROR": "red"}


def _print_summary_table(company: str, results) -> None:
    table = Table(title=f"Pipeline Summary: {company}")
    table.add_column("Stage")
    table.add_column("Status")
    table.add_column("Detail")
    table.add_column("Time (s)")
    for r in results:
        color = _STATUS_COLOR.get(r.status, "white")
        table.add_row(r.stage, f"[{color}]{r.status}[/{color}]", r.detail, str(r.duration_seconds))
    console.print(table)

    error_stages = [r.stage for r in results if r.status == "ERROR"]
    if error_stages:
        console.print(f"\n[yellow]Note: the following stage(s) hit an error and produced no data this run: {', '.join(error_stages)}.[/yellow]")


@pipeline_app.command("run")
def run_pipeline(
    company: str = typer.Argument(
        None,
        help="Company name (substring match, as shown in 'o2v company list'). Omit this and use --companies instead for a batch.",
    ),
    companies: str = typer.Option(
        None, "--companies",
        help="Comma-separated company names to run the full pipeline for, one after another. "
        "Use this OR the single 'company' argument, not both.",
    ),
    components: str = typer.Option(
        ",".join(DEFAULT_COMPONENTS), "--components",
        help="Comma-separated O2V components to run retrieval/extraction for.",
    ),
    framework: str = typer.Option(None, "--framework", help="Framework name (default: settings.retrieval_framework_name)."),
    force: bool = typer.Option(False, "--force", help="Re-parse/re-chunk/re-embed/re-extract even where already done (disables the resume behavior that otherwise skips already-completed work)."),
    skip_discovery: bool = typer.Option(False, "--skip-discovery", help="Skip the discovery stage — use if documents are already registered."),
    skip_acquisition: bool = typer.Option(False, "--skip-acquisition", help="Skip the acquisition stage — use if documents are already downloaded."),
    embedding_retry_passes: int = typer.Option(
        None, "--embedding-retry-passes",
        help="Override settings.pipeline_embedding_retry_passes for this run.",
    ),
) -> None:
    """
    Run discovery -> acquisition -> parsing -> chunking -> embeddings ->
    retrieval -> extraction, in order, for one company (the 'company'
    argument) or a batch of them (--companies, comma-separated — same
    convention as 'extraction pilot's --companies).

    Design decision: in batch mode, one company's failure does NOT stop
    the batch — each company gets its own orchestrator.run() call inside
    its own try/except, so a company whose site is unreachable or whose
    documents fail to parse doesn't cost you the other companies queued
    behind it in what may be an hours-long unattended run. Each
    company's own stage-level partial-completion tolerance (see
    orchestrator.py's module docstring) still applies underneath this.
    """
    if company and companies:
        console.print("[red]Pass either a single company argument or --companies, not both.[/red]")
        raise typer.Exit(code=1)
    if not company and not companies:
        console.print("[red]Provide a company name, or --companies \"A,B,C\" for a batch.[/red]")
        raise typer.Exit(code=1)

    company_list = [company] if company else [c.strip() for c in companies.split(",") if c.strip()]
    component_list = [c.strip() for c in components.split(",") if c.strip()]

    orchestrator = PipelineOrchestrator(embedding_retry_passes=embedding_retry_passes)

    succeeded: list[str] = []
    errored: list[str] = []

    for i, one_company in enumerate(company_list, start=1):
        if len(company_list) > 1:
            console.print(f"\n[bold]=== ({i}/{len(company_list)}) Running pipeline for '{one_company}' ===[/bold] — components: {', '.join(component_list)}\n")
        else:
            console.print(f"[bold]Running pipeline for '{one_company}'[/bold] — components: {', '.join(component_list)}\n")

        try:
            results = orchestrator.run(
                one_company,
                components=component_list,
                framework_name=framework,
                force=force,
                skip_discovery=skip_discovery,
                skip_acquisition=skip_acquisition,
            )
            _print_summary_table(one_company, results)
            if any(r.status == "ERROR" for r in results):
                errored.append(one_company)
            else:
                succeeded.append(one_company)
        except Exception as exc:  # noqa: BLE001 - deliberately broad: one company's unhandled exception must not kill the batch
            console.print(f"[red]'{one_company}' raised an unhandled error and was skipped: {exc}[/red]")
            errored.append(one_company)

    if len(company_list) > 1:
        console.print(f"\n[bold]=== Batch complete ===[/bold]")
        console.print(f"[green]Clean: {len(succeeded)}[/green]  [yellow]Had errors: {len(errored)}[/yellow]")
        if errored:
            console.print(f"[yellow]Companies with at least one stage error: {', '.join(errored)}[/yellow]")
