"""
Automatic local Ollama startup — added after a real overnight run where a
dead/crashed Ollama server had to be manually restarted (`ollama serve`)
and manually re-checked (`curl http://localhost:11434`) by hand, repeatedly,
across a multi-hour session.

Design decision: this is deliberately scoped to Ollama specifically, not a
generic "restart any provider" mechanism — Ollama is the one provider
that's a local process this codebase can plausibly start itself
(`subprocess.Popen(["ollama", "serve"])`); OpenAI/Anthropic are remote
services with no local process to restart. `ensure_ollama_running` is a
no-op safe to call unconditionally from any embeddings/extraction
pre-flight check regardless of which provider is actually configured — it
returns `False` immediately (matching a plain failed health check) for any
provider whose name isn't `"ollama"`, so callers don't need their own
branch to decide whether auto-start applies.

Design decision: `subprocess.Popen(["ollama", "serve"], ...)` relies on
`ollama` being on PATH — the same assumption already implicit in every
`ollama serve` / `ollama pull` instruction this project's README/`.env.example`
already gives a user to run by hand. If `ollama` isn't on PATH, `Popen`
raises `FileNotFoundError`, which is caught and reported as "could not
auto-start" rather than propagating — auto-start failing should never be
worse than the pre-existing "health check failed, skip this stage" outcome
it's trying to improve on.
"""

from __future__ import annotations

import subprocess
import sys
import time

import httpx

from src.config.logging_config import get_logger

logger = get_logger(__name__)

# Tracks whether THIS process has already attempted to start Ollama, so a
# pipeline run touching multiple stages (embeddings, then extraction)
# doesn't spawn a second redundant `ollama serve` if the first stage's
# attempt already succeeded — or, worse, spawn a second attempt every time
# a later stage's health check happens to catch Ollama mid-startup from
# the first attempt. Reset per-process (module-level, not persisted), so a
# genuinely fresh run always gets a fresh attempt.
_startup_attempted = False


def ensure_ollama_running(
    base_url: str,
    *,
    provider_name: str,
    startup_timeout_seconds: float = 30.0,
    poll_interval_seconds: float = 2.0,
) -> bool:
    """
    If `provider_name != "ollama"`, returns False immediately — this
    function only knows how to start Ollama specifically (see module
    docstring).

    Otherwise: checks whether Ollama is already reachable at `base_url`
    (a quick GET, same check `OllamaEmbeddingProvider.health_check`/
    `OllamaLLMProvider.health_check` already do); if so, returns True
    without attempting to start anything. If not, and this process hasn't
    already tried once, spawns `ollama serve` as a detached background
    process and polls `base_url` every `poll_interval_seconds` until it
    responds or `startup_timeout_seconds` elapses.

    Returns True if Ollama is confirmed reachable by the time this
    returns (whether it was already running, or this call started it),
    False otherwise — including if `ollama` isn't installed/on PATH, or
    it started but never became reachable within the timeout (e.g. still
    loading a large model).
    """
    if provider_name != "ollama":
        return False

    if _check_reachable(base_url):
        return True

    global _startup_attempted
    if _startup_attempted:
        # Already tried once this process and it didn't come up in time —
        # don't spawn a second `ollama serve` (would just error on the
        # same port); the caller's normal "unreachable, skip" path applies.
        return False
    _startup_attempted = True

    logger.warning(
        "Ollama is not reachable at %s — attempting to start it automatically "
        "('ollama serve'), polling for up to %.0fs before giving up.",
        base_url, startup_timeout_seconds,
    )

    if not _spawn_ollama_serve():
        return False

    deadline = time.monotonic() + startup_timeout_seconds
    while time.monotonic() < deadline:
        time.sleep(poll_interval_seconds)
        if _check_reachable(base_url):
            logger.info("Ollama came up successfully after auto-start — resuming.")
            return True

    logger.warning(
        "Ollama did not become reachable at %s within %.0fs of auto-start — "
        "it may still be loading a large model in the background. Giving up "
        "for now; the current stage will proceed with whatever health checks "
        "report from here.",
        base_url, startup_timeout_seconds,
    )
    return False


def _check_reachable(base_url: str, timeout: float = 5.0) -> bool:
    try:
        response = httpx.get(base_url, timeout=timeout)
        return response.status_code == 200
    except httpx.HTTPError:
        return False


def _spawn_ollama_serve() -> bool:
    """
    Launches `ollama serve` as a detached background process (never
    awaited/joined — this function returns as soon as the process is
    launched, not when it finishes, since `ollama serve` runs
    indefinitely until stopped). Returns False (instead of raising) if
    `ollama` isn't on PATH or the OS refuses to spawn it, so a caller can
    treat "couldn't auto-start" the same as "tried, still unreachable."
    """
    popen_kwargs = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }
    if sys.platform == "win32":
        # Detach fully from this process's console so closing/Ctrl-C'ing
        # the Python process doesn't take the Ollama server down with it —
        # mirrors what a user gets by running 'ollama serve' in its own
        # separate terminal window, which is the manual workflow this
        # replaces.
        popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    else:
        popen_kwargs["start_new_session"] = True

    try:
        subprocess.Popen(["ollama", "serve"], **popen_kwargs)
        return True
    except FileNotFoundError:
        logger.warning("Could not auto-start Ollama: 'ollama' executable not found on PATH.")
        return False
    except OSError as exc:
        logger.warning("Could not auto-start Ollama: %s", exc)
        return False


def reset_startup_attempted_flag() -> None:
    """Test/CLI-reset hook — clears the 'already tried once' guard so a fresh pipeline run (or a test) isn't silently blocked by a previous attempt in the same process."""
    global _startup_attempted
    _startup_attempted = False
