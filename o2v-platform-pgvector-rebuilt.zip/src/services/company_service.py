"""
Company Registry service.

Design decision: all business logic (dedup rules, CSV parsing/validation)
lives here, NOT in the CLI layer and NOT in the model. The CLI should only
ever translate "user typed a command" into "call a service function" and
format the result — this is what lets us add a REST API (Platform API, per
the architecture doc) in a later sprint that calls these exact same
service functions, without duplicating or re-deriving any logic that
currently only exists inside CLI command bodies.
"""

import csv
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from src.config.logging_config import get_logger
from src.core.constants import CompanyStatus, DEFAULT_PAGE_SIZE
from src.core.exceptions import CompanyImportError
from src.models.company import Company

logger = get_logger(__name__)

REQUIRED_CSV_COLUMNS = {"name"}
OPTIONAL_CSV_COLUMNS = {"ticker", "website", "sector", "country"}


def get_company_by_name(session: Session, name: str) -> Company | None:
    """Look up a company by exact name — the basis for import-time dedup."""
    stmt = select(Company).where(Company.name == name)
    return session.execute(stmt).scalar_one_or_none()


def create_company(
    session: Session,
    name: str,
    ticker: str | None = None,
    website: str | None = None,
    sector: str | None = None,
    country: str | None = None,
) -> Company:
    """
    Create a single company.

    Callers are expected to have already checked for an existing company
    with the same name (see `import_companies_from_csv` below) — this
    function does not silently upsert, because a duplicate-name attempt
    is more often a caller bug than a legitimate update, and failing loudly
    here surfaces that immediately rather than masking it.
    """
    company = Company(
        name=name.strip(),
        ticker=ticker.strip() if ticker else None,
        website=website.strip() if website else None,
        sector=sector.strip() if sector else None,
        country=country.strip() if country else None,
        status=CompanyStatus.PENDING.value,
    )
    session.add(company)
    session.flush()  # populate company.id without ending the transaction
    return company


def list_companies(
    session: Session, limit: int = DEFAULT_PAGE_SIZE, offset: int = 0
) -> list[Company]:
    """Return companies ordered by name, paginated — used by `o2v company list`."""
    stmt = select(Company).order_by(Company.name).limit(limit).offset(offset)
    return list(session.execute(stmt).scalars().all())


def count_companies(session: Session) -> int:
    return session.query(Company).count()


def import_companies_from_csv(session: Session, csv_path: Path) -> dict:
    """
    Bulk-import companies from a CSV file.

    Design decision: this function validates the ENTIRE file before writing
    ANY row (two-pass: validate, then insert) — a partially-imported CSV due
    to a typo in row 87 of 100 is a worse failure mode than "nothing was
    imported, here's exactly why," especially once this is driven by an
    unattended pipeline rather than a human watching the CLI output.

    Returns a summary dict: {"created": int, "skipped_existing": [names],
    "total_rows": int} so the CLI can report a clear outcome instead of
    just "done."
    """
    if not csv_path.exists():
        raise CompanyImportError(f"CSV file not found: {csv_path}")

    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise CompanyImportError("CSV file has no header row.")

        header = {col.strip().lower() for col in reader.fieldnames}
        missing = REQUIRED_CSV_COLUMNS - header
        if missing:
            raise CompanyImportError(
                f"CSV is missing required column(s): {', '.join(sorted(missing))}"
            )

        rows = list(reader)

    # Pass 1: validate every row has a non-empty name before writing anything.
    for i, row in enumerate(rows, start=2):  # row 1 is the header
        name = (row.get("name") or "").strip()
        if not name:
            raise CompanyImportError(f"Row {i}: 'name' column is empty.")

    created: list[str] = []
    skipped_existing: list[str] = []

    # Pass 2: insert, skipping (not erroring on) names that already exist —
    # re-running an import with an updated CSV should be safe, not destructive.
    for row in rows:
        name = row["name"].strip()
        if get_company_by_name(session, name) is not None:
            skipped_existing.append(name)
            logger.info("Skipping existing company: %s", name)
            continue

        create_company(
            session,
            name=name,
            ticker=row.get("ticker"),
            website=row.get("website"),
            sector=row.get("sector"),
            country=row.get("country"),
        )
        created.append(name)

    logger.info(
        "Company import complete: %d created, %d skipped (already existed).",
        len(created),
        len(skipped_existing),
    )

    return {
        "created": created,
        "skipped_existing": skipped_existing,
        "total_rows": len(rows),
    }
