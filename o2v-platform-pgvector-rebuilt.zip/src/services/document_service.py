"""
Document Registry service.

Design decision: mirrors `company_service.py`'s shape deliberately — a
thin, query-only layer over the `DocumentRegistry` model, with all
discovery LOGIC (what to search, how to classify, how to validate) living
in `services/document_discovery_service.py` and `src/discovery/` instead.
This module's only job is persistence and lookup, exactly like
`framework_service.py`'s relationship to `registry/framework_loader.py`
from Sprint 1 — the same separation-of-concerns pattern applied to a new
subsystem, not a new pattern invented for Sprint 2.
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from src.config.logging_config import get_logger
from src.core.constants import DEFAULT_PAGE_SIZE, DocumentStatus
from src.models.document import DocumentRegistry

logger = get_logger(__name__)


def get_document_by_company_and_url(
    session: Session, company_id: uuid.UUID, official_url: str
) -> DocumentRegistry | None:
    """Look up an existing document by (company, URL) — the basis for discovery-time dedup."""
    stmt = select(DocumentRegistry).where(
        DocumentRegistry.company_id == company_id,
        DocumentRegistry.official_url == official_url,
    )
    return session.execute(stmt).scalar_one_or_none()


def create_document(
    session: Session,
    company_id: uuid.UUID,
    document_name: str,
    document_category: str,
    document_type: str,
    official_url: str,
    source_domain: str,
    discovery_method: str,
    document_year: int | None = None,
    status: str = DocumentStatus.DISCOVERED.value,
) -> DocumentRegistry:
    """
    Create a single Document Registry row.

    Callers (DocumentDiscoveryService) are expected to have already checked
    `get_document_by_company_and_url` — this function does not upsert, for
    the same reasoning as `company_service.create_company`: a duplicate
    attempt reaching this far is more likely a caller bug than an intended
    update, so failing loudly (via the DB's unique constraint) rather than
    silently overwriting is the safer default.
    """
    document = DocumentRegistry(
        company_id=company_id,
        document_name=document_name,
        document_category=document_category,
        document_type=document_type,
        document_year=document_year,
        official_url=official_url,
        source_domain=source_domain,
        discovery_method=discovery_method,
        status=status,
        last_checked=datetime.now(timezone.utc),
    )
    session.add(document)
    session.flush()
    return document


def list_documents(
    session: Session,
    company_id: uuid.UUID | None = None,
    limit: int = DEFAULT_PAGE_SIZE,
    offset: int = 0,
) -> list[DocumentRegistry]:
    """
    List documents, optionally scoped to one company.

    `company_id=None` returns across ALL companies — used by `document list`
    (the platform-wide view); passing a specific company_id is what
    `document show <company>` uses underneath.
    """
    stmt = select(DocumentRegistry).order_by(
        DocumentRegistry.company_id, DocumentRegistry.document_category
    )
    if company_id is not None:
        stmt = stmt.where(DocumentRegistry.company_id == company_id)
    stmt = stmt.limit(limit).offset(offset)
    return list(session.execute(stmt).scalars().all())


def count_documents(session: Session, company_id: uuid.UUID | None = None) -> int:
    stmt = select(func.count()).select_from(DocumentRegistry)
    if company_id is not None:
        stmt = stmt.where(DocumentRegistry.company_id == company_id)
    return session.execute(stmt).scalar_one()


def count_by_category(session: Session) -> dict[str, int]:
    """Used by `discover stats` — how many documents exist per category, platform-wide."""
    stmt = (
        select(DocumentRegistry.document_category, func.count())
        .group_by(DocumentRegistry.document_category)
        .order_by(DocumentRegistry.document_category)
    )
    return dict(session.execute(stmt).all())


def count_by_status(session: Session) -> dict[str, int]:
    """Used by `discover stats` — how many documents are DISCOVERED vs UNREACHABLE, platform-wide."""
    stmt = (
        select(DocumentRegistry.status, func.count())
        .group_by(DocumentRegistry.status)
        .order_by(DocumentRegistry.status)
    )
    return dict(session.execute(stmt).all())


def count_by_discovery_method(session: Session) -> dict[str, int]:
    """Used by `discover stats` — breakdown of how documents were found (SEC API vs sitemap vs heuristic)."""
    stmt = (
        select(DocumentRegistry.discovery_method, func.count())
        .group_by(DocumentRegistry.discovery_method)
        .order_by(DocumentRegistry.discovery_method)
    )
    return dict(session.execute(stmt).all())


def count_companies_with_documents(session: Session) -> int:
    """Used by `discover stats` — how many distinct companies have at least one discovered document."""
    stmt = select(func.count(func.distinct(DocumentRegistry.company_id)))
    return session.execute(stmt).scalar_one()
