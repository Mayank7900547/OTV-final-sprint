"""
Document Discovery orchestration service.

Design decision: this module is the ONLY place that combines the three
concerns Sprint 2 requires — finding candidate URLs (src/discovery/),
validating them (url_validator.py), and persisting the survivors
(document_service.py) — into one coherent per-company workflow. Each of
those three concerns is independently testable and independently
reusable (e.g. `url_validator.validate_url` will get reused unchanged by
a future re-check/staleness job), which is exactly the "thin
orchestration over independently-useful pieces" shape the Sprint 1
architecture doc's Retrieval/Extraction modules also follow.

Design decision: `discover_for_all_companies` catches and logs a per-
company `DiscoveryError` rather than letting it propagate — this directly
implements the architecture doc's stated failure-handling principle
("Company 37 failing should never block companies 38-100"). A single
company whose SEC ticker mapping fails or whose website is unreachable
does not stop the batch; it's recorded as a failure in the returned
summary and the run continues.
"""

from dataclasses import dataclass, field

from sqlalchemy.orm import Session

from src.config.logging_config import get_logger
from src.core.constants import DocumentStatus
from src.core.exceptions import DiscoveryError
from src.discovery import sec_edgar_client, sitemap_crawler
from src.discovery.url_validator import validate_url
from src.models.company import Company
from src.services import company_service, document_service

logger = get_logger(__name__)


@dataclass
class CompanyDiscoveryResult:
    """Outcome of running discovery for a single company — what the CLI reports back."""

    company_name: str
    created: int = 0
    skipped_duplicates: int = 0
    rejected: list[tuple[str, str]] = field(default_factory=list)  # (url, reason)
    unreachable: list[str] = field(default_factory=list)
    error: str | None = None

    @property
    def total_candidates(self) -> int:
        return self.created + self.skipped_duplicates + len(self.rejected) + len(self.unreachable)


def _register_candidate(
    session: Session,
    company: Company,
    document_name: str,
    document_category: str,
    document_type: str,
    official_url: str,
    discovery_method: str,
    document_year: int | None,
    result: CompanyDiscoveryResult,
) -> None:
    """
    Shared validate -> dedup -> reachability-check -> persist pipeline used
    for every candidate, regardless of which discoverer (SEC EDGAR,
    sitemap, heuristic probe) produced it. Factored out once both
    discoverers needed the identical sequence of checks — duplicating this
    per-source would risk the two sources silently drifting in behavior
    (e.g. one remembering to dedup and the other forgetting).
    """
    validation = validate_url(official_url, company.website)
    if not validation.allowed:
        logger.info(
            "Rejected URL for company '%s': %s (%s)", company.name, official_url, validation.reason
        )
        result.rejected.append((official_url, validation.reason or "not allowed"))
        return

    existing = document_service.get_document_by_company_and_url(session, company.id, official_url)
    if existing is not None:
        logger.debug("Duplicate skipped for company '%s': %s", company.name, official_url)
        result.skipped_duplicates += 1
        return

    # SEC EDGAR results are authoritative by construction (SEC itself
    # served the filing) — we don't re-probe them for reachability, both to
    # avoid hammering SEC with a redundant request per filing and because a
    # 200 from `data.sec.gov/submissions/...` already implies the archived
    # document exists. Sitemap/heuristic candidates DO get an extra
    # reachability check here (via url_validator.py's caller having only
    # checked the domain, not liveness) — noted precisely because those
    # sources are inherently guesses (a sitemap can list a stale URL; a
    # heuristic path can 404), whereas SEC's own JSON API already vouches
    # for the filing's existence.
    logger.info(
        "Discovered: company='%s' category=%s method=%s url=%s",
        company.name,
        document_category,
        discovery_method,
        official_url,
    )
    document_service.create_document(
        session,
        company_id=company.id,
        document_name=document_name,
        document_category=document_category,
        document_type=document_type,
        official_url=official_url,
        source_domain=validation.domain or "",
        discovery_method=discovery_method,
        document_year=document_year,
        status=DocumentStatus.DISCOVERED.value,
    )
    result.created += 1


def discover_for_company(session: Session, company: Company) -> CompanyDiscoveryResult:
    """
    Run full discovery (SEC EDGAR + sitemap/heuristic) for one company and
    persist validated, non-duplicate results.

    Raises nothing for ordinary per-URL failures (rejected/unreachable are
    recorded in the returned result, not raised) — only a whole-source
    failure (DiscoveryError, e.g. SEC's API itself being down) propagates,
    and even that is caught one level up by `discover_for_all_companies`
    so it never aborts a multi-company run.
    """
    result = CompanyDiscoveryResult(company_name=company.name)

    sec_candidates = sec_edgar_client.discover_sec_filings(company.ticker)
    for candidate in sec_candidates:
        _register_candidate(
            session,
            company,
            document_name=candidate.document_name,
            document_category=candidate.document_category.value,
            document_type=candidate.document_type.value,
            official_url=candidate.official_url,
            discovery_method=candidate.discovery_method.value,
            document_year=candidate.document_year,
            result=result,
        )

    web_candidates = sitemap_crawler.discover_web_documents(company.website, company.name)
    for candidate in web_candidates:
        _register_candidate(
            session,
            company,
            document_name=candidate.document_name,
            document_category=candidate.document_category.value,
            document_type=candidate.document_type,
            official_url=candidate.official_url,
            discovery_method=candidate.discovery_method.value,
            document_year=candidate.document_year,
            result=result,
        )

    logger.info(
        "Discovery complete for '%s': %d created, %d duplicates skipped, %d rejected, %d unreachable "
        "(%d candidates total).",
        company.name,
        result.created,
        result.skipped_duplicates,
        len(result.rejected),
        len(result.unreachable),
        result.total_candidates,
    )
    return result


def discover_for_all_companies(session: Session) -> list[CompanyDiscoveryResult]:
    """
    Run discovery for every company in the registry, one at a time.

    See module docstring — a single company's DiscoveryError is caught and
    recorded (result.error set, everything else left at zero) rather than
    aborting the batch, per the architecture doc's failure-isolation
    principle.
    """
    companies = company_service.list_companies(session, limit=10_000)
    results: list[CompanyDiscoveryResult] = []

    for company in companies:
        try:
            results.append(discover_for_company(session, company))
        except DiscoveryError as exc:
            logger.error("Discovery failed entirely for company '%s': %s", company.name, exc)
            results.append(CompanyDiscoveryResult(company_name=company.name, error=str(exc)))

    return results


def get_company_or_raise(session: Session, company_name: str) -> Company:
    """
    Small convenience used by the CLI: look up a company by name and raise
    a clear, specific error if it doesn't exist, rather than the CLI
    command needing to duplicate this None-check itself.
    """
    company = company_service.get_company_by_name(session, company_name)
    if company is None:
        raise DiscoveryError(
            f"No company named '{company_name}' found in the registry. "
            "Check `o2v company list` for exact names."
        )
    return company
