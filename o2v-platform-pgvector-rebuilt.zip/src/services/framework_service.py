"""
Framework Registry service.

Design decision: `upsert_framework_fields` is written as delete-then-insert
per framework (not row-by-row upsert) because framework YAML files are the
source of truth in their entirety — if a field was removed from the YAML
between imports, we want it gone from the DB too, not lingering as a stale
row nobody remembers to clean up. This makes `framework import` a true
"sync to this file" operation rather than an additive-only one, which
matters once frameworks are actively edited over time (renaming a field,
splitting a component) rather than just appended to.
"""

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from src.config.logging_config import get_logger
from src.core.constants import DEFAULT_PAGE_SIZE
from src.models.framework import Framework

logger = get_logger(__name__)


def list_framework_names(session: Session) -> list[str]:
    """Distinct framework names currently registered — used by `framework show` with no args."""
    stmt = select(Framework.framework_name).distinct().order_by(Framework.framework_name)
    return [row[0] for row in session.execute(stmt).all()]


def list_fields_for_framework(
    session: Session, framework_name: str, limit: int = DEFAULT_PAGE_SIZE
) -> list[Framework]:
    stmt = (
        select(Framework)
        .where(Framework.framework_name == framework_name)
        .order_by(Framework.component_name, Framework.field_name)
        .limit(limit)
    )
    return list(session.execute(stmt).scalars().all())


def count_frameworks(session: Session) -> int:
    return len(list_framework_names(session))


def upsert_framework_fields(
    session: Session, framework_name: str, fields: list[dict]
) -> dict:
    """
    Replace all rows for a given framework_name with the provided field list.

    `fields` is a list of dicts: {"component_name", "field_name",
    "description", "document_sources"} — produced by
    `registry/framework_loader.py` after parsing and validating a YAML file.
    This function deliberately does not parse YAML itself (single
    responsibility: the loader validates shape, the service persists) —
    that separation is what lets Sprint 2+ add a second loader (e.g. a JSON
    or a web-form-based framework editor) without touching this function.
    """
    # Delete existing rows for this framework first (see module docstring).
    session.execute(
        delete(Framework).where(Framework.framework_name == framework_name)
    )

    created = []
    for field in fields:
        row = Framework(
            framework_name=framework_name,
            component_name=field["component_name"],
            field_name=field["field_name"],
            description=field.get("description"),
            document_sources=field.get("document_sources") or [],
        )
        session.add(row)
        created.append(row)

    session.flush()
    logger.info(
        "Framework '%s' synced: %d fields written.", framework_name, len(created)
    )
    return {"framework_name": framework_name, "fields_written": len(created)}
