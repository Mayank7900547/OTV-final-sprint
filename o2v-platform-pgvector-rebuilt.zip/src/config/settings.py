"""
Application configuration.

Design decision: we use `pydantic-settings` rather than raw `os.getenv()`
calls scattered through the codebase, for three reasons that matter even
at Sprint 1 scale:

1. Validation at startup — if DB_PORT is set to "abc" instead of a number,
   we want the app to fail immediately with a clear error, not three
   modules deep into a confusing runtime TypeError.
2. A single typed object (`settings`) that every module imports, instead of
   each module deciding for itself how to parse an env var (e.g. one module
   treating "DEBUG=true" as truthy, another checking `== "1"`).
3. This is the same pattern later sprints will extend (e.g. adding
   ANTHROPIC_API_KEY, QDRANT_URL) without touching any code that already
   consumes `settings` — new fields just appear, so growth is additive.

Only Environment/Logging/Database/Paths config exists in Sprint 1, per the
explicit scope (no AI/LLM/vector-store settings yet).
"""

from functools import lru_cache
from urllib.parse import quote_plus

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from src.core.constants import Environment


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- Environment ---
    environment: Environment = Field(
        default=Environment.DEV,
        description="Deployment environment: dev, staging, or prod.",
    )

    # --- Database ---
    # Individual components (rather than a single DATABASE_URL string) so that
    # Docker Compose can inject them independently per service, and so a
    # misconfigured single field (e.g. a typo'd URL) fails loudly per-field
    # rather than as one opaque connection string.
    db_host: str = Field(default="localhost")
    db_port: int = Field(default=5432)
    db_name: str = Field(default="o2v_platform")
    db_user: str = Field(default="o2v_user")
    db_password: str = Field(default="o2v_password")

    # --- Logging ---
    log_level: str = Field(default="INFO")
    log_to_file: bool = Field(default=True)

    # --- CLI / misc ---
    app_name: str = Field(default="O2V Platform")

    # --- Document Discovery (Sprint 2) ---
    # Trusted external domains beyond a company's own site — SEC EDGAR is
    # the canonical example (a 10-K legitimately lives on sec.gov, not on
    # apple.com). This list is intentionally SHORT: the discovery service's
    # core safety property is allowlist-first (reject anything not
    # explicitly permitted), so this list only needs to name the handful of
    # third-party sources we trust, not enumerate the much longer list of
    # sources we don't (Wikipedia, blogs, news, forums, GitHub mirrors) —
    # those are excluded by default, not by name. See
    # src/discovery/url_validator.py for where this is enforced.
    discovery_trusted_external_domains: list[str] = Field(
        default=["sec.gov", "www.sec.gov", "data.sec.gov"],
        description="Domains trusted as official sources beyond a company's own website.",
    )
    discovery_timeout_seconds: float = Field(
        default=10.0,
        description="Per-request timeout for discovery HTTP calls (sitemap fetch, URL probes, SEC API).",
    )
    discovery_retry_limit: int = Field(
        default=3,
        description="Max attempts per HTTP request before giving up on that single URL.",
    )
    discovery_retry_backoff_seconds: float = Field(
        default=1.0,
        description="Base delay between retries; doubles each attempt (simple exponential backoff).",
    )
    discovery_rate_limit_delay_seconds: float = Field(
        default=0.5,
        description=(
            "Fixed pause between consecutive outbound requests during a discovery run. "
            "SEC EDGAR's fair-use policy asks for a modest request rate, and being polite "
            "to a company's own site (which was never built to handle a scraper) matters "
            "just as much — a simple fixed delay is deliberately chosen over a token-bucket "
            "limiter here: discovery runs are not high-throughput or latency-sensitive, so "
            "the added complexity of a real rate limiter isn't earning its keep yet."
        ),
    )
    discovery_user_agent: str = Field(
        default="O2VPlatform/1.0 (Document Discovery; contact: platform-admin@example.com)",
        description=(
            "User-Agent sent on every discovery HTTP request. Required — not optional — "
            "for SEC EDGAR specifically: SEC blocks/rate-limits requests without a "
            "descriptive User-Agent identifying the requester. Set this to a real contact "
            "in production; the placeholder here will still work but should be replaced."
        ),
    )

    # --- Document Acquisition (Sprint 3) ---
    # Mirrors the discovery_* section above: tunables that legitimately vary
    # per environment (a CI box downloading nothing vs. a production worker
    # pulling real filings), added additively without touching any existing
    # field a prior sprint already consumes.
    acquisition_concurrent_downloads: int = Field(
        default=5,
        description="Global cap on simultaneous in-flight document downloads.",
    )
    acquisition_max_retries: int = Field(
        default=3,
        description="Max download attempts per document before marking it FAILED.",
    )
    acquisition_retry_backoff_factor: float = Field(
        default=2.0,
        description="Base for exponential backoff between retry attempts (seconds = factor ** attempt).",
    )
    acquisition_min_file_size_bytes: int = Field(
        default=1024,
        description="Downloaded files smaller than this are rejected as corrupt/empty.",
    )
    acquisition_max_file_size_bytes: int = Field(
        default=104_857_600,  # 100 MB
        description="Downloaded files larger than this (by header or by stream) are rejected.",
    )
    acquisition_timeout_seconds: float = Field(
        default=30.0,
        description="Per-request timeout for document download HTTP calls.",
    )
    acquisition_user_agent: str = Field(
        default="O2VPlatform/1.0 (Document Acquisition; contact: platform-admin@example.com)",
        description="User-Agent sent on every document download request.",
    )

    # --- Document Parsing (Sprint 4) ---
    # Mirrors the acquisition_* / discovery_* sections above: additive,
    # environment-tunable knobs for the new subsystem, none of which touch
    # any field a prior sprint already consumes.
    parsing_max_pages: int | None = Field(
        default=2000,
        description="PDFs with more pages than this are truncated to the first N pages before extraction.",
    )
    parsing_max_document_size_bytes: int = Field(
        default=209_715_200,  # 200 MB
        description="Documents larger than this on disk are rejected before parsing is attempted.",
    )
    parsing_max_time_seconds: float = Field(
        default=120.0,
        description="Hard wall-clock limit for parsing a single document before it's aborted as FAILED.",
    )
    parsing_parallel_workers: int = Field(
        default=4,
        description="Number of documents parsed concurrently during a batch (`parse all` / `parse company`) run.",
    )
    parsing_default_parser: str = Field(
        default="pdf",
        description="Document type used when a file's type cannot be determined and no hint is available.",
    )
    parsing_ocr_enabled: bool = Field(
        default=False,
        description="Placeholder for future OCR fallback on scanned/image-only PDFs - not implemented in Sprint 4.",
    )
    parsing_language_detection_enabled: bool = Field(
        default=True,
        description="Whether parsers attempt best-effort language detection on extracted text.",
    )

    # --- Document Chunking (Sprint 5) ---
    # Mirrors the parsing_* / acquisition_* / discovery_* sections above:
    # additive, environment-tunable knobs for the new subsystem, none of
    # which touch any field a prior sprint already consumes.
    chunking_chunk_size: int = Field(
        default=1000,
        description="Target chunk size in characters that RecursiveChunker aims for.",
    )
    chunking_chunk_overlap: int = Field(
        default=150,
        description="Characters of overlap carried from the end of one chunk into the start of the next.",
    )
    chunking_min_chunk_size: int = Field(
        default=100,
        description="Chunks smaller than this are folded into a neighboring chunk where possible.",
    )
    chunking_max_chunk_size: int = Field(
        default=2000,
        description="Hard ceiling on chunk size in characters — never exceeded, even for atomic content like tables.",
    )
    chunking_separator_hierarchy: list[str] = Field(
        default=["\n\n", "\n", ". ", " ", ""],
        description=(
            "Ordered separators RecursiveChunker tries, most-structural first "
            "(paragraph, then line, then sentence, then word, then hard character split)."
        ),
    )
    chunking_semantic_chunking_enabled: bool = Field(
        default=False,
        description="Placeholder for a future embedding-similarity-based chunker — not implemented in Sprint 5.",
    )
    chunking_parallel_workers: int = Field(
        default=4,
        description="Number of parsed documents chunked concurrently during a batch (`chunk all` / `chunk company`) run.",
    )

    # --- Embedding Generation & Vector Database (Sprint 6) ---
    # Provider/model selection is intentionally decoupled from the
    # provider CLASS (see src/embeddings/embedding_factory.py) — swapping
    # providers or models is a config change here, never a code change.
    #
    # DEFAULT IS A LOCAL PROVIDER (Ollama), NOT OpenAI. This is a
    # deliberate architectural decision, not an oversight: the O2V
    # platform must be usable end-to-end without requiring anyone to buy
    # commercial API credits. OpenAI remains a fully-supported, working
    # provider — set EMBEDDINGS_PROVIDER=openai (and OPENAI_API_KEY) to
    # opt into it — but it is opt-in, not the out-of-the-box default.
    embeddings_provider: str = Field(
        default="ollama",
        description="Which registered embedding provider to use (see embedding_factory.available_providers()).",
    )
    embeddings_model_name: str = Field(
        default="nomic-embed-text",
        description="Model name passed to the active embedding provider. For 'openai', use e.g. 'text-embedding-3-small'.",
    )
    embeddings_model_version: str = Field(
        default="1",
        description="Version tag recorded alongside every embedding — bumped whenever the model/config changes enough to warrant re-embedding.",
    )
    embeddings_dimension: int = Field(
        default=768,
        description="Expected output dimension of the active provider/model combination. nomic-embed-text=768; OpenAI text-embedding-3-small=1536 (adjust if you switch providers/models).",
    )
    embeddings_batch_size: int = Field(
        default=100,
        description="Maximum number of chunks sent to the provider in a single embed_batch() call.",
    )
    embeddings_max_concurrent_requests: int = Field(
        default=4,
        description="Maximum number of concurrent in-flight embedding batches during a batch (`embed all` / `embed company`) run.",
    )
    embeddings_retry_limit: int = Field(
        default=3,
        description="Number of additional attempts made if a provider call fails before the chunk is recorded as FAILED.",
    )
    embeddings_retry_backoff_seconds: float = Field(
        default=1.0,
        description="Base backoff delay between retries — see src/embeddings/utils.py::with_retries.",
    )
    embeddings_timeout_seconds: float = Field(
        default=30.0,
        description="Per-request timeout passed to the active embedding provider's client.",
    )
    embeddings_circuit_breaker_threshold: int = Field(
        default=10,
        description=(
            "Number of consecutive fully-failed batches after which embed_many() stops "
            "submitting further batches rather than continuing to grind through the same "
            "failure (e.g. the provider being genuinely down or resource-starved). Set to 0 "
            "to disable — every batch is still attempted regardless of prior failures. "
            "Chunks not yet attempted when the breaker trips are simply left as-is (not "
            "embedded) and can be picked up by a later `embeddings retry-failed` / "
            "`embed_many` call once the underlying issue is resolved — this never marks "
            "anything as permanently failed, it just stops burning time in one run."
        ),
    )
    embeddings_health_check_timeout_seconds: float = Field(
        default=5.0,
        description=(
            "Timeout for the lightweight pre-flight connectivity check embed_many() runs "
            "before starting a batch — deliberately much shorter than embeddings_timeout_seconds "
            "so a genuinely unreachable provider is detected in seconds, not by burning through "
            "a full embeddings_retry_limit-worth of embeddings_timeout_seconds-length timeouts "
            "on the first real batch."
        ),
    )
    embeddings_vector_db_backend: str = Field(
        default="postgres",
        description="Which registered vector store backend to use (see src/embeddings/vector_store.py::available_vector_stores()).",
    )
    embeddings_openai_api_key: str | None = Field(
        default=None,
        description="API key for the OpenAI embedding provider — loaded from OPENAI_API_KEY. Only required if EMBEDDINGS_PROVIDER=openai. None disables that provider until set.",
        validation_alias="OPENAI_API_KEY",
    )
    embeddings_ollama_base_url: str = Field(
        default="http://localhost:11434",
        description="Base URL of a running Ollama server, used by the 'ollama' embedding provider. No API key required — this is the local, no-cost default.",
    )

    # --- Semantic Evidence Retrieval (Sprint 7) ---
    # See src/retrieval/types.py::RetrievalConfig for how these combine
    # at request time, and src/retrieval/reranker.py for the reranker
    # registry these values feed into. No commercial LLM configuration
    # exists here — retrieval works entirely off Sprint 6's embedding
    # provider (semantic) and Postgres full-text search (lexical).
    retrieval_candidate_k: int = Field(
        default=200,
        description="Broad candidate pool size fetched PER QUERY (semantic and lexical each) before thresholding/reranking.",
    )
    retrieval_final_evidence_k: int = Field(
        default=100,
        description="Target size of the final, reranked, diversity-controlled evidence pool per retrieval request.",
    )
    retrieval_similarity_threshold: float = Field(
        default=0.15,
        description="Minimum raw (pre-normalization) cosine similarity for a candidate to survive semantic filtering. Relaxed automatically (see retrieval_threshold_relaxation_*) if it would otherwise yield zero candidates.",
    )
    retrieval_semantic_weight: float = Field(
        default=0.6,
        description="Weight of the semantic similarity signal in final_score. Must sum to 1.0 with lexical/metadata weights — see RetrievalConfig.",
    )
    retrieval_lexical_weight: float = Field(
        default=0.25,
        description="Weight of the lexical (full-text) relevance signal in final_score.",
    )
    retrieval_metadata_weight: float = Field(
        default=0.15,
        description="Weight of the metadata-alignment signal (document type vs. Phase 1 document_sources) in final_score.",
    )
    retrieval_metadata_match_score: float = Field(
        default=1.0,
        description="metadata_score assigned when a candidate's document type matches the matched query field's expected document_sources.",
    )
    retrieval_metadata_no_match_score: float = Field(
        default=0.4,
        description="metadata_score assigned when there is no document_sources match — deliberately > 0, since document_sources is a curated expectation, not an exhaustive allow-list.",
    )
    retrieval_max_queries_per_component: int | None = Field(
        default=None,
        description="Cap on how many Phase 1-derived query formulations are used per component. None = use every Framework field for that component.",
    )
    retrieval_diversity_max_per_document: int = Field(
        default=15,
        description="Maximum number of evidence items the final pool may draw from a single document.",
    )
    retrieval_diversity_max_per_section: int = Field(
        default=5,
        description="Maximum number of evidence items the final pool may draw from a single (document, section) pair.",
    )
    retrieval_threshold_relaxation_step: float = Field(
        default=0.05,
        description="Amount retrieval_similarity_threshold is lowered by per relaxation attempt when a request would otherwise return zero candidates.",
    )
    retrieval_threshold_relaxation_max_attempts: int = Field(
        default=3,
        description="Maximum number of threshold relaxation attempts before returning an explicit NO_RELEVANT_EVIDENCE outcome.",
    )
    retrieval_framework_name: str = Field(
        default="O2V",
        description="Which imported Framework (see src/models/framework.py) supplies component/field definitions that drive query generation.",
    )
    retrieval_reranker: str = Field(
        default="deterministic",
        description="Which registered reranker to use (see src/retrieval/reranker.py::available_rerankers()). 'deterministic' requires no LLM of any kind.",
    )

    # --- Semantic Extraction (Sprint 8) ---
    # Mirrors the embeddings_*/retrieval_* sections above: this is the
    # first place a commercial-or-local LLM COMPLETION provider (not
    # embedding provider) is configured — see src/extraction/llm_factory.py
    # for the provider registry these values select between. Deliberately
    # provider-agnostic (LLM_PROVIDER, not e.g. OPENAI_MODEL as the only
    # option) per the Sprint 8 brief's "must remain provider-independent"
    # requirement — swapping ollama -> openai -> anthropic is a config
    # change, never a code change.
    llm_provider: str = Field(
        default="ollama",
        description="Which registered LLM completion provider to use for extraction (see src/extraction/llm_factory.py::available_llm_providers()). 'ollama' is the local, no-API-key default, matching the embeddings provider default.",
    )
    llm_model_name: str = Field(
        default="llama3.1",
        description="Model name passed to the active LLM provider. Provider-specific — e.g. 'llama3.1' for ollama, 'gpt-4o-mini' for openai, 'claude-sonnet-4-6' for anthropic.",
    )
    llm_temperature: float = Field(
        default=0.0,
        description="Sampling temperature for extraction calls. Deliberately defaults to 0.0 — extraction is meant to be a reproducible read of the supplied evidence, not creative generation (see Sprint 8 brief's 'Reproducibility' extraction principle).",
    )
    llm_max_output_tokens: int = Field(
        default=2000,
        description="Max tokens the provider may generate for a single field extraction response.",
    )
    llm_timeout_seconds: float = Field(
        default=60.0,
        description="Per-request timeout for LLM completion calls — longer than embeddings_timeout_seconds since extraction prompts/responses are larger and completion is slower than embedding.",
    )
    llm_retry_limit: int = Field(
        default=3,
        description="Number of additional attempts made if a provider call fails or returns malformed JSON before the field extraction is recorded as FAILED.",
    )
    llm_retry_backoff_seconds: float = Field(
        default=1.0,
        description="Base backoff delay between retries — same convention as embeddings_retry_backoff_seconds.",
    )
    llm_circuit_breaker_threshold: int = Field(
        default=5,
        description=(
            "Number of consecutive field-extraction failures (PROVIDER_ERROR or PARSE_ERROR) "
            "after which extract_component() stops attempting the remaining fields for that "
            "component rather than continuing to fail at the same rate. Set to 0 to disable. "
            "Fields not yet attempted are simply skipped this run, not marked as any kind of "
            "permanent failure — a later extract_component()/extract_field() call will attempt "
            "them fresh. Default is lower than embeddings_circuit_breaker_threshold because a "
            "single LLM extraction call is far more expensive (seconds-to-minutes vs. sub-second) "
            "than a single embedding call, so it's worth giving up sooner."
        ),
    )
    llm_health_check_timeout_seconds: float = Field(
        default=5.0,
        description=(
            "Timeout for the lightweight pre-flight connectivity check extract_component() runs "
            "before attempting any field — same rationale as embeddings_health_check_timeout_seconds: "
            "catch a genuinely unreachable provider in seconds, not after llm_retry_limit-many "
            "llm_timeout_seconds-length timeouts on the very first field."
        ),
    )
    llm_openai_api_key: str | None = Field(
        default=None,
        description="API key for the OpenAI LLM provider. Only required if LLM_PROVIDER=openai. Deliberately a SEPARATE field from embeddings_openai_api_key (both load from OPENAI_API_KEY by default) since a deployment could plausibly use OpenAI for one and not the other.",
        validation_alias="OPENAI_API_KEY",
    )
    llm_anthropic_api_key: str | None = Field(
        default=None,
        description="API key for the Anthropic LLM provider. Only required if LLM_PROVIDER=anthropic.",
        validation_alias="ANTHROPIC_API_KEY",
    )
    llm_ollama_base_url: str = Field(
        default="http://localhost:11434",
        description="Base URL of a running Ollama server, used by the 'ollama' LLM provider. No API key required — this is the local, no-cost default, same server embeddings_ollama_base_url points at (Ollama serves both endpoints).",
    )
    extraction_evidence_max_items: int = Field(
        default=25,
        description="Max number of RetrievedEvidence rows (by rank) included in a single field's extraction prompt — bounds prompt size even when Sprint 7's final_evidence_k is large.",
    )
    extraction_evidence_max_chars_per_item: int = Field(
        default=1500,
        description="Max characters of chunk_text included per evidence item in the prompt — a defensive truncation, not expected to trigger for normally-sized chunks.",
    )

    # --- Pipeline Orchestrator (chains Sprints 2-8 for one company) ---
    pipeline_embedding_retry_passes: int = Field(
        default=8,
        description=(
            "How many additional embed_many() passes PipelineOrchestrator runs for the "
            "embeddings stage beyond the first, picking up whatever's still missing each "
            "time (chunks with an active embedding are always skipped automatically, so "
            "re-running is safe). Higher than a single blind retry because each pass's own "
            "pre-flight health check now auto-restarts a dead local Ollama server (see "
            "src/pipeline/ollama_manager.py) — extra passes are cheap when things are "
            "actually fine, and safe (each pass's own circuit breaker stops it quickly) "
            "when they're not. See pipeline_embedding_consecutive_stall_limit for the "
            "actual stop condition."
        ),
    )
    pipeline_embedding_consecutive_stall_limit: int = Field(
        default=2,
        description=(
            "Number of consecutive embeddings passes that must each make ZERO progress "
            "before the embeddings stage gives up for this run (as opposed to stopping "
            "after a single zero-progress pass). Found in practice: one pass returning "
            "0 succeeded purely because a local Ollama server had died in between passes, "
            "immediately followed by a fully healthy pass after a restart — stopping after "
            "exactly one stall would have ended the stage prematurely with real progress "
            "still to be made."
        ),
    )

    @property
    def database_url(self) -> str:
        """
        Build the SQLAlchemy connection string from components.

        Kept as a computed property (not a stored field) so there is exactly
        one place this assembly logic lives — if we ever need to switch driver
        (e.g. psycopg2 -> psycopg3), this is the only line that changes.

        `db_user`/`db_password` are percent-encoded via `quote_plus` before
        being interpolated into the URL. Without this, any credential
        containing a character that's reserved in URI syntax — '@', ':',
        '/', '#', '%', etc. — silently corrupts the parsed connection
        string rather than raising an error: e.g. a password of
        'Md@7378450856' produces 'postgresql://user:Md@7378450856@host/db',
        which every URL parser reads as user='user', password='Md',
        host='7378450856@host' — the extra '@' is treated as a second
        (later, "winning") credentials/host separator. This is a real bug
        that was hit in practice with a real Windows Postgres password
        containing '@', not a hypothetical: `psycopg2.OperationalError`
        reported `could not translate host name "7378450856@localhost"`.
        `db_name` is not encoded since Postgres database names cannot
        contain '@' by the database engine's own naming rules, so there's
        no equivalent risk there.
        """
        user = quote_plus(self.db_user)
        password = quote_plus(self.db_password)
        return (
            f"postgresql+psycopg2://{user}:{password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @property
    def is_prod(self) -> bool:
        return self.environment == Environment.PROD


@lru_cache
def get_settings() -> Settings:
    """
    Return a cached Settings instance.

    `lru_cache` ensures `.env` is parsed once per process, not on every
    import — settings are treated as immutable for the process lifetime,
    which also makes behavior predictable in tests (no surprise re-reads
    of environment variables mid-run).
    """
    return Settings()


settings = get_settings()
