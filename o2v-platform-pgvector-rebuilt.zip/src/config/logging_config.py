"""
Logging configuration.

Design decision: standard library `logging`, not a third-party logger
(loguru/structlog), for Sprint 1. The platform will eventually want
structured JSON logs feeding an observability stack (per the architecture
doc), but introducing that now, before there's any pipeline activity worth
observing, is premature — stdlib logging with a clean formatter is enough
to prove out Company/Framework registry operations. The formatter below is
already written to make a future swap to JSON output a one-function change
(`_build_formatter`), not a rewrite of every call site, since all logging
still goes through `get_logger()`.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler

from src.config.settings import settings
from src.utils.paths import LOGS_DIR

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured = False


def _build_formatter() -> logging.Formatter:
    return logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)


def configure_logging() -> None:
    """
    Configure the root logger once per process.

    Idempotent by design (`_configured` guard) — CLI commands and tests may
    both call this; we never want duplicate handlers silently doubling every
    log line, which is a common and confusing bug in naive logging setups.
    """
    global _configured
    if _configured:
        return

    root_logger = logging.getLogger()
    root_logger.setLevel(settings.log_level.upper())

    formatter = _build_formatter()

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    if settings.log_to_file:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            LOGS_DIR / "o2v_platform.log",
            maxBytes=5 * 1024 * 1024,  # 5 MB per file
            backupCount=5,
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    # Quiet noisy third-party loggers so `INFO` level stays readable —
    # SQLAlchemy's engine logger is chatty at INFO about every SQL statement,
    # which is useful for debugging but not for everyday CLI use.
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    """
    Return a module-scoped logger, ensuring configuration has run.

    Every module should call `get_logger(__name__)` rather than
    `logging.getLogger(__name__)` directly — this guarantees logging is
    configured (handlers attached) the first time any module logs, even if
    the CLI entry point forgot to call `configure_logging()` explicitly.
    """
    configure_logging()
    return logging.getLogger(name)
