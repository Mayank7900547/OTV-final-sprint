"""Downloader Interface and HTTP Implementation."""
import abc
import httpx
from pathlib import Path
from typing import Tuple, Optional
from src.config.settings import settings
from src.acquisition.exceptions import AcquisitionError, FileTooLargeError, SSRFValidationError
from src.acquisition.rate_limiter import HostRateLimiter
from src.acquisition.ssrf_guard import is_url_safe

class BaseDownloader(abc.ABC):
    @abc.abstractmethod
    async def fetch(self, url: str, staging_path: Path) -> Tuple[int, Optional[str]]:
        """Downloads document source stream to staging destination."""
        pass

class HttpDownloader(BaseDownloader):
    def __init__(self, rate_limiter: HostRateLimiter, max_redirects: int = 5):
        self.rate_limiter = rate_limiter
        self.max_redirects = max_redirects

    async def fetch(self, initial_url: str, staging_path: Path) -> Tuple[int, Optional[str]]:
        current_url = initial_url
        async with httpx.AsyncClient(
            headers={"User-Agent": settings.acquisition_user_agent},
            timeout=settings.acquisition_timeout_seconds,
        ) as client:
            for _ in range(self.max_redirects + 1):
                if not is_url_safe(current_url):
                    raise SSRFValidationError(f"URL failed SSRF validation: {current_url}")

                # `throttle()` (unlike the older `acquire()`) holds the
                # per-host concurrency slot for this entire hop -- request
                # send through full body stream -- so
                # `acquisition_concurrent_downloads`-per-host is actually
                # enforced against real in-flight downloads, not just
                # against entry into the pacing delay. See
                # rate_limiter.py's docstrings for the distinction.
                async with self.rate_limiter.throttle(current_url):
                    response = await client.send(client.build_request("GET", current_url), stream=True)
                    if response.is_redirect:
                        target = response.headers.get("location")
                        if not target:
                            raise AcquisitionError("Redirect response missing Location header")
                        current_url = str(httpx.URL(current_url).join(target))
                        await response.aclose()
                        continue

                    response.raise_for_status()
                    length = response.headers.get("Content-Length")
                    if length and int(length) > settings.acquisition_max_file_size_bytes:
                        await response.aclose()
                        raise FileTooLargeError("Content-Length header exceeds limit")

                    content_type = response.headers.get("Content-Type")
                    downloaded = 0
                    try:
                        with open(staging_path, "wb") as f:
                            async for chunk in response.aiter_bytes(chunk_size=8192):
                                downloaded += len(chunk)
                                if downloaded > settings.acquisition_max_file_size_bytes:
                                    raise FileTooLargeError("Stream exceeded maximum size limit")
                                f.write(chunk)
                        return response.status_code, content_type
                    finally:
                        await response.aclose()
        raise AcquisitionError("Exceeded maximum HTTP redirects")
