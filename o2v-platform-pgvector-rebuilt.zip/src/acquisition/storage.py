"""Pluggable Enterprise Storage Backends."""
import abc
import shutil
from pathlib import Path
from src.acquisition.exceptions import StorageError

class BaseStorageBackend(abc.ABC):
    @abc.abstractmethod
    def save(self, source_path: Path, destination_key: str) -> str: pass

    @abc.abstractmethod
    def move(self, source_key: str, destination_key: str) -> str: pass

    @abc.abstractmethod
    def delete(self, key: str) -> bool: pass

    @abc.abstractmethod
    def exists(self, key: str) -> bool: pass

class LocalDiskStorageBackend(BaseStorageBackend):
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _resolve(self, key: str) -> Path:
        return self.base_dir / Path(key.lstrip("/"))

    def save(self, source_path: Path, destination_key: str) -> str:
        dest_path = self._resolve(destination_key)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, dest_path)
        return str(dest_path)

    def move(self, source_key: str, destination_key: str) -> str:
        src_path = self._resolve(source_key) if not Path(source_key).is_absolute() else Path(source_key)
        dest_path = self._resolve(destination_key)
        if not src_path.exists():
            raise StorageError(f"Source file does not exist: {src_path}")
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src_path), str(dest_path))
        return str(dest_path)

    def delete(self, key: str) -> bool:
        path = self._resolve(key) if not Path(key).is_absolute() else Path(key)
        if path.exists():
            path.unlink()
            return True
        return False

    def exists(self, key: str) -> bool:
        path = self._resolve(key) if not Path(key).is_absolute() else Path(key)
        return path.exists()