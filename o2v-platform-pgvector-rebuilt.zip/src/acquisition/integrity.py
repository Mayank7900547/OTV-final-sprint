"""Binary and MIME Header Document Integrity Validation Module."""
import hashlib
from pathlib import Path
from typing import Tuple, Optional
from src.config.settings import settings
from src.core.constants import DocumentType


class FileIntegrityValidator:
    @staticmethod
    def calculate_sha256(file_path: Path, chunk_size: int = 65536) -> str:
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            while chunk := f.read(chunk_size):
                sha256.update(chunk)
        return sha256.hexdigest()

    @classmethod
    def validate_document_integrity(
        cls,
        file_path: Path,
        content_type_header: Optional[str] = None,
        document_type: Optional[str] = None,
    ) -> Tuple[bool, Optional[str]]:
        """
        Structural integrity check for a downloaded document. Dispatches
        to a format-specific check (PDF magic-bytes/EOF, or a lightweight
        HTML sanity check) based on `document_type` — which should be the
        DocumentRegistry row's own `document_type` (set at discovery time
        by `classify_document_type()`/SEC EDGAR client, same "registry
        value is authoritative" convention `ParserFactory` already uses
        for the same column) — falling back to sniffing
        `content_type_header` if the caller doesn't have it.

        Design decision: this used to be PDF-only (`validate_pdf_integrity`,
        unconditionally rejecting `text/html`). That was too narrow for
        real official sources — SEC EDGAR routinely serves 10-Ks/proxy
        statements as `.htm`, and "About Us" pages are HTML by nature —
        and Sprint 4's parser already has a dedicated `html_parser.py`,
        so acquisition rejecting HTML was blocking a capability the rest
        of the pipeline already supports. Only PDF and HTML are accepted,
        matching `DocumentType`'s only two concrete values (`UNKNOWN`
        aside) — this isn't opened up to arbitrary content types.
        """
        if not file_path.exists():
            return False, "File does not exist on disk."

        file_size = file_path.stat().st_size
        if file_size < settings.acquisition_min_file_size_bytes:
            return False, f"File size ({file_size} B) is below threshold."
        if file_size > settings.acquisition_max_file_size_bytes:
            return False, f"File size ({file_size} B) exceeds maximum limit."

        resolved_type = cls._resolve_document_type(document_type, content_type_header)
        if resolved_type == DocumentType.HTML.value:
            return cls._validate_html_structure(file_path)
        if resolved_type == DocumentType.PDF.value:
            return cls._validate_pdf_structure(file_path)

        # Neither the registry's document_type nor the Content-Type header
        # could be resolved to PDF or HTML — reject rather than guess,
        # same as the original PDF-only validator's Content-Type branch.
        return False, f"Unsupported or undeterminable document type (content_type={content_type_header!r}, document_type={document_type!r})."

    @classmethod
    def validate_pdf_integrity(
        cls, file_path: Path, content_type_header: Optional[str] = None
    ) -> Tuple[bool, Optional[str]]:
        """
        Deprecated alias kept for backward compatibility — behaves exactly
        as before (PDF-only; any non-PDF Content-Type is rejected). New
        callers should use `validate_document_integrity`, which is
        content-type-aware. Not called anywhere in this codebase anymore
        (see `service.py`); kept only so external code depending on the
        old name doesn't break.
        """
        if content_type_header:
            clean_ct = content_type_header.split(";")[0].strip().lower()
            if clean_ct in ["text/html", "application/json", "text/plain"]:
                return False, f"Invalid Content-Type for PDF: '{content_type_header}'"

        if not file_path.exists():
            return False, "File does not exist on disk."
        file_size = file_path.stat().st_size
        if file_size < settings.acquisition_min_file_size_bytes:
            return False, f"File size ({file_size} B) is below threshold."
        if file_size > settings.acquisition_max_file_size_bytes:
            return False, f"File size ({file_size} B) exceeds maximum limit."

        return cls._validate_pdf_structure(file_path)

    @staticmethod
    def _resolve_document_type(document_type: Optional[str], content_type_header: Optional[str]) -> Optional[str]:
        if document_type in (DocumentType.PDF.value, DocumentType.HTML.value):
            return document_type

        if content_type_header:
            clean_ct = content_type_header.split(";")[0].strip().lower()
            if clean_ct == "application/pdf":
                return DocumentType.PDF.value
            if clean_ct in ("text/html", "application/xhtml+xml"):
                return DocumentType.HTML.value

        return None

    @staticmethod
    def _validate_pdf_structure(file_path: Path) -> Tuple[bool, Optional[str]]:
        try:
            file_size = file_path.stat().st_size
            with open(file_path, "rb") as f:
                header = f.read(1024)
                if b"%PDF-" not in header:
                    return False, "Missing '%PDF-' magic bytes."

                f.seek(max(0, file_size - 1024))
                trailer = f.read()
                if b"%%EOF" not in trailer:
                    return False, "Missing '%%EOF' end-of-file marker."

            return True, None
        except OSError as e:
            return False, f"IO error during integrity inspection: {str(e)}"

    @staticmethod
    def _validate_html_structure(file_path: Path) -> Tuple[bool, Optional[str]]:
        """
        Deliberately as cheap/structural as the PDF check above — this is
        not a full HTML parse (Sprint 4's `html_parser.py` already owns
        that job downstream). Looks for a case-insensitive `<html` or
        `<!doctype html` opening marker in the first 2KB, which real HTML
        documents always have near the start and binary garbage
        mislabeled as HTML will not.
        """
        try:
            with open(file_path, "rb") as f:
                head = f.read(2048).lower()
                if b"<html" not in head and b"<!doctype html" not in head:
                    return False, "Missing an '<html' or '<!DOCTYPE html' opening marker in the first 2KB."
            return True, None
        except OSError as e:
            return False, f"IO error during integrity inspection: {str(e)}"
