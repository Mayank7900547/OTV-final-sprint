"""Core Document Acquisition Orchestration Service."""
import time
import asyncio
from datetime import datetime, timezone
from typing import Optional, List
from uuid import UUID as PyUUID
from sqlalchemy import desc

from src.config.settings import settings
from src.database.connection import session_scope
from src.config.logging_config import get_logger
from src.models.document import DocumentRegistry
from src.models.company import Company

from src.acquisition.models import DocumentVersion, DownloadHistory, DownloadStatusEnum, DocumentVersionStatusEnum
from src.acquisition.file_manager import EnterpriseFileManager
from src.acquisition.integrity import FileIntegrityValidator
from src.acquisition.downloader import HttpDownloader
from src.acquisition.rate_limiter import HostRateLimiter
from src.acquisition.telemetry import telemetry
from src.acquisition.exceptions import FileIntegrityError, FileTooLargeError
from src.acquisition.types import DownloadResult

logger = get_logger(__name__)

class DocumentAcquisitionService:
    def __init__(self, session_factory=None, downloader=None):
        self._session_factory = session_factory or session_scope
        self.global_semaphore = asyncio.Semaphore(settings.acquisition_concurrent_downloads)
        self.rate_limiter = HostRateLimiter(requests_per_second=2.0, max_concurrent_per_host=2)
        self.downloader = downloader or HttpDownloader(rate_limiter=self.rate_limiter)

    async def download_document(self, doc_id: PyUUID) -> DownloadResult:
        start_time = time.time()
        async with self.global_semaphore:
            attempt = 1
            last_error = ""
            status_code = None

            with self._session_factory() as session:
                doc = session.query(DocumentRegistry).filter(DocumentRegistry.id == doc_id).with_for_update().first()
                if not doc:
                    return {"status": "FAILED", "doc_id": doc_id, "error": "Document not found"}

                # DocumentRegistry stores company_id (FK), not a company_name
                # column — resolve the display name via Company directly
                # rather than adding a new relationship attribute to Sprint
                # 2's model.
                company = session.query(Company).filter(Company.id == doc.company_id).first()
                company_name = company.name if company else "unknown_company"

                while attempt <= settings.acquisition_max_retries:
                    started_at = datetime.now(timezone.utc)
                    staging_path = EnterpriseFileManager.get_staging_path(str(doc.id))
                    try:
                        status_code, content_type = await self.downloader.fetch(doc.official_url, staging_path)
                        
                        is_valid, err_reason = FileIntegrityValidator.validate_document_integrity(
                            staging_path, content_type_header=content_type, document_type=doc.document_type
                        )
                        if not is_valid:
                            raise FileIntegrityError(err_reason)

                        file_hash = FileIntegrityValidator.calculate_sha256(staging_path)
                        file_size = staging_path.stat().st_size

                        latest_version = (
                            session.query(DocumentVersion)
                            .filter(
                                DocumentVersion.document_id == doc.id,
                                DocumentVersion.status == DocumentVersionStatusEnum.ACTIVE,
                            )
                            .order_by(desc(DocumentVersion.version_number))
                            .with_for_update()
                            .first()
                        )

                        raw_target_key = EnterpriseFileManager.get_raw_target_key(
                            company_name, doc.document_year, doc.document_name or str(doc.id)
                        )

                        if latest_version:
                            if latest_version.file_hash == file_hash:
                                staging_path.unlink(missing_ok=True)
                                session.add(DownloadHistory(
                                    document_id=doc.id, attempt_number=attempt,
                                    download_status=DownloadStatusEnum.DUPLICATE_SKIPPED,
                                    response_code=status_code, started_at=started_at
                                ))
                                session.commit()
                                await telemetry.record_duplicate()
                                return {
                                    "status": "DUPLICATE_SKIPPED",
                                    "doc_id": doc.id,
                                    "version": latest_version.version_number,
                                    "file_size": file_size,
                                    "hash": file_hash
                                }

                            archived_dest = EnterpriseFileManager.archive_existing_file(
                                latest_version.storage_path, company_name, doc.document_year, latest_version.version_number
                            )
                            latest_version.storage_path = archived_dest
                            latest_version.status = DocumentVersionStatusEnum.ARCHIVED
                            next_version = latest_version.version_number + 1
                        else:
                            next_version = 1

                        promoted_path = EnterpriseFileManager.promote_staging_to_raw(staging_path, raw_target_key)
                        
                        new_version = DocumentVersion(
                            document_id=doc.id,
                            version_number=next_version,
                            file_hash=file_hash,
                            storage_path=promoted_path,
                            file_size=file_size,
                            status=DocumentVersionStatusEnum.ACTIVE
                        )
                        session.add(new_version)
                        session.add(DownloadHistory(
                            document_id=doc.id, attempt_number=attempt,
                            download_status=DownloadStatusEnum.SUCCESS,
                            response_code=status_code, started_at=started_at
                        ))
                        session.commit()

                        duration = time.time() - start_time
                        await telemetry.record_success(file_size, duration)

                        return {
                            "status": "SUCCESS",
                            "doc_id": doc.id,
                            "version": next_version,
                            "path": promoted_path,
                            "download_time": round(duration, 3),
                            "file_size": file_size,
                            "hash": file_hash
                        }

                    except Exception as exc:
                        last_error = str(exc)
                        status_enum = (
                            DownloadStatusEnum.CORRUPTED
                            if isinstance(exc, (FileIntegrityError, FileTooLargeError))
                            else DownloadStatusEnum.FAILED
                        )
                        session.add(DownloadHistory(
                            document_id=doc.id, attempt_number=attempt,
                            download_status=status_enum, response_code=status_code,
                            error_message=last_error, started_at=started_at
                        ))
                        session.commit()
                        if staging_path.exists():
                            staging_path.unlink(missing_ok=True)
                        attempt += 1
                        if attempt <= settings.acquisition_max_retries:
                            await asyncio.sleep(settings.acquisition_retry_backoff_factor ** attempt)

                await telemetry.record_failure()
                return {"status": "FAILED", "doc_id": doc.id, "error": last_error}

    async def process_all_pending_documents(self, company_filter: Optional[str] = None) -> List[DownloadResult]:
        with self._session_factory() as session:
            query = session.query(DocumentRegistry.id)
            if company_filter:
                # DocumentRegistry has no company_name column — filtering by
                # company name requires joining to Company via company_id.
                query = query.join(Company, Company.id == DocumentRegistry.company_id).filter(
                    Company.name.ilike(f"%{company_filter}%")
                )
            pending_ids = [r[0] for r in query.all()]
            
        tasks = [self.download_document(doc_id) for doc_id in pending_ids]
        return await asyncio.gather(*tasks)
