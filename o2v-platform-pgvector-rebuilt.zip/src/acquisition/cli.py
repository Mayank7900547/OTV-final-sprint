"""Typer CLI integration for Sprint 3 Acquisition."""
import typer
import asyncio
from typing import Optional
from uuid import UUID as PyUUID
from src.database.connection import session_scope
from src.acquisition.service import DocumentAcquisitionService
from src.acquisition.telemetry import telemetry
from src.acquisition.models import DocumentVersion

acquisition_app = typer.Typer(name="acquisition", help="Sprint 3 Acquisition & Versioning CLI")

@acquisition_app.command("run")
def run_acquisition(company: Optional[str] = typer.Option(None, "--company", "-c", help="Filter by company")):
    typer.echo("Starting enterprise acquisition workflow...")
    service = DocumentAcquisitionService(session_factory=session_scope)
    asyncio.run(service.process_all_pending_documents(company_filter=company))
    
    summary = telemetry.get_summary()
    typer.echo("\n=== ACQUISITION TELEMETRY ===")
    typer.echo(f"Succeeded : {summary['downloads_succeeded']}")
    typer.echo(f"Skipped   : {summary['duplicates_skipped']}")
    typer.echo(f"Failures  : {summary['failures']}")
    typer.echo(f"Bandwidth : {summary['total_bytes_mb']} MB")
    typer.echo("=============================")

@acquisition_app.command("history")
def show_history(doc_id: str = typer.Argument(..., help="Document UUID")):
    with session_scope() as session:
        versions = session.query(DocumentVersion).filter(DocumentVersion.document_id == PyUUID(doc_id)).all()
        typer.echo(f"\nVersions for {doc_id}:")
        for v in versions:
            typer.echo(f"v{v.version_number} | {v.status.value} | {v.file_size} bytes | {v.storage_path}")
