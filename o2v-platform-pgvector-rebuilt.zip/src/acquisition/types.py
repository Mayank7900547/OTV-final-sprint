"""Shared Type Definitions, Protocols, and TypedDicts for Sprint 3 Acquisition."""
from typing import TypedDict
from uuid import UUID

class DownloadResult(TypedDict, total=False):
    """Standardized result dictionary returned after a document acquisition attempt."""
    status: str          # SUCCESS, DUPLICATE_SKIPPED, FAILED
    doc_id: UUID         # UUID of the document registry entry
    version: int         # Assigned version number (if successful or skipped)
    path: str            # Final absolute or relative storage path of the PDF
    error: str           # Detailed error message (if status is FAILED)
    download_time: float # Duration of download execution in seconds
    file_size: int       # File size in bytes
    hash: str            # SHA-256 cryptographic file hash

class AcquisitionSummary(TypedDict):
    """Aggregated telemetry summary for acquisition run reporting."""
    total_bytes_mb: float
    downloads_succeeded: int
    duplicates_skipped: int
    failures: int
    total_duration_sec: float