"""Isolated Metrics and Observability Collector with Concurrency Protection."""
import asyncio
from typing import Dict, Any

class AcquisitionTelemetry:
    def __init__(self):
        self.bytes_downloaded: int = 0
        self.success_count: int = 0
        self.duplicate_count: int = 0
        self.failure_count: int = 0
        self.total_duration_seconds: float = 0.0
        self._lock = asyncio.Lock()

    async def record_success(self, size_bytes: int, duration: float):
        async with self._lock:
            self.bytes_downloaded += size_bytes
            self.success_count += 1
            self.total_duration_seconds += duration

    async def record_duplicate(self):
        async with self._lock:
            self.duplicate_count += 1

    async def record_failure(self):
        async with self._lock:
            self.failure_count += 1

    def get_summary(self) -> Dict[str, Any]:
        return {
            "total_bytes_mb": round(self.bytes_downloaded / (1024 * 1024), 2),
            "downloads_succeeded": self.success_count,
            "duplicates_skipped": self.duplicate_count,
            "failures": self.failure_count,
            "total_duration_sec": round(self.total_duration_seconds, 2),
        }

telemetry = AcquisitionTelemetry()