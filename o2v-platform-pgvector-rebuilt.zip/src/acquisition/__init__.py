"""Sprint 3 Document Acquisition and Version Management Package."""
from src.acquisition.service import DocumentAcquisitionService
from src.acquisition.cli import acquisition_app

__all__ = ["DocumentAcquisitionService", "acquisition_app"]