"""
Acquisition-time SSRF guard.

Design decision: this is a NEW, minimal module — not a reuse of
`src.discovery.url_validator.validate_url`. That function (Sprint 2)
answers a different question: "is this domain one we trust as a content
source for THIS company's discovery run" (own-site-or-subdomain, or an
explicitly trusted external domain like sec.gov). It already ran once, at
discovery time, before a URL was ever written into `DocumentRegistry`.

This module answers a narrower, download-time question that has nothing
to do with company/domain trust: "does this URL, right now (including
after following redirects), resolve to something the acquisition worker
should never be allowed to fetch?" — loopback, RFC1918 private ranges,
link-local, other reserved ranges, or a cloud metadata address. That's a
classic SSRF protection concern (e.g. a compromised or malicious redirect
target pointing the downloader at an internal service), distinct from
"is this domain content we trust." Overloading Sprint 2's validator with
this second, unrelated meaning would blur two different security
guarantees, so it gets its own small, self-contained module here instead.
"""
import ipaddress
import socket
from urllib.parse import urlparse

# Hostnames blocked outright, regardless of DNS resolution.
_BLOCKED_HOSTNAMES = {"localhost", "metadata.google.internal"}

# Well-known cloud metadata endpoints (AWS/Azure/GCP all use this address).
_METADATA_IPS = {"169.254.169.254"}


def is_url_safe(url: str) -> bool:
    """
    Return True if the URL's scheme and resolved host are safe to fetch.

    Fails closed: unparseable URLs, non-http(s) schemes, unresolvable
    hosts, and any resolved IP in a private/loopback/link-local/reserved/
    multicast range are all treated as unsafe.
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return False

    if parsed.scheme not in ("http", "https"):
        return False
    if not parsed.hostname:
        return False

    hostname = parsed.hostname.lower()
    if hostname in _BLOCKED_HOSTNAMES:
        return False

    try:
        resolved_ips = {info[4][0] for info in socket.getaddrinfo(hostname, None)}
    except socket.gaierror:
        return False

    for ip_str in resolved_ips:
        if ip_str in _METADATA_IPS:
            return False
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_reserved
            or ip.is_multicast
            or ip.is_unspecified
        ):
            return False

    return True
