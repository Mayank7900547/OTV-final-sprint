"""Per-Host Token-Bucket Rate Limiter."""
import urllib.parse
import asyncio
from collections import defaultdict
from contextlib import asynccontextmanager

class HostRateLimiter:
    def __init__(self, requests_per_second: float = 2.0, max_concurrent_per_host: int = 2):
        self.delay = 1.0 / requests_per_second
        self.max_concurrent_per_host = max_concurrent_per_host
        self._host_semaphores = defaultdict(lambda: asyncio.Semaphore(self.max_concurrent_per_host))
        # Monotonic per-loop clock, not wall-clock time -- see _wait_for_pacing.
        self._last_request_time = defaultdict(lambda: -float("inf"))
        self._lock = asyncio.Lock()

    async def _wait_for_pacing(self, domain: str):
        async with self._lock:
            # asyncio's own clock: monotonic (never jumps backward on NTP
            # sync, unlike time.time()) and it's the same clock asyncio.sleep
            # schedules against internally, so there's no cross-clock
            # mismatch between "elapsed" and "how long we actually slept".
            loop = asyncio.get_event_loop()
            elapsed = loop.time() - self._last_request_time[domain]
            if elapsed < self.delay:
                await asyncio.sleep(self.delay - elapsed)
            self._last_request_time[domain] = loop.time()

    async def acquire(self, url: str):
        """
        Pace requests to a host and cap concurrent *entries into the
        pacing gate itself*.

        NOTE: this method's `async with self._host_semaphores[domain]`
        block only wraps the pacing delay above -- it releases the
        semaphore as soon as `acquire()` returns, BEFORE a caller goes on
        to do the actual (potentially slow) work the pacing was meant to
        gate. That means `max_concurrent_per_host` does NOT bound how many
        downloads to a host are in flight at once if callers use this
        method the way `HttpDownloader` used to. Kept for backward
        compatibility and for callers that only want pacing, not a held
        concurrency slot -- see `throttle()` below for the version that
        actually holds the slot for the duration of the caller's work.
        """
        domain = urllib.parse.urlparse(url).netloc.lower()
        async with self._host_semaphores[domain]:
            await self._wait_for_pacing(domain)

    @asynccontextmanager
    async def throttle(self, url: str):
        """
        Pace requests to a host AND hold a concurrency slot for the
        host for as long as the caller's `async with` block is open --
        e.g. wrapping an entire request/response/body-download cycle, not
        just the pacing delay before it starts. This is what actually
        enforces `max_concurrent_per_host` as a cap on simultaneous
        in-flight downloads to a host, which `acquire()` alone does not
        (see its docstring).

        Usage:
            async with rate_limiter.throttle(url):
                ...send the request and stream the response body...
        """
        domain = urllib.parse.urlparse(url).netloc.lower()
        async with self._host_semaphores[domain]:
            await self._wait_for_pacing(domain)
            yield