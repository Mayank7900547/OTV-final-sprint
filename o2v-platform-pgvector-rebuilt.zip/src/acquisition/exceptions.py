"""Sprint 3 Domain Exceptions extending O2V Core Error Hierarchy."""
from src.core.exceptions import O2VError

class AcquisitionError(O2VError):
    """Base exception for document acquisition failures."""

class FileIntegrityError(AcquisitionError):
    """Raised when downloaded file fails PDF magic bytes or EOF validation."""

class FileTooLargeError(AcquisitionError):
    """Raised when file exceeds acquisition_max_file_size_bytes before or during streaming."""

class SSRFValidationError(AcquisitionError):
    """Raised when a download URL or redirect target fails SSRF safety checks."""

class StorageError(AcquisitionError):
    """Raised when filesystem or object storage operations fail."""

class RateLimitError(AcquisitionError):
    """Raised when host rate limiting bounds are violated."""
