"""Enterprise File Manager for Path Resolution and Staging Promotion."""
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from src.config.logging_config import get_logger
from src.utils.paths import DATA_DIR, STAGING_DIR
from src.acquisition.storage import LocalDiskStorageBackend
from src.acquisition.exceptions import StorageError

logger = get_logger(__name__)
# Base dir is DATA_DIR (not RAW_DATA_DIR) because storage keys already carry
# their own top-level prefix (e.g. "raw/...", "archive/...") — see
# get_raw_target_key/archive_existing_file below. This matches the same
# path-resolution convention established in src/utils/paths.py.
storage_backend = LocalDiskStorageBackend(DATA_DIR)

class EnterpriseFileManager:
    @staticmethod
    def get_raw_target_key(company: str, year: Optional[int], filename: str) -> str:
        clean_company = "".join(c for c in company if c.isalnum() or c in (" ", "_", "-")).strip().replace(" ", "_")
        clean_filename = "".join(c for c in filename if c.isalnum() or c in (" ", ".", "_", "-")).strip().replace(" ", "_")
        if not clean_filename.lower().endswith(".pdf"):
            clean_filename += ".pdf"
        year_str = str(year) if year is not None else "undated"
        return f"raw/{clean_company}/{year_str}/{clean_filename}"

    @staticmethod
    def get_staging_path(document_id: str) -> Path:
        target = STAGING_DIR / f"doc_{document_id}_{datetime.now(timezone.utc).timestamp()}.part"
        target.parent.mkdir(parents=True, exist_ok=True)
        return target

    @classmethod
    def archive_existing_file(cls, existing_path_str: str, company: str, year: Optional[int], version_num: int) -> str:
        existing_path = Path(existing_path_str)
        if not existing_path.exists():
            raise StorageError(f"Cannot archive non-existent file: {existing_path_str}")
        timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        year_str = str(year) if year is not None else "undated"
        archived_name = f"{existing_path.stem}_v{version_num}_{timestamp_str}{existing_path.suffix}"
        return storage_backend.move(str(existing_path), f"archive/{company}/{year_str}/{archived_name}")

    @classmethod
    def promote_staging_to_raw(cls, staging_path: Path, raw_target_key: str) -> str:
        return storage_backend.move(str(staging_path), raw_target_key)
