"""Typer CLI integration for Sprint 8 Semantic Extraction — mirrors `src/retrieval/cli.py`'s shape."""

from __future__ import annotations

import uuid

import typer
from rich.console import Console
from rich.table import Table

from src.database.connection import session_scope
from src.extraction.extraction_service import ExtractionService, available_components
from src.extraction.llm_factory import available_llm_providers
from src.extraction.models import ExtractionResult
from src.extraction.telemetry import telemetry
from src.models.company import Company

extraction_app = typer.Typer(name="extraction", help="Sprint 8 Semantic Extraction CLI")
show_app = typer.Typer(help="Inspect extraction results and statistics.")
extraction_app.add_typer(show_app, name="show")

console = Console()

_STATUS_COLOR = {"SUCCESS": "green", "PROVIDER_ERROR": "red", "PARSE_ERROR": "red", "NO_EVIDENCE": "yellow"}
_CONFIDENCE_COLOR = {"High": "green", "Medium": "yellow", "Low": "yellow", "Not Found": "dim"}


def _resolve_company(session, company: str) -> Company | None:
    """Accepts either a company UUID or a name substring — same convenience `retrieval/cli.py` gives."""
    try:
        company_id = uuid.UUID(company)
        return session.query(Company).filter(Company.id == company_id).first()
    except ValueError:
        return session.query(Company).filter(Company.name.ilike(f"%{company}%")).first()


def _print_outcome(outcome: dict) -> None:
    status = outcome.get("status")
    color = _STATUS_COLOR.get(status, "white")
    resumed_tag = " [dim](resumed from previous run — not re-attempted)[/dim]" if outcome.get("resumed_from_previous_run") else ""
    console.print(f"[{color}]{status}[/{color}] component={outcome.get('component')} field={outcome.get('field_name')}{resumed_tag}")
    if status == "SUCCESS":
        conf = outcome.get("confidence")
        conf_color = _CONFIDENCE_COLOR.get(conf, "white")
        console.print(f"  confidence=[{conf_color}]{conf}[/{conf_color}] provider={outcome.get('llm_provider')} retries={outcome.get('retries')} time={outcome.get('extraction_duration')}s")
        if outcome.get("exact_text"):
            console.print(f"  exact_text: {outcome['exact_text'][:200]}")
        if outcome.get("remarks"):
            console.print(f"  remarks: {outcome['remarks']}")
    elif outcome.get("error"):
        console.print(f"  — {outcome['error']}")


def _print_summary() -> None:
    summary = telemetry.get_summary()
    console.print("\n=== EXTRACTION TELEMETRY ===")
    console.print(f"Requests            : {summary['extraction_requests']}")
    console.print(f"Successful          : {summary['successful_extractions']}")
    console.print(f"  of which Not Found: {summary['not_found_extractions']}")
    console.print(f"Failed              : {summary['failed_extractions']}")
    console.print(f"No evidence         : {summary['no_evidence_count']}")
    console.print(f"Avg latency (s)     : {summary['average_latency']}")
    console.print(f"Avg retries         : {summary['average_retries']}")
    console.print(f"Active provider     : {summary['active_provider'] or '-'}")
    console.print("=============================")


# --------------------------------------------------------------------------
# extract
# --------------------------------------------------------------------------


@extraction_app.command("field")
def extract_field(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(..., "--component", help="O2V component, e.g. Purpose, Behaviour, Value Agenda."),
    field: str = typer.Option(..., "--field", help="Exact O2V field name, as shown in `o2v framework show O2V`."),
    provider: str = typer.Option(None, "--provider", help=f"LLM provider override (default: settings.llm_provider). Available: {', '.join(available_llm_providers())}"),
    framework: str = typer.Option(None, "--framework", help="Framework name (default: settings.retrieval_framework_name)."),
) -> None:
    """Extract one O2V field for one company from Sprint 7's most recent retrieved evidence."""
    with session_scope() as session:
        company_row = _resolve_company(session, company)
        if company_row is None:
            console.print(f"[yellow]No company found matching '{company}'.[/yellow]")
            return

        service = ExtractionService(llm_provider_name=provider)
        outcome = service.extract_field(
            session, company_id=company_row.id, component=component, field_name=field, framework_name=framework
        )

    _print_outcome(outcome)


@extraction_app.command("component")
def extract_component(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(..., "--component", help="O2V component, e.g. Purpose, Behaviour, Value Agenda."),
    provider: str = typer.Option(None, "--provider", help="LLM provider override (default: settings.llm_provider)."),
    framework: str = typer.Option(None, "--framework", help="Framework name (default: settings.retrieval_framework_name)."),
    force: bool = typer.Option(False, "--force", help="Re-run every field even if it already succeeded against the current evidence batch (disables resume)."),
) -> None:
    """Extract every Framework-registered field under one O2V component for a company."""
    with session_scope() as session:
        company_row = _resolve_company(session, company)
        if company_row is None:
            console.print(f"[yellow]No company found matching '{company}'.[/yellow]")
            return

        service = ExtractionService(llm_provider_name=provider)
        outcomes = service.extract_component(
            session, company_id=company_row.id, component=component, framework_name=framework, force=force
        )

    for outcome in outcomes:
        _print_outcome(outcome)
    _print_summary()


@extraction_app.command("pilot")
def extract_pilot(
    companies: str = typer.Option(None, "--companies", help="Comma-separated company names. Default: all companies currently in the registry (intended for a small ~5-company pilot batch)."),
    components: str = typer.Option("Purpose,Behaviour,Value Agenda", "--components", help="Comma-separated O2V components."),
    provider: str = typer.Option(None, "--provider", help="LLM provider override (default: settings.llm_provider)."),
    force: bool = typer.Option(False, "--force", help="Re-run every field even if it already succeeded against the current evidence batch (disables resume)."),
) -> None:
    """
    Run extraction across a small pilot batch of companies x components — the
    Sprint 8 brief's 'pilot batch of ~5 companies' entry point. Does not
    process the full company registry unless --companies is omitted AND
    the registry itself only contains a small pilot set (see data/companies/sample_companies.csv).
    """
    with session_scope() as session:
        if companies:
            names = [c.strip() for c in companies.split(",") if c.strip()]
            company_rows = [_resolve_company(session, name) for name in names]
            company_rows = [c for c in company_rows if c is not None]
        else:
            company_rows = session.query(Company).limit(5).all()

        if not company_rows:
            console.print("[yellow]No matching companies found. Import companies first: o2v company import data/companies/sample_companies.csv[/yellow]")
            return

        component_list = [c.strip() for c in components.split(",") if c.strip()]
        service = ExtractionService(llm_provider_name=provider)

        for company_row in company_rows:
            console.print(f"\n[bold]{company_row.name}[/bold]")
            for component in component_list:
                outcomes = service.extract_component(session, company_id=company_row.id, component=component, force=force)
                for outcome in outcomes:
                    _print_outcome(outcome)

    _print_summary()


# --------------------------------------------------------------------------
# show
# --------------------------------------------------------------------------


@show_app.command("components")
def show_components(framework: str = typer.Option("O2V", "--framework", help="Framework name.")) -> None:
    """List O2V components available for extraction under a framework (from imported Framework rows)."""
    with session_scope() as session:
        components = available_components(session, framework_name=framework)

    if not components:
        console.print(f"[yellow]No components found for framework '{framework}'. Has it been imported?[/yellow]")
        return
    for name in components:
        console.print(f"- {name}")


@show_app.command("providers")
def show_providers() -> None:
    """List registered LLM providers (some may be architecture placeholders — see llm_factory.py)."""
    for name in available_llm_providers():
        console.print(f"- {name}")


@show_app.command("results")
def show_results(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(None, "--component", help="Optional: filter to one O2V component."),
) -> None:
    """Show the current staged extraction results for a company (optionally scoped to one component)."""
    with session_scope() as session:
        company_row = _resolve_company(session, company)
        if company_row is None:
            console.print(f"[yellow]No company found matching '{company}'.[/yellow]")
            return

        query = session.query(ExtractionResult).filter(ExtractionResult.company_id == company_row.id)
        if component:
            query = query.filter(ExtractionResult.component == component)
        rows = query.order_by(ExtractionResult.component.asc(), ExtractionResult.field_name.asc()).all()

    if not rows:
        console.print(f"[yellow]No extraction results found for '{company}'. Run 'extraction component' or 'extraction field' first.[/yellow]")
        return

    table = Table(title=f"Extraction Results: {company_row.name}")
    table.add_column("Component")
    table.add_column("Field")
    table.add_column("Status")
    table.add_column("Confidence")
    table.add_column("Exact Text")
    table.add_column("Source")
    for r in rows:
        table.add_row(
            r.component, r.field_name, r.status, r.confidence or "-",
            (r.exact_text or "-")[:60], r.source_document_name or "-",
        )
    console.print(table)


@show_app.command("statistics")
def show_statistics() -> None:
    """Show cumulative telemetry for this process's extraction activity."""
    _print_summary()
