"""
Sprint 8 domain exceptions extending the O2V core error hierarchy.

Design decision: same flat-hierarchy-under-one-base shape as
`src/embeddings/exceptions.py` / `src/retrieval/exceptions.py` — every
failure mode Sprint 8 can hit is a direct child of `ExtractionError`, none
specializes another, so callers can catch broadly (`except ExtractionError`)
or narrowly (`except LLMProviderUnavailableError`) as needed.
"""

from src.core.exceptions import O2VError


class ExtractionError(O2VError):
    """Base exception for all Sprint 8 semantic extraction failures."""


class LLMProviderUnavailableError(ExtractionError):
    """
    Raised when the configured LLM completion provider cannot serve a
    request — covers both genuinely unreachable providers (network/auth
    failure) and architecture-placeholder providers registered in
    `llm_factory.py` that exist to prove out the plugin boundary but have
    no working implementation yet. Mirrors
    `src/embeddings/exceptions.py::ProviderUnavailableError`.
    """


class LLMConfigurationError(ExtractionError):
    """Raised when an LLM provider is constructed with an invalid/missing configuration (e.g. unknown provider name, missing API key)."""


class InvalidLLMResponseError(ExtractionError):
    """
    Raised when a provider's raw response is malformed in a way that
    prevents even attempting JSON extraction (e.g. empty response, wrapped
    error payload). Distinct from `ExtractionSchemaError`, which is raised
    further downstream once *some* JSON was parsed but it doesn't satisfy
    the extraction contract — see `validation.py`.
    """


class ExtractionSchemaError(ExtractionError):
    """
    Raised when the LLM's JSON output — after parsing — fails to satisfy
    the Sprint 8 output contract (see `validation.py::validate_extraction_payload`):
    missing required keys, wrong types, an invalid confidence value, or a
    confidence/exact_text combination the contract disallows (e.g.
    confidence=High with no exact_text).
    """


class FrameworkFieldNotFoundError(ExtractionError):
    """Raised when `extract_field`/`extract_component` is asked to extract a (component, field_name) pair that doesn't exist in the Framework Registry for the given framework_name."""


class NoEvidenceSuppliedError(ExtractionError):
    """
    Raised only by callers that specifically want to treat "Sprint 7
    supplied zero evidence rows for this company/component" as an error
    rather than data. `ExtractionService` itself never raises this — per
    the same "no-result is an outcome, not an exception" precedent
    `RetrievalService`/`NoRelevantEvidenceError` established in Sprint 7,
    it returns `ExtractionStatus.NO_EVIDENCE` instead. Kept available for
    symmetry with `retrieval/exceptions.py::NoRelevantEvidenceError`.
    """
