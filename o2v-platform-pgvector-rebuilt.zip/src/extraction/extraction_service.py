"""
Sprint 8 semantic extraction service.

Design decision: `ExtractionService` consumes Sprint 7's REAL persisted
`RetrievedEvidence` rows (via `_load_evidence`) — it never builds a
parallel chunk/candidate structure. Per the Sprint 8 brief's "Sprint 8
must consume the REAL Sprint 7 output... Do not create fake parallel
chunk objects if real Sprint 7 objects are available" — this is that
integration point, the ONLY place Sprint 8 reads from Sprint 7's tables.

Design decision: `extract_field` operates on the MOST RECENT retrieval
`request_id` for a given (company, component) — a company/component can
have multiple historical retrieval runs (Sprint 7 doesn't delete old
ones), and extraction should always work from the freshest evidence pool,
mirroring how a human researcher would use the latest search results, not
a stale one. Scoping by request_id (not just company+component) also
means every extraction's `request_id` column gives a complete lineage
back to one specific Sprint 7 run.

Design decision: field-context comes from `Framework` rows exclusively
(`_field_context`), never a hardcoded field list — per the brief's
"Framework/Schema Registry is the authoritative source... Do not create a
second competing schema." `extract_component` iterates whatever fields
are registered under a component, so a new Framework row is immediately
extractable with no service-layer change.

Design decision: retries (`settings.llm_retry_limit`) are shared across
BOTH provider failures and JSON/schema validation failures — a
validation failure retry sends the model a corrective follow-up prompt
explaining exactly what was wrong (see `_build_retry_prompt`), which is
what lets a transiently-malformed response recover instead of immediately
failing the whole extraction, per the brief's "implement robust JSON
parsing and validation at the extraction boundary."
"""

from __future__ import annotations

import time
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from src.config.logging_config import get_logger
from src.config.settings import settings
from src.core.constants import EvidenceConfidence, ExtractionStatus
from src.extraction.exceptions import ExtractionSchemaError, FrameworkFieldNotFoundError, InvalidLLMResponseError, LLMProviderUnavailableError
from src.extraction.llm_factory import get_llm_provider
from src.extraction.models import ExtractionResult
from src.extraction.prompt_builder import build_prompts
from src.extraction.telemetry import telemetry
from src.extraction.types import EvidenceItem, ExtractionOutcome, FieldContext
from src.extraction.validation import parse_and_validate
from src.pipeline.ollama_manager import ensure_ollama_running
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.models.framework import Framework
from src.retrieval.models import RetrievedEvidence

logger = get_logger(__name__)


def available_components(session: Session, *, framework_name: str = "O2V") -> list[str]:
    """Distinct O2V components registered under a framework — reused by the CLI, same as `retrieval/query_generator.py::available_components`."""
    stmt = (
        select(Framework.component_name)
        .where(Framework.framework_name == framework_name)
        .distinct()
        .order_by(Framework.component_name)
    )
    return [row[0] for row in session.execute(stmt).all()]


class ExtractionService:
    """Orchestrates one or more field extractions for a company against Sprint 7's retrieved evidence."""

    def __init__(self, *, llm_provider_name: str | None = None, llm_provider=None):
        # `llm_provider` (a constructed instance) takes precedence over
        # `llm_provider_name` (resolved via the factory) -- same
        # "instance override beats name" pattern RetrievalService's
        # `provider` constructor argument establishes for
        # BaseEmbeddingProvider. This is what lets tests inject a fake
        # provider without registering it in the global factory registry.
        self._llm_provider_name = llm_provider_name
        self._llm_provider_instance = llm_provider

    def _resolve_provider_name(self) -> str:
        if self._llm_provider_instance is not None:
            return getattr(self._llm_provider_instance, "provider_name", "custom")
        return self._llm_provider_name or settings.llm_provider

    def _resolve_provider(self):
        """Same instance-beats-name resolution as `_call_llm_with_retries` — extracted so `extract_component`'s pre-flight health check uses the exact same provider a real field extraction would."""
        return self._llm_provider_instance or get_llm_provider(self._llm_provider_name)

    # ------------------------------------------------------------------
    # Field context (Framework Registry)
    # ------------------------------------------------------------------

    def _field_context(
        self, session: Session, *, framework_name: str, component: str, field_name: str
    ) -> FieldContext:
        row = (
            session.query(Framework)
            .filter(
                Framework.framework_name == framework_name,
                Framework.component_name == component,
                Framework.field_name == field_name,
            )
            .first()
        )
        if row is None:
            raise FrameworkFieldNotFoundError(
                f"No Framework field {field_name!r} under component={component!r}, "
                f"framework={framework_name!r}. Has the framework been imported? (see 'o2v framework import')"
            )
        return FieldContext(
            framework_name=framework_name,
            component_name=component,
            field_name=field_name,
            field_definition=row.description,
            expected_document_sources=list(row.document_sources or []),
        )

    def _fields_for_component(self, session: Session, *, framework_name: str, component: str) -> list[FieldContext]:
        rows = (
            session.query(Framework)
            .filter(Framework.framework_name == framework_name, Framework.component_name == component)
            .order_by(Framework.field_name.asc())
            .all()
        )
        return [
            FieldContext(
                framework_name=framework_name,
                component_name=component,
                field_name=row.field_name,
                field_definition=row.description,
                expected_document_sources=list(row.document_sources or []),
            )
            for row in rows
        ]

    # ------------------------------------------------------------------
    # Evidence loading (real Sprint 7 output — see module docstring)
    # ------------------------------------------------------------------

    def _latest_request_id(self, session: Session, *, company_id, component: str) -> str | None:
        """
        Ordered by (retrieval_timestamp DESC, id DESC) — the id tie-
        breaker matters because `retrieval_timestamp` uses Postgres'
        `func.now()` (transaction start time), which is IDENTICAL for
        multiple `RetrievedEvidence` rows inserted in the same
        transaction/request (e.g. two retrieval runs done back-to-back
        without an intervening commit). The autoincrement `id` is the
        only column guaranteed to be monotonically ordered in that case.
        """
        row = (
            session.query(RetrievedEvidence.request_id)
            .filter(RetrievedEvidence.company_id == company_id, RetrievedEvidence.component == component)
            .order_by(RetrievedEvidence.retrieval_timestamp.desc(), RetrievedEvidence.id.desc())
            .first()
        )
        return row[0] if row else None

    def _load_evidence(
        self, session: Session, *, company_id, component: str, request_id: str | None = None
    ) -> list[RetrievedEvidence]:
        """
        Loads `RetrievedEvidence` rows for a company/component, scoped to
        one retrieval request (see module docstring for why: freshest run
        by default, or an explicit `request_id` for reproducing/
        inspecting a past extraction). Ordered by `rank` so
        `settings.extraction_evidence_max_items` truncation keeps the
        strongest evidence, not an arbitrary subset.
        """
        target_request_id = request_id or self._latest_request_id(session, company_id=company_id, component=component)
        if target_request_id is None:
            return []

        rows = (
            session.query(RetrievedEvidence)
            .filter(
                RetrievedEvidence.company_id == company_id,
                RetrievedEvidence.component == component,
                RetrievedEvidence.request_id == target_request_id,
            )
            .order_by(RetrievedEvidence.rank.asc())
            .limit(settings.extraction_evidence_max_items)
            .all()
        )
        return rows

    def _evidence_items_from_rows(self, session: Session, rows: list[RetrievedEvidence]) -> list[EvidenceItem]:
        """
        Projects `RetrievedEvidence` rows into the thin `EvidenceItem`
        shape the prompt builder needs, joining `DocumentRegistry` for
        `document_type` (content CATEGORY, e.g. "annual_report" — NOT
        persisted on `RetrievedEvidence` itself; see
        `retrieval_service.py`'s candidate-building step, which only
        snapshots `chunk_index`/`document_year`/`source_domain` into
        `source_metadata`) needed for the source-priority instructions in
        the prompt.
        """
        if not rows:
            return []
        document_ids = {row.document_id for row in rows}
        documents = {
            doc.id: doc
            for doc in session.query(DocumentRegistry).filter(DocumentRegistry.id.in_(document_ids)).all()
        }
        items = []
        for row in rows:
            doc = documents.get(row.document_id)
            metadata = row.source_metadata or {}
            items.append(
                EvidenceItem(
                    retrieval_id=row.retrieval_id,
                    chunk_text=row.chunk_text,
                    document_id=str(row.document_id),
                    document_type=doc.document_category if doc else None,
                    document_year=metadata.get("document_year"),
                    source_domain=metadata.get("source_domain"),
                    page_number=row.page_number,
                    section_title=row.section_title,
                    final_score=row.final_score,
                )
            )
        return items

    # ------------------------------------------------------------------
    # LLM call with retry (provider errors + malformed/invalid JSON)
    # ------------------------------------------------------------------

    def _existing_success_outcome(
        self, session: Session, *, company_id, framework_name: str, component: str, field_name: str, request_id: str
    ) -> ExtractionOutcome | None:
        """
        A persisted `ExtractionResult` counts as "already done, skip it"
        ONLY if it succeeded against the CURRENT retrieval batch
        (`request_id` matches) — never a stale one. This matters because
        of `retrieval refresh-all` (Sprint 7): if new evidence has since
        become available (e.g. after `embeddings retry-failed` embeds
        chunks that failed earlier), a field extracted against the OLD,
        now-superseded evidence batch must be re-attempted against the
        new one, not skipped just because SOME attempt once succeeded.
        A resumed/re-run pipeline should redo strictly less work than a
        fresh one, never redo LESS than correctness requires.
        """
        row = (
            session.query(ExtractionResult)
            .filter(
                ExtractionResult.company_id == company_id,
                ExtractionResult.framework_name == framework_name,
                ExtractionResult.component == component,
                ExtractionResult.field_name == field_name,
                ExtractionResult.status == ExtractionStatus.SUCCESS.value,
                ExtractionResult.request_id == request_id,
            )
            .first()
        )
        if row is None:
            return None
        return {
            "status": row.status,
            "company_id": row.company_id,
            "component": row.component,
            "field_name": row.field_name,
            "confidence": row.confidence,
            "exact_text": row.exact_text,
            "remarks": row.remarks,
            "source_document_id": str(row.source_document_id) if row.source_document_id else None,
            "source_retrieval_id": row.source_retrieval_id,
            "page_number": row.page_number,
            "document_year": row.document_year,
            "source_url": row.source_url,
            "evidence_count": row.evidence_count,
            "llm_provider": row.llm_provider,
            "llm_model_name": row.llm_model_name,
            "retries": row.retries,
            "extraction_duration": 0.0,
            "error": None,
            "resumed_from_previous_run": True,
        }

    def _build_retry_prompt(self, original_user_prompt: str, *, raw_response: str, error_message: str) -> str:
        """
        Builds a corrective follow-up user prompt after a parse/schema
        failure — repeats the original request plus the exact JSON error,
        so the model can self-correct instead of the whole extraction
        immediately failing. See module docstring on shared retry budget.
        """
        return (
            f"{original_user_prompt}\n\n---\n\n"
            f"Your previous response could not be used because: {error_message}\n\n"
            f"Your previous response was:\n{raw_response[:1000]}\n\n"
            f"Respond again with ONLY a corrected JSON object matching the required shape exactly."
        )

    def _call_llm_with_retries(
        self, *, system_prompt: str, user_prompt: str, valid_retrieval_ids: set[str]
    ) -> tuple[dict | None, int, str, str | None, str | None]:
        """
        Returns (payload_or_None, retries_used, last_raw_response, status_if_failed, error_message).
        `status_if_failed` is None on success, otherwise one of
        `ExtractionStatus.PROVIDER_ERROR` / `PARSE_ERROR`.
        """
        provider = self._llm_provider_instance or get_llm_provider(self._llm_provider_name)
        attempts = settings.llm_retry_limit + 1
        current_user_prompt = user_prompt
        last_raw_response = ""
        last_error = ""

        for attempt in range(attempts):
            try:
                raw_response = provider.complete(system_prompt=system_prompt, user_prompt=current_user_prompt)
                last_raw_response = raw_response
            except LLMProviderUnavailableError as exc:
                last_error = str(exc)
                if attempt < attempts - 1:
                    time.sleep(settings.llm_retry_backoff_seconds * (attempt + 1))
                    continue
                return None, attempt, last_raw_response, ExtractionStatus.PROVIDER_ERROR.value, last_error

            try:
                payload = parse_and_validate(raw_response, valid_retrieval_ids=valid_retrieval_ids)
                return dict(payload), attempt, raw_response, None, None
            except (InvalidLLMResponseError, ExtractionSchemaError) as exc:
                last_error = str(exc)
                if attempt < attempts - 1:
                    current_user_prompt = self._build_retry_prompt(
                        user_prompt, raw_response=raw_response, error_message=last_error
                    )
                    continue
                return None, attempt, last_raw_response, ExtractionStatus.PARSE_ERROR.value, last_error

        # Unreachable given attempts >= 1, but keeps type-checkers honest.
        return None, attempts - 1, last_raw_response, ExtractionStatus.PARSE_ERROR.value, last_error

    # ------------------------------------------------------------------
    # Persistence (upsert into the extraction staging store)
    # ------------------------------------------------------------------

    def _persist(self, session: Session, *, company_id, framework_name: str, component: str, field: str, outcome: ExtractionOutcome) -> ExtractionResult:
        extraction_id = f"{company_id}:{component}:{field}"
        row = (
            session.query(ExtractionResult)
            .filter(
                ExtractionResult.company_id == company_id,
                ExtractionResult.framework_name == framework_name,
                ExtractionResult.component == component,
                ExtractionResult.field_name == field,
            )
            .first()
        )
        if row is None:
            row = ExtractionResult(
                extraction_id=extraction_id,
                company_id=company_id,
                framework_name=framework_name,
                component=component,
                field_name=field,
            )
            session.add(row)

        row.status = outcome["status"]
        row.exact_text = outcome.get("exact_text")
        row.confidence = outcome.get("confidence")
        row.remarks = outcome.get("remarks")
        row.source_retrieval_id = outcome.get("source_retrieval_id")
        row.source_document_id = uuid.UUID(outcome["source_document_id"]) if outcome.get("source_document_id") else None
        row.source_document_name = outcome.get("source_document_name")
        row.source_type = outcome.get("source_type")
        row.source_url = outcome.get("source_url")
        row.document_year = outcome.get("document_year")
        row.page_number = outcome.get("page_number")
        row.section_title = outcome.get("section_title")
        row.request_id = outcome.get("request_id")
        row.evidence_count = outcome.get("evidence_count", 0)
        row.llm_provider = outcome.get("llm_provider")
        row.llm_model_name = outcome.get("llm_model_name")
        row.retries = outcome.get("retries", 0)
        row.raw_llm_response = outcome.get("raw_llm_response")
        row.error = outcome.get("error")

        session.flush()
        return row

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_field(
        self,
        session: Session,
        *,
        company_id,
        component: str,
        field_name: str,
        framework_name: str | None = None,
        request_id: str | None = None,
    ) -> ExtractionOutcome:
        """
        Extract one O2V field for one company from Sprint 7's retrieved
        evidence, persist the result to the extraction staging store, and
        return the outcome. Never raises for "no evidence"/"provider
        failed"/"malformed output" — those are `ExtractionStatus` values,
        same "outcome as data" convention `RetrievalService` established.
        """
        framework_name = framework_name or settings.retrieval_framework_name
        company_id = company_id if isinstance(company_id, uuid.UUID) else uuid.UUID(str(company_id))
        started = time.monotonic()
        telemetry.record_request()

        field = self._field_context(session, framework_name=framework_name, component=component, field_name=field_name)

        evidence_rows = self._load_evidence(session, company_id=company_id, component=component, request_id=request_id)
        if not evidence_rows:
            outcome: ExtractionOutcome = {
                "status": ExtractionStatus.NO_EVIDENCE.value,
                "company_id": company_id,
                "component": component,
                "field_name": field_name,
                "evidence_count": 0,
                "llm_provider": self._resolve_provider_name(),
                "llm_model_name": settings.llm_model_name,
                "retries": 0,
                "extraction_duration": round(time.monotonic() - started, 4),
                "error": "No Sprint 7 retrieved evidence found for this company/component. Run 'retrieval retrieve' first.",
            }
            self._persist(session, company_id=company_id, framework_name=framework_name, component=component, field=field_name, outcome=outcome)
            telemetry.record_outcome(status=outcome["status"], confidence=None, duration=outcome["extraction_duration"], retries=0, provider=outcome["llm_provider"])
            return outcome

        resolved_request_id = evidence_rows[0].request_id
        evidence_items = self._evidence_items_from_rows(session, evidence_rows)
        evidence_by_id = {item.retrieval_id: item for item in evidence_items}

        company = session.get(Company, company_id)
        company_name = company.name if company else str(company_id)

        system_prompt, user_prompt = build_prompts(company_name=company_name, field=field, evidence=evidence_items)

        provider_name = self._resolve_provider_name()
        payload, retries, raw_response, failure_status, error_message = self._call_llm_with_retries(
            system_prompt=system_prompt, user_prompt=user_prompt, valid_retrieval_ids=set(evidence_by_id)
        )
        duration = round(time.monotonic() - started, 4)

        if failure_status is not None:
            outcome = {
                "status": failure_status,
                "company_id": company_id,
                "component": component,
                "field_name": field_name,
                "evidence_count": len(evidence_items),
                "request_id": resolved_request_id,
                "llm_provider": provider_name,
                "llm_model_name": settings.llm_model_name,
                "retries": retries,
                "raw_llm_response": raw_response[:5000] if raw_response else None,
                "extraction_duration": duration,
                "error": error_message,
            }
            self._persist(session, company_id=company_id, framework_name=framework_name, component=component, field=field_name, outcome=outcome)
            telemetry.record_outcome(status=failure_status, confidence=None, duration=duration, retries=retries, provider=provider_name)
            logger.warning("Extraction failed for company=%s component=%s field=%s: %s", company_id, component, field_name, error_message)
            return outcome

        # Success — attach source metadata from the cited evidence item (if any).
        source_item = evidence_by_id.get(payload.get("source_retrieval_id")) if payload.get("source_retrieval_id") else None
        source_document_name = source_type = source_url = None
        if source_item is not None:
            doc = session.get(DocumentRegistry, uuid.UUID(source_item.document_id))
            if doc is not None:
                source_document_name = doc.document_name
                source_type = doc.document_category
                source_url = doc.official_url

        outcome = {
            "status": ExtractionStatus.SUCCESS.value,
            "company_id": company_id,
            "component": component,
            "field_name": field_name,
            "confidence": payload["confidence"],
            "exact_text": payload.get("exact_text"),
            "remarks": payload.get("remarks"),
            "source_retrieval_id": payload.get("source_retrieval_id"),
            "source_document_id": source_item.document_id if source_item else None,
            "source_document_name": source_document_name,
            "source_type": source_type,
            "source_url": source_url,
            "document_year": source_item.document_year if source_item else None,
            "page_number": source_item.page_number if source_item else None,
            "section_title": source_item.section_title if source_item else None,
            "request_id": resolved_request_id,
            "evidence_count": len(evidence_items),
            "llm_provider": provider_name,
            "llm_model_name": settings.llm_model_name,
            "retries": retries,
            "extraction_duration": duration,
        }
        self._persist(session, company_id=company_id, framework_name=framework_name, component=component, field=field_name, outcome=outcome)
        telemetry.record_outcome(status=outcome["status"], confidence=outcome["confidence"], duration=duration, retries=retries, provider=provider_name)
        return outcome

    def extract_component(
        self,
        session: Session,
        *,
        company_id,
        component: str,
        framework_name: str | None = None,
        request_id: str | None = None,
        force: bool = False,
    ) -> list[ExtractionOutcome]:
        """
        Extract every Framework-registered field under one O2V component
        for a company — the pilot's natural unit of work.

        Design decision (resume support): before calling the LLM for a
        field, checks whether that field already has a SUCCESS result
        from the SAME retrieval batch (see `_existing_success_outcome`'s
        docstring for why "same batch" matters, not just "any success
        ever"). If so, that field is skipped — no LLM call, no wait —
        and its previously-persisted outcome is returned as-is, tagged
        `resumed_from_previous_run: True`. This is what lets a killed or
        interrupted `pipeline run` (e.g. the PC got shut down mid-
        extraction) be re-run as-is and pick back up roughly where it
        left off, instead of re-paying the full LLM cost for fields
        that already finished — extraction is the most expensive stage
        by far (Microsoft: ~37 minutes for 29 fields), so this is where
        a resume actually saves meaningful time. Pass force=True to
        disable this and force every field to be re-attempted.

        Two pieces of resilience, same reasoning and shape as
        `EmbeddingService.embed_many`'s (see its docstring) — added after
        a real overnight run where every one of ~29 fields timed out
        against a resource-starved local Ollama model, taking hours to
        discover that:

        1. PRE-FLIGHT HEALTH CHECK — before attempting any field, a cheap
           `provider.health_check()` probe (seconds). If the provider is
           unreachable right now, every field is skipped immediately with
           a clear reason instead of discovering the same thing field by
           field, each costing a full `llm_retry_limit`-many
           `llm_timeout_seconds`-length wait.

        2. CIRCUIT BREAKER — if `settings.llm_circuit_breaker_threshold`
           fields in a row come back PROVIDER_ERROR or PARSE_ERROR, the
           remaining not-yet-attempted fields in this component are
           skipped rather than attempted at the same failure rate. Skipped
           fields are NOT persisted as any kind of failure — they're
           simply not attempted this run, and a later `extract_component`/
           `extract_field` call attempts them fresh once the underlying
           issue is resolved.
        """
        framework_name = framework_name or settings.retrieval_framework_name
        fields = self._fields_for_component(session, framework_name=framework_name, component=component)
        if not fields:
            return []

        resolved_request_id = request_id or self._latest_request_id(session, company_id=company_id, component=component)

        provider = self._resolve_provider()
        if not provider.health_check():
            base_url = getattr(provider, "_base_url", settings.llm_ollama_base_url)
            if ensure_ollama_running(base_url, provider_name=self._resolve_provider_name()) and provider.health_check():
                logger.info("Provider=%s recovered after auto-start — proceeding with extraction normally.", self._resolve_provider_name())
            else:
                logger.warning(
                    "Pre-flight health check failed for provider=%s — provider is unreachable, "
                    "skipping all %s field(s) for company=%s component=%s without attempting them. "
                    "Check the provider is running (e.g. 'ollama serve') and retry.",
                    self._resolve_provider_name(), len(fields), company_id, component,
                )
                return []

        threshold = settings.llm_circuit_breaker_threshold
        consecutive_failures = 0
        outcomes: list[ExtractionOutcome] = []
        resumed_count = 0

        for field in fields:
            if threshold and consecutive_failures >= threshold:
                logger.warning(
                    "Circuit breaker tripped after %s consecutive extraction failures — "
                    "skipping remaining %s field(s) for company=%s component=%s this run.",
                    consecutive_failures, len(fields) - len(outcomes), company_id, component,
                )
                break

            if not force and resolved_request_id is not None:
                existing = self._existing_success_outcome(
                    session, company_id=company_id, framework_name=framework_name,
                    component=component, field_name=field.field_name, request_id=resolved_request_id,
                )
                if existing is not None:
                    outcomes.append(existing)
                    resumed_count += 1
                    consecutive_failures = 0
                    continue

            outcome = self.extract_field(
                session,
                company_id=company_id,
                component=component,
                field_name=field.field_name,
                framework_name=framework_name,
                request_id=resolved_request_id,
            )
            outcomes.append(outcome)

            failed = outcome.get("status") in (ExtractionStatus.PROVIDER_ERROR.value, ExtractionStatus.PARSE_ERROR.value)
            consecutive_failures = consecutive_failures + 1 if failed else 0

        if resumed_count:
            logger.info(
                "Resumed %s/%s field(s) for company=%s component=%s from a previous run's SUCCESS "
                "against the same evidence batch — %s field(s) actually attempted this run.",
                resumed_count, len(fields), company_id, component, len(fields) - resumed_count,
            )

        return outcomes
