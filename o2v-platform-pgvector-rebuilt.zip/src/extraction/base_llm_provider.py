"""
Abstract base LLM completion provider — the plugin boundary every LLM
provider (Ollama/OpenAI/Anthropic today; Azure OpenAI as an architecture
placeholder — see `llm_factory.py`) must implement.

Design decision: mirrors `src/embeddings/base_embedding_provider.py`'s
shape closely, adapted from "embed a batch of texts" to "complete one
structured-JSON prompt" — a minimal new provider is "one class, one
method" (`complete`), per the same "Future providers should require only:
1. Create provider class. 2. Register provider. 3. No architecture
changes." property Sprint 6 established for embeddings and the Sprint 8
brief explicitly requires again ("Sprint 8 must remain provider-
independent... If the current repository already has an LLM provider
abstraction: extend it. Do not create a second provider system.") — this
IS that one abstraction; no embedding-provider code is touched or
duplicated.

Design decision: `complete()` returns the provider's raw text response,
not a parsed dict — parsing/validation is `validation.py`'s job (single
responsibility, same split `parser/` vs `chunking/` already uses), so a
provider implementation never needs to know anything about the Sprint 8
JSON schema. This is also what keeps a provider trivially swappable: two
providers can return semantically-identical JSON with different
whitespace/formatting, and the provider layer doesn't need to care.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class BaseLLMProvider(ABC):
    """
    Common interface every LLM completion provider must implement.

    Unlike `BaseEmbeddingProvider` (which validates output dimension),
    there is no comparable structural guarantee a base class can enforce
    on a completion response — a provider's raw text might not even be
    valid JSON. That's expected and handled one layer up, in
    `extraction_service.py` (parse -> on failure, retry with a
    corrective follow-up -> on repeated failure, `ExtractionStatus.PARSE_ERROR`).
    """

    #: Short machine-readable name recorded on `ExtractionResult.llm_provider`.
    provider_name: str = "base"

    def __init__(self, *, model_name: str, temperature: float, max_output_tokens: int):
        self.model_name = model_name
        self.temperature = temperature
        self.max_output_tokens = max_output_tokens

    @abstractmethod
    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        """
        Send one system+user prompt pair to the provider and return the
        raw text of its response. Subclasses implement the actual
        provider call (HTTP request, SDK call, etc.); retrying on
        transient failure and JSON parsing both happen in
        `extraction_service.py`, not here — a provider's only job is
        "make the call, return the text, or raise
        `LLMProviderUnavailableError`."
        """

    def health_check(self, timeout: float | None = None) -> bool:
        """
        Cheap, fast "is this provider even reachable right now" probe —
        deliberately NOT the same code path as `complete()`. Found in
        practice: a full LLM completion call against a resource-starved
        local model can legitimately take minutes even when working
        correctly, so discovering the provider is actually just dead
        takes `llm_retry_limit`-many `llm_timeout_seconds`-length waits —
        tens of minutes — on the very first field of a multi-field batch.
        This runs BEFORE `extract_component` starts working through its
        field list, so a dead provider is caught in `timeout` seconds.

        Default implementation: a trivial real `complete()` call — works
        for any provider without every subclass needing to implement it,
        but exercises the real (possibly slow) code path, so it inherits
        whatever the provider's normal latency is. Providers with a
        cheaper, dedicated reachability check (e.g. Ollama's own root
        endpoint, independent of model load/inference time) should
        override this — see `OllamaLLMProvider.health_check`.

        Returns True/False rather than raising — this is a yes/no
        question for the caller to act on, not an error condition itself.
        """
        try:
            self.complete(system_prompt="Respond with only the word: ok", user_prompt="ping")
            return True
        except Exception:
            return False
