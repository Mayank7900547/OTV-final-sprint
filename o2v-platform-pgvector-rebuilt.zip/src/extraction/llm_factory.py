"""
LLM completion provider registry and factory — the single place provider
selection happens, mirroring `src/embeddings/embedding_factory.py` exactly.
Adding a provider is: one class + one `@register_provider(...)` line here,
no changes anywhere else in `src/extraction/`.

Design decision: THREE providers get real implementations (Ollama, OpenAI,
Anthropic), not just one — per explicit product direction: "build the LLM
layer behind an abstraction/provider interface, so later you can swap
Ollama -> OpenAI -> Anthropic -> another provider without rewriting
Sprint 8." Ollama remains the default (matches `settings.embeddings_provider`'s
default and rationale: local, no API key, no cost, nothing to configure to
get the pipeline running end-to-end). OpenAI and Anthropic are equally
real, switched to purely via `LLM_PROVIDER` + the matching API key setting
— no code path treats one as more "supported" than another. Azure OpenAI
is kept as a registered-but-placeholder entry, consistent with
`embedding_factory.py`'s existing placeholder pattern, so the registry
shape (a provider CAN exist without a working backend yet) is proven out
here too.

All three real providers are prompted identically (same system_prompt +
user_prompt from `prompt_builder.py`) and instructed to return ONLY a JSON
object — `extraction_service.py` parses whatever text comes back the same
way regardless of provider, so provider choice never changes extraction
behavior beyond model quality/latency/cost.
"""

from __future__ import annotations

import httpx

from src.config.settings import settings
from src.extraction.base_llm_provider import BaseLLMProvider
from src.extraction.exceptions import InvalidLLMResponseError, LLMConfigurationError, LLMProviderUnavailableError

_PROVIDER_REGISTRY: dict[str, type[BaseLLMProvider]] = {}


def register_provider(name: str):
    """Class decorator: registers a `BaseLLMProvider` subclass under `name` in the factory."""

    def decorator(cls: type[BaseLLMProvider]) -> type[BaseLLMProvider]:
        _PROVIDER_REGISTRY[name] = cls
        return cls

    return decorator


def available_llm_providers() -> list[str]:
    return sorted(_PROVIDER_REGISTRY)


def get_llm_provider(name: str | None = None, **overrides) -> BaseLLMProvider:
    """
    Construct a provider by name (defaulting to `settings.llm_provider`),
    with `model_name`/`temperature`/`max_output_tokens` defaulting from
    settings and overridable per call — the single choke point
    `ExtractionService` (and the CLI) go through, so no other module ever
    imports a concrete provider class directly. Mirrors
    `embedding_factory.py::get_provider` exactly.
    """
    provider_name = (name or settings.llm_provider).lower()
    try:
        provider_cls = _PROVIDER_REGISTRY[provider_name]
    except KeyError as exc:
        raise LLMConfigurationError(
            f"Unknown LLM provider {provider_name!r}. Available: {available_llm_providers()}"
        ) from exc

    kwargs = {
        "model_name": overrides.pop("model_name", settings.llm_model_name),
        "temperature": overrides.pop("temperature", settings.llm_temperature),
        "max_output_tokens": overrides.pop("max_output_tokens", settings.llm_max_output_tokens),
    }
    kwargs.update(overrides)
    return provider_cls(**kwargs)


# ---------------------------------------------------------------------------
# Ollama — local, no-cost default provider (mirrors embeddings default).
# ---------------------------------------------------------------------------


@register_provider("ollama")
class OllamaLLMProvider(BaseLLMProvider):
    """
    Calls a locally-running Ollama server's `/api/chat` endpoint with
    `format: "json"` (Ollama's built-in constrained-JSON-output mode) —
    requires no API key and no external network access. Requires Ollama
    itself to be installed/running and the configured chat model pulled
    (`ollama pull llama3.1` for the default model). Same server
    `embeddings_ollama_base_url` points at; only the endpoint differs.
    """

    provider_name = "ollama"

    def __init__(
        self,
        *,
        model_name: str,
        temperature: float,
        max_output_tokens: int,
        base_url: str | None = None,
        timeout: float | None = None,
        client: httpx.Client | None = None,
    ):
        super().__init__(model_name=model_name, temperature=temperature, max_output_tokens=max_output_tokens)
        self._base_url = (base_url or settings.llm_ollama_base_url).rstrip("/")
        self._timeout = timeout or settings.llm_timeout_seconds
        # Injectable for tests — avoids every test needing a real,
        # locally-running Ollama server to exercise this provider's logic.
        self._client = client

    def _get_client(self) -> httpx.Client:
        if self._client is not None:
            return self._client
        self._client = httpx.Client(timeout=self._timeout)
        return self._client

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        client = self._get_client()
        try:
            response = client.post(
                f"{self._base_url}/api/chat",
                json={
                    "model": self.model_name,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt},
                    ],
                    "format": "json",
                    "stream": False,
                    "options": {"temperature": self.temperature, "num_predict": self.max_output_tokens},
                },
            )
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise LLMProviderUnavailableError(
                f"Ollama returned HTTP {exc.response.status_code} for model {self.model_name!r} — "
                f"is the model pulled? Try: ollama pull {self.model_name}. Response: {exc.response.text[:300]}"
            ) from exc
        except httpx.HTTPError as exc:
            raise LLMProviderUnavailableError(
                f"Could not reach Ollama at {self._base_url} — is it running? "
                f"Start it with 'ollama serve', or set LLM_OLLAMA_BASE_URL. ({exc})"
            ) from exc

        try:
            payload = response.json()
            return payload["message"]["content"]
        except (ValueError, KeyError, TypeError) as exc:
            raise InvalidLLMResponseError(
                f"Ollama returned an unexpected response shape (expected a JSON object with a "
                f"'message.content' string): {exc}"
            ) from exc

    def health_check(self, timeout: float | None = None) -> bool:
        """
        Fast override: a plain GET to Ollama's root endpoint — same
        approach as `OllamaEmbeddingProvider.health_check` and the same
        reasoning: independent of `self._timeout` (`llm_timeout_seconds`,
        which can be many minutes for a real completion), so a dead
        server is detected in a few seconds via
        `settings.llm_health_check_timeout_seconds`, not by waiting out
        the same long timeout a real extraction call uses.
        """
        check_timeout = timeout if timeout is not None else settings.llm_health_check_timeout_seconds
        try:
            response = httpx.get(self._base_url, timeout=check_timeout)
            return response.status_code == 200
        except httpx.HTTPError:
            return False


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------


@register_provider("openai")
class OpenAILLMProvider(BaseLLMProvider):
    """Calls OpenAI's Chat Completions API with `response_format={"type": "json_object"}` — OpenAI's structured-output mode, preferred over post-hoc parsing per the Sprint 8 brief."""

    provider_name = "openai"

    def __init__(
        self,
        *,
        model_name: str,
        temperature: float,
        max_output_tokens: int,
        api_key: str | None = None,
        timeout: float | None = None,
        client=None,
    ):
        super().__init__(model_name=model_name, temperature=temperature, max_output_tokens=max_output_tokens)
        self._api_key = api_key or settings.llm_openai_api_key
        self._timeout = timeout or settings.llm_timeout_seconds
        # Injectable for tests — avoids every test needing a real API key
        # or network access to exercise this provider's logic.
        self._client = client

    def _get_client(self):
        if self._client is not None:
            return self._client
        if not self._api_key:
            raise LLMProviderUnavailableError(
                "OpenAI LLM provider requires an API key — set OPENAI_API_KEY "
                "(loaded as settings.llm_openai_api_key)."
            )
        try:
            import openai
        except ImportError as exc:
            raise LLMProviderUnavailableError(
                "The 'openai' package is not installed. Add it to requirements.txt to use this provider."
            ) from exc
        self._client = openai.OpenAI(api_key=self._api_key, timeout=self._timeout)
        return self._client

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        client = self._get_client()
        try:
            response = client.chat.completions.create(
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
        except LLMProviderUnavailableError:
            raise
        except Exception as exc:  # provider SDK errors are re-raised as our domain exception
            raise LLMProviderUnavailableError(f"OpenAI completion request failed: {exc}") from exc

        try:
            return response.choices[0].message.content
        except (IndexError, AttributeError) as exc:
            raise InvalidLLMResponseError(f"OpenAI returned an unexpected response shape: {exc}") from exc


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------


@register_provider("anthropic")
class AnthropicLLMProvider(BaseLLMProvider):
    """
    Calls Anthropic's Messages API. Anthropic has no dedicated
    "JSON mode" response_format flag (unlike OpenAI) — instead the system
    prompt (`prompt_builder.py`) explicitly instructs "respond with ONLY a
    JSON object, no prose, no markdown fences", and `validation.py`'s
    parser strips a markdown code fence defensively if the model adds one
    anyway. This is the standard, documented way to get reliable JSON out
    of Claude models.
    """

    provider_name = "anthropic"

    def __init__(
        self,
        *,
        model_name: str,
        temperature: float,
        max_output_tokens: int,
        api_key: str | None = None,
        timeout: float | None = None,
        client=None,
    ):
        super().__init__(model_name=model_name, temperature=temperature, max_output_tokens=max_output_tokens)
        self._api_key = api_key or settings.llm_anthropic_api_key
        self._timeout = timeout or settings.llm_timeout_seconds
        # Injectable for tests — avoids every test needing a real API key
        # or network access to exercise this provider's logic.
        self._client = client

    def _get_client(self):
        if self._client is not None:
            return self._client
        if not self._api_key:
            raise LLMProviderUnavailableError(
                "Anthropic LLM provider requires an API key — set ANTHROPIC_API_KEY "
                "(loaded as settings.llm_anthropic_api_key)."
            )
        try:
            import anthropic
        except ImportError as exc:
            raise LLMProviderUnavailableError(
                "The 'anthropic' package is not installed. Add it to requirements.txt to use this provider."
            ) from exc
        self._client = anthropic.Anthropic(api_key=self._api_key, timeout=self._timeout)
        return self._client

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        client = self._get_client()
        try:
            response = client.messages.create(
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
        except LLMProviderUnavailableError:
            raise
        except Exception as exc:  # provider SDK errors are re-raised as our domain exception
            raise LLMProviderUnavailableError(f"Anthropic completion request failed: {exc}") from exc

        try:
            text_blocks = [block.text for block in response.content if getattr(block, "type", None) == "text"]
            if not text_blocks:
                raise InvalidLLMResponseError("Anthropic response contained no text content blocks.")
            return "".join(text_blocks)
        except AttributeError as exc:
            raise InvalidLLMResponseError(f"Anthropic returned an unexpected response shape: {exc}") from exc


# ---------------------------------------------------------------------------
# Architecture placeholder — mirrors embedding_factory.py's pattern for
# providers that are registered/constructible but not yet wired up.
# ---------------------------------------------------------------------------


@register_provider("azure_openai")
class AzureOpenAILLMProvider(BaseLLMProvider):
    """Registered architecture placeholder — same role as `AzureOpenAIEmbeddingProvider` in `embedding_factory.py`. Constructible; `complete()` refuses to run until wired up."""

    provider_name = "azure_openai"

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        raise LLMProviderUnavailableError(
            "azure_openai is registered as an architecture placeholder — "
            "wire up the Azure OpenAI client (endpoint + deployment name) to enable it."
        )
