"""In-process metrics collector for extraction activity — mirrors `src.retrieval.telemetry.RetrievalTelemetry`'s shape."""

from __future__ import annotations

import threading

from src.core.constants import EvidenceConfidence, ExtractionStatus
from src.extraction.types import ExtractionSummary


class ExtractionTelemetry:
    def __init__(self):
        self.extraction_requests: int = 0
        self.successful_extractions: int = 0
        self.not_found_extractions: int = 0
        self.failed_extractions: int = 0
        self.no_evidence_count: int = 0
        self.total_duration_seconds: float = 0.0
        self.total_retries: int = 0
        self.active_provider: str = ""
        self._lock = threading.Lock()

    def record_request(self) -> None:
        with self._lock:
            self.extraction_requests += 1

    def record_outcome(self, *, status: str, confidence: str | None, duration: float, retries: int, provider: str) -> None:
        with self._lock:
            self.total_duration_seconds += duration
            self.total_retries += retries
            self.active_provider = provider
            if status == ExtractionStatus.SUCCESS.value:
                self.successful_extractions += 1
                if confidence == EvidenceConfidence.NOT_FOUND.value:
                    self.not_found_extractions += 1
            elif status == ExtractionStatus.NO_EVIDENCE.value:
                self.no_evidence_count += 1
            else:
                self.failed_extractions += 1

    def get_summary(self) -> ExtractionSummary:
        with self._lock:
            attempted = self.successful_extractions + self.failed_extractions + self.no_evidence_count
            average_latency = round(self.total_duration_seconds / attempted, 4) if attempted else 0.0
            average_retries = round(self.total_retries / attempted, 2) if attempted else 0.0
            return {
                "extraction_requests": self.extraction_requests,
                "successful_extractions": self.successful_extractions,
                "not_found_extractions": self.not_found_extractions,
                "failed_extractions": self.failed_extractions,
                "no_evidence_count": self.no_evidence_count,
                "average_latency": average_latency,
                "average_retries": average_retries,
                "active_provider": self.active_provider,
            }

    def reset(self) -> None:
        with self._lock:
            self.__init__()  # noqa: PLC2801 - deliberate reinitialization, matches other telemetry.py modules' pattern


telemetry = ExtractionTelemetry()
