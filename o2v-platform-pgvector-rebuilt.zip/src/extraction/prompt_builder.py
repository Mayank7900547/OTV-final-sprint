"""
Sprint 8 extraction prompt construction.

Design decision: system instructions, O2V methodology context, and the
output-schema contract are all STATIC text built once
(`SYSTEM_PROMPT_TEMPLATE`); only the component/field definition and the
evidence block are per-call. This is the "separate system instructions
from field context, don't build one enormous hard-coded prompt containing
all current and future O2V fields" requirement from the Sprint 8 brief —
`build_prompts()` is handed a single `FieldContext` (one field) and a list
of `EvidenceItem`s; it never sees or hardcodes the other ~28 fields. A new
field extracting correctly is purely a Framework Registry data question,
never a prompt-builder code change.

Design decision: the user prompt repeats the field's `field_definition`
and `expected_document_sources` verbatim from the Framework row (not a
paraphrase), matching the brief's "Phase 1 methodology is authoritative...
do not invent new definitions" instruction — whatever's registered in
`data/frameworks/o2v.yaml` is exactly what reaches the model.
"""

from __future__ import annotations

import json

from src.config.settings import settings
from src.extraction.types import EvidenceItem, FieldContext

SYSTEM_PROMPT_TEMPLATE = """You are a corporate disclosure research analyst extracting structured \
evidence for the O2V framework, which assesses organizations on three components: Purpose (why the \
organization exists beyond financial returns), Behaviour (how the organization operates internally), and \
Value Agenda (what the organization intends to achieve).

Your job is to extract evidence for ONE specific O2V field from the official evidence supplied to you below. \
You are NOT being asked to research this company from scratch, and you must not use any knowledge about the \
company beyond what is supplied in the evidence.

Follow these rules exactly:

1. OFFICIAL SOURCES ONLY. The supplied evidence has already been restricted to official corporate sources by \
an earlier retrieval stage. Do not discount evidence for this reason, but never supplement it with outside \
knowledge, even if you believe you know relevant facts about this company.

2. PRESERVE ORIGINAL LANGUAGE. If you find supporting evidence, extract the organization's actual wording. \
Do not rewrite, summarize, or polish the language into generic AI phrasing.

3. NO UNSUPPORTED INTERPRETATION. Only extract evidence that the field definition below is actually about. \
Evidence that merely contains a related keyword but does not satisfy the field definition must NOT be extracted \
— treat this the same as no evidence at all. Conversely, evidence that clearly supports the field's underlying \
concept must be extracted even if it never uses the exact framework terminology.

4. NOT FOUND IS VALID. If none of the supplied evidence supports this field, respond with confidence \
"Not Found" and no exact_text. Do not guess, extrapolate, or fill in generic company information.

5. ATOMIC EVIDENCE. Extract a single, coherent piece of evidence for this field — do not merge multiple \
unrelated ideas into one exact_text.

6. CONFLICTING EVIDENCE. If multiple evidence items genuinely conflict on this field, do not silently pick \
one. Extract the higher-priority source's text (Annual Report / 10-K > Sustainability/ESG Report > Corporate \
Governance Report > Code of Conduct > CEO Letter > Investor Relations > About Us Page > other), and explain \
the conflict in "remarks".

7. CONFIDENCE. Use exactly one of: "High" (evidence explicitly and unambiguously supports the field, in the \
organization's own words), "Medium" (evidence supports the field but requires interpretation, is partial, or \
the literal terminology is absent though the concept is clearly present), "Low" (evidence is only tangentially \
related, or sources conflict and could not be fully resolved), "Not Found" (no supporting evidence exists in \
what was supplied). If confidence is "Medium" or "Low", you MUST explain why in "remarks".

8. OUTPUT FORMAT. Respond with ONLY a single JSON object — no markdown code fences, no prose before or after \
it — matching exactly this shape:

{
  "exact_text": "<the organization's own words, or null if confidence is \\"Not Found\\">",
  "confidence": "<High|Medium|Low|Not Found>",
  "remarks": "<explanation, required for Medium/Low/Not Found, or null for High>",
  "source_retrieval_id": "<the retrieval_id of the ONE evidence item exact_text was drawn from, or null if Not Found>"
}
"""


def _format_evidence_block(evidence: list[EvidenceItem]) -> str:
    """
    Renders the supplied evidence as a numbered list carrying exactly the
    source metadata the output contract needs to preserve (retrieval_id,
    document type/year/domain, page, section) — each item's text is
    defensively truncated to `settings.extraction_evidence_max_chars_per_item`
    (a normally-sized chunk never hits this; it exists so a single
    oversized chunk can't blow out the prompt budget).
    """
    if not evidence:
        return "(No evidence was supplied for this field.)"

    max_chars = settings.extraction_evidence_max_chars_per_item
    lines = []
    for idx, item in enumerate(evidence, start=1):
        text = item.chunk_text
        if len(text) > max_chars:
            text = text[:max_chars] + " [...truncated]"
        lines.append(
            f"[Evidence {idx}] retrieval_id={item.retrieval_id} "
            f"source_type={item.document_type or 'unknown'} "
            f"year={item.document_year or 'unknown'} "
            f"domain={item.source_domain or 'unknown'} "
            f"page={item.page_number if item.page_number is not None else 'unknown'} "
            f"section={item.section_title or 'unknown'} "
            f"relevance_score={item.final_score:.3f}\n"
            f"{text}"
        )
    return "\n\n".join(lines)


def build_prompts(
    *, company_name: str, field: FieldContext, evidence: list[EvidenceItem]
) -> tuple[str, str]:
    """
    Build the (system_prompt, user_prompt) pair for one field extraction
    call. Returns the SYSTEM prompt unchanged (it's pure methodology/
    output-contract text, identical across every field/company/call) and
    a USER prompt carrying only this call's variable content: company
    identity, component, field definition/sources, and the evidence block.
    """
    sources_line = ", ".join(field.expected_document_sources) if field.expected_document_sources else "any official corporate publication"

    user_prompt = f"""COMPANY: {company_name}

O2V COMPONENT: {field.component_name}

TARGET FIELD: {field.field_name}

FIELD DEFINITION: {field.field_definition or '(no definition on record — use the component-level description above)'}

EXPECTED SOURCE TYPES FOR THIS FIELD: {sources_line}

RETRIEVED EVIDENCE (already restricted to official sources and ranked by relevance for this company/component; \
evaluate each item against the field definition above rather than assuming all of it applies):

{_format_evidence_block(evidence)}

Now extract evidence for the TARGET FIELD above, following all rules in the system prompt, and respond with \
ONLY the JSON object."""

    return SYSTEM_PROMPT_TEMPLATE, user_prompt


def debug_prompt_json_example() -> str:
    """Small helper used by tests/CLI to show the exact output shape the system prompt asks for, without duplicating the literal string in two places."""
    return json.dumps(
        {"exact_text": "...", "confidence": "High", "remarks": None, "source_retrieval_id": "..."},
        indent=2,
    )
