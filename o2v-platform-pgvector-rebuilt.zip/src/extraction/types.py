"""Shared type definitions and value objects for Sprint 8 semantic extraction — mirrors `src/retrieval/types.py`'s shape."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypedDict
from uuid import UUID


@dataclass
class FieldContext:
    """
    One O2V field's extraction context, built from a `Framework` row
    (see `src/models/framework.py`) — NOT a hardcoded field list. This is
    what makes the extraction prompt data-driven: adding a Framework row
    is enough for `PromptBuilder` to build a new field's prompt, no code
    change required (same extensibility property Sprint 7's
    `query_generator.py` already relies on for the same Framework rows).
    """

    framework_name: str
    component_name: str
    field_name: str
    field_definition: str | None
    expected_document_sources: list[str] = field(default_factory=list)


@dataclass
class EvidenceItem:
    """
    One piece of evidence handed to the LLM for one field extraction —
    a deliberately thin projection of a `RetrievedEvidence` row (see
    `src/retrieval/models.py`), carrying only what the prompt and the
    output's source-traceability fields actually need. Built by
    `extraction_service.py::_evidence_items_from_rows`, never constructed
    directly from a fabricated/parallel evidence structure — see the
    Sprint 8 brief's "Do not create fake parallel chunk objects."
    """

    retrieval_id: str
    chunk_text: str
    document_id: str
    document_type: str | None
    document_year: int | None
    source_domain: str | None
    page_number: int | None
    section_title: str | None
    final_score: float


class ExtractionPayload(TypedDict, total=False):
    """
    The parsed-and-validated JSON shape the LLM must return for one field,
    BEFORE `ExtractionResult` persistence adds run/traceability metadata.
    Field names deliberately match the Sprint 8 brief's output contract
    (`exact_text`, `confidence`, `remarks`, ...) and the architecture doc's
    §3.7 Extraction Staging shape (`exact_text, source_chunk_id,
    page_number, confidence, reasoning`) — `reasoning` is stored as
    `remarks` here to match the brief's explicit field name; the two are
    the same concept.
    """

    exact_text: str | None  # None / omitted when confidence == "Not Found"
    confidence: str  # one of EvidenceConfidence's values
    remarks: str | None
    source_retrieval_id: str | None  # which supplied EvidenceItem.retrieval_id the extraction was drawn from


class ExtractionOutcome(TypedDict, total=False):
    """Standardized result dictionary returned after one `ExtractionService.extract_field()` call — mirrors `RetrievalOutcome`."""

    status: str  # ExtractionStatus value
    company_id: UUID
    component: str
    field_name: str
    confidence: str
    exact_text: str | None
    remarks: str | None
    source_document_id: str | None
    source_retrieval_id: str | None
    page_number: int | None
    document_year: int | None
    source_url: str | None
    evidence_count: int
    llm_provider: str
    llm_model_name: str
    retries: int
    extraction_duration: float
    error: str


class ExtractionSummary(TypedDict):
    """Aggregated telemetry summary for extraction activity — mirrors `RetrievalSummary`."""

    extraction_requests: int
    successful_extractions: int
    not_found_extractions: int
    failed_extractions: int
    no_evidence_count: int
    average_latency: float
    average_retries: float
    active_provider: str
