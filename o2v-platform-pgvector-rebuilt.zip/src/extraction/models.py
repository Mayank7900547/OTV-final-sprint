"""
Database model for Sprint 8 extraction output — the "extraction staging"
store named in `docs/02_platform_architecture.md` §3.7.

Design decision: deliberately MUTABLE/queryable, not the final immutable
Ground Truth store — per the Sprint 8 brief ("Do not create the final
immutable Ground Truth Store. That belongs to later stages... extraction
staging should be queryable/updatable as validation runs"), `updated_at`
exists specifically so a future Sprint 9 validation pass can write back a
validation verdict onto this SAME row rather than Sprint 8 needing to
anticipate Sprint 9's schema. One row = one (company, component, field)
extraction attempt's current best result.

Design decision: `exact_text`/`source_document_id`/`page_number`/etc. are
denormalized snapshots taken at extraction time, not re-derived on read —
same reasoning as `RetrievedEvidence` (see `src/retrieval/models.py`'s
module docstring): if a document is later re-discovered or re-chunked, an
`ExtractionResult` row must still show exactly what evidence it was
actually extracted from at the time.

Design decision: column names deliberately match BOTH the Sprint 8
brief's dataset spec (Company Name, O2V Component, Field Name, Exact
Extracted Text, Source Document, Page Number, Document Year, Source URL,
Evidence Confidence, Remarks + Source Type) AND the architecture doc's
§3.7 staging shape (`exact_text, source_chunk_id, page_number, confidence,
reasoning` — `reasoning` stored as `remarks` to match the brief's explicit
field name, same concept). `company_id`/`document_id` stay as real FKs
(joined for "Company Name"/"Source Document" display) rather than
denormalizing those strings too, since — unlike a retrieval snapshot —
company/document identity for an extraction genuinely shouldn't drift.
"""

import uuid

from sqlalchemy import JSON, Column, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID

from src.database.base import Base


class ExtractionResult(Base):
    """One (company, O2V component, field) extraction attempt's current best result."""

    __tablename__ = "extraction_results"
    __table_args__ = (
        # One current result per (company, component, field) — re-extraction
        # updates the existing row (see extraction_service.py) rather than
        # accumulating history rows, consistent with this being a STAGING
        # store, not an append-only audit log. Framework name is included
        # since two frameworks could theoretically define the same
        # component/field name differently.
        UniqueConstraint(
            "company_id", "framework_name", "component", "field_name",
            name="uq_extraction_company_framework_component_field",
        ),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Deterministic, human-readable id for this extraction attempt --
    # f"{company_id}:{component}:{field_name}" -- same "external id
    # alongside the autoincrement PK" pattern as RetrievedEvidence.retrieval_id.
    extraction_id = Column(String(255), nullable=False, index=True)

    company_id = Column(PG_UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)
    framework_name = Column(String(255), nullable=False, index=True)
    component = Column(String(255), nullable=False, index=True)
    field_name = Column(String(255), nullable=False, index=True)

    # --- extraction result ---
    status = Column(String(30), nullable=False)  # ExtractionStatus value
    exact_text = Column(Text, nullable=True)  # null when confidence == "Not Found" or status != SUCCESS
    confidence = Column(String(20), nullable=True)  # EvidenceConfidence value; null when status != SUCCESS
    remarks = Column(Text, nullable=True)

    # --- source traceability (snapshot at extraction time) ---
    source_retrieval_id = Column(String(80), nullable=True)  # -> RetrievedEvidence.retrieval_id the text was drawn from
    source_document_id = Column(PG_UUID(as_uuid=True), ForeignKey("document_registry.id", ondelete="SET NULL"), nullable=True, index=True)
    source_document_name = Column(String(500), nullable=True)
    source_type = Column(String(100), nullable=True)  # DocumentCategory value, e.g. "annual_report"
    source_url = Column(String(1000), nullable=True)
    document_year = Column(Integer, nullable=True)
    page_number = Column(Integer, nullable=True)
    section_title = Column(String(1000), nullable=True)

    # --- run metadata ---
    request_id = Column(String(64), nullable=True)  # Sprint 7 retrieval request_id the evidence pool came from
    evidence_count = Column(Integer, nullable=False, default=0)  # how many evidence items were supplied to the LLM
    llm_provider = Column(String(50), nullable=True)
    llm_model_name = Column(String(255), nullable=True)
    retries = Column(Integer, nullable=False, default=0)
    raw_llm_response = Column(Text, nullable=True)  # kept only on PARSE_ERROR, to aid debugging malformed output
    error = Column(Text, nullable=True)  # populated on PROVIDER_ERROR / PARSE_ERROR

    # Free-form JSON slot reserved for Sprint 9 to attach a validation
    # verdict onto this same row (see module docstring) without a
    # migration -- Sprint 8 never writes to this column itself.
    validation_metadata = Column(JSON, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<ExtractionResult id={self.id} company_id={self.company_id} "
            f"component={self.component!r} field={self.field_name!r} "
            f"status={self.status!r} confidence={self.confidence!r}>"
        )
