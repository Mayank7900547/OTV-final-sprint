"""
Parsing and validation of the LLM's raw text response against the Sprint 8
extraction contract (`types.py::ExtractionPayload`).

Design decision: parsing and validation are a SEPARATE layer from both the
provider (`llm_factory.py`, which only returns raw text) and the service
(`extraction_service.py`, which orchestrates retries around this module) —
same single-responsibility split as `parser/` vs `chunking/`. This is also
what makes the "malformed LLM output" and "JSON parsing failure" test
cases (Sprint 8 brief, tests #16-17) exercisable in isolation, with a
hand-written string, no provider or database involved.
"""

from __future__ import annotations

import json
import re

from src.core.constants import EvidenceConfidence
from src.extraction.exceptions import ExtractionSchemaError, InvalidLLMResponseError
from src.extraction.types import ExtractionPayload

_VALID_CONFIDENCE_VALUES = {c.value for c in EvidenceConfidence}

# Strips a ```json ... ``` or ``` ... ``` fence some models wrap JSON in
# despite being told not to (see AnthropicLLMProvider's docstring) —
# applied defensively regardless of which provider produced the text.
_CODE_FENCE_RE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL)


def _strip_code_fence(text: str) -> str:
    text = text.strip()
    match = _CODE_FENCE_RE.match(text)
    return match.group(1).strip() if match else text


def parse_json_response(raw_text: str) -> dict:
    """
    Parse the provider's raw text into a dict. Raises
    `InvalidLLMResponseError` (not `ExtractionSchemaError`) on failure —
    this function only knows whether the text IS valid JSON, not whether
    that JSON satisfies the extraction contract; that's `validate_extraction_payload`'s job.
    """
    if not raw_text or not raw_text.strip():
        raise InvalidLLMResponseError("LLM returned an empty response.")

    cleaned = _strip_code_fence(raw_text)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise InvalidLLMResponseError(f"LLM response was not valid JSON: {exc}. Raw response: {raw_text[:500]!r}") from exc

    if not isinstance(parsed, dict):
        raise InvalidLLMResponseError(f"LLM response parsed to {type(parsed).__name__}, expected a JSON object.")

    return parsed


def validate_extraction_payload(payload: dict, *, valid_retrieval_ids: set[str] | None = None) -> ExtractionPayload:
    """
    Validate a parsed JSON dict against the Sprint 8 output contract and
    return it normalized as an `ExtractionPayload`. Raises
    `ExtractionSchemaError` (with a specific, actionable message) on any
    violation — the caller (`extraction_service.py`) uses that message to
    build a corrective retry prompt, so messages are written to be
    directly useful to an LLM re-reading them, not just a human.

    Rules enforced (mirrors the Sprint 8 brief's OUTPUT CONTRACT / JSON
    REQUIREMENTS / CONFIDENCE sections):
      - "confidence" is required and must be one of the four valid values.
      - "exact_text" is required and non-empty UNLESS confidence == "Not Found".
      - "exact_text" must be null/absent when confidence == "Not Found"
        (the model isn't allowed to both claim Not Found and supply text).
      - "remarks" is required (non-empty) when confidence is Medium, Low,
        or Not Found.
      - "source_retrieval_id", if the evidence pool's valid ids are known
        (`valid_retrieval_ids`), must reference one of the supplied
        evidence items — a model is not allowed to cite evidence it wasn't
        given.
    """
    confidence = payload.get("confidence")
    if not isinstance(confidence, str) or confidence not in _VALID_CONFIDENCE_VALUES:
        raise ExtractionSchemaError(
            f"'confidence' must be one of {sorted(_VALID_CONFIDENCE_VALUES)}, got {confidence!r}."
        )

    exact_text = payload.get("exact_text")
    if exact_text is not None and not isinstance(exact_text, str):
        raise ExtractionSchemaError(f"'exact_text' must be a string or null, got {type(exact_text).__name__}.")

    if confidence == EvidenceConfidence.NOT_FOUND.value:
        if exact_text:
            raise ExtractionSchemaError(
                "'exact_text' must be null when confidence is 'Not Found' — evidence was either found or it wasn't."
            )
    else:
        if not exact_text or not exact_text.strip():
            raise ExtractionSchemaError(
                f"'exact_text' is required and must be non-empty when confidence is {confidence!r}."
            )

    remarks = payload.get("remarks")
    if remarks is not None and not isinstance(remarks, str):
        raise ExtractionSchemaError(f"'remarks' must be a string or null, got {type(remarks).__name__}.")
    if confidence in (EvidenceConfidence.MEDIUM.value, EvidenceConfidence.LOW.value, EvidenceConfidence.NOT_FOUND.value):
        if not remarks or not remarks.strip():
            raise ExtractionSchemaError(
                f"'remarks' is required and must explain why when confidence is {confidence!r}."
            )

    source_retrieval_id = payload.get("source_retrieval_id")
    if source_retrieval_id is not None and not isinstance(source_retrieval_id, str):
        raise ExtractionSchemaError(
            f"'source_retrieval_id' must be a string or null, got {type(source_retrieval_id).__name__}."
        )
    if confidence == EvidenceConfidence.NOT_FOUND.value and source_retrieval_id:
        raise ExtractionSchemaError(
            "'source_retrieval_id' must be null when confidence is 'Not Found' — there is no source to cite."
        )
    if (
        source_retrieval_id
        and valid_retrieval_ids is not None
        and source_retrieval_id not in valid_retrieval_ids
    ):
        raise ExtractionSchemaError(
            f"'source_retrieval_id' {source_retrieval_id!r} does not match any retrieval_id in the supplied "
            f"evidence — you may only cite evidence you were actually given. Valid ids: {sorted(valid_retrieval_ids)}."
        )
    if confidence != EvidenceConfidence.NOT_FOUND.value and not source_retrieval_id and valid_retrieval_ids:
        raise ExtractionSchemaError(
            "'source_retrieval_id' is required when confidence is not 'Not Found' — identify which supplied "
            "evidence item exact_text was drawn from."
        )

    return ExtractionPayload(
        exact_text=exact_text,
        confidence=confidence,
        remarks=remarks,
        source_retrieval_id=source_retrieval_id,
    )


def parse_and_validate(raw_text: str, *, valid_retrieval_ids: set[str] | None = None) -> ExtractionPayload:
    """Convenience wrapper combining `parse_json_response` + `validate_extraction_payload` — what `extraction_service.py` calls on every attempt."""
    payload = parse_json_response(raw_text)
    return validate_extraction_payload(payload, valid_retrieval_ids=valid_retrieval_ids)
