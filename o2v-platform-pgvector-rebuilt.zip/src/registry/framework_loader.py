"""
Framework definition loader.

This module is the actual mechanism behind the requirement "add O2V, COSO,
Balanced Scorecard, ESG, ISO 27001 without changing code": a framework is
defined entirely as a YAML file under `data/frameworks/`, and this loader
turns that file into rows for the Framework table. Adding a new framework
is: write a new YAML file, run `o2v framework import <path>`. No Python
changes, no new model, no migration.

Expected YAML shape:

    framework_name: O2V
    components:
      - component_name: Purpose
        fields:
          - field_name: Mission Statement
            description: "The company's stated reason for existing."
            document_sources: ["Annual Report", "About Us Page"]
          - field_name: Vision Statement
            description: "..."
            document_sources: ["Annual Report"]
      - component_name: Behaviour
        fields: [...]

Validation is deliberately strict (raises `FrameworkValidationError` with a
specific, actionable message) rather than best-effort — a malformed
framework file silently producing zero or partial fields would be a much
worse failure than the CLI refusing to import it with a clear reason.
"""

from pathlib import Path
from typing import Any

import yaml

from src.core.exceptions import FrameworkValidationError

REQUIRED_TOP_LEVEL_KEYS = {"framework_name", "components"}
REQUIRED_COMPONENT_KEYS = {"component_name", "fields"}
REQUIRED_FIELD_KEYS = {"field_name"}


def load_framework_yaml(path: Path) -> dict[str, Any]:
    """Parse and validate a framework YAML file. Returns the raw parsed dict on success."""
    if not path.exists():
        raise FrameworkValidationError(f"Framework file not found: {path}")

    with path.open(encoding="utf-8") as f:
        try:
            raw = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise FrameworkValidationError(f"Invalid YAML in {path}: {exc}") from exc

    if not isinstance(raw, dict):
        raise FrameworkValidationError(
            f"{path}: top-level YAML content must be a mapping, got {type(raw).__name__}."
        )

    missing = REQUIRED_TOP_LEVEL_KEYS - raw.keys()
    if missing:
        raise FrameworkValidationError(
            f"{path}: missing required top-level key(s): {', '.join(sorted(missing))}"
        )

    if not isinstance(raw["components"], list) or not raw["components"]:
        raise FrameworkValidationError(
            f"{path}: 'components' must be a non-empty list."
        )

    for i, component in enumerate(raw["components"]):
        if not isinstance(component, dict):
            raise FrameworkValidationError(
                f"{path}: components[{i}] must be a mapping."
            )
        missing_c = REQUIRED_COMPONENT_KEYS - component.keys()
        if missing_c:
            raise FrameworkValidationError(
                f"{path}: components[{i}] missing key(s): {', '.join(sorted(missing_c))}"
            )
        if not isinstance(component["fields"], list) or not component["fields"]:
            raise FrameworkValidationError(
                f"{path}: components[{i}] ('{component['component_name']}') "
                "must have a non-empty 'fields' list."
            )
        for j, field in enumerate(component["fields"]):
            if not isinstance(field, dict):
                raise FrameworkValidationError(
                    f"{path}: components[{i}].fields[{j}] must be a mapping."
                )
            missing_f = REQUIRED_FIELD_KEYS - field.keys()
            if missing_f:
                raise FrameworkValidationError(
                    f"{path}: components[{i}].fields[{j}] missing key(s): "
                    f"{', '.join(sorted(missing_f))}"
                )

    return raw


def flatten_framework(raw: dict[str, Any]) -> list[dict]:
    """
    Flatten a validated, nested framework dict into a flat list of field rows
    matching what `framework_service.upsert_framework_fields` expects.

    Kept as a separate pure function (no I/O, no DB) so it's trivially unit
    testable on its own — see tests/test_framework_loader.py.
    """
    rows: list[dict] = []
    for component in raw["components"]:
        for field in component["fields"]:
            rows.append(
                {
                    "component_name": component["component_name"],
                    "field_name": field["field_name"],
                    "description": field.get("description"),
                    "document_sources": field.get("document_sources") or [],
                }
            )
    return rows


def load_and_flatten(path: Path) -> tuple[str, list[dict]]:
    """Convenience wrapper: load + validate + flatten in one call. Returns (framework_name, rows)."""
    raw = load_framework_yaml(path)
    return raw["framework_name"], flatten_framework(raw)
