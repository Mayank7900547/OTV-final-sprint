"""
URL validation for discovered documents.

Design decision: ALLOWLIST-FIRST, not a blocklist. The Sprint 2 brief lists
Wikipedia, blogs, news sites, forums, and GitHub mirrors as things to
reject — but enumerating every blog platform, news domain, and forum on
the internet is a losing game (there will always be one more we forgot to
list, and the very next new blogging platform that launches would sail
straight through an unenumerated blocklist). Instead, this module rejects
EVERYTHING by default and only allows:

1. A domain that IS the company's own registered website domain
   (Company.website, from Sprint 1), or a subdomain of it (e.g.
   `investors.apple.com` when the company's site is `apple.com`).
2. A domain explicitly listed in `settings.discovery_trusted_external_domains`
   (SEC EDGAR's domains, by default — see config/settings.py).

This means Wikipedia, blogs, news sites, forums, and GitHub mirrors are
rejected not because they're named anywhere in this file, but because
they structurally can't be a subdomain of a company's own site and aren't
on the short trusted-external list. That's a stronger guarantee than a
blocklist could ever give, and it's also why this module needs almost no
maintenance as new junk-source domains appear over time.
"""

from dataclasses import dataclass
from urllib.parse import urlparse

from src.config.settings import settings


@dataclass
class UrlValidationResult:
    allowed: bool
    domain: str | None
    reason: str | None = None


def _extract_domain(url: str) -> str | None:
    """Return the lowercase netloc (host) of a URL, or None if unparseable."""
    try:
        parsed = urlparse(url)
    except ValueError:
        return None
    if not parsed.scheme or not parsed.netloc:
        return None
    # Strip a port if present (e.g. "example.com:8080" -> "example.com") —
    # discovery targets are always standard web ports, and comparing with a
    # stray port attached would falsely reject a legitimate domain match.
    return parsed.netloc.lower().split(":")[0]


def _is_same_domain_or_subdomain(domain: str, company_domain: str) -> bool:
    """
    True if `domain` equals `company_domain` or is a subdomain of it.

    String-suffix comparison with a leading "." is deliberately used
    (`domain.endswith("." + company_domain)`) rather than a full public-
    suffix-list library — correct enough for the "is this company's own
    site" check we need, without pulling in a dependency (`tldextract` or
    similar) whose main value-add is handling multi-part public suffixes
    (e.g. "co.uk") that matter for cookie-scoping use cases, not for this
    one-directional "is X part of Y's domain" check.
    """
    domain = domain.lower()
    company_domain = company_domain.lower()
    return domain == company_domain or domain.endswith("." + company_domain)


def validate_url(url: str, company_website: str | None) -> UrlValidationResult:
    """
    Validate a candidate document URL against the allowlist described above.

    `company_website` is the company's registered `website` field (Sprint 1
    Company Registry) — may be None for a company registered without one,
    in which case only the trusted-external domains (e.g. SEC EDGAR) can
    ever validate for that company, which is the correct behavior: we have
    no basis to trust an arbitrary domain as "this company's own site" if
    we were never told what that site is.
    """
    domain = _extract_domain(url)
    if domain is None:
        return UrlValidationResult(allowed=False, domain=None, reason="unparseable URL")

    if domain in settings.discovery_trusted_external_domains:
        return UrlValidationResult(allowed=True, domain=domain)

    if company_website:
        company_domain = _extract_domain(company_website) or company_website.lower()
        if _is_same_domain_or_subdomain(domain, company_domain):
            return UrlValidationResult(allowed=True, domain=domain)

    return UrlValidationResult(
        allowed=False,
        domain=domain,
        reason=(
            f"domain '{domain}' is neither the company's own domain "
            f"('{company_website}') nor a trusted external domain "
            f"({', '.join(settings.discovery_trusted_external_domains)})"
        ),
    )
