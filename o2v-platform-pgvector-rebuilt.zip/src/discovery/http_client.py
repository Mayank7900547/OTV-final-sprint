"""
Shared HTTP client for the discovery subsystem.

Design decision: a single thin module-level `get()` function, not a class,
and not a raw `httpx.get()` call scattered across `sec_edgar_client.py` and
`sitemap_crawler.py`. Three reasons this matters:

1. Every discovery HTTP call (SEC EDGAR, a company's sitemap, a heuristic
   path probe) needs the SAME cross-cutting behavior — timeout, retry,
   rate-limit delay, and a mandatory descriptive User-Agent (SEC EDGAR
   specifically rejects/rate-limits requests without one; being a good
   citizen matters for company websites too). Putting it in one place
   means that behavior is enforced everywhere, not "everywhere except the
   one call site someone forgot."
2. This is the ONE function tests mock (`unittest.mock.patch
   ("src.discovery.http_client.get")`) to simulate network responses
   without touching the network — see tests/test_discovery_*.py. Keeping
   the surface area small (one function, one return shape) makes mocking
   trivial and keeps test setup from needing an HTTP mocking library
   (respx, responses) as an extra dependency.
3. `get()` never raises for network-level failures (timeout, DNS failure,
   connection refused, non-2xx status) — it returns a `FetchResult` with
   `ok=False` and a `reason` string instead. A single failed probe of one
   candidate URL during discovery is an ordinary, expected outcome (most
   heuristic path guesses will 404), not an exceptional one — raising
   would force every caller into try/except for what is actually the
   common case.
"""

import time
from dataclasses import dataclass

import httpx

from src.config.logging_config import get_logger
from src.config.settings import settings

logger = get_logger(__name__)

_last_request_time: float = 0.0


@dataclass
class FetchResult:
    """Outcome of a single HTTP GET, success or failure — see module docstring point 3."""

    ok: bool
    url: str
    status_code: int | None = None
    text: str | None = None
    reason: str | None = None


def _apply_rate_limit() -> None:
    """
    Enforce a minimum delay between consecutive requests.

    Module-level `_last_request_time` (not per-call-site state) is
    deliberate — the rate limit is a property of "how fast are we hitting
    the network," which is global across every discovery call in the
    process, not something each caller should have to coordinate on its
    own.
    """
    global _last_request_time
    elapsed = time.monotonic() - _last_request_time
    remaining = settings.discovery_rate_limit_delay_seconds - elapsed
    if remaining > 0:
        time.sleep(remaining)
    _last_request_time = time.monotonic()


def get(url: str) -> FetchResult:
    """
    Fetch a URL with retry/backoff, timeout, rate limiting, and a mandatory
    User-Agent. Never raises — see module docstring.
    """
    headers = {"User-Agent": settings.discovery_user_agent}
    last_reason = "unknown error"

    for attempt in range(1, settings.discovery_retry_limit + 1):
        _apply_rate_limit()
        try:
            response = httpx.get(
                url,
                headers=headers,
                timeout=settings.discovery_timeout_seconds,
                follow_redirects=True,
            )
        except httpx.TimeoutException:
            last_reason = "timeout"
        except httpx.RequestError as exc:
            last_reason = f"request error: {exc}"
        else:
            if response.status_code == 200:
                return FetchResult(ok=True, url=url, status_code=200, text=response.text)
            last_reason = f"HTTP {response.status_code}"
            # Don't retry a definitive 4xx (the URL is wrong/gone, retrying
            # won't help) — only retry on 5xx or the exception branches above,
            # which are more plausibly transient.
            if 400 <= response.status_code < 500:
                logger.debug("Not retrying %s — client error %s", url, response.status_code)
                return FetchResult(
                    ok=False, url=url, status_code=response.status_code, reason=last_reason
                )

        if attempt < settings.discovery_retry_limit:
            backoff = settings.discovery_retry_backoff_seconds * (2 ** (attempt - 1))
            logger.debug(
                "Retrying %s (attempt %d/%d) after %s — backing off %.1fs",
                url,
                attempt,
                settings.discovery_retry_limit,
                last_reason,
                backoff,
            )
            time.sleep(backoff)

    logger.info("Giving up on %s after %d attempts (%s)", url, settings.discovery_retry_limit, last_reason)
    return FetchResult(ok=False, url=url, reason=last_reason)
