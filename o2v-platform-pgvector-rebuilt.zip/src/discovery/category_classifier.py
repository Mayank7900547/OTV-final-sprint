"""
Document category classification and year extraction.

Design decision: pure keyword/regex matching on the URL (path + query),
not an LLM call. This is intentional and matches the Sprint 2 brief
exactly ("NO LLM") — classification here only needs to answer "does this
URL look like it points at a Sustainability Report vs a Code of Conduct,"
which is a task keyword matching handles well given how consistently
companies name their own URL paths (`/sustainability`, `/code-of-conduct`,
`/investor-relations` are near-universal conventions). Reserving an LLM
for this would be spending a real, non-trivial resource on a problem that
doesn't need one — exactly the kind of cost-inefficiency the Sprint 1
architecture doc's cost-optimization section warned against.

Category rules are checked in a fixed priority order (most-specific
first) because URL paths often contain multiple plausible keywords at
once (e.g. a path containing both "governance" and "report" is far more
likely a Corporate Governance Report than a generic Annual Report), and
first-match-wins needs a deliberate order to resolve that correctly
rather than by keyword-list iteration order accidentally deciding it.
"""

import re
from urllib.parse import urlparse

from src.core.constants import DocumentCategory, DocumentType

# Ordered most-specific-first — see module docstring.
_CATEGORY_KEYWORDS: list[tuple[DocumentCategory, tuple[str, ...]]] = [
    (DocumentCategory.PROXY_STATEMENT, ("proxy-statement", "proxy_statement", "def-14a", "def14a")),
    (DocumentCategory.CORPORATE_GOVERNANCE_REPORT, ("corporate-governance", "governance-report", "governance")),
    (DocumentCategory.CODE_OF_CONDUCT, ("code-of-conduct", "code_of_conduct", "conduct-policy")),
    (DocumentCategory.BUSINESS_ETHICS, ("business-ethics", "ethics-policy", "ethics")),
    (DocumentCategory.ESG_REPORT, ("esg-report", "esg_report", "/esg")),
    (DocumentCategory.SUSTAINABILITY_REPORT, ("sustainability-report", "sustainability")),
    (DocumentCategory.CORPORATE_RESPONSIBILITY_REPORT, ("corporate-responsibility", "csr-report", "/csr")),
    (DocumentCategory.AI_TECHNOLOGY_REPORT, ("ai-strategy", "responsible-ai", "ai-principles", "technology-report")),
    (DocumentCategory.CEO_LETTER, ("ceo-letter", "letter-to-shareholders", "chairman-letter")),
    (DocumentCategory.PROXY_STATEMENT, ("proxy",)),  # broader fallback, checked after the specific DEF 14A match
    (DocumentCategory.INVESTOR_RELATIONS, ("investor-relations", "investors", "/ir/")),
    (DocumentCategory.ABOUT_US, ("about-us", "/about")),
    (DocumentCategory.ANNUAL_REPORT, ("annual-report", "annual_report")),
]

_YEAR_PATTERN = re.compile(r"\b(19\d{2}|20\d{2})\b")


def classify_category(url: str) -> DocumentCategory:
    """
    Classify a URL into a DocumentCategory by keyword match on its path.

    Returns DocumentCategory.UNKNOWN rather than raising when nothing
    matches — an unclassifiable URL is a normal outcome during heuristic/
    sitemap discovery (most of a company's sitemap is not one of our
    target categories), not an error condition.
    """
    path = urlparse(url).path.lower()
    query = urlparse(url).query.lower()
    haystack = f"{path} {query}"

    for category, keywords in _CATEGORY_KEYWORDS:
        if any(keyword in haystack for keyword in keywords):
            return category

    return DocumentCategory.UNKNOWN


def classify_document_type(url: str) -> DocumentType:
    """Infer file format from the URL's extension. Defaults to HTML (a webpage) if ambiguous."""
    path = urlparse(url).path.lower()
    if path.endswith(".pdf"):
        return DocumentType.PDF
    if path.endswith((".htm", ".html")) or "." not in path.rsplit("/", 1)[-1]:
        return DocumentType.HTML
    return DocumentType.UNKNOWN


def extract_year(text: str) -> int | None:
    """
    Extract a plausible publication year (1900-2099) from a URL or filename.

    Returns the LAST match, not the first — company URLs commonly embed
    other 4-digit numbers before the year (e.g. a CIK-like path segment),
    while the year is conventionally the closest-to-the-filename token
    (e.g. ".../reports/2019/annual-report-2024.pdf" — the trailing 2024 is
    the actual report year, not the 2019 in the path). This is a heuristic,
    not a guarantee — callers with an authoritative date (e.g. the SEC
    EDGAR API's actual filing date) should prefer that over this function
    entirely; see sec_edgar_client.py, which does exactly that.
    """
    matches = _YEAR_PATTERN.findall(text)
    return int(matches[-1]) if matches else None
