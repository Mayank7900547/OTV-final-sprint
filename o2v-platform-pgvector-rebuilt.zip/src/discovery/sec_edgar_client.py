"""
SEC EDGAR discovery client.

Design decision: SEC EDGAR's own public JSON APIs, not a search engine and
not an LLM. This is the most authoritative discovery source available for
US-listed companies — filing metadata (form type, filing date, accession
number) comes directly from SEC's system of record, so results here don't
need heuristic classification or year-extraction guessing the way
sitemap/probe-based discovery does (see sitemap_crawler.py).

Two SEC endpoints are used, both public and requiring no authentication
(only a descriptive User-Agent, enforced globally by http_client.py):

1. https://www.sec.gov/files/company_tickers.json
   A static ticker -> CIK (Central Index Key) mapping SEC publishes for
   exactly this purpose. Fetched once per process and cached in memory
   (see `_TickerCikCache`) — re-fetching a ~1MB static reference file on
   every single company's discovery run would be wasteful and slow for
   no benefit, since the mapping doesn't change within a single discovery
   session.

2. https://data.sec.gov/submissions/CIK{10-digit-zero-padded}.json
   A company's full filing history: form types, filing dates, and enough
   path components to construct the actual document URL. Filtered here to
   the form types Sprint 2 cares about: 10-K, 20-F (foreign private
   issuers file this instead of 10-K), and DEF 14A (proxy statements).
"""

import json
from dataclasses import dataclass

from src.config.logging_config import get_logger
from src.core.constants import DocumentCategory, DocumentType, DiscoveryMethod
from src.core.exceptions import DocumentSourceUnavailableError
from src.discovery import http_client

logger = get_logger(__name__)

TICKER_MAP_URL = "https://www.sec.gov/files/company_tickers.json"
SUBMISSIONS_URL_TEMPLATE = "https://data.sec.gov/submissions/CIK{cik}.json"
ARCHIVES_URL_TEMPLATE = "https://www.sec.gov/Archives/edgar/data/{cik_no_zeros}/{accession_no_dashes}/{primary_doc}"

# Form types this platform cares about -> the DocumentCategory they map to.
# A dict, not a branching if/elif chain, so adding a new SEC form type
# later (e.g. "10-K/A" amendments) is a one-line addition here, not a new
# code branch elsewhere.
_RELEVANT_FORM_TYPES: dict[str, DocumentCategory] = {
    "10-K": DocumentCategory.FORM_10K,
    "20-F": DocumentCategory.FORM_20F,
    "DEF 14A": DocumentCategory.PROXY_STATEMENT,
}


@dataclass
class SecFilingCandidate:
    """A single SEC filing, ready to be validated/persisted by DocumentDiscoveryService."""

    document_name: str
    document_category: DocumentCategory
    document_type: DocumentType
    document_year: int | None
    official_url: str
    discovery_method: DiscoveryMethod = DiscoveryMethod.SEC_EDGAR_API


class _TickerCikCache:
    """
    In-process cache of SEC's ticker -> CIK mapping.

    Design decision: an in-memory cache on a module-level singleton, not a
    database table. This is external reference data SEC itself maintains
    and re-publishes — persisting our own copy would mean it silently goes
    stale, and correctness (always reflecting SEC's current mapping) is
    more important here than the modest cost of an occasional re-fetch.
    The cache exists purely to avoid re-fetching within a single discovery
    run across many companies, not to avoid it across runs.
    """

    def __init__(self) -> None:
        self._map: dict[str, str] | None = None  # uppercase ticker -> zero-padded CIK

    def _load(self) -> dict[str, str]:
        result = http_client.get(TICKER_MAP_URL)
        if not result.ok or result.text is None:
            raise DocumentSourceUnavailableError(
                f"Could not load SEC ticker-to-CIK mapping from {TICKER_MAP_URL}: {result.reason}"
            )
        try:
            raw = json.loads(result.text)
        except json.JSONDecodeError as exc:
            raise DocumentSourceUnavailableError(
                f"SEC ticker-to-CIK mapping at {TICKER_MAP_URL} was not valid JSON: {exc}"
            ) from exc

        # The file's shape is {"0": {"cik_str": 320193, "ticker": "AAPL", ...}, "1": {...}, ...}
        mapping: dict[str, str] = {}
        for entry in raw.values():
            ticker = entry.get("ticker")
            cik = entry.get("cik_str")
            if ticker and cik is not None:
                mapping[ticker.upper()] = str(cik).zfill(10)
        return mapping

    def get_cik(self, ticker: str) -> str | None:
        if self._map is None:
            self._map = self._load()
        return self._map.get(ticker.upper())


_ticker_cache = _TickerCikCache()


def discover_sec_filings(ticker: str | None) -> list[SecFilingCandidate]:
    """
    Discover 10-K/20-F/DEF 14A filings for a company by ticker.

    Returns an empty list (not an error) when `ticker` is None or the
    ticker has no CIK mapping — a private or non-US-listed company
    legitimately has no SEC filings, which is a normal outcome, not a
    failure. Raises DocumentSourceUnavailableError only when the SEC APIs
    themselves are unreachable/malformed (a whole-source failure — see
    that exception's docstring in core/exceptions.py).
    """
    if not ticker:
        return []

    cik = _ticker_cache.get_cik(ticker)
    if cik is None:
        logger.info("No SEC CIK found for ticker '%s' — skipping SEC EDGAR discovery.", ticker)
        return []

    submissions_url = SUBMISSIONS_URL_TEMPLATE.format(cik=cik)
    result = http_client.get(submissions_url)
    if not result.ok or result.text is None:
        raise DocumentSourceUnavailableError(
            f"Could not load SEC submissions for CIK {cik} (ticker {ticker}): {result.reason}"
        )

    try:
        submissions = json.loads(result.text)
    except json.JSONDecodeError as exc:
        raise DocumentSourceUnavailableError(
            f"SEC submissions response for CIK {cik} was not valid JSON: {exc}"
        ) from exc

    recent = submissions.get("filings", {}).get("recent", {})
    forms = recent.get("form", [])
    dates = recent.get("filingDate", [])
    accession_numbers = recent.get("accessionNumber", [])
    primary_documents = recent.get("primaryDocument", [])

    candidates: list[SecFilingCandidate] = []
    cik_no_zeros = str(int(cik))

    for form, filing_date, accession_number, primary_doc in zip(
        forms, dates, accession_numbers, primary_documents
    ):
        if form not in _RELEVANT_FORM_TYPES:
            continue

        category = _RELEVANT_FORM_TYPES[form]
        year = int(filing_date[:4]) if filing_date else None
        accession_no_dashes = accession_number.replace("-", "")

        url = ARCHIVES_URL_TEMPLATE.format(
            cik_no_zeros=cik_no_zeros,
            accession_no_dashes=accession_no_dashes,
            primary_doc=primary_doc,
        )

        candidates.append(
            SecFilingCandidate(
                document_name=f"{ticker.upper()} {form} ({year})" if year else f"{ticker.upper()} {form}",
                document_category=category,
                document_type=DocumentType.PDF if primary_doc.lower().endswith(".pdf") else DocumentType.HTML,
                document_year=year,
                official_url=url,
            )
        )

    logger.info("SEC EDGAR: found %d relevant filing(s) for ticker '%s'.", len(candidates), ticker)
    return candidates
