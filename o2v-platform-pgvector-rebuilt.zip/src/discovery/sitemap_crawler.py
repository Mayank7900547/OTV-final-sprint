"""
Company-website document discovery: sitemap parsing + heuristic path/
subdomain probing.

Design decision: two complementary, both non-LLM, strategies against a
company's own domain (Company.website from Sprint 1), run UNCONDITIONALLY
and merged (see `discover_web_documents`) — this was originally
fallback-only (heuristic probing only ran if the sitemap found nothing),
but live testing against apple.com showed that assumption was wrong: a
real sitemap can return a partial/thin result (Apple's found only an
About Us page) without being empty, so "the sitemap found something" is
not proof it found everything. Running both and merging by URL is the
fix — see `discover_web_documents`'s docstring for the full reasoning.

1. Sitemap crawl — fetch `{domain}/sitemap.xml`, parse the `<loc>`
   entries with the standard library's `xml.etree.ElementTree`
   (deliberately not a new dependency: sitemap XML is simple enough that
   pulling in lxml/BeautifulSoup for this one task isn't justified), and
   keep only URLs whose path classifies to a known DocumentCategory (see
   category_classifier.py). This is "structural URL discovery" — reading
   a site's own map of its pages — not "document parsing": we never read
   the CONTENT of what a URL points to, only its address, which keeps this
   squarely inside Sprint 2's scope (parsing PDF/HTML *content* is
   explicitly Sprint 3+).

2. Heuristic probing — construct candidate URLs the company's site
   conventionally uses and keep the ones that return HTTP 200. Two shapes:

   a. Path probes on the company's own root domain (e.g.
      `apple.com/investor-relations`).
   b. Subdomain-root probes (e.g. `investor.apple.com`) — several large
      companies host an entire section (most commonly Investor Relations,
      Sustainability/ESG, or Governance) on its own subdomain rather than
      a path, and a bare subdomain root has no path keywords for
      `classify_category` to match against, so it can't be found by
      sitemap crawling OR path-keyword classification. Both probe shapes
      are checked against a KNOWN, pre-assigned category (the dict key
      each candidate path/prefix is listed under) rather than
      re-classifying the resulting URL — see `_build_candidate` and the
      note in its docstring about why this also fixed a real bug.

   Every added path or subdomain prefix is one more HTTP request per
   company per discovery run, so this list is deliberately curated to
   real, common conventions rather than grown without bound — an
   unbounded guess-list would turn "polite discovery" into something
   closer to a scan.
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from urllib.parse import urljoin

from src.config.logging_config import get_logger
from src.core.constants import DiscoveryMethod, DocumentCategory
from src.discovery import http_client
from src.discovery.category_classifier import classify_category, classify_document_type, extract_year

logger = get_logger(__name__)

# Candidate paths per category, probed on the company's own root domain.
# Curated to real, common URL conventions across large corporate sites —
# see module docstring for why this is deliberately bounded, not
# exhaustive. Since discover_via_heuristic_probe assigns the category
# directly from the dict key (see _build_candidate), a path here no
# longer needs to itself contain a keyword classify_category would
# recognize — it only needs to be a real convention worth probing.
_HEURISTIC_PATHS: dict[DocumentCategory, tuple[str, ...]] = {
    DocumentCategory.INVESTOR_RELATIONS: (
        "/investor-relations",
        "/investors",
        "/ir",
        "/en/investors",
        "/company/investors",
    ),
    DocumentCategory.SUSTAINABILITY_REPORT: (
        "/sustainability",
        "/sustainability-report",
        "/en/sustainability",
    ),
    DocumentCategory.ESG_REPORT: (
        "/esg",
        "/esg-report",
    ),
    DocumentCategory.CODE_OF_CONDUCT: (
        "/code-of-conduct",
        # Regression: this path was already listed here before this
        # change but classify_category("/business-conduct") returns
        # UNKNOWN (no keyword matches "business-conduct"), so
        # _candidate_from_url silently dropped it even on a 200 response
        # — a dead entry since Sprint 2's original build. Fixed by
        # assigning category from the dict key instead of re-classifying.
        "/business-conduct",
        "/governance/code-of-conduct",
    ),
    DocumentCategory.BUSINESS_ETHICS: (
        "/business-ethics",
        "/ethics",
    ),
    DocumentCategory.CORPORATE_GOVERNANCE_REPORT: (
        "/governance",
        "/corporate-governance",
        "/investors/governance",
    ),
    DocumentCategory.ABOUT_US: (
        "/about",
        "/about-us",
        "/company/about-us",
    ),
    DocumentCategory.ANNUAL_REPORT: (
        "/annual-report",
        "/annual-reports",
        "/investors/annual-reports",
    ),
    DocumentCategory.PROXY_STATEMENT: (
        "/proxy-statement",
        "/proxy",
    ),
    DocumentCategory.CORPORATE_RESPONSIBILITY_REPORT: (
        "/corporate-responsibility",
        "/csr",
    ),
    DocumentCategory.CEO_LETTER: (
        "/ceo-letter",
        "/letter-to-shareholders",
    ),
}

# Subdomain prefixes probed at their bare root (e.g. "investor" ->
# https://investor.{company-domain}/) — see module docstring, strategy 2b.
# Kept to categories where hosting an entire subdomain (rather than a
# path) is a genuinely common real-world pattern; not every category has
# one. A prefix appears under exactly one category here, even though a
# term like "esg" could plausibly overlap with Sustainability, to avoid
# probing the same URL twice under two different assigned categories.
_HEURISTIC_SUBDOMAINS: dict[DocumentCategory, tuple[str, ...]] = {
    DocumentCategory.INVESTOR_RELATIONS: ("investor", "investors", "ir"),
    DocumentCategory.SUSTAINABILITY_REPORT: ("sustainability",),
    DocumentCategory.ESG_REPORT: ("esg",),
    DocumentCategory.CORPORATE_GOVERNANCE_REPORT: ("governance",),
}

# XML namespace used by the sitemap protocol (sitemaps.org) — sitemap.xml
# files declare this namespace, so <loc> tags must be looked up with it.
_SITEMAP_NS = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}


@dataclass
class WebDocumentCandidate:
    """A single company-site document candidate, ready for validation/persistence."""

    document_name: str
    document_category: DocumentCategory
    document_type: str
    document_year: int | None
    official_url: str
    discovery_method: DiscoveryMethod


def _bare_domain(website: str) -> str:
    """
    Strip scheme, path, and a leading "www." from a company's website
    string, leaving just the registrable-ish domain — e.g.
    "https://www.apple.com/" or "apple.com" -> "apple.com" — so it can be
    used as the parent domain for subdomain probing
    (f"https://investor.{bare_domain}").
    """
    domain = website.split("://", 1)[-1]
    domain = domain.split("/", 1)[0]
    if domain.startswith("www."):
        domain = domain[len("www.") :]
    return domain


def _build_candidate(
    url: str, method: DiscoveryMethod, company_name: str, category: DocumentCategory
) -> WebDocumentCandidate:
    """
    Build a candidate for a KNOWN category — used by heuristic probing
    (both path- and subdomain-based), where the category is already known
    from which dict entry produced this URL, so re-running keyword
    classification on the URL is both unnecessary and, for a bare
    subdomain root with no path (e.g. "https://investor.apple.com/"),
    would always fail (classify_category has nothing to match against an
    empty/root path). This is also what fixed the "/business-conduct"
    dead-entry bug — see _HEURISTIC_PATHS' CODE_OF_CONDUCT comment.
    """
    year = extract_year(url)
    doc_type = classify_document_type(url)
    label = category.value.replace("_", " ").title()
    name = f"{company_name} {label} ({year})" if year else f"{company_name} {label}"
    return WebDocumentCandidate(
        document_name=name,
        document_category=category,
        document_type=doc_type.value,
        document_year=year,
        official_url=url,
        discovery_method=method,
    )


def _candidate_from_url(url: str, method: DiscoveryMethod, company_name: str) -> WebDocumentCandidate | None:
    """
    Build a candidate for a sitemap-discovered URL, whose category is NOT
    known in advance — classify it by keyword match, and return None
    (not a candidate) if nothing matches. Only used for sitemap crawling;
    heuristic probing knows its category ahead of time (see
    _build_candidate).
    """
    category = classify_category(url)
    if category == DocumentCategory.UNKNOWN:
        return None
    return _build_candidate(url, method, company_name, category)


def _parse_sitemap_urls(xml_text: str) -> list[str]:
    """Extract every <loc> URL from a sitemap.xml document. Returns [] on any parse failure."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    return [loc.text.strip() for loc in root.findall(".//sm:loc", _SITEMAP_NS) if loc.text]


def discover_via_sitemap(website: str, company_name: str) -> list[WebDocumentCandidate]:
    """
    Attempt sitemap-based discovery. Returns [] (not an error) if no usable
    sitemap is found — the caller (DocumentDiscoveryService) falls back to
    heuristic probing in that case, which is an expected, ordinary path,
    not a failure condition.
    """
    sitemap_url = urljoin(website if website.startswith("http") else f"https://{website}", "/sitemap.xml")
    result = http_client.get(sitemap_url)
    if not result.ok or result.text is None:
        logger.info("No usable sitemap at %s (%s) — will fall back to heuristic probing.", sitemap_url, result.reason)
        return []

    urls = _parse_sitemap_urls(result.text)
    candidates = []
    for url in urls:
        candidate = _candidate_from_url(url, DiscoveryMethod.SITEMAP_CRAWL, company_name)
        if candidate:
            candidates.append(candidate)

    logger.info("Sitemap crawl of %s: %d relevant URL(s) out of %d total.", sitemap_url, len(candidates), len(urls))
    return candidates


def _probe_paths(base: str, company_name: str) -> list[WebDocumentCandidate]:
    """Probe every conventional path in _HEURISTIC_PATHS against the company's own root domain."""
    candidates: list[WebDocumentCandidate] = []
    for category, paths in _HEURISTIC_PATHS.items():
        for path in paths:
            url = urljoin(base, path)
            result = http_client.get(url)
            if not result.ok:
                logger.debug("Heuristic path probe miss: %s (%s)", url, result.reason)
                continue
            candidates.append(_build_candidate(url, DiscoveryMethod.HEURISTIC_PROBE, company_name, category))
    return candidates


def _probe_subdomains(bare_domain: str, company_name: str) -> list[WebDocumentCandidate]:
    """Probe every conventional subdomain root in _HEURISTIC_SUBDOMAINS (e.g. investor.<domain>)."""
    candidates: list[WebDocumentCandidate] = []
    for category, prefixes in _HEURISTIC_SUBDOMAINS.items():
        for prefix in prefixes:
            url = f"https://{prefix}.{bare_domain}/"
            result = http_client.get(url)
            if not result.ok:
                logger.debug("Heuristic subdomain probe miss: %s (%s)", url, result.reason)
                continue
            candidates.append(_build_candidate(url, DiscoveryMethod.HEURISTIC_PROBE, company_name, category))
    return candidates


def discover_via_heuristic_probe(website: str, company_name: str) -> list[WebDocumentCandidate]:
    """
    Probe conventional paths on the company's own root domain AND
    conventional subdomain roots (e.g. investor.<domain>) — see module
    docstring, strategy 2. Runs unconditionally alongside sitemap
    discovery, not only as a fallback — see discover_web_documents.
    """
    base = website if website.startswith("http") else f"https://{website}"
    bare_domain = _bare_domain(website)

    candidates = _probe_paths(base, company_name)
    candidates.extend(_probe_subdomains(bare_domain, company_name))

    logger.info(
        "Heuristic probe of %s: %d path/subdomain candidate(s) responded with a relevant page.",
        base,
        len(candidates),
    )
    return candidates


def discover_web_documents(website: str | None, company_name: str) -> list[WebDocumentCandidate]:
    """
    Top-level entry point: run BOTH sitemap discovery and heuristic
    path/subdomain probing, merged and deduplicated by URL. Returns []
    immediately if the company has no registered website — there is
    nothing to crawl.

    Design decision (revised after live testing against apple.com): this
    used to run heuristic probing only as a FALLBACK when the sitemap
    returned nothing at all. That assumption — "the sitemap found
    something, so it must be comprehensive enough" — turned out to be
    wrong in practice: Apple's real sitemap.xml returned exactly one
    relevant match (an About Us page) and nothing for Sustainability,
    Code of Conduct, or Investor Relations, even though those pages
    demonstrably exist at their conventional heuristic paths. A sitemap
    finding ONE relevant page is not evidence it lists ALL relevant pages,
    so "found something" is the wrong trigger for skipping the fallback.

    Running both unconditionally costs a small, bounded number of extra
    HTTP requests per company (one per entry in _HEURISTIC_PATHS plus one
    per entry in _HEURISTIC_SUBDOMAINS) — cheap relative to correctness
    here, especially since `http_client.get` already rate-limits and
    short-circuits 4xx responses without retrying.
    """
    if not website:
        return []

    sitemap_results = discover_via_sitemap(website, company_name)
    heuristic_results = discover_via_heuristic_probe(website, company_name)

    # Merge, deduplicating by URL — the same page can legitimately be
    # found by both strategies (e.g. a sitemap that DOES list
    # /sustainability AND the heuristic probe independently finding the
    # same path); keep the sitemap version when both find the same URL,
    # since sitemap discovery required no path-guessing and is the
    # stronger signal of the two.
    seen_urls = {c.official_url for c in sitemap_results}
    merged = list(sitemap_results)
    for candidate in heuristic_results:
        if candidate.official_url not in seen_urls:
            merged.append(candidate)
            seen_urls.add(candidate.official_url)

    return merged
