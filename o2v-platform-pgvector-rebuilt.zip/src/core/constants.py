"""
Core constants for the O2V Platform.

Design decision: constants that describe *domain concepts* (statuses, defaults)
live here, separate from `config/settings.py` (which holds *environment-specific*
configuration like DB credentials or log level). This split matters because
constants here are the same in every environment (dev/staging/prod), while
settings.py values change per environment. Mixing the two makes it unclear
which values are safe to change freely vs. which require an env var.
"""

from enum import Enum


class CompanyStatus(str, Enum):
    """
    Lifecycle status of a company as it moves through the platform pipeline.

    Only PENDING/IN_PROGRESS/DONE/FAILED are needed in Sprint 1 (no pipeline
    stages exist yet — companies are just registered). The enum is deliberately
    named around *pipeline* status, not "row state," so later sprints
    (Discovery, Extraction, etc.) can reuse it directly instead of each
    stage inventing its own status vocabulary.
    """

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    FAILED = "failed"


class Environment(str, Enum):
    """Deployment environment — drives config defaults (see config/settings.py)."""

    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"


class DocumentCategory(str, Enum):
    """
    The content classification of a discovered document.

    Deliberately mirrors the `document_sources` vocabulary already used in
    the Framework Registry's field definitions (see data/frameworks/o2v.yaml,
    e.g. a Purpose field expects sources ["Annual Report", "About Us Page"]).
    Keeping the two vocabularies aligned (even though they're stored in
    different tables) is what will let Sprint 3+ join "this field needs an
    Annual Report" against "here are the Annual Reports we discovered for
    this company" without a translation layer between them.
    """

    ANNUAL_REPORT = "annual_report"
    FORM_10K = "form_10k"
    FORM_20F = "form_20f"
    ESG_REPORT = "esg_report"
    SUSTAINABILITY_REPORT = "sustainability_report"
    CORPORATE_GOVERNANCE_REPORT = "corporate_governance_report"
    CODE_OF_CONDUCT = "code_of_conduct"
    BUSINESS_ETHICS = "business_ethics"
    CEO_LETTER = "ceo_letter"
    ABOUT_US = "about_us"
    INVESTOR_RELATIONS = "investor_relations"
    PROXY_STATEMENT = "proxy_statement"
    CORPORATE_RESPONSIBILITY_REPORT = "corporate_responsibility_report"
    AI_TECHNOLOGY_REPORT = "ai_technology_report"
    UNKNOWN = "unknown"


class DocumentType(str, Enum):
    """
    The file format/medium of a discovered document — distinct from
    `DocumentCategory` (which describes *content*, not *format*). A
    Sustainability Report and a Code of Conduct can both be a PDF; this
    field is what a later download-stage sprint will branch on to decide
    which fetch strategy to use.
    """

    PDF = "pdf"
    HTML = "html"
    UNKNOWN = "unknown"


class DiscoveryMethod(str, Enum):
    """
    How a document's URL was found. Stored per-row (not just logged) because
    it materially affects trust: an SEC EDGAR API result is authoritative,
    while a heuristic path-guess is a best-effort probe that happened to
    return 200. Later validation/review stages can weight confidence by
    this field without re-deriving it.
    """

    SEC_EDGAR_API = "sec_edgar_api"
    SITEMAP_CRAWL = "sitemap_crawl"
    HEURISTIC_PROBE = "heuristic_probe"
    MANUAL = "manual"


class DocumentStatus(str, Enum):
    """
    Reachability status of a discovered document URL as of `last_checked`.

    Sprint 2 only ever writes DISCOVERED or UNREACHABLE (a URL either
    validated successfully or it didn't). STALE is reserved for a future
    re-check job (Sprint 2+/3) that revisits previously-discovered URLs on
    a schedule and marks ones that have gone dead since — the column and
    enum value exist now so that job doesn't need a schema migration later.
    """

    DISCOVERED = "discovered"
    UNREACHABLE = "unreachable"
    STALE = "stale"


class EvidenceConfidence(str, Enum):
    """
    Confidence level assigned to a Sprint 8 field extraction.

    No prior sprint establishes this vocabulary — Sprint 8 is where it's
    introduced, per the Sprint 8 brief's "If the repository already defines
    High/Medium/Low, use those definitions" instruction (it doesn't yet, so
    this IS that definition, for every later sprint to reuse rather than
    reinvent). Semantics, applied by `src/extraction/extraction_service.py`:

    - HIGH: evidence explicitly and unambiguously supports the field, in
      the organization's own language, from a single clear source (or
      multiple agreeing official sources).
    - MEDIUM: evidence supports the field but requires some interpretation
      (e.g. the literal O2V terminology is absent, or evidence is thin/
      partial), OR sources agree but only one is genuinely authoritative.
    - LOW: evidence is tangentially related, or the model surfaced a
      genuine conflict between sources it could not resolve via the
      source-priority hierarchy.

    NOT_FOUND is deliberately a separate value from LOW, not an even-lower
    tier of LOW — per the Sprint 8 brief's "Not Found is a valid extraction
    result", it's a distinct outcome (no exact_text at all), not "evidence
    of confidence lower than Low".
    """

    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    NOT_FOUND = "Not Found"


class ExtractionStatus(str, Enum):
    """
    Outcome status of one Sprint 8 field-extraction attempt (one
    `ExtractionService.extract_field()` call) — mirrors the
    "SKIPPED/FAILED as data, not exceptions" convention `RetrievalOutcome`
    (Sprint 7) and `EmbeddingOutcome` (Sprint 6) already established.
    """

    SUCCESS = "SUCCESS"  # LLM call + JSON parsing succeeded (result may still be Not Found — see EvidenceConfidence)
    NO_EVIDENCE = "NO_EVIDENCE"  # Sprint 7 supplied zero evidence rows for this company/component — LLM was never called
    PROVIDER_ERROR = "PROVIDER_ERROR"  # LLM provider unreachable/errored after retries exhausted
    PARSE_ERROR = "PARSE_ERROR"  # LLM responded but output could not be parsed/validated as the extraction schema after retries


# Default pagination size for CLI/list commands. Centralized so every
# "list" command (companies, frameworks, ...) behaves consistently without
# each command hardcoding its own number.
DEFAULT_PAGE_SIZE = 50

# Name of the environment variable that points to an alternate .env file.
# Lets CI or Docker override which env file is loaded without touching code.
ENV_FILE_VAR = "O2V_ENV_FILE"
