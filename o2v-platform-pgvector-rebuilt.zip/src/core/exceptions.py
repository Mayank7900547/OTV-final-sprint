"""
Custom exception hierarchy.

Design decision: every layer of the app (services, registry, CLI) raises
these instead of bare Exceptions / letting SQLAlchemy errors bubble up
unwrapped. This gives us two things later sprints will depend on:

1. The CLI can catch `O2VError` at the top level and print a clean message
   instead of a raw Python traceback to end users.
2. When we add the orchestration layer (Sprint 3+), workers can distinguish
   "this failed in a way that's retryable" (e.g. DatabaseError) from
   "this failed in a way that's a data problem and needs human attention"
   (e.g. ValidationError) — that distinction is core to the failure-handling
   design in the architecture doc, so it's worth establishing the vocabulary
   now even though nothing retries yet.
"""


class O2VError(Exception):
    """Base class for all platform-specific errors."""


class ConfigurationError(O2VError):
    """Raised when required configuration/environment variables are missing or invalid."""


class DatabaseError(O2VError):
    """Raised when a database operation fails in a way the caller should know about."""


class RegistryError(O2VError):
    """Raised for problems in the Company or Framework registries (e.g. duplicate entries)."""


class FrameworkValidationError(RegistryError):
    """Raised when a framework definition file (YAML) is malformed or incomplete."""


class CompanyImportError(RegistryError):
    """Raised when a company import file (CSV) is malformed or a row fails validation."""


class DiscoveryError(O2VError):
    """
    Base class for Document Discovery failures.

    Deliberately a SEPARATE branch from RegistryError, not a subclass of it —
    Discovery reads from the Company/Framework registries but is its own
    subsystem with its own failure modes (network, external API shape
    changes) that have nothing to do with "duplicate entry" style registry
    errors. Keeping them siblings under O2VError (rather than nesting
    Discovery under Registry) keeps `except RegistryError` from accidentally
    swallowing network failures it was never designed to handle.
    """


class DocumentSourceUnavailableError(DiscoveryError):
    """
    Raised when a discovery source (SEC EDGAR API, a company's own site) is
    unreachable or returns an unexpected shape for an ENTIRE company's
    discovery run — not for a single rejected/unreachable candidate URL.

    Deliberately distinct from a single URL being unreachable (that's just
    recorded as DocumentStatus.UNREACHABLE, not an exception — see
    DocumentDiscoveryService) — this exception is for the case where
    discovery couldn't even attempt candidates for a company (e.g. SEC's
    ticker-to-CIK mapping file itself failed to load). The distinction
    matters for the "one company's failure shouldn't block the batch"
    requirement: this exception is caught and logged per-company by
    `discover_for_all_companies`, exactly like the architecture doc's
    failure-handling design calls for.
    """
