"""
Document Registry model.

Design decision: `official_url` carries a UNIQUE constraint scoped to
`company_id` (not globally unique) — the same URL could theoretically be
relevant to two different companies in edge cases (a shared IR platform
page, unlikely but not impossible), and scoping the constraint to
`company_id` is what actually enforces "prevent duplicates" as specified
in the Sprint 2 brief: the same company can't have the same URL registered
twice, which is the dedup guarantee that matters. This mirrors the
`Company.name` unique-constraint pattern from Sprint 1 — the DB constraint
is the last line of defense; the primary dedup check happens in
`services/document_service.py` before an insert is even attempted, for
the same reason Sprint 1's company import checks by name before writing
(a clean "already exists, skipping" message beats a raw IntegrityError).

A ForeignKey to `companies.id` with `ondelete="CASCADE"` means deleting a
company also removes its discovered documents — appropriate here because
a Document Registry row has no meaning independent of the company it was
discovered for (unlike, say, a Framework row, which is meaningful on its
own and correctly has no such relationship).
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.core.constants import DocumentStatus
from src.database.base import Base


class DocumentRegistry(Base):
    __tablename__ = "document_registry"
    __table_args__ = (
        UniqueConstraint("company_id", "official_url", name="uq_document_company_url"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    company_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("companies.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    document_name: Mapped[str] = mapped_column(String(500), nullable=False)
    # Stored as plain strings (not DB-level enum types) for the same reason
    # Company.status and Framework's flat fields are — adding a new
    # DocumentCategory value later (see core/constants.py) never requires a
    # migration, just a new Python enum member. Validity is enforced at the
    # application layer (Pydantic-free here since this is an ORM model, but
    # the service layer only ever writes values from the constants.py enums).
    document_category: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    document_type: Mapped[str] = mapped_column(String(20), nullable=False)
    document_year: Mapped[int | None] = mapped_column(nullable=True)

    official_url: Mapped[str] = mapped_column(String(1000), nullable=False)
    source_domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    discovery_method: Mapped[str] = mapped_column(String(50), nullable=False)

    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=DocumentStatus.DISCOVERED.value, index=True
    )
    last_checked: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<DocumentRegistry id={self.id} company_id={self.company_id} "
            f"category={self.document_category} url={self.official_url!r}>"
        )
