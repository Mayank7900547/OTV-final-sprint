"""
Company Registry model.

Design decision: `ticker` and `website` are nullable (not every private
company has a ticker), but `name` has a unique constraint — the Company
Registry's whole job (per the architecture doc) is to be the single
source of truth keyed by identity, so silently allowing duplicate "Apple
Inc." rows would undermine that from day one. Dedup-on-import logic lives
in the service layer (see services/company_service.py); the DB constraint
is the last line of defense, not the primary mechanism, since a good error
message from the service is more useful than a raw IntegrityError.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.core.constants import CompanyStatus
from src.database.base import Base


class Company(Base):
    __tablename__ = "companies"
    __table_args__ = (UniqueConstraint("name", name="uq_companies_name"),)

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    ticker: Mapped[str | None] = mapped_column(String(20), nullable=True)
    website: Mapped[str | None] = mapped_column(String(500), nullable=True)
    sector: Mapped[str | None] = mapped_column(String(255), nullable=True)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)

    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default=CompanyStatus.PENDING.value
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return f"<Company id={self.id} name={self.name!r} status={self.status}>"
