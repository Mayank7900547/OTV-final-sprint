"""
Framework Registry model.

Design decision: this is a single flat table (framework_name, component_name,
field_name, description, document_sources) rather than three normalized
tables (frameworks -> components -> fields) as sketched in the platform
architecture doc.

This is a conscious simplification for Sprint 1, matching the exact schema
requested: a flat row-per-field model is the simplest thing that satisfies
"add O2V, COSO, Balanced Scorecard, ESG, ISO 27001 without changing code" —
inserting a new framework is still just inserting new rows, no schema
change required. The normalized 3-table version becomes worth the added
join complexity once we need referential integrity across many frameworks
sharing components, or per-component metadata beyond what's needed here;
that's a natural Sprint 2+ refinement, not a Sprint 1 requirement, and
migrating from flat to normalized later is a straightforward migration
(group by framework_name/component_name) rather than a redesign.

A unique constraint on (framework_name, component_name, field_name) is the
mechanism that actually prevents "code changes needed" from creeping back
in: it makes re-importing the same YAML file idempotent (upsert) instead
of accumulating duplicate rows every time `framework import` is run.
"""

import uuid
from datetime import datetime

from sqlalchemy import ARRAY, DateTime, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from src.database.base import Base


class Framework(Base):
    __tablename__ = "frameworks"
    __table_args__ = (
        UniqueConstraint(
            "framework_name",
            "component_name",
            "field_name",
            name="uq_framework_component_field",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    framework_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    component_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    field_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Postgres ARRAY, not a comma-joined string — keeps "which document types
    # matter for this field" queryable (e.g. "find all fields expecting a
    # Code of Conduct") rather than requiring string-splitting at query time.
    document_sources: Mapped[list[str] | None] = mapped_column(
        ARRAY(String(255)), nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<Framework {self.framework_name}/{self.component_name}/"
            f"{self.field_name}>"
        )
