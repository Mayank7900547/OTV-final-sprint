"""Typer CLI integration for Sprint 7 Semantic Evidence Retrieval — mirrors `src/embeddings/cli.py`'s shape."""

from __future__ import annotations

import uuid

import typer
from rich.console import Console
from rich.table import Table

from src.database.connection import session_scope
from src.models.company import Company
from src.retrieval.models import RetrievedEvidence
from src.retrieval.query_generator import available_components
from src.retrieval.retrieval_service import RetrievalService
from src.retrieval.telemetry import telemetry

retrieval_app = typer.Typer(name="retrieval", help="Sprint 7 Semantic Evidence Retrieval CLI")
show_app = typer.Typer(help="Inspect retrieved evidence and retrieval statistics.")
retrieval_app.add_typer(show_app, name="show")

console = Console()


def _resolve_company(session, company: str) -> Company | None:
    """Accepts either a company UUID or a name substring — same convenience the chunking/embeddings CLIs give for company scoping."""
    try:
        company_id = uuid.UUID(company)
        return session.query(Company).filter(Company.id == company_id).first()
    except ValueError:
        return session.query(Company).filter(Company.name.ilike(f"%{company}%")).first()


def _print_outcome(outcome: dict) -> None:
    status = outcome.get("status")
    color = {"SUCCESS": "green", "FAILED": "red", "NO_RELEVANT_EVIDENCE": "yellow"}.get(status, "white")
    console.print(f"[{color}]{status}[/{color}] component={outcome.get('component')}")
    if status == "SUCCESS":
        console.print(
            f"  request_id={outcome.get('request_id')} candidates={outcome.get('candidate_count')} "
            f"final_evidence={outcome.get('final_evidence_count')} relaxations={outcome.get('threshold_relaxations')} "
            f"avg_semantic_score={outcome.get('average_semantic_score')} time={outcome.get('retrieval_duration')}s"
        )
    elif status == "NO_RELEVANT_EVIDENCE":
        console.print(
            f"  request_id={outcome.get('request_id')} candidates={outcome.get('candidate_count')} "
            f"relaxations={outcome.get('threshold_relaxations')} — no candidates survived even after relaxation."
        )
    elif outcome.get("error"):
        console.print(f"  — {outcome['error']}")


def _print_summary() -> None:
    summary = telemetry.get_summary()
    console.print("\n=== RETRIEVAL TELEMETRY ===")
    console.print(f"Requests            : {summary['retrieval_requests']}")
    console.print(f"Successful          : {summary['successful_retrievals']}")
    console.print(f"Failed              : {summary['failed_retrievals']}")
    console.print(f"Empty results       : {summary['empty_result_count']}")
    console.print(f"Empty-result rate   : {summary['empty_result_rate']}")
    console.print(f"Avg latency (s)     : {summary['average_latency']}")
    console.print(f"Avg candidate count : {summary['average_candidate_count']}")
    console.print(f"Avg evidence count  : {summary['average_final_evidence_count']}")
    console.print(f"Avg similarity      : {summary['average_similarity']}")
    console.print(f"Active provider     : {summary['active_provider'] or '-'}")
    console.print("============================")


# --------------------------------------------------------------------------
# retrieve
# --------------------------------------------------------------------------


@retrieval_app.command("retrieve")
def retrieve(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(..., "--component", help="O2V component, e.g. Purpose, Behaviour, Value Agenda."),
    document: str = typer.Option(None, "--document", help="Optional: scope retrieval to a single DocumentRegistry UUID."),
    framework: str = typer.Option(None, "--framework", help="Framework name to derive queries from (default: settings.retrieval_framework_name)."),
) -> None:
    """Retrieve evidence for one company + O2V component — covers 'retrieve by company/document/component' conceptually."""
    with session_scope() as session:
        company_row = _resolve_company(session, company)
        if company_row is None:
            console.print(f"[yellow]No company found matching '{company}'.[/yellow]")
            return

        service = RetrievalService()
        outcome = service.retrieve_evidence(
            session,
            company_id=company_row.id,
            component=component,
            document_id=uuid.UUID(document) if document else None,
            framework_name=framework,
        )

    _print_outcome(outcome)


@retrieval_app.command("refresh-all")
def refresh_all(
    framework: str = typer.Option(None, "--framework", help="Framework name (default: settings.retrieval_framework_name)."),
) -> None:
    """
    Re-runs retrieval for every (company, component) pair that already has
    RetrievedEvidence rows, producing a fresh, newer batch for each. For
    after new chunks get embedded post-hoc (e.g. a retry-failed run) —
    extraction (Sprint 8) always reads the MOST RECENT request_id per
    company/component (see extraction_service.py's _load_evidence), so a
    fresh run here is what lets newly embedded chunks actually be
    considered for the shortlist, without needing to delete or touch the
    older evidence rows at all — they're just superseded by recency.
    """
    with session_scope() as session:
        pairs = (
            session.query(RetrievedEvidence.company_id, RetrievedEvidence.component)
            .distinct()
            .order_by(RetrievedEvidence.company_id, RetrievedEvidence.component)
            .all()
        )
        console.print(f"Found {len(pairs)} (company, component) pairs with existing evidence. Refreshing each...")

        service = RetrievalService()
        succeeded = 0
        failed = 0
        for company_id, component in pairs:
            outcome = service.retrieve_evidence(
                session, company_id=company_id, component=component, framework_name=framework
            )
            if outcome.get("status") == "SUCCESS":
                succeeded += 1
            else:
                failed += 1
            _print_outcome(outcome)

    console.print(f"\n[green]Refreshed: {succeeded}[/green]  [red]Failed/no evidence: {failed}[/red]")


@show_app.command("components")
def show_components(framework: str = typer.Option("O2V", "--framework", help="Framework name.")) -> None:
    """List O2V components available for retrieval under a framework (from imported Framework rows)."""
    with session_scope() as session:
        components = available_components(session, framework_name=framework)

    if not components:
        console.print(f"[yellow]No components found for framework '{framework}'. Has it been imported?[/yellow]")
        return
    for name in components:
        console.print(f"- {name}")


@show_app.command("candidates")
def show_candidates(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(..., "--component", help="O2V component."),
    limit: int = typer.Option(20, help="Max rows to preview."),
) -> None:
    """Preview the most recent retrieval's raw candidate scores for a company + component (pre-final-pool detail)."""
    with session_scope() as session:
        company_row = _resolve_company(session, company)
        if company_row is None:
            console.print(f"[yellow]No company found matching '{company}'.[/yellow]")
            return
        rows = (
            session.query(RetrievedEvidence)
            .filter(RetrievedEvidence.company_id == company_row.id, RetrievedEvidence.component == component)
            .order_by(RetrievedEvidence.retrieval_timestamp.desc(), RetrievedEvidence.rank.asc())
            .limit(limit)
            .all()
        )

    if not rows:
        console.print(f"[yellow]No retrieved evidence found for '{company}' / {component}. Run 'retrieval retrieve' first.[/yellow]")
        return

    table = Table(title=f"Candidates: {company_row.name} / {component} (showing {len(rows)})")
    table.add_column("Rank")
    table.add_column("Semantic")
    table.add_column("Lexical")
    table.add_column("Metadata")
    table.add_column("Final")
    table.add_column("Page")
    table.add_column("Section")
    table.add_column("Text")
    for r in rows:
        table.add_row(
            str(r.rank), f"{r.semantic_score:.3f}", f"{r.lexical_score:.3f}", f"{r.metadata_score:.3f}",
            f"{r.final_score:.3f}", str(r.page_number or "-"), (r.section_title or "-")[:30], r.chunk_text[:60],
        )
    console.print(table)


@show_app.command("evidence")
def show_evidence(
    company: str = typer.Option(..., "--company", help="Company UUID or name substring."),
    component: str = typer.Option(..., "--component", help="O2V component."),
    limit: int = typer.Option(100, help="Max rows to display."),
) -> None:
    """Preview the final evidence pool (same data as 'show candidates' — alias for the brief's 'preview final evidence' operation)."""
    show_candidates(company=company, component=component, limit=limit)


@show_app.command("statistics")
def show_statistics() -> None:
    """Show cumulative telemetry for this process's retrieval activity."""
    _print_summary()
