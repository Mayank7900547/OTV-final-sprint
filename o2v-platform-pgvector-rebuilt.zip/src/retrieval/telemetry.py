"""
In-process metrics collector for retrieval activity -- mirrors
`src.embeddings.telemetry.EmbeddingTelemetry`'s shape, with the fields
the Sprint 7 brief's "Telemetry" section specifically calls out:
candidate counts, final evidence counts, average similarity, and
empty-result rate.
"""

from __future__ import annotations

import threading

from src.retrieval.types import RetrievalSummary


class RetrievalTelemetry:
    def __init__(self):
        self.retrieval_requests: int = 0
        self.successful_retrievals: int = 0
        self.failed_retrievals: int = 0
        self.empty_result_count: int = 0
        self.total_duration_seconds: float = 0.0
        self.total_candidate_count: int = 0
        self.total_final_evidence_count: int = 0
        self.total_similarity: float = 0.0
        self.similarity_samples: int = 0
        self.active_provider: str = ""
        self._lock = threading.Lock()

    def record_request(self) -> None:
        with self._lock:
            self.retrieval_requests += 1

    def record_success(
        self, *, duration: float, candidate_count: int, final_evidence_count: int, average_similarity: float, provider: str
    ) -> None:
        with self._lock:
            self.successful_retrievals += 1
            self.total_duration_seconds += duration
            self.total_candidate_count += candidate_count
            self.total_final_evidence_count += final_evidence_count
            if final_evidence_count > 0:
                self.total_similarity += average_similarity
                self.similarity_samples += 1
            self.active_provider = provider
            if final_evidence_count == 0:
                self.empty_result_count += 1

    def record_failure(self) -> None:
        with self._lock:
            self.failed_retrievals += 1

    def get_summary(self) -> RetrievalSummary:
        with self._lock:
            attempted = self.successful_retrievals + self.failed_retrievals
            average_latency = (
                round(self.total_duration_seconds / self.successful_retrievals, 4)
                if self.successful_retrievals
                else 0.0
            )
            average_candidate_count = (
                round(self.total_candidate_count / self.successful_retrievals, 1)
                if self.successful_retrievals
                else 0.0
            )
            average_final_evidence_count = (
                round(self.total_final_evidence_count / self.successful_retrievals, 1)
                if self.successful_retrievals
                else 0.0
            )
            average_similarity = (
                round(self.total_similarity / self.similarity_samples, 4) if self.similarity_samples else 0.0
            )
            empty_result_rate = round(self.empty_result_count / attempted, 4) if attempted else 0.0
            return {
                "retrieval_requests": self.retrieval_requests,
                "successful_retrievals": self.successful_retrievals,
                "failed_retrievals": self.failed_retrievals,
                "empty_result_count": self.empty_result_count,
                "average_latency": average_latency,
                "average_candidate_count": average_candidate_count,
                "average_final_evidence_count": average_final_evidence_count,
                "average_similarity": average_similarity,
                "empty_result_rate": empty_result_rate,
                "active_provider": self.active_provider,
            }

    def reset(self) -> None:
        with self._lock:
            self.__init__()  # noqa: PLC2801 - deliberate reinitialization, matches other telemetry.py modules' pattern


telemetry = RetrievalTelemetry()
