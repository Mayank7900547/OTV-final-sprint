"""
Retrieval Service — Sprint 7 orchestration layer.

Pipeline (per the brief's "Core Pipeline" section):

    generate multi-queries (query_generator.py, from Framework rows)
        -> semantic search per query (semantic_search.py, via Sprint 6 provider/vector store)
        -> lexical search per query (lexical_search.py, Postgres FTS)
        -> build EvidenceCandidates, compute per-query metadata_score
        -> similarity-threshold filtering, with relaxation if empty (recall protection)
        -> optional post-hoc metadata filters (validation.py)
        -> reranker.rerank(): merge -> dedup -> hybrid score -> sort -> diversify
        -> persist RetrievedEvidence rows (models.py)

Design decision: `company_id` and `component` are required, dedicated
parameters (not entries in a generic filters dict) because every
`RetrievedEvidence` row's data model requires both -- this is fundamentally
"retrieve evidence for THIS company's THIS O2V component", not a general
search endpoint. `document_id` is an optional secondary scope (retrieve
within one document). Everything else the brief's "Metadata Filtering"
section lists (document_type, date, section, page, source) goes through
`extra_filters`, applied AFTER retrieval+threshold (not narrowing the
initial candidate pool) — per the brief's "Filtering must not
accidentally eliminate semantically relevant evidence when a filter was
not explicitly requested", narrowing recall-critical early retrieval
with anything beyond company/document scope risks exactly that.

Design decision: never raises for an empty result. Per the brief's
"No-Result Behaviour" section, an empty evidence pool after full
threshold relaxation is a legitimate, expected OUTCOME (`status:
"NO_RELEVANT_EVIDENCE"`), not an error — same "SKIPPED/FAILED as data,
not exceptions" convention `DocumentChunkingService`/
`EmbeddingGenerationService` already established. `NoRelevantEvidenceError`
(see exceptions.py) remains available for a caller that specifically
wants to raise on this outcome, but the service itself doesn't.
"""

from __future__ import annotations

import time

from sqlalchemy.orm import Session

from src.chunking.models import Chunk
from src.config.logging_config import get_logger
from src.config.settings import settings
from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.embedding_factory import get_provider
from src.models.company import Company
from src.models.document import DocumentRegistry
from src.retrieval.exceptions import RetrievalError
from src.retrieval.hybrid_scoring import compute_metadata_score
from src.retrieval.lexical_search import lexical_search
from src.retrieval.models import RetrievedEvidence
from src.retrieval.query_generator import generate_queries_for_component
from src.retrieval.reranker import BaseReranker, get_reranker
from src.retrieval.semantic_search import semantic_search
from src.retrieval.telemetry import telemetry
from src.retrieval.types import EvidenceCandidate, RetrievalConfig, RetrievalOutcome, RetrievalQuery
from src.retrieval.utils import new_request_id
from src.retrieval.validation import validate_metadata_filters

logger = get_logger(__name__)


class RetrievalService:
    def __init__(
        self,
        *,
        provider: BaseEmbeddingProvider | None = None,
        vector_store_backend: str | None = None,
        reranker: BaseReranker | None = None,
        config: RetrievalConfig | None = None,
    ):
        self._provider = provider or get_provider()
        self._vector_store_backend = vector_store_backend or settings.embeddings_vector_db_backend
        self._reranker = reranker or get_reranker(settings.retrieval_reranker)
        self._config = config or self._default_config()

    def _default_config(self) -> RetrievalConfig:
        return RetrievalConfig(
            candidate_k=settings.retrieval_candidate_k,
            final_evidence_k=settings.retrieval_final_evidence_k,
            similarity_threshold=settings.retrieval_similarity_threshold,
            semantic_weight=settings.retrieval_semantic_weight,
            lexical_weight=settings.retrieval_lexical_weight,
            metadata_weight=settings.retrieval_metadata_weight,
            max_queries_per_component=settings.retrieval_max_queries_per_component,
            diversity_max_per_document=settings.retrieval_diversity_max_per_document,
            diversity_max_per_section=settings.retrieval_diversity_max_per_section,
            threshold_relaxation_step=settings.retrieval_threshold_relaxation_step,
            threshold_relaxation_max_attempts=settings.retrieval_threshold_relaxation_max_attempts,
            framework_name=settings.retrieval_framework_name,
        )

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def retrieve_evidence(
        self,
        session: Session,
        *,
        company_id,
        component: str,
        document_id=None,
        extra_filters: dict | None = None,
        framework_name: str | None = None,
    ) -> RetrievalOutcome:
        telemetry.record_request()
        start = time.monotonic()
        request_id = new_request_id()
        extra_filters = extra_filters or {}
        framework_name = framework_name or self._config.framework_name

        try:
            validate_metadata_filters(extra_filters)

            company = session.query(Company).filter(Company.id == company_id).first()
            if company is None:
                raise RetrievalError(f"Company {company_id} not found.")

            queries = generate_queries_for_component(
                session, component, framework_name=framework_name, max_queries=self._config.max_queries_per_component
            )

            per_query_candidates = [
                self._retrieve_for_query(session, company, query, document_id=document_id) for query in queries
            ]

            threshold = self._config.similarity_threshold
            relaxations = 0
            filtered_lists = self._filter_by_threshold(per_query_candidates, threshold)
            candidate_count = sum(len(lst) for lst in filtered_lists)

            # Recall protection: relax the threshold rather than accept an
            # empty pool outright — "candidate expansion" is achieved here
            # implicitly too, since a generous candidate_k (default 200,
            # see RetrievalConfig) already over-fetches per query up
            # front, so relaxation surfaces candidates that were already
            # fetched but initially filtered out, without extra round trips.
            while candidate_count == 0 and relaxations < self._config.threshold_relaxation_max_attempts:
                threshold = max(0.0, threshold - self._config.threshold_relaxation_step)
                relaxations += 1
                filtered_lists = self._filter_by_threshold(per_query_candidates, threshold)
                candidate_count = sum(len(lst) for lst in filtered_lists)

            filtered_lists = [self._apply_extra_filters(lst, extra_filters) for lst in filtered_lists]

            final_evidence = self._reranker.rerank(filtered_lists, config=self._config)

            duration = time.monotonic() - start

            if not final_evidence:
                telemetry.record_success(
                    duration=duration, candidate_count=candidate_count, final_evidence_count=0,
                    average_similarity=0.0, provider=self._provider.provider_name,
                )
                return {
                    "status": "NO_RELEVANT_EVIDENCE",
                    "request_id": request_id,
                    "company_id": company_id,
                    "component": component,
                    "candidate_count": candidate_count,
                    "final_evidence_count": 0,
                    "threshold_relaxations": relaxations,
                    "average_semantic_score": 0.0,
                    "retrieval_duration": round(duration, 4),
                }

            rows = self._persist(session, request_id, company_id, component, final_evidence)
            session.commit()

            average_similarity = sum(c.semantic_score for c in final_evidence) / len(final_evidence)
            telemetry.record_success(
                duration=duration, candidate_count=candidate_count, final_evidence_count=len(rows),
                average_similarity=average_similarity, provider=self._provider.provider_name,
            )

            return {
                "status": "SUCCESS",
                "request_id": request_id,
                "company_id": company_id,
                "component": component,
                "candidate_count": candidate_count,
                "final_evidence_count": len(rows),
                "threshold_relaxations": relaxations,
                "average_semantic_score": round(average_similarity, 4),
                "retrieval_duration": round(duration, 4),
            }

        except RetrievalError as exc:
            # No session.rollback() here -- every RetrievalError in this
            # method is raised BEFORE _persist() ever runs (validation,
            # missing company, query generation), so nothing has been
            # staged on the session to roll back. Same precedent
            # `EmbeddingGenerationService` sets: it only rolls back in
            # `_persist_one`, the one place writes are actually staged.
            telemetry.record_failure()
            duration = time.monotonic() - start
            logger.warning("Retrieval failed for company=%s component=%s: %s", company_id, component, exc)
            return {
                "status": "FAILED",
                "request_id": request_id,
                "company_id": company_id,
                "component": component,
                "error": str(exc),
                "retrieval_duration": round(duration, 4),
            }

    # ------------------------------------------------------------------
    # Per-query retrieval
    # ------------------------------------------------------------------

    def _retrieve_for_query(
        self, session: Session, company: Company, query: RetrievalQuery, *, document_id=None
    ) -> list[EvidenceCandidate]:
        vector_filters = {"company": company.name}
        if document_id is not None:
            vector_filters["document_id"] = str(document_id)

        semantic_hits = semantic_search(
            session, self._provider, query.text,
            vector_store_backend=self._vector_store_backend, top_k=self._config.candidate_k, filters=vector_filters,
        )
        lexical_hits = lexical_search(
            session, query.text, top_k=self._config.candidate_k, company_id=company.id, document_id=document_id,
        )

        return self._build_candidates(session, company.id, query, semantic_hits, lexical_hits)

    def _build_candidates(
        self, session: Session, company_id, query: RetrievalQuery, semantic_hits: list[dict], lexical_hits: list[dict]
    ) -> list[EvidenceCandidate]:
        combined: dict[int, dict] = {}
        for hit in semantic_hits:
            combined.setdefault(hit["chunk_id"], {"document_id": hit["document_id"]})["semantic_score"] = hit["score"]
        for hit in lexical_hits:
            entry = combined.setdefault(hit["chunk_id"], {"document_id": hit["document_id"]})
            entry["lexical_score"] = hit["score"]

        if not combined:
            return []

        chunk_rows = (
            session.query(Chunk, DocumentRegistry.document_type, DocumentRegistry.document_year, DocumentRegistry.source_domain)
            .join(DocumentRegistry, DocumentRegistry.id == Chunk.document_id)
            .filter(Chunk.id.in_(combined.keys()))
            .all()
        )

        candidates: list[EvidenceCandidate] = []
        for chunk, document_type, document_year, source_domain in chunk_rows:
            info = combined[chunk.id]
            candidate = EvidenceCandidate(
                chunk_id=chunk.id,
                document_id=chunk.document_id,
                company_id=company_id,
                page_number=chunk.page_number,
                section_title=chunk.section_title,
                document_type=document_type,
                chunk_text=chunk.text,
                semantic_score=info.get("semantic_score", 0.0),
                lexical_score=info.get("lexical_score", 0.0),
                matched_queries=[query.field_name],
                source_metadata={
                    "chunk_index": chunk.chunk_index,
                    "document_year": document_year,
                    "source_domain": source_domain,
                },
            )
            candidate.metadata_score = compute_metadata_score(
                candidate, [query],
                match_score=settings.retrieval_metadata_match_score,
                no_match_score=settings.retrieval_metadata_no_match_score,
            )
            candidates.append(candidate)
        return candidates

    # ------------------------------------------------------------------
    # Threshold / filtering
    # ------------------------------------------------------------------

    def _filter_by_threshold(
        self, per_query_candidates: list[list[EvidenceCandidate]], threshold: float
    ) -> list[list[EvidenceCandidate]]:
        """
        Keep a candidate if its RAW (pre-normalization) semantic score
        clears `threshold`, OR it has any lexical match at all — a
        lexical-only hit (e.g. the chunk predates embedding generation,
        or the model's semantic score for it happens to be low) must not
        be silently discarded by a semantic-only threshold, per the
        brief's "Lexical retrieval must remain available."
        """
        return [
            [c for c in candidates if c.semantic_score >= threshold or c.lexical_score > 0]
            for candidates in per_query_candidates
        ]

    def _apply_extra_filters(self, candidates: list[EvidenceCandidate], extra_filters: dict) -> list[EvidenceCandidate]:
        if not extra_filters:
            return candidates

        filtered = []
        for candidate in candidates:
            if "document_type" in extra_filters and candidate.document_type != extra_filters["document_type"]:
                continue
            if "section" in extra_filters and (candidate.section_title or "") != extra_filters["section"]:
                continue
            if "page" in extra_filters and candidate.page_number != extra_filters["page"]:
                continue
            if "date" in extra_filters and candidate.source_metadata.get("document_year") != extra_filters["date"]:
                continue
            if "source" in extra_filters and candidate.source_metadata.get("source_domain") != extra_filters["source"]:
                continue
            if "document" in extra_filters and str(candidate.document_id) != str(extra_filters["document"]):
                continue
            # "company" / "component" are accepted but no-op here: both
            # are already enforced structurally via required parameters,
            # not via this dict — see module docstring.
            filtered.append(candidate)
        return filtered

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist(
        self, session: Session, request_id: str, company_id, component: str, final_evidence: list[EvidenceCandidate]
    ) -> list[RetrievedEvidence]:
        rows: list[RetrievedEvidence] = []
        for rank, candidate in enumerate(final_evidence, start=1):
            row = RetrievedEvidence(
                retrieval_id=f"{request_id}:{rank}",
                request_id=request_id,
                chunk_id=candidate.chunk_id,
                document_id=candidate.document_id,
                company_id=company_id,
                component=component,
                rank=rank,
                semantic_score=candidate.semantic_score,
                lexical_score=candidate.lexical_score,
                metadata_score=candidate.metadata_score,
                final_score=candidate.final_score,
                page_number=candidate.page_number,
                section_title=candidate.section_title,
                chunk_text=candidate.chunk_text,
                source_metadata=candidate.source_metadata,
            )
            session.add(row)
            rows.append(row)
        session.flush()
        return rows
