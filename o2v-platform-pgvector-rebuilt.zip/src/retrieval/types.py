"""Shared type definitions and value objects for Sprint 7 retrieval."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypedDict
from uuid import UUID


@dataclass
class RetrievalQuery:
    """
    One multi-query formulation for an O2V component, derived from a
    single Framework field's `description` (see `query_generator.py`) —
    NOT a hardcoded, invented question. `field_name` is kept alongside
    `text` purely for traceability (so a retrieved chunk's telemetry can
    say *which* Phase 1 field's formulation surfaced it).
    """

    text: str
    field_name: str
    component: str
    document_sources: list[str] | None = None


@dataclass
class EvidenceCandidate:
    """
    One candidate chunk moving through the retrieval pipeline —
    semantic/lexical/metadata scores accumulate onto this object as it
    passes through `semantic_search.py` -> `lexical_search.py` ->
    `hybrid_scoring.py` -> `deduplication.py` -> `diversity.py` ->
    `reranker.py`, at which point it becomes a persisted
    `RetrievedEvidence` row (see `models.py`).
    """

    chunk_id: int
    document_id: UUID
    company_id: UUID
    page_number: int | None
    section_title: str | None
    document_type: str | None
    chunk_text: str

    semantic_score: float = 0.0
    lexical_score: float = 0.0
    metadata_score: float = 0.0
    final_score: float = 0.0

    matched_queries: list[str] = field(default_factory=list)
    source_metadata: dict = field(default_factory=dict)


@dataclass
class RetrievalConfig:
    """
    All Sprint 7 tunables in one place — mirrors `ChunkerConfig` /
    `EmbeddingGenerationService`'s config-object pattern from Sprints 5/6.
    Every field here is deliberately NOT hardcoded elsewhere in this
    package; `retrieval_service.py` builds exactly one of these from
    `settings.py` and threads it through the whole pipeline.
    """

    candidate_k: int = 200
    final_evidence_k: int = 100
    similarity_threshold: float = 0.15
    semantic_weight: float = 0.6
    lexical_weight: float = 0.25
    metadata_weight: float = 0.15
    max_queries_per_component: int | None = None
    diversity_max_per_document: int = 15
    diversity_max_per_section: int = 5
    threshold_relaxation_step: float = 0.05
    threshold_relaxation_max_attempts: int = 3
    framework_name: str = "O2V"

    def __post_init__(self) -> None:
        from src.retrieval.exceptions import RetrievalConfigurationError

        weight_sum = self.semantic_weight + self.lexical_weight + self.metadata_weight
        if not (0.99 <= weight_sum <= 1.01):
            raise RetrievalConfigurationError(
                f"semantic_weight + lexical_weight + metadata_weight must sum to 1.0 "
                f"(got {weight_sum:.3f}: {self.semantic_weight} + {self.lexical_weight} + {self.metadata_weight})."
            )
        if self.candidate_k <= 0:
            raise RetrievalConfigurationError(f"candidate_k must be positive, got {self.candidate_k}.")
        if self.final_evidence_k <= 0:
            raise RetrievalConfigurationError(f"final_evidence_k must be positive, got {self.final_evidence_k}.")
        if not (0.0 <= self.similarity_threshold <= 1.0):
            raise RetrievalConfigurationError(f"similarity_threshold must be in [0, 1], got {self.similarity_threshold}.")


class RetrievalOutcome(TypedDict, total=False):
    """Standardized result dictionary returned after one retrieve_evidence() call."""

    status: str  # SUCCESS, NO_RELEVANT_EVIDENCE, FAILED
    request_id: str
    company_id: UUID
    component: str
    candidate_count: int
    final_evidence_count: int
    threshold_relaxations: int
    average_semantic_score: float
    retrieval_duration: float
    error: str


class RetrievalSummary(TypedDict):
    """Aggregated telemetry summary for retrieval activity — see `telemetry.py`."""

    retrieval_requests: int
    successful_retrievals: int
    failed_retrievals: int
    empty_result_count: int
    average_latency: float
    average_candidate_count: float
    average_final_evidence_count: float
    average_similarity: float
    empty_result_rate: float
    active_provider: str
