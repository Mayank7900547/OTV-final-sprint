"""
Sprint 7 domain exceptions.

Design decision: same flat hierarchy under one base as every other
sprint's `exceptions.py` — every failure mode is a direct child of
`RetrievalError`. `ProviderUnavailableError` is reused from
`src.embeddings.exceptions` rather than redefined here (per the brief's
"reuse existing project exceptions where appropriate. Do not create
duplicate exception hierarchies unnecessarily.") — a retrieval failure
caused by an embedding provider being unreachable IS an embeddings
provider failure, not a new kind of error; retrieval just propagates it.
"""

from src.core.exceptions import O2VError

# Re-exported so callers can `except ProviderUnavailableError` from this
# module without needing to know it actually lives in `src.embeddings` —
# see module docstring for why it isn't redefined.
from src.embeddings.exceptions import ProviderUnavailableError  # noqa: F401


class RetrievalError(O2VError):
    """Base exception for all Sprint 7 retrieval failures."""


class QueryGenerationError(RetrievalError):
    """Raised when multi-query formulations can't be derived — e.g. the requested O2V component has no Framework rows."""


class VectorSearchError(RetrievalError):
    """Raised when semantic/vector retrieval fails for a reason other than the provider being unavailable."""


class LexicalSearchError(RetrievalError):
    """Raised when lexical (full-text) retrieval fails."""


class RankingError(RetrievalError):
    """Raised when scoring or reranking candidates fails."""


class MetadataFilterError(RetrievalError):
    """Raised when a requested metadata filter is invalid (e.g. an unknown filter key)."""


class NoRelevantEvidenceError(RetrievalError):
    """
    Raised only when NO candidates survive retrieval even after full
    threshold relaxation and candidate expansion — i.e. a genuine "there
    is nothing here" result, not merely "results are below the default
    threshold" (which triggers relaxation instead, per the brief's
    "No-Result Behaviour" section).
    """


class RetrievalConfigurationError(RetrievalError):
    """Raised when retrieval is configured with an invalid combination of settings (weights, thresholds, k values)."""
