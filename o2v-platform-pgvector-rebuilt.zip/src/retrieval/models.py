"""
Database model for Sprint 7 retrieval output.

Design decision: `RetrievedEvidence` is a SNAPSHOT, not a live view —
`chunk_text` and `source_metadata` are denormalized copies taken at
retrieval time, not re-derived from `Chunk`/`Embedding` on read. This
matters for traceability: if a chunk is later re-chunked or re-embedded
(Sprint 5/6 versioning), a `RetrievedEvidence` row from an earlier
retrieval run must still show Sprint 8 exactly what evidence it was
actually shown, not whatever the chunk looks like now. `chunk_id` is
still kept as a real FK for the cases where following back to the live
`Chunk` row is exactly what's wanted (e.g. re-embedding-aware re-retrieval).

Design decision: `request_id` (not `id`) is what groups every
`RetrievedEvidence` row produced by one `RetrievalService.retrieve_evidence()`
call — a single request typically produces up to `final_evidence_k` rows.
This is the same "external, deterministic-ish, human-inspectable
identifier alongside the autoincrement PK" pattern `Chunk.chunk_id` and
`Embedding.embedding_id` already established in Sprints 5/6, generalized
to a whole retrieval RUN rather than a single row.
"""

import uuid

from sqlalchemy import JSON, Column, DateTime, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

from src.database.base import Base


class RetrievedEvidence(Base):
    """One ranked evidence item in a retrieval run's final evidence pool."""

    __tablename__ = "retrieved_evidence"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Deterministic, human-readable id for THIS evidence item specifically
    # (distinct from `request_id`, which groups an entire run) -- same
    # "external id alongside the autoincrement PK" pattern as
    # `Chunk.chunk_id` / `Embedding.embedding_id`. Built as
    # f"{request_id}:{rank}" once rank is assigned (see retrieval_service.py).
    retrieval_id = Column(String(80), nullable=False, index=True)

    # Groups every row produced by one RetrievalService.retrieve_evidence()
    # call. Not a FK to another table -- see module docstring for why no
    # separate "RetrievalRequest" row is persisted (in-process telemetry.py
    # covers request-level stats without adding another history table).
    request_id = Column(String(64), nullable=False, index=True)

    chunk_id = Column(Integer, ForeignKey("chunks.id", ondelete="SET NULL"), nullable=True, index=True)
    document_id = Column(PG_UUID(as_uuid=True), ForeignKey("document_registry.id", ondelete="CASCADE"), nullable=False, index=True)
    company_id = Column(PG_UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False, index=True)

    component = Column(String(255), nullable=False, index=True)
    rank = Column(Integer, nullable=False)

    semantic_score = Column(Float, nullable=False, default=0.0)
    lexical_score = Column(Float, nullable=False, default=0.0)
    metadata_score = Column(Float, nullable=False, default=0.0)
    final_score = Column(Float, nullable=False, default=0.0)

    page_number = Column(Integer, nullable=True)
    section_title = Column(String(1000), nullable=True)

    # Snapshotted at retrieval time -- see module docstring.
    chunk_text = Column(Text, nullable=False)
    source_metadata = Column(JSON, nullable=True)

    retrieval_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    chunk = relationship("Chunk", backref="retrieved_evidence")

    def __repr__(self) -> str:  # pragma: no cover - debug convenience only
        return (
            f"<RetrievedEvidence id={self.id} request_id={self.request_id!r} "
            f"component={self.component!r} rank={self.rank} chunk_id={self.chunk_id}>"
        )
