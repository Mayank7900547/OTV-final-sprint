"""
Lexical/keyword retrieval.

Design decision: uses Postgres's BUILT-IN full-text search
(`to_tsvector`/`plainto_tsquery`/`ts_rank`) rather than a dedicated search
engine (Elasticsearch, Whoosh, a new Python full-text dependency, etc.).
This project's Postgres database is already the system of record for
every prior sprint's output, `to_tsvector`/`ts_rank` require zero new
infrastructure or dependencies (they ship with Postgres itself, unlike
`pgvector`), and the brief explicitly favors solutions requiring no new
paid/heavy infrastructure. If lexical search quality needs to grow beyond
what Postgres FTS offers (e.g. BM25, synonym expansion), swapping this
module's implementation is the entire blast radius -- callers only see
`lexical_search(query_text, ...) -> list[dict]`.
"""

from __future__ import annotations

from sqlalchemy import func
from sqlalchemy.orm import Session

from src.chunking.models import Chunk
from src.retrieval.exceptions import LexicalSearchError


def lexical_search(
    session: Session,
    query_text: str,
    *,
    top_k: int,
    company_id=None,
    document_id=None,
) -> list[dict]:
    """
    Full-text search `Chunk.text` for `query_text`, ranked by Postgres's
    `ts_rank`. Returns `{chunk_id, document_id, score}` dicts, sorted by
    score descending -- `score` is `ts_rank`'s raw value (unbounded, not
    a [0, 1] similarity), which is why `hybrid_scoring.py` normalizes it
    before combining with the semantic/metadata scores.
    """
    try:
        tsvector = func.to_tsvector("english", Chunk.text)
        tsquery = func.plainto_tsquery("english", query_text)
        rank = func.ts_rank(tsvector, tsquery).label("score")

        query = session.query(Chunk.id, Chunk.document_id, rank).filter(tsvector.op("@@")(tsquery))
        if company_id is not None:
            from src.models.document import DocumentRegistry

            query = query.join(DocumentRegistry, DocumentRegistry.id == Chunk.document_id).filter(
                DocumentRegistry.company_id == company_id
            )
        if document_id is not None:
            query = query.filter(Chunk.document_id == document_id)

        rows = query.order_by(rank.desc()).limit(top_k).all()
    except Exception as exc:  # noqa: BLE001 - any DB-layer failure here is a lexical search failure, not a caller bug
        raise LexicalSearchError(f"Lexical search failed for query {query_text!r}: {exc}") from exc

    return [{"chunk_id": row[0], "document_id": row[1], "score": float(row[2])} for row in rows]
