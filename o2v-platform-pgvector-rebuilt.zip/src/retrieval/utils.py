"""Small shared helpers for the retrieval pipeline."""

from __future__ import annotations

import uuid


def new_request_id() -> str:
    """A short, unique id grouping every `RetrievedEvidence` row from one retrieval request -- see `models.py`."""
    return uuid.uuid4().hex[:16]
