"""
Validation for Sprint 7 retrieval inputs.

Design decision: `validate_metadata_filters` allow-lists filter KEYS
(company/document/document_type/date/section/page/source/component --
exactly the set the brief's "Metadata Filtering" section names) and
rejects anything else outright, per the brief's "Filtering must not
accidentally eliminate semantically relevant evidence when a filter was
not explicitly requested" -- an unrecognized filter key is much more
likely to be a caller typo than an intentional new filter dimension, and
silently ignoring it (rather than raising) risks exactly the "filtered
out relevant evidence because of an accidental default" failure mode the
brief warns against.
"""

from __future__ import annotations

from src.retrieval.exceptions import MetadataFilterError

_ALLOWED_FILTER_KEYS = {
    "company",
    "document",
    "document_type",
    "date",
    "section",
    "page",
    "source",
    "component",
}


def validate_metadata_filters(filters: dict | None) -> None:
    if not filters:
        return
    unknown = set(filters) - _ALLOWED_FILTER_KEYS
    if unknown:
        raise MetadataFilterError(
            f"Unknown metadata filter key(s): {sorted(unknown)}. Allowed: {sorted(_ALLOWED_FILTER_KEYS)}."
        )


def validate_component_name(component: str, available: list[str]) -> None:
    from src.retrieval.exceptions import QueryGenerationError

    if component not in available:
        raise QueryGenerationError(
            f"Unknown O2V component {component!r}. Available components: {available}."
        )
