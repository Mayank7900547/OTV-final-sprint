"""
Semantic/vector retrieval.

Design decision: this module is the ONLY place Sprint 7 imports
`src.embeddings.embedding_factory` / `src.embeddings.vector_store` --
consistent with the "provider independence" requirement, it never
imports a concrete provider or vector store class, only the factory
functions (`get_provider`, `get_vector_store`), so swapping the active
embedding provider or vector backend (a `settings.py` config change, per
Sprint 6) changes nothing here or anywhere else in `src.retrieval`.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from src.embeddings.base_embedding_provider import BaseEmbeddingProvider
from src.embeddings.exceptions import EmbeddingError
from src.embeddings.vector_store import get_vector_store
from src.retrieval.exceptions import VectorSearchError


def semantic_search(
    session: Session,
    provider: BaseEmbeddingProvider,
    query_text: str,
    *,
    vector_store_backend: str,
    top_k: int,
    filters: dict | None = None,
) -> list[dict]:
    """
    Embed `query_text` with `provider`, then run
    `BaseVectorStore.similarity_search` against the configured backend.

    Returns the raw list of dicts `similarity_search` produces
    (`{embedding_id, chunk_id, document_id, score, metadata}`) -- turning
    these into `EvidenceCandidate`s is `retrieval_service.py`'s job, not
    this module's, so this function stays a thin, independently-testable
    wrapper around "one query in, ranked chunk ids out".
    """
    try:
        query_vector = provider.embed_single(query_text)
    except EmbeddingError as exc:
        # Deliberately not caught more narrowly than EmbeddingError --
        # ProviderUnavailableError (transient network/auth failure) and
        # InvalidProviderResponseError (malformed response) both mean the
        # same thing to a retrieval caller: this query's semantic leg
        # didn't produce a vector. Re-raised as VectorSearchError so
        # `retrieval_service.py` has one exception type to handle for
        # "semantic retrieval didn't work", regardless of which
        # embeddings-layer exception caused it.
        raise VectorSearchError(f"Could not embed query {query_text!r}: {exc}") from exc

    store = get_vector_store(vector_store_backend, session=session)
    try:
        return store.similarity_search(query_vector, top_k=top_k, filters=filters)
    except NotImplementedError as exc:
        raise VectorSearchError(
            f"Vector store backend {vector_store_backend!r} does not support similarity_search: {exc}"
        ) from exc
