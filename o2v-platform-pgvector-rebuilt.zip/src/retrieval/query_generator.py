"""
Multi-query formulation generation.

Design decision: query text is derived DIRECTLY from `Framework.description`
rows imported from `data/frameworks/o2v.yaml` (Sprint 1's Framework
Registry) -- never a hardcoded English question invented for this sprint.
The Sprint 7 brief is explicit that the retrieval query set "MUST be
derived from the project's authoritative Phase 1 methodology rather than
blindly copying [example] questions", and the Phase 1 methodology's
authoritative form, in this repository, IS the imported `Framework` rows
(framework_name/component_name/field_name/description) -- that's what
`framework import` puts in the database and what every other part of the
platform already treats as the source of truth for what each O2V
component means.

Why field DESCRIPTIONS make good semantic queries (not just labels): each
one is already phrased as a natural-language definition of what kind of
statement counts as evidence for that field -- e.g. Purpose's "Purpose
Statement" field description is "An explicit 'why we exist' statement,
distinct from mission/vision if present." Embedding that description and
searching for chunks semantically close to it is exactly the mechanism
that lets a chunk like "Our ambition is to remove barriers preventing
entrepreneurs from accessing capital, technology and markets" surface for
Purpose without ever containing the word "purpose" -- both sentences are
about an organization's fundamental motivating reason for existing, which
is what the embedding space actually captures.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from src.models.framework import Framework
from src.retrieval.exceptions import QueryGenerationError
from src.retrieval.types import RetrievalQuery


def generate_queries_for_component(
    session: Session,
    component_name: str,
    *,
    framework_name: str = "O2V",
    max_queries: int | None = None,
) -> list[RetrievalQuery]:
    """
    Build one `RetrievalQuery` per `Framework` field row under
    `component_name`, in the framework's stored field order. Raises
    `QueryGenerationError` if the component doesn't exist in the
    specified framework at all -- a typo'd component name should fail
    loudly here, not silently retrieve nothing three pipeline stages later.
    """
    rows = (
        session.query(Framework)
        .filter(Framework.framework_name == framework_name, Framework.component_name == component_name)
        .order_by(Framework.field_name.asc())
        .all()
    )
    if not rows:
        raise QueryGenerationError(
            f"No Framework fields found for component={component_name!r} under framework={framework_name!r}. "
            f"Has '{framework_name}' been imported (see `o2v framework import`), and is the component name correct?"
        )

    queries = [
        RetrievalQuery(
            text=row.description or row.field_name,
            field_name=row.field_name,
            component=component_name,
            document_sources=row.document_sources,
        )
        for row in rows
    ]

    if max_queries is not None:
        queries = queries[:max_queries]

    return queries


def available_components(session: Session, *, framework_name: str = "O2V") -> list[str]:
    """Every distinct component name defined under a framework -- used by the CLI to validate/list valid `--component` values."""
    rows = (
        session.query(Framework.component_name)
        .filter(Framework.framework_name == framework_name)
        .distinct()
        .order_by(Framework.component_name.asc())
        .all()
    )
    return [row[0] for row in rows]
