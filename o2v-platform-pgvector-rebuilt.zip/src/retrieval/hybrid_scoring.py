"""
Hybrid scoring: normalizes semantic/lexical scores onto a comparable
[0, 1] range and combines them with the metadata-alignment score into
each candidate's `final_score`.

Design decision: normalization is done PER RETRIEVAL RUN (min-max over
whatever candidates this specific request produced), not against a fixed
global scale. Cosine similarity and `ts_rank` live on entirely different
numeric scales (roughly [-1, 1] vs. an unbounded small positive float),
and neither scale is stable across different embedding models or query
lengths -- a fixed global normalization constant would need re-tuning
every time the embedding provider changes, which directly conflicts with
the provider-independence requirement. Min-max over the current
candidate set has no such dependency and degrades gracefully (a
single-candidate or zero-variance set normalizes to a constant rather
than dividing by zero).

Design decision: `final_score = semantic_weight*semantic + lexical_weight*lexical
+ metadata_weight*metadata`, weights loaded from `RetrievalConfig`
(validated in `types.py` to sum to 1.0) rather than hardcoded -- per the
brief: "Weights MUST be configurable. Do not hard-code arbitrary weights
without documenting the rationale." The rationale for the DEFAULT weights
(0.6 / 0.25 / 0.15, see `types.py`/`settings.py`) is: semantic similarity
is the primary retrieval signal (per the brief's "Semantic retrieval is
primary"), lexical match is a meaningful secondary signal (exact
terminology is still valuable evidence when present), and metadata
alignment is the weakest signal on its own (a chunk from the "right"
document type is a mild prior, not proof of relevance) -- so it gets the
smallest weight.
"""

from __future__ import annotations

from src.retrieval.types import EvidenceCandidate, RetrievalConfig, RetrievalQuery


def normalize_scores(candidates: list[EvidenceCandidate], *, attr: str) -> None:
    """Min-max normalize `candidates[i].<attr>` in place to [0, 1]. No-op for an empty or zero-variance set."""
    if not candidates:
        return
    values = [getattr(c, attr) for c in candidates]
    lo, hi = min(values), max(values)
    if hi == lo:
        # Every candidate scored identically (including the common
        # "nobody has this score at all" case, all zeros) -- leave as-is
        # rather than manufacturing a fake 0.5 for everyone.
        return
    for candidate in candidates:
        raw = getattr(candidate, attr)
        setattr(candidate, attr, (raw - lo) / (hi - lo))


def compute_metadata_score(
    candidate: EvidenceCandidate,
    matched_queries: list[RetrievalQuery],
    *,
    match_score: float = 1.0,
    no_match_score: float = 0.4,
) -> float:
    """
    Score how well `candidate.document_type` aligns with the Phase 1
    `document_sources` expected for the query field(s) that matched it --
    e.g. a Purpose-component chunk from an "Annual Report" scores higher
    than one from an unrelated, unlisted document type. This is a real
    signal (Framework rows already carry `document_sources`, imported
    from `o2v.yaml`), not a placeholder -- see `query_generator.py`.

    `no_match_score` is deliberately NOT 0.0: `document_sources` is a
    curated *expectation*, not an exhaustive allow-list -- a chunk from
    an unlisted document type is still legitimate evidence (per the
    brief's "Filtering must not accidentally eliminate semantically
    relevant evidence when a filter was not explicitly requested"), it
    just doesn't get the same metadata-alignment credit.
    """
    if not candidate.document_type or not matched_queries:
        return no_match_score
    for query in matched_queries:
        sources = getattr(query, "document_sources", None)
        if sources and candidate.document_type in sources:
            return match_score
    return no_match_score


def compute_final_scores(candidates: list[EvidenceCandidate], *, config: RetrievalConfig) -> None:
    """
    Normalize semantic/lexical scores, then set `final_score` on every
    candidate per `config`'s weights. Mutates `candidates` in place
    (matches `normalize_scores`'s in-place convention) and returns
    nothing, since every caller already holds the list.
    """
    normalize_scores(candidates, attr="semantic_score")
    normalize_scores(candidates, attr="lexical_score")

    for candidate in candidates:
        candidate.final_score = (
            config.semantic_weight * candidate.semantic_score
            + config.lexical_weight * candidate.lexical_score
            + config.metadata_weight * candidate.metadata_score
        )
