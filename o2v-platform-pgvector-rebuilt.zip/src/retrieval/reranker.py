"""
Reranking abstraction.

Design decision: mirrors `src.embeddings.embedding_factory`'s
register-a-class-under-a-name factory pattern exactly -- `BaseReranker`
is the interface, `DeterministicReranker` (hybrid score + diversity) is
the one real, working implementation, and `CrossEncoderReranker` /
`LocalLLMReranker` / `CommercialLLMReranker` are registered architecture
placeholders (construct fine, `rerank()` raises `ProviderUnavailableError`
naming the missing integration) -- same "future providers require only:
1. class, 2. register, 3. no architecture changes" extensibility bar
Sprint 6 set, applied here to rerankers instead of embedding providers.

Design decision: `CommercialLLMReranker` existing as a PLACEHOLDER (not
implemented, not called) is what satisfies the brief's "Sprint 7 is NOT
responsible for final semantic extraction... the retrieval engine must
function without a commercial LLM API" -- the extension point for an
LLM-based reranker exists for a future sprint to fill in, but
`DeterministicReranker` (this sprint's active default, see `settings.py`)
never calls one.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from src.embeddings.exceptions import ProviderUnavailableError
from src.retrieval.deduplication import drop_near_duplicate_text, merge_by_chunk_id
from src.retrieval.diversity import select_diverse_evidence
from src.retrieval.hybrid_scoring import compute_final_scores
from src.retrieval.types import EvidenceCandidate, RetrievalConfig

_RERANKER_REGISTRY: dict[str, type["BaseReranker"]] = {}


def register_reranker(name: str):
    """Class decorator: registers a `BaseReranker` subclass under `name`."""

    def decorator(cls: type["BaseReranker"]) -> type["BaseReranker"]:
        _RERANKER_REGISTRY[name] = cls
        return cls

    return decorator


def available_rerankers() -> list[str]:
    return sorted(_RERANKER_REGISTRY)


def get_reranker(name: str) -> "BaseReranker":
    from src.retrieval.exceptions import RankingError

    try:
        return _RERANKER_REGISTRY[name.lower()]()
    except KeyError as exc:
        raise RankingError(f"Unknown reranker {name!r}. Available: {available_rerankers()}") from exc


class BaseReranker(ABC):
    """Common interface every reranking strategy must implement."""

    reranker_name: str = "base"

    @abstractmethod
    def rerank(self, candidate_lists: list[list[EvidenceCandidate]], *, config: RetrievalConfig) -> list[EvidenceCandidate]:
        """
        Take the per-query candidate lists produced by semantic/lexical
        search, and return the final, ordered, diversity-controlled
        evidence pool (already truncated to `config.final_evidence_k`).
        """


@register_reranker("deterministic")
class DeterministicReranker(BaseReranker):
    """
    Default reranker: merge -> dedup -> score -> sort -> diversify.
    Uses exactly the signals the brief lists as acceptable for an initial
    implementation ("semantic similarity, lexical relevance, metadata
    relevance, section relevance, document relevance, diversity") and
    nothing else -- no external calls, no LLM, fully deterministic given
    the same candidate inputs and config.
    """

    reranker_name = "deterministic"

    def rerank(self, candidate_lists: list[list[EvidenceCandidate]], *, config: RetrievalConfig) -> list[EvidenceCandidate]:
        merged = merge_by_chunk_id(candidate_lists)
        compute_final_scores(merged, config=config)
        merged.sort(key=lambda c: c.final_score, reverse=True)
        deduplicated = drop_near_duplicate_text(merged)
        return select_diverse_evidence(deduplicated, config=config)


class _PlaceholderReranker(BaseReranker):
    """Shared placeholder behavior for rerankers not yet integrated -- mirrors `embedding_factory._PlaceholderEmbeddingProvider`."""

    integration_hint: str = "not yet implemented"

    def rerank(self, candidate_lists, *, config):
        raise ProviderUnavailableError(
            f"{self.reranker_name} is registered as an architecture placeholder — {self.integration_hint}."
        )


@register_reranker("cross_encoder")
class CrossEncoderReranker(_PlaceholderReranker):
    reranker_name = "cross_encoder"
    integration_hint = "add a local cross-encoder model (e.g. sentence-transformers CrossEncoder) to enable it"


@register_reranker("local_llm")
class LocalLLMReranker(_PlaceholderReranker):
    reranker_name = "local_llm"
    integration_hint = "wire up a call to a local LLM (e.g. via Ollama) to score candidate relevance to enable it"


@register_reranker("commercial_llm")
class CommercialLLMReranker(_PlaceholderReranker):
    reranker_name = "commercial_llm"
    integration_hint = "wire up a commercial LLM provider (e.g. Claude, OpenAI) to enable it — opt-in only, never required"
