"""
Sprint 7 — Semantic Evidence Retrieval Engine.

Consumes Sprint 5/6 output (`Chunk` rows and their `Embedding` vectors)
and produces a ranked, deduplicated, diversity-controlled evidence pool
for each O2V component (Purpose, Behaviour, Value Agenda), ready for
Sprint 8's downstream semantic extraction to consume.

Integration contract (see module docstrings in `retrieval_service.py` for
detail):

Sprint 6 -> Sprint 7 (consumed):
    chunk identifiers, chunk text, embeddings, document metadata,
    company metadata, source/page metadata — all already present on
    `src.chunking.models.Chunk` and `src.embeddings.models.Embedding`.

Sprint 7 -> Sprint 8 (produced):
    ranked `RetrievedEvidence` rows — see `models.py` — carrying scores,
    full source traceability, O2V component context, and retrieval
    metadata.

This package deliberately does NOT call a commercial LLM API anywhere —
see `reranker.py`'s module docstring for how the reranking abstraction
stays provider-independent while still leaving room for a future
LLM-based reranker to be added as an additive, opt-in backend.
"""
