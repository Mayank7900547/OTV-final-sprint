"""
Diversity-aware selection.

Design decision: greedy selection with per-document and per-section caps,
not embedding-space clustering (k-means/HDBSCAN over vectors). The brief
lists "documents / sections / pages / semantic clusters" as places to
diversify -- document and section are already first-class, reliable
fields on every candidate (`document_id`, `section_title`) with zero
additional computation, and capping how many chunks can come from the
same document/section is a direct, effective proxy for "don't return 50
near-identical chunks from the same paragraph": chunks from the same
section are exactly the ones most likely to be near-duplicates or
trivial restatements of each other. True embedding-space clustering is
listed in the brief as a WHERE-APPROPRIATE mechanism, not a requirement,
and would add real complexity (choosing a clustering algorithm, a
distance threshold, handling clusters of size 1) for marginal gain over
the document/section caps at this project's stated chunk-overlap-driven
redundancy pattern (see `deduplication.py`'s module docstring).
"""

from __future__ import annotations

from collections import defaultdict

from src.retrieval.types import EvidenceCandidate, RetrievalConfig


def select_diverse_evidence(
    candidates: list[EvidenceCandidate], *, config: RetrievalConfig
) -> list[EvidenceCandidate]:
    """
    Walk `candidates` in the order given (callers pass them already
    sorted by `final_score` descending), greedily keeping each one unless
    doing so would exceed `config.diversity_max_per_document` for its
    document or `config.diversity_max_per_section` for its section,
    until `config.final_evidence_k` items are kept or candidates run out.

    Deliberately does not "backfill" past the caps once a natural stop
    point is reached even if fewer than `final_evidence_k` items were
    selected -- respecting the diversity ceiling takes priority over
    hitting the target count exactly; a smaller, more diverse pool is the
    correct outcome for a document that's genuinely concentrated in one
    section.
    """
    per_document_count: dict = defaultdict(int)
    per_section_count: dict = defaultdict(int)
    selected: list[EvidenceCandidate] = []

    for candidate in candidates:
        if len(selected) >= config.final_evidence_k:
            break

        doc_key = candidate.document_id
        section_key = (candidate.document_id, candidate.section_title)

        if per_document_count[doc_key] >= config.diversity_max_per_document:
            continue
        if candidate.section_title is not None and per_section_count[section_key] >= config.diversity_max_per_section:
            continue

        selected.append(candidate)
        per_document_count[doc_key] += 1
        per_section_count[section_key] += 1

    return selected
