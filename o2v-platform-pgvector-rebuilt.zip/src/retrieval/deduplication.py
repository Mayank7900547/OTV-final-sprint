"""
Candidate deduplication.

Design decision: two dedup passes, not one. (1) Exact `chunk_id` merge --
the SAME chunk surfaced by two different query formulations is not two
pieces of evidence, it's one chunk with two matching signals; merging
keeps the best score of each type and records every query that matched
it (`matched_queries`), which is itself a useful downstream signal (a
chunk matching 3 different Purpose-field queries is stronger evidence
than one matching only 1). (2) Near-duplicate text -- Sprint 5's
`RecursiveChunker` overlap feature (see `src/chunking/recursive_chunker.py`)
deliberately makes adjacent chunks share a trailing/leading span of text;
without a near-duplicate pass, two overlap-adjacent chunks both matching
a query would burn two evidence-pool slots on substantially the same
sentence. Near-duplicate detection here is deliberately cheap
(normalized-text equality after whitespace/case folding), not a
similarity threshold -- catching genuinely near-identical chunks is the
goal, not general semantic redundancy, which `diversity.py` handles
separately at the document/section level.
"""

from __future__ import annotations

from src.retrieval.types import EvidenceCandidate


def merge_by_chunk_id(candidate_lists: list[list[EvidenceCandidate]]) -> list[EvidenceCandidate]:
    """
    Merge candidates appearing across multiple query result sets, keyed
    by `chunk_id`. When the same chunk appears more than once, keeps the
    MAX of each score type seen (a chunk should get credit for its best
    match, not be penalized by a weaker query also finding it) and unions
    `matched_queries`.
    """
    merged: dict[int, EvidenceCandidate] = {}
    for candidates in candidate_lists:
        for candidate in candidates:
            existing = merged.get(candidate.chunk_id)
            if existing is None:
                merged[candidate.chunk_id] = candidate
                continue
            existing.semantic_score = max(existing.semantic_score, candidate.semantic_score)
            existing.lexical_score = max(existing.lexical_score, candidate.lexical_score)
            existing.metadata_score = max(existing.metadata_score, candidate.metadata_score)
            existing.matched_queries.extend(
                q for q in candidate.matched_queries if q not in existing.matched_queries
            )
    return list(merged.values())


def _normalize_text(text: str) -> str:
    return " ".join(text.lower().split())


def drop_near_duplicate_text(candidates: list[EvidenceCandidate]) -> list[EvidenceCandidate]:
    """
    Drop candidates whose normalized text exactly matches an
    already-kept candidate's, keeping the FIRST occurrence encountered.
    Callers should sort `candidates` by score descending before calling
    this so "first occurrence" means "highest-scoring occurrence".
    """
    seen_text: set[str] = set()
    kept: list[EvidenceCandidate] = []
    for candidate in candidates:
        key = _normalize_text(candidate.chunk_text)
        if key in seen_text:
            continue
        seen_text.add(key)
        kept.append(candidate)
    return kept
