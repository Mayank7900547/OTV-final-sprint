"""
Centralized path resolution.

Design decision: every other module imports paths from HERE rather than
computing `Path(__file__).parent...` locally. Path arithmetic scattered
across files is a classic source of bugs when the project is later
containerized (Docker working directory differs from local dev) or
when tests run from a different cwd than the CLI does. One source of
truth means Docker, tests, and local dev all agree on where "data/" is,
because they all resolve it the same way.
"""

from pathlib import Path

# Repo root = three levels up from this file (src/utils/paths.py -> repo root).
PROJECT_ROOT = Path(__file__).resolve().parents[2]

DATA_DIR = PROJECT_ROOT / "data"
COMPANIES_DATA_DIR = DATA_DIR / "companies"
FRAMEWORKS_DATA_DIR = DATA_DIR / "frameworks"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
STAGING_DIR = DATA_DIR / "staging"
ARCHIVE_DIR = DATA_DIR / "archive"

LOGS_DIR = PROJECT_ROOT / "logs"
DOCS_DIR = PROJECT_ROOT / "docs"


def ensure_data_dirs() -> None:
    """
    Create all expected data/log directories if they don't exist.

    Called once from `o2v init` (see cli/main.py) rather than at import time —
    importing this module should never have side effects on the filesystem;
    only an explicit command should.
    """
    for directory in (
        COMPANIES_DATA_DIR,
        FRAMEWORKS_DATA_DIR,
        RAW_DATA_DIR,
        PROCESSED_DATA_DIR,
        STAGING_DIR,
        ARCHIVE_DIR,
        LOGS_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)
